; =============================================================================
; MattiaOS Stage2 Bootloader — v3.5
; Ordine OBBLIGATORIO: istruzione JMP come primissimo byte, poi dati e func.
; Bug fix v3.5:
;   - Codice eseguibile PER PRIMO (la CPU esegue da 0x8000)
;   - Offset Limine corretti: response* è a +0x28 dentro ogni request struct
;     (struct layout: id[4]=32B, revision=8B, response*=8B → response@+0x28)
;   - E820 buffer (0x6000) NON viene azzerato dalla clear dei response (0x5000..0x5FFF)
;
; Memoria usata:
;   0x5000..0x5FFF  Limine responses (HHDM, memmap, kaddr)
;   0x5100..0x51FF  Array puntatori Limine memmap entries
;   0x5200..0x57FF  Limine memmap entry structs convertiti da E820
;   0x5FFC          E820 count (scritto da stage1) — NON sovrascrivere!
;   0x6000..0x6FFF  E820 buffer (scritto da stage1) — NON sovrascrivere!
;   0x7C00          Stack pointer (condiviso 16/32/64-bit)
;   0x8000..0xDFFF  Stage2 stesso (57344B = 28 settori CD)
;   0x10000..0x17FFF Page tables PML4/PDPT/PD (9 pagine × 4096)
;   0x10000..0x4BFFF Kernel ELF caricato temporaneamente
;   0x600000..0x63BFFF Kernel ELF copiato prima del setup PT
;
; Mappa pagine:
;   PML4[0]   → PDPT_ID@0x11000  (identity 0-4GB, 2MB huge pages)
;   PML4[256] → PDPT_HHDM@0x16000 (HHDM 0xFFFF800000000000 → phys 0)
;   PML4[511] → PDPT_KERN@0x17000 → PD_KERN@0x18000
;     PD_KERN[0]=0x200000|PS  (2MB: kernel .text/.rodata/.data/.bss)
;     PD_KERN[1]=0x400000|PS  (2MB: kernel BSS overflow)
;     PD_KERN[2]=0x600000|PS  (2MB: ELF staging area)
;
; Limine patch (section .limine_requests @ paddr 0x33b000):
;   hhdm   response* @ +0x128  (abs paddr 0x319128)
;   memmap response* @ +0x0A8  (abs paddr 0x3190A8)
;   kaddr  response* @ +0x0E8  (abs paddr 0x3190E8)
; =============================================================================

BITS 16
ORG 0x8000

; ─── PRIMA ISTRUZIONE: salta sopra i dati ───────────────────────────────────
    jmp near stage2_entry

; ─── DATI (accessibili via indirizzo fisico da tutti i modi) ─────────────────
vga_row: dw 0
vga_col: dw 0
drv16:   db 0
dap16:   db 16, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0
kentry:  dq 0xFFFFFFFF800193D5   ; aggiornato a ogni compilazione

s_boot: db "MattiaOS v3.5 - Stage2 avviato", 13, 10, 0
s_a20:  db "A20 fast gate OK", 13, 10, 0
s_load: db "Kernel ELF caricato (120 sett CD)", 13, 10, 0
s_e13:  db "ERRORE INT13h - halt!", 13, 10, 0
s_cp32: db "PM32: copia kernel 0x10000->0x600000", 13, 10, 0
s_pt32: db "PM32: page tables pronte", 13, 10, 0
s_lm64: db "LM64: Long Mode attivo", 13, 10, 0
s_elf:  db "LM64: ELF loader OK", 13, 10, 0
s_resp: db "LM64: Limine responses patched", 13, 10, 0
s_jmp:  db "LM64: Salto a kernel_main!", 13, 10, 0
s_bad:  db "ERRORE: ELF magic non valido!", 13, 10, 0

; ─── GDT 32 e 64 ─────────────────────────────────────────────────────────────
ALIGN 8
gdt32:     dq 0
           dq 0x00CF9A000000FFFF    ; code32 descriptor (0x08)
           dq 0x00CF92000000FFFF    ; data32 descriptor (0x10)
gdt32_end:
gdt32_ptr: dw gdt32_end - gdt32 - 1
           dd gdt32

ALIGN 8
gdt64:     dq 0
           dq 0x00AF9A000000FFFF    ; code64 descriptor (0x08)
           dq 0x00AF92000000FFFF    ; data64 descriptor (0x10)
gdt64_end:
gdt64_ptr: dw gdt64_end - gdt64 - 1
           dd gdt64

; =============================================================================
; ── FUNZIONI 16-BIT ──────────────────────────────────────────────────────────

; Pulisce lo schermo VGA (80×25, 0xB8000)
vga_cls:
    push ax
    push cx
    push di
    push es
    mov ax, 0xB800
    mov es, ax
    xor di, di
    mov cx, 80*25
    mov ax, 0x0720      ; spazio, attributo grigio su nero
.cls_l: stosw
    loop .cls_l
    mov word [vga_row], 0
    mov word [vga_col], 0
    pop es
    pop di
    pop cx
    pop ax
    ret

; Stampa SI (stringa null-term) su VGA (bianco) + porta 0xE9
vga16:
    push ax
    push bx
    push es
    mov bx, 0xB800
    mov es, bx
.v16_l:
    lodsb
    test al, al
    jz .v16_d
    out 0xE9, al
    cmp al, 13
    je .v16_cr
    cmp al, 10
    je .v16_lf
    movzx bx, word [vga_row]
    imul bx, bx, 80
    add bx, word [vga_col]
    shl bx, 1
    mov ah, 0x0F            ; bianco brillante su nero
    mov [es:bx], ax
    inc word [vga_col]
    cmp word [vga_col], 80
    jl .v16_l
    mov word [vga_col], 0
    inc word [vga_row]
    jmp .v16_l
.v16_cr: mov word [vga_col], 0
    jmp .v16_l
.v16_lf: inc word [vga_row]
    jmp .v16_l
.v16_d:
    pop es
    pop bx
    pop ax
    ret

; =============================================================================
; ── INGRESSO STAGE2 ───────────────────────────────────────────────────────────
stage2_entry:
    cli
    cld
    xor ax, ax
    mov ds, ax
    mov es, ax
    mov ss, ax
    mov sp, 0x7C00
    sti
    mov [drv16], dl     ; salva drive number da stage1

    call vga_cls
    mov si, s_boot
    call vga16

    ; A20 fast gate (porta 0x92)
    in  al, 0x92
    or  al, 2
    and al, 0xFE
    out 0x92, al
    mov si, s_a20
    call vga16

    ; Carica 120 settori CD (2048B l'uno) da LBA [0x7DF0] → 0x10000
    ; Ogni iterazione: ES += 0x80 (phys += 2048)
    mov eax, dword [0x7DF0]         ; kernel_start_LBA da stage1
    mov dword [dap16+8],  eax
    mov dword [dap16+12], 0
    mov word  [dap16+2],  1         ; 1 settore per volta
    mov word  [dap16+4],  0x0000    ; offset nel buffer = 0
    mov word  [dap16+6],  0x1000    ; segmento iniziale → phys 0x10000
    mov ecx, 120

.load_loop:
    test ecx, ecx
    jz   .load_ok
    lea  si, [dap16]
    mov  ah, 0x42
    mov  dl, [drv16]
    int  0x13
    jc   .load_err
    add  word [dap16+6], 0x80       ; segmento += 0x80 → phys += 2048
    inc  dword [dap16+8]            ; LBA++
    dec  ecx
    jmp  .load_loop
.load_ok:
    mov si, s_load
    call vga16
    jmp enter_pm32

.load_err:
    mov si, s_e13
    call vga16
.hlt16: hlt
    jmp .hlt16

; Transizione a PM32
enter_pm32:
    cli
    lgdt [gdt32_ptr]
    mov eax, cr0
    or  eax, 1
    mov cr0, eax
    jmp 0x08:pm32

; =============================================================================
BITS 32
; ── PROTECTED MODE 32-BIT ────────────────────────────────────────────────────
pm32:
    mov ax, 0x10
    mov ds, ax
    mov es, ax
    mov fs, ax
    mov gs, ax
    mov ss, ax
    mov esp, 0x7C00

    ; 1. Copia kernel ELF 0x10000→0x600000 PRIMA di sovrascrivere con page tables
    mov esi, 0x10000
    mov edi, 0x600000
    mov ecx, (120*2048)/4
    rep movsd
    mov esi, s_cp32
    call vga32

    ; 2. Azzera area page tables @ 0x10000 (9 × 4096B)
    mov edi, 0x10000
    mov ecx, 9*4096/4
    xor eax, eax
    rep stosd

    ; 3. Costruisce page tables
    ; PML4[0]   → PDPT_ID   @ 0x11000  (identity 0-4GB)
    mov dword [0x10000 +   0*8], 0x11000|3
    ; PML4[256] → PDPT_HHDM @ 0x16000  (HHDM 0xFFFF800000000000)
    mov dword [0x10000 + 256*8], 0x16000|3
    ; PML4[511] → PDPT_KERN @ 0x17000  (0xFFFFFFFF80000000)
    mov dword [0x10000 + 511*8], 0x17000|3

    ; PDPT_ID[0..3] → PD0..PD3
    mov dword [0x11000 +  0], 0x12000|3
    mov dword [0x11000 +  8], 0x13000|3
    mov dword [0x11000 + 16], 0x14000|3
    mov dword [0x11000 + 24], 0x15000|3

    ; PDPT_HHDM[0..3] = stesse PD identity
    mov dword [0x16000 +  0], 0x12000|3
    mov dword [0x16000 +  8], 0x13000|3
    mov dword [0x16000 + 16], 0x14000|3
    mov dword [0x16000 + 24], 0x15000|3

    ; PDPT_KERN[510] → PD_KERN @ 0x18000
    ; (indice 510 perché 0xFFFFFFFF80000000 → PDPT index = bits[38:30] = 510)
    mov dword [0x17000 + 510*8], 0x18000|3

    ; PD_KERN: huge pages 2MB
    mov dword [0x18000 + 0*8], 0x200000|(1<<7)|3  ; kernel phys
    mov dword [0x18000 + 1*8], 0x400000|(1<<7)|3  ; kernel BSS overflow
    mov dword [0x18000 + 2*8], 0x600000|(1<<7)|3  ; ELF staging

    ; PD0 identity 0-1GB (2MB huge pages)
    mov edi, 0x12000
    mov eax, 0x000000|(1<<7)|3
    mov ecx, 512
.pd0: mov [edi], eax
    mov dword [edi+4], 0
    add eax, 0x200000
    add edi, 8
    loop .pd0

    ; PD1 identity 1-2GB
    mov edi, 0x13000
    mov eax, 0x40000000|(1<<7)|3
    mov ecx, 512
.pd1: mov [edi], eax
    mov dword [edi+4], 0
    add eax, 0x200000
    add edi, 8
    loop .pd1

    ; PD2 identity 2-3GB
    mov edi, 0x14000
    mov eax, 0x80000000|(1<<7)|3
    mov ecx, 512
.pd2: mov [edi], eax
    mov dword [edi+4], 0
    add eax, 0x200000
    add edi, 8
    loop .pd2

    ; PD3 identity 3-4GB
    mov edi, 0x15000
    mov eax, 0xC0000000|(1<<7)|3
    mov ecx, 512
.pd3: mov [edi], eax
    mov dword [edi+4], 0
    add eax, 0x200000
    add edi, 8
    loop .pd3

    mov esi, s_pt32
    call vga32

    ; 4. Attiva Long Mode
    lgdt [gdt64_ptr]
    mov eax, cr4
    or  eax, (1<<4)|(1<<5)|(1<<7)  ; PSE + PAE + PGE
    mov cr4, eax
    mov eax, 0x10000
    mov cr3, eax
    mov ecx, 0xC0000080
    rdmsr
    or  eax, (1<<8)          ; LME
    wrmsr
    mov eax, cr0
    or  eax, 0x80000001      ; PG + PE
    mov cr0, eax
    jmp 0x08:lm64

; VGA output PM32 (verde, 0x0A)
vga32:
    push eax
    push ebx
    push edi
    push esi
.v32_l:
    mov al, [esi]
    test al, al
    jz .v32_d
    out 0xE9, al
    inc esi
    cmp al, 13
    je .v32_cr
    cmp al, 10
    je .v32_lf
    movzx ebx, word [vga_row]
    imul ebx, ebx, 80
    movzx edi, word [vga_col]
    add ebx, edi
    shl ebx, 1
    add ebx, 0xB8000
    mov ah, 0x0A            ; verde su nero
    mov [ebx], ax
    inc word [vga_col]
    cmp word [vga_col], 80
    jl .v32_l
    mov word [vga_col], 0
    inc word [vga_row]
    jmp .v32_l
.v32_cr: mov word [vga_col], 0
    jmp .v32_l
.v32_lf: inc word [vga_row]
    jmp .v32_l
.v32_d:
    pop esi
    pop edi
    pop ebx
    pop eax
    ret

; =============================================================================
BITS 64
; ── LONG MODE 64-BIT ─────────────────────────────────────────────────────────
lm64:
    mov ax, 0x10
    mov ds, ax
    mov es, ax
    mov fs, ax
    mov gs, ax
    mov ss, ax
    mov rsp, 0x7C00

    mov rsi, s_lm64
    call vga64

    ; 5. ELF loader: parsa ELF da 0x600000, copia segmenti a paddr_eff
    mov rbx, 0x600000
    cmp dword [rbx], 0x464C457F     ; 0x7F 'E' 'L' 'F'
    jne .elf_err

    mov rax, [rbx+0x18]             ; e_entry (virtual)
    mov [kentry], rax               ; aggiorna kentry con il valore dal kernel ELF

    movzx rcx, word [rbx+0x38]      ; e_phnum
    mov rsi, [rbx+0x20]             ; e_phoff
    add rsi, rbx                    ; puntatore assoluto al primo PH
    movzx r12, word [rbx+0x36]      ; e_phentsize

    mov r14, 0xFFFFFFFF80000000     ; kernel virtual base
    mov r13, 0x200000               ; kernel physical base

.ph_loop:
    test rcx, rcx
    jz   .ph_done
    cmp  dword [rsi], 1             ; PT_LOAD?
    jne  .ph_skip

    mov r8,  [rsi+0x08]             ; p_offset nell'ELF
    add r8,  rbx                    ; → indirizzo fisico nel buffer ELF
    mov r9,  [rsi+0x10]             ; p_vaddr
    sub r9,  r14                    ; p_vaddr - virt_base
    add r9,  r13                    ; + phys_base = paddr_eff
    mov r10, [rsi+0x20]             ; p_filesz
    mov r11, [rsi+0x28]             ; p_memsz

    test r10, r10
    jz   .ph_skip

    push rsi
    push rcx
    mov rsi, r8
    mov rdi, r9
    mov rcx, r10
    rep movsb                       ; copia p_filesz byte

    ; Zero BSS (memsz > filesz)
    mov rcx, r11
    sub rcx, r10
    jle .ph_no_bss
    xor al, al
    rep stosb
.ph_no_bss:
    pop rcx
    pop rsi

.ph_skip:
    add rsi, r12
    dec rcx
    jmp .ph_loop

.ph_done:
    mov rsi, s_elf
    call vga64

    ; 6. Costruisce Limine responses @ 0x5000..0x5FFF
    ;    ATTENZIONE: azzerato SOLO 0x5000..0x5FFF, NON 0x6000 (E820 buffer!)
    ; BUG FIX: salva E820 count PRIMA di azzerare (stage1 lo scrive a 0x5FFC)
    movzx r13, dword [0x5FFC]   ; r13 = E820 count (r13 libero dopo ELF loader)
    mov rdi, 0x5000
    mov rcx, 0x1000/8
    xor rax, rax
    rep stosq

    mov r15, 0xFFFF800000000000     ; HHDM offset

    ; HHDM response @ 0x5000: {revision=0, offset=HHDM}
    mov qword [0x5000], 0
    mov qword [0x5008], r15

    ; memmap response @ 0x5020: {revision=0, count=N, entries=ptr}
    mov qword [0x5020], 0
    mov rax, r13                     ; E820 count salvato prima del clear
    test rax, rax
    jnz .cnt_nonzero
    mov rax, 4                      ; fallback: 0 entries → usa 4 voci fittizie
    jmp .cnt_ok
.cnt_nonzero:
    cmp rax, 32                     ; cap a 32 (max stage1)
    jle .cnt_ok
    mov rax, 32
.cnt_ok:
    mov qword [0x5028], rax
    mov rdx, 0x5100
    add rdx, r15                    ; puntatore HHDM all'array entries
    mov qword [0x5030], rdx

    ; Converti E820 → Limine memmap entries @ 0x5200..0x57FF
    ; E820 entry: {base:8, length:8, type:4} = 20 byte
    ; Limine entry: {base:8, length:8, type:8} = 24 byte
    ; Tipi: E820 type 1 (Usable) → Limine 0 (USABLE), altrimenti → 1 (RESERVED)
    mov r13, qword [0x5028]         ; numero entries
    xor rbx, rbx
.mm_loop:
    cmp rbx, r13
    jge .mm_done

    ; Scrivi puntatore HHDM all'entry nell'array @ 0x5100
    mov rax, rbx
    imul rax, rax, 24               ; offset entry = i * 24
    add rax, 0x5200
    add rax, r15                    ; HHDM virtual pointer
    mov [0x5100 + rbx*8], rax

    ; Leggi entry E820 (20B da 0x6000)
    mov rdi, rbx
    imul rdi, rdi, 20
    add rdi, 0x6000
    mov r8,  [rdi]                  ; base
    mov r9,  [rdi+8]                ; length
    mov r10d, [rdi+16]              ; type

    ; Scrivi entry Limine @ 0x5200 + i*24
    mov rdi, rbx
    imul rdi, rdi, 24
    add rdi, 0x5200
    mov [rdi],   r8
    mov [rdi+8], r9
    xor r11, r11
    cmp r10d, 1                     ; E820 type 1 = Usable?
    je  .mm_usable
    mov r11, 1                      ; altrimenti Reserved
.mm_usable:
    mov [rdi+16], r11

    inc rbx
    jmp .mm_loop
.mm_done:

    ; kaddr response @ 0x5400: {revision=0, phys_base=0x200000, virt_base=0xFFFFFFFF80000000}
    mov qword [0x5400], 0
    mov qword [0x5408], 0x200000
    mov rax, 0xFFFFFFFF80000000
    mov qword [0x5410], rax

    ; 7. Patcha Limine request response pointers nel kernel
    ;    .limine_requests @ paddr 0x366000 (VERIFICATO v4.15 — ELF parser Python)
    ;    Struct Limine: id[4]=32B, revision=8B, response*=8B → response @ +0x28
    ;    Offset VERIFICATI con ELF parser Python su kernel v4.15:
    ;      hhdm  .response @ section+0x128  (abs paddr 0x35a128)
    ;      memmap.response @ section+0x0A8  (abs paddr 0x35a0A8)
    ;      kaddr .response @ section+0x0E8  (abs paddr 0x35a0E8)
    mov rbx, 0x366000               ; paddr sezione .limine_requests (v4.15)

    ; HHDM response (section+0x128, abs paddr 0x33d128)
    mov rax, 0x5000
    add rax, r15                    ; HHDM virtual → 0xFFFF800000005000
    mov [rbx + 0x128], rax

    ; memmap response (section+0x0A8, abs paddr 0x33d0A8)
    mov rax, 0x5020
    add rax, r15                    ; HHDM virtual → 0xFFFF800000005020
    mov [rbx + 0x0A8], rax

    ; kaddr response (section+0x0E8, abs paddr 0x33d0E8)
    mov rax, 0x5400
    add rax, r15                    ; HHDM virtual → 0xFFFF800000005400
    mov [rbx + 0x0E8], rax

    mov rsi, s_resp
    call vga64

    ; 8. Salta a kernel_main
    mov rsi, s_jmp
    call vga64
    mov rax, [kentry]
    jmp rax

.elf_err:
    mov rsi, s_bad
    call vga64
.hang64:
    hlt
    jmp .hang64

; VGA output LM64 (giallo, 0x0E)
vga64:
    push rax
    push rbx
    push rdi
    push rsi
.v64_l:
    mov al, [rsi]
    test al, al
    jz  .v64_d
    out 0xE9, al
    inc rsi
    cmp al, 13
    je  .v64_cr
    cmp al, 10
    je  .v64_lf
    movzx rbx, word [vga_row]
    imul rbx, rbx, 80
    movzx rdi, word [vga_col]
    add rbx, rdi
    shl rbx, 1
    add rbx, 0xB8000
    mov ah, 0x0E                    ; giallo su nero
    mov [rbx], ax
    inc word [vga_col]
    cmp word [vga_col], 80
    jl  .v64_l
    mov word [vga_col], 0
    inc word [vga_row]
    jmp .v64_l
.v64_cr: mov word [vga_col], 0
    jmp .v64_l
.v64_lf: inc word [vga_row]
    jmp .v64_l
.v64_d:
    pop rsi
    pop rdi
    pop rbx
    pop rax
    ret

times 57344 - ($ - $$) db 0         ; padding a 28 settori CD esatti
