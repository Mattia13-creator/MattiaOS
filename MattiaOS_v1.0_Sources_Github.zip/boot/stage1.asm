BITS 16
ORG 0x7C00

    jmp short _start
    nop
    times 8 - ($ - $$) db 0
bi_PVD:      dd 0
bi_boot_LBA: dd 0
bi_boot_len: dd 0
bi_checksum: dd 0
             times 40 db 0
    times 90 - ($ - $$) db 0

_start:
    cli
    cld
    xor ax, ax
    mov ds, ax
    mov es, ax
    mov ss, ax
    mov sp, 0x7BFE
    sti
    mov [drv], dl

    ; INT 13h extensions check
    mov ah, 0x41
    mov bx, 0x55AA
    int 0x13
    jnc .ok
.halt: hlt
    jmp .halt
.ok:
    ; A20 line enable (fast gate)
    in  al, 0x92
    or  al, 2
    and al, 0xFE        ; non triggerare reset
    out 0x92, al

    ; E820: salva count a 0x5FFC, buffer da 0x6000
    xor ebx, ebx
    mov di, 0x6000
    mov dword [0x5FFC], 0
.e820:
    mov eax, 0xE820
    mov edx, 0x534D4150
    mov ecx, 20
    int 0x15
    jc .e820done
    cmp eax, 0x534D4150
    jne .e820done
    add di, 20
    inc dword [0x5FFC]
    cmp dword [0x5FFC], 32
    je .e820done
    test ebx, ebx
    jnz .e820
.e820done:

    ; Carica stage2 (28 settori) da (bi_boot_LBA+1) a 0x8000
    mov eax, dword [bi_boot_LBA]
    inc eax
    mov dword [dap+8], eax
    mov word  [dap+2], 28
    mov word  [dap+4], 0x8000
    mov word  [dap+6], 0x0000
    lea si, [dap]
    mov ah, 0x42
    mov dl, [drv]
    int 0x13
    jc .halt

    ; Carica kernel ELF (600 settori = 1.2MB) da (bi_boot_LBA+29) a 0x100000+
    ; Usiamo INT 15h AX=0x87 (Extended Memory Copy) per caricare >1MB
    ; Oppure: carica in chunks < 1MB e copia

    ; Piano: carica a 0x20000 (128KB low mem) a blocchi da 128KB, 
    ; poi copia ad alto via INT15/AX=0x87
    ; Questo è complicato. Alternativa più semplice: 
    ; passa a stage2 in real mode, stage2 esegue il caricamento

    mov dl, [drv]
    ; Passa il LBA del kernel a stage2 via 0x7DF0
    mov eax, dword [bi_boot_LBA]
    add eax, 29
    mov dword [0x7DF0], eax     ; kernel_start_LBA per stage2

    jmp 0x0000:0x8000           ; salta a stage2 (ancora in real mode)

drv: db 0
dap: db 16, 0
     dw 1, 0, 0
     dd 0, 0

; Boot signature a offset 510 — richiesta da SeaBIOS anche per El Torito no-emulation
times 510 - ($ - $$) db 0
dw 0xAA55
; Padding fino a 2048 bytes (1 settore CD)
times 2048 - ($ - $$) db 0
