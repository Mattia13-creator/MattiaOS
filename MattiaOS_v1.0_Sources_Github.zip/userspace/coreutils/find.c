/*
 * find.c — ricerca file nella gerarchia di directory
 * Supporta: -name, -type (f d l), -size, -mtime, -perm, -exec, -print
 *           -maxdepth, -mindepth, -not/-!, -and/-a, -or/-o
 */
#include "../include/userspace.h"

/* =========================================================================
 * Predicati
 * ========================================================================= */
typedef enum {
    PRED_NONE, PRED_NAME, PRED_TYPE, PRED_SIZE, PRED_MTIME,
    PRED_PERM, PRED_EXEC, PRED_PRINT, PRED_PRUNE,
    PRED_NOT, PRED_AND, PRED_OR,
    PRED_MAXDEPTH, PRED_MINDEPTH
} pred_type_t;

typedef struct pred pred_t;
struct pred {
    pred_type_t type;
    char  arg[512];
    pred_t *left, *right;
};

static int   s_maxdepth = 0x7fffffff;
static int   s_mindepth = 0;
static char *s_exec_args[64];
static int   s_exec_argc;
static int   s_exec_has_placeholder = 0;

/* Glob match semplice per -name */
static int match_glob(const char *pat, const char *str) {
    while (*pat) {
        if (*pat == '*') {
            pat++;
            if (!*pat) return 1;
            while (*str) { if (match_glob(pat, str)) return 1; str++; }
            return 0;
        } else if (*pat == '?') {
            if (!*str) return 0;
            pat++; str++;
        } else {
            if (*pat != *str) return 0;
            pat++; str++;
        }
    }
    return *str == '\0';
}

/* Valuta predicato su un file */
static int eval_pred(const pred_t *p, const char *path,
                     const char *name, const struct stat *st, int depth) {
    if (!p) return 1;
    switch (p->type) {
    case PRED_NAME:
        return match_glob(p->arg, name);
    case PRED_TYPE: {
        char t = p->arg[0];
        if (t == 'f') return S_ISREG(st->st_mode);
        if (t == 'd') return S_ISDIR(st->st_mode);
        if (t == 'l') return S_ISLNK(st->st_mode);
        if (t == 'b') return S_ISBLK(st->st_mode);
        if (t == 'c') return S_ISCHR(st->st_mode);
        if (t == 'p') return S_ISFIFO(st->st_mode);
        if (t == 's') return S_ISSOCK(st->st_mode);
        return 0;
    }
    case PRED_SIZE: {
        const char *sp = p->arg;
        int mod = 0;
        if (*sp == '+') { mod = 1; sp++; }
        else if (*sp == '-') { mod = -1; sp++; }
        long long sz = atoll(sp);
        char unit = sp[strlen(sp)-1];
        if (unit == 'k' || unit == 'K') sz *= 1024;
        else if (unit == 'M') sz *= 1024*1024;
        else if (unit == 'G') sz *= 1024LL*1024*1024;
        else sz *= 512; /* blocchi di default */
        if (mod > 0) return st->st_size > sz;
        if (mod < 0) return st->st_size < sz;
        return st->st_size == sz;
    }
    case PRED_MTIME: {
        const char *mp = p->arg;
        int mod = 0;
        if (*mp == '+') { mod = 1; mp++; }
        else if (*mp == '-') { mod = -1; mp++; }
        long long days = atoll(mp);
        struct timespec now = {0,0};
        sys_clock_gettime(CLOCK_REALTIME, &now);
        long long cutoff = now.tv_sec - days * 86400;
        if (mod > 0) return st->st_mtime < cutoff;
        if (mod < 0) return st->st_mtime > cutoff;
        long long diff = (now.tv_sec - st->st_mtime) / 86400;
        return diff == days;
    }
    case PRED_PERM: {
        unsigned int perm = (unsigned int)strtol(p->arg, (char**)0, 8);
        return (st->st_mode & 0777) == perm;
    }
    case PRED_PRINT:
        printf("%s\n", path);
        return 1;
    case PRED_EXEC: {
        char *args[64]; int ai = 0;
        for (int i = 0; i < s_exec_argc && ai < 62; i++) {
            if (strcmp(s_exec_args[i], "{}") == 0)
                args[ai++] = (char *)path;
            else
                args[ai++] = s_exec_args[i];
        }
        args[ai] = (char *)0;
        char *exe_path = args[0];
        /* Cerca in PATH se non assoluto */
        int pid = fork();
        if (pid == 0) {
            execve(exe_path, args, (char*[]){(char*)0});
            exit(127);
        }
        if (pid > 0) {
            int status;
            sys_wait4(pid, &status, 0);
            return WIFEXITED(status) && WEXITSTATUS(status) == 0;
        }
        return 0;
    }
    case PRED_NOT:
        return !eval_pred(p->left, path, name, st, depth);
    case PRED_AND:
        return eval_pred(p->left, path, name, st, depth) &&
               eval_pred(p->right, path, name, st, depth);
    case PRED_OR:
        return eval_pred(p->left, path, name, st, depth) ||
               eval_pred(p->right, path, name, st, depth);
    case PRED_MAXDEPTH:
    case PRED_MINDEPTH:
    case PRED_PRUNE:
        return 1;
    default:
        return 1;
    }
}

/* =========================================================================
 * Walk ricorsivo
 * ========================================================================= */
static void walk(const char *path, pred_t *pred, int depth, int print_default) {
    if (depth > s_maxdepth) return;

    struct stat st;
    if (sys_lstat(path, &st) < 0) {
        fprintf(stderr, "find: %s: %s\n", path, strerror(errno));
        return;
    }

    const char *name = strrchr(path, '/');
    name = name ? name + 1 : path;

    /* Valuta predicato e stampa se soddisfatto */
    if (depth >= s_mindepth) {
        int match = pred ? eval_pred(pred, path, name, &st, depth) : 1;
        if (match) {
            if (print_default) printf("%s\n", path);
        }
    }

    /* Ricorsione nelle directory */
    if (!S_ISDIR(st.st_mode)) return;

    int fd = open(path, O_RDONLY, 0);
    if (fd < 0) return;

    char dbuf[4096]; int bytes;
    while ((bytes = sys_getdents(fd, dbuf, sizeof(dbuf))) > 0) {
        int off = 0;
        while (off < bytes) {
            struct dirent *d = (struct dirent *)(dbuf + off);
            if (d->d_reclen == 0) break;
            if (strcmp(d->d_name, ".") != 0 && strcmp(d->d_name, "..") != 0) {
                char sub[4096];
                snprintf(sub, sizeof(sub), "%s/%s", path, d->d_name);
                walk(sub, pred, depth + 1, print_default);
            }
            off += d->d_reclen;
        }
    }
    close(fd);
}

/* =========================================================================
 * Parser argomenti
 * ========================================================================= */
static int s_argc;
static char **s_argv;
static int s_pos;

static pred_t *parse_expr(int depth);

static pred_t *new_pred(pred_type_t type) {
    pred_t *p = (pred_t *)xcalloc(1, sizeof(pred_t));
    p->type = type;
    return p;
}

static pred_t *parse_primary(void) {
    if (s_pos >= s_argc) return (pred_t *)0;
    const char *tok = s_argv[s_pos++];

    if (strcmp(tok, "!") == 0 || strcmp(tok, "-not") == 0) {
        pred_t *p = new_pred(PRED_NOT);
        p->left = parse_primary();
        return p;
    }
    if (strcmp(tok, "(") == 0) {
        pred_t *p = parse_expr(0);
        if (s_pos < s_argc && strcmp(s_argv[s_pos], ")") == 0) s_pos++;
        return p;
    }
    if (strcmp(tok, "-name") == 0 && s_pos < s_argc) {
        pred_t *p = new_pred(PRED_NAME);
        strncpy(p->arg, s_argv[s_pos++], 511);
        return p;
    }
    if (strcmp(tok, "-type") == 0 && s_pos < s_argc) {
        pred_t *p = new_pred(PRED_TYPE);
        strncpy(p->arg, s_argv[s_pos++], 511);
        return p;
    }
    if (strcmp(tok, "-size") == 0 && s_pos < s_argc) {
        pred_t *p = new_pred(PRED_SIZE);
        strncpy(p->arg, s_argv[s_pos++], 511);
        return p;
    }
    if (strcmp(tok, "-mtime") == 0 && s_pos < s_argc) {
        pred_t *p = new_pred(PRED_MTIME);
        strncpy(p->arg, s_argv[s_pos++], 511);
        return p;
    }
    if (strcmp(tok, "-perm") == 0 && s_pos < s_argc) {
        pred_t *p = new_pred(PRED_PERM);
        strncpy(p->arg, s_argv[s_pos++], 511);
        return p;
    }
    if (strcmp(tok, "-print") == 0) return new_pred(PRED_PRINT);
    if (strcmp(tok, "-prune") == 0) return new_pred(PRED_PRUNE);
    if (strcmp(tok, "-maxdepth") == 0 && s_pos < s_argc) {
        s_maxdepth = atoi(s_argv[s_pos++]);
        return new_pred(PRED_MAXDEPTH);
    }
    if (strcmp(tok, "-mindepth") == 0 && s_pos < s_argc) {
        s_mindepth = atoi(s_argv[s_pos++]);
        return new_pred(PRED_MINDEPTH);
    }
    if (strcmp(tok, "-exec") == 0) {
        pred_t *p = new_pred(PRED_EXEC);
        s_exec_argc = 0;
        while (s_pos < s_argc &&
               strcmp(s_argv[s_pos], ";") != 0 &&
               s_exec_argc < 62) {
            if (strcmp(s_argv[s_pos], "{}") == 0) s_exec_has_placeholder = 1;
            s_exec_args[s_exec_argc++] = s_argv[s_pos++];
        }
        if (s_pos < s_argc) s_pos++; /* skip ; */
        s_exec_args[s_exec_argc] = (char *)0;
        return p;
    }
    /* Token non riconosciuto: torna indietro */
    s_pos--;
    return (pred_t *)0;
}

static pred_t *parse_expr(int depth) {
    pred_t *left = parse_primary();
    while (s_pos < s_argc) {
        const char *op = s_argv[s_pos];
        if (strcmp(op, ")") == 0) break;
        if (strcmp(op, "-or") == 0 || strcmp(op, "-o") == 0) {
            s_pos++;
            pred_t *right = parse_primary();
            pred_t *p = new_pred(PRED_OR);
            p->left = left; p->right = right;
            left = p;
        } else if (strcmp(op, "-and") == 0 || strcmp(op, "-a") == 0) {
            s_pos++;
            pred_t *right = parse_primary();
            pred_t *p = new_pred(PRED_AND);
            p->left = left; p->right = right;
            left = p;
        } else {
            /* Implicit AND */
            pred_t *right = parse_primary();
            if (!right) break;
            pred_t *p = new_pred(PRED_AND);
            p->left = left; p->right = right;
            left = p;
        }
    }
    (void)depth;
    return left;
}

int main(int argc, char **argv) {
    if (argc < 2) {
        walk(".", (pred_t *)0, 0, 1); return 0;
    }

    /* Raccogli le directory di partenza */
    char *start_dirs[64]; int ndirs = 0;
    int i = 1;
    while (i < argc && argv[i][0] != '-' && strcmp(argv[i], "!") != 0) {
        start_dirs[ndirs++] = argv[i++];
    }
    if (ndirs == 0) { start_dirs[0] = "."; ndirs = 1; }

    /* Parsa i predicati */
    s_argc = argc - i;
    s_argv = argv + i;
    s_pos  = 0;
    pred_t *pred = (s_argc > 0) ? parse_expr(0) : (pred_t *)0;

    /* Determina se c'è -print esplicito */
    /* Per semplicità: print_default = 1 sempre (come find standard) */
    int print_default = 1;
    /* Se l'utente ha specificato -print o -exec, non stampare automaticamente */
    /* (override: MattiaOS find stampa sempre il percorso, come GNU find default) */

    for (int d = 0; d < ndirs; d++)
        walk(start_dirs[d], pred, 0, print_default);

    return 0;
}
