/*
 * cut.c — estrae campi o intervalli di caratteri/byte
 * Flags: -f lista_campi, -d delimitatore, -c lista_char, -b lista_byte
 *        --complement inverte la selezione, -s salta righe senza delimitatore
 */
#include "../include/userspace.h"

#define MAX_RANGES 64
typedef struct { int lo, hi; } range_t;
static range_t s_ranges[MAX_RANGES];
static int     s_nranges = 0;

/* Parsa "1,3-5,7-" in array di range */
static void parse_list(const char *s, int max_field) {
    s_nranges = 0;
    char buf[256]; strncpy(buf, s, 255);
    char *save, *tok = strtok_r(buf, ",", &save);
    while (tok && s_nranges < MAX_RANGES) {
        range_t r;
        char *dash = strchr(tok, '-');
        if (!dash) {
            r.lo = r.hi = atoi(tok);
        } else if (dash == tok) {
            r.lo = 1; r.hi = atoi(dash+1);
        } else {
            *dash = '\0'; r.lo = atoi(tok);
            r.hi = *(dash+1) ? atoi(dash+1) : max_field;
        }
        s_ranges[s_nranges++] = r;
        tok = strtok_r((char*)0, ",", &save);
    }
}

static int in_range(int n) {
    for (int i = 0; i < s_nranges; i++)
        if (n >= s_ranges[i].lo && n <= s_ranges[i].hi) return 1;
    return 0;
}

static int opt_complement = 0, opt_skip = 0;

static void cut_line_fields(const char *line, char delim) {
    int field = 1, first_out = 1;
    const char *start = line;
    const char *p = line;
    while (1) {
        if (*p == delim || *p == '\0') {
            int sel = in_range(field);
            if (opt_complement) sel = !sel;
            if (sel) {
                if (!first_out) write(1, &delim, 1);
                write(1, start, p - start);
                first_out = 0;
            }
            if (*p == '\0') break;
            start = p + 1; field++;
        }
        p++;
    }
    write(1, "\n", 1);
}

static void cut_line_chars(const char *line, int by_byte) {
    int n = (int)strlen(line);
    int first_out = 1;
    (void)by_byte;
    for (int i = 1; i <= n; i++) {
        int sel = in_range(i);
        if (opt_complement) sel = !sel;
        if (sel) { write(1, &line[i-1], 1); first_out = 0; }
    }
    (void)first_out;
    write(1, "\n", 1);
}

static void process_fd(int fd, int mode, char delim) {
    char line[65536]; int li = 0; char c;
    while (read(fd, &c, 1) == 1) {
        if (c == '\n') {
            line[li] = '\0';
            if (mode == 'f') {
                if (opt_skip && !strchr(line, delim)) { printf("%s\n", line); }
                else cut_line_fields(line, delim);
            } else cut_line_chars(line, mode == 'b');
            li = 0;
        } else if (li < 65534) line[li++] = c;
    }
    if (li > 0) {
        line[li] = '\0';
        if (mode == 'f') cut_line_fields(line, delim);
        else cut_line_chars(line, 0);
    }
}

int main(int argc, char **argv) {
    int mode = 'f'; /* f=fields, c=chars, b=bytes */
    char delim = '\t';
    char *list_s = (char*)0;
    int first = 1;

    for (int i = 1; i < argc; i++) {
        if (!strcmp(argv[i], "--complement")) { opt_complement=1; first=i+1; }
        else if (!strcmp(argv[i], "-s"))      { opt_skip=1; first=i+1; }
        else if (argv[i][0]=='-'&&argv[i][1]) {
            for (int j=1;argv[i][j];j++) {
                if (argv[i][j]=='f') { mode='f'; if(argv[i][j+1]){list_s=argv[i]+j+1;j=(int)strlen(argv[i])-1;} else if(argv[i+1]) list_s=argv[++i]; }
                else if (argv[i][j]=='c') { mode='c'; if(argv[i][j+1]){list_s=argv[i]+j+1;j=(int)strlen(argv[i])-1;} else if(argv[i+1]) list_s=argv[++i]; }
                else if (argv[i][j]=='b') { mode='b'; if(argv[i][j+1]){list_s=argv[i]+j+1;j=(int)strlen(argv[i])-1;} else if(argv[i+1]) list_s=argv[++i]; }
                else if (argv[i][j]=='d') { if(argv[i][j+1]){delim=argv[i][j+1];j=(int)strlen(argv[i])-1;} else if(argv[i+1]) delim=argv[++i][0]; }
            }
            first=i+1;
        }
    }

    if (!list_s) { fprintf(stderr,"Uso: cut -f lista [-d sep] [file...]\n"); return 1; }
    parse_list(list_s, 0x7fffffff);

    if (first >= argc) process_fd(0, mode, delim);
    else for (int i=first;i<argc;i++) {
        int fd=open(argv[i],O_RDONLY,0);
        if(fd<0){fprintf(stderr,"cut: %s: %s\n",argv[i],strerror(errno));continue;}
        process_fd(fd, mode, delim); close(fd);
    }
    return 0;
}
