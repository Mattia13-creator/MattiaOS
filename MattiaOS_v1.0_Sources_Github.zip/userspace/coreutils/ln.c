/*
 * ln.c — crea hard link o symbolic link
 * Flags: -s simbolico, -f forza, -v verbose
 */
#include "../include/userspace.h"

int main(int argc, char **argv) {
    int opt_sym = 0, opt_force = 0, opt_verbose = 0;
    int first = 1;

    for (int i = 1; i < argc; i++) {
        if (argv[i][0] == '-' && argv[i][1]) {
            for (int j = 1; argv[i][j]; j++) {
                switch (argv[i][j]) {
                case 's': opt_sym     = 1; break;
                case 'f': opt_force   = 1; break;
                case 'v': opt_verbose = 1; break;
                }
            }
            first = i + 1;
        }
    }

    int nfiles = argc - first;
    if (nfiles < 2) { fprintf(stderr, "Uso: ln [-sfv] sorgente dest\n"); return 1; }

    char *src = argv[first];
    char *dst = argv[argc - 1];

    /* Se dest è directory, costruisci il percorso completo */
    char full_dst[4096];
    struct stat dst_st;
    if (sys_stat(dst, &dst_st) == 0 && S_ISDIR(dst_st.st_mode)) {
        const char *base = strrchr(src, '/');
        base = base ? base + 1 : src;
        snprintf(full_dst, sizeof(full_dst), "%s/%s", dst, base);
        dst = full_dst;
    }

    if (opt_force) unlink(dst);

    int r;
    if (opt_sym) r = sys_symlink(src, dst);
    else         r = sys_link(src, dst);

    if (r < 0) {
        fprintf(stderr, "ln: %s: %s\n", dst, strerror(errno));
        return 1;
    }
    if (opt_verbose) {
        printf("'%s' -> '%s'\n", dst, src);
    }
    return 0;
}
