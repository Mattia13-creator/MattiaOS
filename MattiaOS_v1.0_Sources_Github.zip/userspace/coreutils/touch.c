/*
 * touch.c — aggiorna timestamp o crea file vuoto
 * Flags: -c non crea il file se non esiste, -a solo atime, -m solo mtime
 */
#include "../include/userspace.h"

int main(int argc, char **argv) {
    int opt_nocreate = 0;
    int first = 1;

    for (int i = 1; i < argc; i++) {
        if (argv[i][0] == '-' && argv[i][1]) {
            for (int j = 1; argv[i][j]; j++) {
                if (argv[i][j] == 'c') opt_nocreate = 1;
            }
            first = i + 1;
        }
    }

    if (first >= argc) { fprintf(stderr, "Uso: touch [-c] file...\n"); return 1; }

    int errors = 0;
    for (int i = first; i < argc; i++) {
        struct stat st;
        int exists = (sys_stat(argv[i], &st) == 0);

        if (!exists) {
            if (opt_nocreate) continue;
            /* Crea file vuoto */
            int fd = open(argv[i], O_WRONLY | O_CREAT | O_TRUNC, 0644);
            if (fd < 0) {
                fprintf(stderr, "touch: %s: %s\n", argv[i], strerror(errno));
                errors++;
                continue;
            }
            close(fd);
        } else {
            /* Aggiorna timestamp con utimensat — due timespec UTIME_NOW */
            struct timespec ts[2] = {
                { 0, 0x3fffffff /* UTIME_NOW */ },
                { 0, 0x3fffffff /* UTIME_NOW */ }
            };
            /* SYS_UTIMENSAT = 280: (dirfd, path, times, flags) */
            long r = __syscall4(280, -100L /* AT_FDCWD */,
                                (long)argv[i], (long)ts, 0L);
            if (r < 0) {
                /* Fallback: open + close aggiorna mtime comunque */
                int fd = open(argv[i], O_WRONLY, 0);
                if (fd >= 0) close(fd);
                else {
                    fprintf(stderr, "touch: %s: %s\n", argv[i], strerror(errno));
                    errors++;
                }
            }
        }
    }
    return errors ? 1 : 0;
}
