/*
 * ping.c — invia pacchetti ICMP Echo Request
 * Uso: ping [-c count] [-i interval] [-s size] [-W timeout] host
 *
 * Usa raw socket ICMP via SYS_SOCKET con AF_INET + SOCK_RAW + IPPROTO_ICMP.
 * Non richiede privilegi se il kernel MattiaOS permette raw socket a root.
 */
#include "../include/userspace.h"

/* =========================================================================
 * Strutture ICMP / IP minimali
 * ========================================================================= */
struct icmp_hdr {
    uint8_t  type;
    uint8_t  code;
    uint16_t checksum;
    uint16_t id;
    uint16_t seq;
};

struct iphdr {
    uint8_t  ihl_ver;
    uint8_t  tos;
    uint16_t tot_len;
    uint16_t id;
    uint16_t frag_off;
    uint8_t  ttl;
    uint8_t  protocol;
    uint16_t check;
    uint32_t saddr;
    uint32_t daddr;
};

#define ICMP_ECHO_REQUEST 8
#define ICMP_ECHO_REPLY   0
#define IPPROTO_ICMP_N    1

/* =========================================================================
 * Calcolo checksum Internet (RFC 1071)
 * ========================================================================= */
static uint16_t checksum(const void *data, size_t len) {
    const uint16_t *ptr = (const uint16_t *)data;
    uint32_t sum = 0;
    while (len > 1) { sum += *ptr++; len -= 2; }
    if (len) sum += *(const uint8_t *)ptr;
    while (sum >> 16) sum = (sum & 0xffff) + (sum >> 16);
    return (uint16_t)~sum;
}

/* =========================================================================
 * Risolve hostname → IP (controlla solo /etc/hosts, poi interpreta come IP)
 * ========================================================================= */
static uint32_t resolve_host(const char *host) {
    /* Prova prima come IP decimale puntato */
    unsigned int a, b, c, d;
    if (sscanf(host, "%u.%u.%u.%u", &a, &b, &c, &d) == 4 &&
        a < 256 && b < 256 && c < 256 && d < 256) {
        return (uint32_t)((a<<24)|(b<<16)|(c<<8)|d);
    }

    /* Cerca in /etc/hosts */
    FILE *f = fopen("/etc/hosts", "r");
    if (f) {
        char line[256];
        while (fgets(line, sizeof(line), f)) {
            if (line[0] == '#') continue;
            char ip[64], name[128], alias[128];
            int n = sscanf(line, "%63s %127s %127s", ip, name, alias);
            if (n >= 2 && (!strcmp(name, host) || (n >= 3 && !strcmp(alias, host)))) {
                fclose(f);
                return resolve_host(ip);
            }
        }
        fclose(f);
    }

    fprintf(stderr, "ping: impossibile risolvere '%s'\n", host);
    return 0;
}

/* =========================================================================
 * Formatta IP come stringa
 * ========================================================================= */
static void ip_to_str(uint32_t ip, char *out) {
    sprintf(out, "%u.%u.%u.%u",
            (ip >> 24) & 0xff, (ip >> 16) & 0xff,
            (ip >> 8)  & 0xff, ip & 0xff);
}

/* =========================================================================
 * main
 * ========================================================================= */
int main(int argc, char **argv) {
    int   opt_count    = -1; /* -1 = infinito */
    int   opt_interval = 1;  /* secondi */
    int   opt_size     = 56; /* byte di payload */
    int   opt_timeout  = 1;  /* secondo */
    const char *host   = (char*)0;

    for (int i = 1; i < argc; i++) {
        if (!strcmp(argv[i], "-c") && argv[i+1])      opt_count    = atoi(argv[++i]);
        else if (!strcmp(argv[i], "-i") && argv[i+1]) opt_interval = atoi(argv[++i]);
        else if (!strcmp(argv[i], "-s") && argv[i+1]) opt_size     = atoi(argv[++i]);
        else if (!strcmp(argv[i], "-W") && argv[i+1]) opt_timeout  = atoi(argv[++i]);
        else if (argv[i][0] != '-') host = argv[i];
    }

    if (!host) { fprintf(stderr, "Uso: ping [-c N] [-i sec] [-s size] host\n"); return 1; }

    uint32_t dst_ip = resolve_host(host);
    if (!dst_ip) return 1;

    char ip_str[20]; ip_to_str(dst_ip, ip_str);

    /* Crea raw socket ICMP */
    int sock = sys_socket(AF_INET, SOCK_RAW, IPPROTO_ICMP_N);
    if (sock < 0) {
        fprintf(stderr, "ping: socket: %s (richiede privilegi root)\n", strerror(errno));
        return 1;
    }

    /* Costruisci sockaddr_in per destinazione */
    struct sockaddr dst_addr;
    memset(&dst_addr, 0, sizeof(dst_addr));
    dst_addr.sa_family = AF_INET;
    /* sa_data: port (2B) + addr (4B) in network byte order */
    uint32_t addr_ne = ((dst_ip & 0xff000000) >> 24) |
                       ((dst_ip & 0x00ff0000) >> 8)  |
                       ((dst_ip & 0x0000ff00) << 8)  |
                       ((dst_ip & 0x000000ff) << 24);
    memcpy(dst_addr.sa_data + 2, &addr_ne, 4);

    int payload_size = opt_size < 8 ? 8 : opt_size;
    if (payload_size > 1400) payload_size = 1400;
    size_t pkt_size = sizeof(struct icmp_hdr) + payload_size;
    uint8_t *pkt = (uint8_t *)xcalloc(1, pkt_size + 8);
    uint8_t *recv_buf = (uint8_t *)xcalloc(1, 4096);

    uint16_t my_id = (uint16_t)(getpid() & 0xffff);

    printf("PING %s (%s) %d byte di dati.\n", host, ip_str, payload_size);

    int sent = 0, received = 0;
    struct timespec t_start, t_send, t_recv;
    sys_clock_gettime(CLOCK_MONOTONIC, &t_start);

    /* Imposta timeout ricezione */
    struct timespec timeout_ts = { .tv_sec = opt_timeout, .tv_nsec = 0 };
    (void)timeout_ts; /* timeout gestito con nanosleep + select se disponibile */

    signal(SIGINT, SIG_DFL); /* Ctrl+C stampa statistiche */

    for (int seq = 1; opt_count < 0 || seq <= opt_count; seq++) {
        /* Costruisci pacchetto ICMP */
        struct icmp_hdr *icmp = (struct icmp_hdr *)pkt;
        icmp->type     = ICMP_ECHO_REQUEST;
        icmp->code     = 0;
        icmp->checksum = 0;
        icmp->id       = my_id;
        icmp->seq      = (uint16_t)seq;
        /* Payload: pattern 0x10..0xff */
        for (int i = 0; i < payload_size; i++)
            pkt[sizeof(struct icmp_hdr) + i] = (uint8_t)(0x10 + i % 0xf0);

        icmp->checksum = checksum(pkt, pkt_size);

        sys_clock_gettime(CLOCK_MONOTONIC, &t_send);

        int n = sys_sendto(sock, pkt, pkt_size, 0, &dst_addr, sizeof(dst_addr));
        if (n < 0) {
            fprintf(stderr, "ping: sendto: %s\n", strerror(errno));
            break;
        }
        sent++;

        /* Ricevi risposta */
        uint32_t fromlen = sizeof(struct sockaddr);
        struct sockaddr from_addr;
        int rn = sys_recvfrom(sock, recv_buf, 4096, 0, &from_addr, &fromlen);
        sys_clock_gettime(CLOCK_MONOTONIC, &t_recv);

        if (rn > 0) {
            struct iphdr *iph = (struct iphdr *)recv_buf;
            int iph_len = (iph->ihl_ver & 0x0f) * 4;
            if (rn >= iph_len + (int)sizeof(struct icmp_hdr)) {
                struct icmp_hdr *ricmp = (struct icmp_hdr *)(recv_buf + iph_len);
                if (ricmp->type == ICMP_ECHO_REPLY &&
                    ricmp->id   == my_id &&
                    ricmp->seq  == (uint16_t)seq) {
                    received++;
                    long long us = (t_recv.tv_sec - t_send.tv_sec) * 1000000LL +
                                   (t_recv.tv_nsec - t_send.tv_nsec) / 1000;
                    char from_ip[20]; ip_to_str(dst_ip, from_ip);
                    printf("%d byte da %s: icmp_seq=%d ttl=%d tempo=%.3f ms\n",
                           rn - iph_len, from_ip, seq, iph->ttl, us / 1000.0);
                }
            }
        } else {
            printf("Richiesta timeout per icmp_seq=%d\n", seq);
        }

        if (opt_count < 0 || seq < opt_count) {
            struct timespec interval_ts = { .tv_sec = opt_interval, .tv_nsec = 0 };
            sys_nanosleep(&interval_ts, (struct timespec*)0);
        }
    }

    /* Statistiche finali */
    sys_clock_gettime(CLOCK_MONOTONIC, &t_recv);
    long long elapsed_ms = (t_recv.tv_sec  - t_start.tv_sec)  * 1000LL +
                           (t_recv.tv_nsec - t_start.tv_nsec) / 1000000LL;
    int lost = sent - received;
    int loss_pct = sent > 0 ? lost * 100 / sent : 0;

    printf("\n--- %s statistiche ping ---\n", host);
    printf("%d pacchetti trasmessi, %d ricevuti, %d%% pacchetti persi, tempo %lldms\n",
           sent, received, loss_pct, elapsed_ms);

    close(sock);
    free(pkt); free(recv_buf);
    return received > 0 ? 0 : 1;
}
