/*
 * ps.c — lista processi
 * Legge /proc/[pid]/status per ogni processo.
 * Flags: -a tutti, -u con utente, -x include senza tty, -f full format
 *        -e tutti i processi
 */
#include "../include/userspace.h"

typedef struct {
    int          pid;
    int          ppid;
    unsigned int uid;
    char         name[256];
    char         state;
    long long    vsz;    /* Virtual size kB */
    long long    rss;    /* RSS kB */
    int          tty;
} proc_info_t;

#define MAX_PROCS 1024
static proc_info_t s_procs[MAX_PROCS];
static int         s_nprocs = 0;

/* Legge /proc/[pid]/status e popola proc_info_t */
static int read_proc_status(int pid, proc_info_t *p) {
    char path[64];
    snprintf(path, sizeof(path), "/proc/%d/status", pid);
    int fd = open(path, O_RDONLY, 0);
    if (fd < 0) return -1;

    p->pid = pid;
    p->ppid = 0; p->uid = 0; p->state = '?';
    p->vsz = 0; p->rss = 0; p->tty = 0;
    strncpy(p->name, "?", 255);

    char buf[4096]; int n = (int)read(fd, buf, sizeof(buf) - 1);
    close(fd);
    if (n <= 0) return -1;
    buf[n] = '\0';

    char *line = buf;
    while (line && *line) {
        char *nl = strchr(line, '\n');
        if (nl) *nl = '\0';

        if (strncmp(line, "Name:", 5) == 0) {
            char *v = line + 5; while (*v == ' ' || *v == '\t') v++;
            strncpy(p->name, v, 255);
        } else if (strncmp(line, "State:", 6) == 0) {
            char *v = line + 6; while (*v == ' ' || *v == '\t') v++;
            p->state = *v;
        } else if (strncmp(line, "Pid:", 4) == 0) {
            p->pid = atoi(line + 4);
        } else if (strncmp(line, "PPid:", 5) == 0) {
            p->ppid = atoi(line + 5);
        } else if (strncmp(line, "Uid:", 4) == 0) {
            p->uid = (unsigned int)atoi(line + 4);
        } else if (strncmp(line, "VmSize:", 7) == 0) {
            p->vsz = atoll(line + 7);
        } else if (strncmp(line, "VmRSS:", 6) == 0) {
            p->rss = atoll(line + 6);
        }

        if (!nl) break;
        line = nl + 1;
    }
    return 0;
}

/* Scansiona /proc per tutti i PID */
static void scan_procs(void) {
    s_nprocs = 0;
    int fd = open("/proc", O_RDONLY, 0);
    if (fd < 0) {
        /* Fallback: prova a leggere il processo corrente e i suoi figli */
        proc_info_t *p = &s_procs[s_nprocs];
        if (read_proc_status(getpid(), p) == 0) s_nprocs++;
        return;
    }
    char dbuf[8192]; int bytes;
    while ((bytes = sys_getdents(fd, dbuf, sizeof(dbuf))) > 0 &&
           s_nprocs < MAX_PROCS) {
        int off = 0;
        while (off < bytes && s_nprocs < MAX_PROCS) {
            struct dirent *d = (struct dirent *)(dbuf + off);
            if (d->d_reclen == 0) break;
            /* Controlla se il nome è numerico (= PID) */
            int is_pid = 1;
            for (int i = 0; d->d_name[i]; i++)
                if (d->d_name[i] < '0' || d->d_name[i] > '9') { is_pid = 0; break; }
            if (is_pid && d->d_name[0]) {
                int pid = atoi(d->d_name);
                if (read_proc_status(pid, &s_procs[s_nprocs]) == 0)
                    s_nprocs++;
            }
            off += d->d_reclen;
        }
    }
    close(fd);
}

static int cmp_pid(const void *a, const void *b) {
    return ((proc_info_t *)a)->pid - ((proc_info_t *)b)->pid;
}

int main(int argc, char **argv) {
    int opt_all = 0, opt_full = 0, opt_user = 0;
    int opt_long __attribute__((unused)) = 0;
    int my_pid = getpid();
    int my_ppid = sys_getppid();

    for (int i = 1; i < argc; i++) {
        if (argv[i][0] == '-') {
            for (int j = 1; argv[i][j]; j++) {
                switch(argv[i][j]) {
                case 'a': case 'e': opt_all  = 1; break;
                case 'f': opt_full = 1; break;
                case 'u': opt_user = 1; break;
                case 'l': opt_long = 1; break;
                case 'x': opt_all  = 1; break;
                }
            }
        } else if (strcmp(argv[i], "aux") == 0 ||
                   strcmp(argv[i], "ax")  == 0) {
            opt_all = opt_full = opt_user = 1;
        } else if (strcmp(argv[i], "ef") == 0) {
            opt_all = opt_full = 1;
        }
    }

    scan_procs();
    qsort(s_procs, s_nprocs, sizeof(proc_info_t), cmp_pid);

    /* Intestazione */
    if (opt_full || opt_user) {
        printf("%-8s %5s %5s %s %5s  %8s  %8s  %s\n",
               "USER", "PID", "PPID", "S", "TTY", "VSZ(kB)", "RSS(kB)", "CMD");
    } else {
        printf("%5s %s %8s %8s  %s\n",
               "PID", "S", "VSZ(kB)", "RSS(kB)", "CMD");
    }

    for (int i = 0; i < s_nprocs; i++) {
        proc_info_t *p = &s_procs[i];
        /* Filtra se non -a: mostra solo processi dell'utente corrente */
        if (!opt_all && p->uid != (unsigned int)getuid() &&
            p->pid != my_pid && p->ppid != my_ppid)
            continue;

        if (opt_full || opt_user) {
            printf("%-8u %5d %5d %c %5d  %8lld  %8lld  %s\n",
                   p->uid, p->pid, p->ppid, p->state, p->tty,
                   p->vsz, p->rss, p->name);
        } else {
            printf("%5d %c %8lld %8lld  %s\n",
                   p->pid, p->state, p->vsz, p->rss, p->name);
        }
    }
    return 0;
}
