/*
 * head.c — stampa le prime N righe di un file
 * Flags: -n N (righe), -c N (byte)
 */
#include "../include/userspace.h"

static void head_fd(int fd, long long nlines, long long nbytes) {
    char buf[4096]; ssize_t n;
    long long lines_left = nlines, bytes_left = nbytes;
    int byte_mode = (nbytes > 0);

    while ((n = read(fd, buf, sizeof(buf))) > 0) {
        if (byte_mode) {
            ssize_t w = n < bytes_left ? n : (ssize_t)bytes_left;
            write(1, buf, w);
            bytes_left -= w;
            if (bytes_left <= 0) return;
        } else {
            for (ssize_t i = 0; i < n; i++) {
                write(1, &buf[i], 1);
                if (buf[i] == '\n') {
                    if (--lines_left <= 0) return;
                }
            }
        }
    }
}

int main(int argc, char **argv) {
    long long nlines = 10, nbytes = 0;
    int first = 1;
    for (int i = 1; i < argc; i++) {
        if (!strcmp(argv[i], "-n") && argv[i+1]) { nlines = atoll(argv[++i]); first=i+1; }
        else if (!strcmp(argv[i], "-c") && argv[i+1]) { nbytes = atoll(argv[++i]); first=i+1; }
        else if (argv[i][0]=='-' && argv[i][1]>='0' && argv[i][1]<='9') { nlines=atoll(argv[i]+1); first=i+1; }
    }
    int nf = argc - first;
    if (nf == 0) { head_fd(0, nlines, nbytes); return 0; }
    for (int i = first; i < argc; i++) {
        if (nf > 1) printf("==> %s <==\n", argv[i]);
        int fd = open(argv[i], O_RDONLY, 0);
        if (fd < 0) { fprintf(stderr, "head: %s: %s\n", argv[i], strerror(errno)); continue; }
        head_fd(fd, nlines, nbytes);
        close(fd);
        if (nf > 1 && i < argc-1) printf("\n");
    }
    return 0;
}
