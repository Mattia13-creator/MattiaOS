/*
 * cat.c — concatena file e stampa su stdout
 * Flags: -n numera righe, -A mostra caratteri non stampabili, -v non stampabili visibili
 */
#include "../include/userspace.h"
#define BUF 8192

static int opt_number = 0, opt_show_all = 0, opt_visible = 0;

static int cat_fd(int fd) {
    static char buf[BUF];
    ssize_t n;
    long long lineno = 1;
    int at_bol = 1; /* at beginning of line */

    while ((n = read(fd, buf, BUF)) > 0) {
        if (!opt_number && !opt_show_all && !opt_visible) {
            /* Fast path: passthrough diretto */
            ssize_t written = 0;
            while (written < n) {
                ssize_t w = write(1, buf + written, n - written);
                if (w <= 0) return 1;
                written += w;
            }
            continue;
        }
        for (ssize_t i = 0; i < n; i++) {
            unsigned char c = (unsigned char)buf[i];
            if (opt_number && at_bol) {
                printf("%6lld\t", lineno++);
                at_bol = 0;
            }
            if (c == '\n') {
                if (opt_show_all) write(1, "$", 1);
                write(1, "\n", 1);
                at_bol = 1;
            } else if ((opt_show_all || opt_visible) && (c < 32 || c == 127) && c != '\t') {
                char esc[4];
                if (c == 127) { esc[0] = '^'; esc[1] = '?'; write(1, esc, 2); }
                else { esc[0] = '^'; esc[1] = c + 64; write(1, esc, 2); }
            } else if (opt_show_all && c > 127) {
                char esc[6];
                snprintf(esc, sizeof(esc), "M-%c", c - 128);
                write(1, esc, strlen(esc));
            } else {
                write(1, &buf[i], 1);
            }
        }
    }
    return n < 0 ? 1 : 0;
}

int main(int argc, char **argv) {
    int first = 1;
    for (int i = 1; i < argc; i++) {
        if (argv[i][0] == '-' && argv[i][1]) {
            for (int j = 1; argv[i][j]; j++) {
                switch (argv[i][j]) {
                case 'n': opt_number  = 1; break;
                case 'A': opt_show_all = 1; break;
                case 'v': opt_visible  = 1; break;
                case 'e': opt_show_all = 1; break;
                }
            }
            first = i + 1;
        }
    }

    int errors = 0;
    if (first >= argc) {
        errors += cat_fd(0); /* stdin */
    } else {
        for (int i = first; i < argc; i++) {
            if (strcmp(argv[i], "-") == 0) {
                errors += cat_fd(0);
            } else {
                int fd = open(argv[i], O_RDONLY, 0);
                if (fd < 0) {
                    fprintf(stderr, "cat: %s: %s\n", argv[i], strerror(errno));
                    errors++;
                    continue;
                }
                errors += cat_fd(fd);
                close(fd);
            }
        }
    }
    return errors ? 1 : 0;
}
