/*
 * du.c — utilizzo disco per file e directory
 * Flags: -h human, -s solo totale, -a tutti i file, -c totale finale, --max-depth N
 */
#include "../include/userspace.h"

static int opt_human = 0, opt_summary = 0, opt_all = 0, opt_total = 0;
static int opt_maxdepth = 0x7fffffff;
static long long s_grand_total = 0;

static long long du_path(const char *path, int depth) {
    struct stat st;
    if (sys_lstat(path, &st) < 0) {
        fprintf(stderr, "du: %s: %s\n", path, strerror(errno));
        return 0;
    }

    long long size = st.st_blocks / 2; /* blocchi da 512B → kB */

    if (!S_ISDIR(st.st_mode)) {
        if (opt_all && !opt_summary && depth <= opt_maxdepth) {
            if (opt_human) {
                char s[16]; format_size_human(st.st_size, s, sizeof(s));
                printf("%-8s %s\n", s, path);
            } else {
                printf("%-8lld %s\n", size, path);
            }
        }
        return size;
    }

    /* Directory */
    int fd = open(path, O_RDONLY, 0);
    if (fd < 0) return size;

    long long total = size;
    char dbuf[4096]; int bytes;
    while ((bytes = sys_getdents(fd, dbuf, sizeof(dbuf))) > 0) {
        int off = 0;
        while (off < bytes) {
            struct dirent *d = (struct dirent *)(dbuf + off);
            if (d->d_reclen == 0) break;
            if (strcmp(d->d_name, ".") && strcmp(d->d_name, "..")) {
                char sub[4096];
                snprintf(sub, sizeof(sub), "%s/%s", path, d->d_name);
                total += du_path(sub, depth + 1);
            }
            off += d->d_reclen;
        }
    }
    close(fd);

    if (!opt_summary || depth == 0) {
        if (depth <= opt_maxdepth) {
            if (opt_human) {
                char s[16]; format_size_human(total * 1024, s, sizeof(s));
                printf("%-8s %s\n", s, path);
            } else {
                printf("%-8lld %s\n", total, path);
            }
        }
    }
    return total;
}

int main(int argc, char **argv) {
    int first = 1;
    for (int i = 1; i < argc; i++) {
        if (!strcmp(argv[i], "-h"))        { opt_human   = 1; first = i+1; }
        else if (!strcmp(argv[i], "-s"))   { opt_summary = 1; first = i+1; }
        else if (!strcmp(argv[i], "-a"))   { opt_all     = 1; first = i+1; }
        else if (!strcmp(argv[i], "-c"))   { opt_total   = 1; first = i+1; }
        else if (!strcmp(argv[i], "--max-depth") && argv[i+1]) {
            opt_maxdepth = atoi(argv[++i]); first = i+1;
        } else if (argv[i][0] == '-') {
            for (int j = 1; argv[i][j]; j++) {
                if (argv[i][j] == 'h') opt_human   = 1;
                if (argv[i][j] == 's') opt_summary = 1;
                if (argv[i][j] == 'a') opt_all     = 1;
                if (argv[i][j] == 'c') opt_total   = 1;
            }
            first = i+1;
        }
    }

    if (first >= argc) { argv[argc] = "."; argc++; }

    for (int i = first; i < argc; i++) {
        long long sz = du_path(argv[i], 0);
        s_grand_total += sz;
    }

    if (opt_total) {
        if (opt_human) {
            char s[16]; format_size_human(s_grand_total * 1024, s, sizeof(s));
            printf("%-8s totale\n", s);
        } else {
            printf("%-8lld totale\n", s_grand_total);
        }
    }
    return 0;
}
