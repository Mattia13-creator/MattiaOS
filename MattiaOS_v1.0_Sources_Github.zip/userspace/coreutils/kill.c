/*
 * kill.c — invia segnale a processo
 * Uso: kill [-SIGNAL | -s SIGNAL] PID...
 *      kill -l  lista segnali
 */
#include "../include/userspace.h"

static const struct { int num; const char *name; } s_signals[] = {
    {1,"HUP"},{2,"INT"},{3,"QUIT"},{4,"ILL"},{5,"TRAP"},{6,"ABRT"},
    {7,"BUS"},{8,"FPE"},{9,"KILL"},{10,"USR1"},{11,"SEGV"},{12,"USR2"},
    {13,"PIPE"},{14,"ALRM"},{15,"TERM"},{17,"CHLD"},{18,"CONT"},
    {19,"STOP"},{20,"TSTP"},{21,"TTIN"},{22,"TTOU"},{28,"WINCH"},
    {0,(char*)0}
};

static int signame_to_num(const char *name) {
    /* Numerica diretta */
    if (name[0] >= '0' && name[0] <= '9') return atoi(name);
    /* Con prefisso SIG */
    const char *n = name;
    if (strncmp(n, "SIG", 3) == 0) n += 3;
    for (int i = 0; s_signals[i].name; i++)
        if (strcmp(s_signals[i].name, n) == 0)
            return s_signals[i].num;
    return -1;
}

int main(int argc, char **argv) {
    int sig = SIGTERM;
    int first_pid = 1;

    if (argc < 2) {
        fprintf(stderr, "Uso: kill [-SIGNAL | -s SIGNAL | -l] PID...\n"); return 1;
    }

    for (int i = 1; i < argc; i++) {
        if (strcmp(argv[i], "-l") == 0 || strcmp(argv[i], "--list") == 0) {
            for (int j = 0; s_signals[j].name; j++)
                printf("%2d) SIG%s\n", s_signals[j].num, s_signals[j].name);
            return 0;
        }
        if (strcmp(argv[i], "-s") == 0 && argv[i+1]) {
            sig = signame_to_num(argv[i+1]);
            if (sig < 0) { fprintf(stderr, "kill: segnale sconosciuto: %s\n", argv[i+1]); return 1; }
            first_pid = i + 2; i++;
        } else if (argv[i][0] == '-' && argv[i][1]) {
            /* -SIGTERM o -15 */
            sig = signame_to_num(argv[i] + 1);
            if (sig < 0) { fprintf(stderr, "kill: segnale sconosciuto: %s\n", argv[i]+1); return 1; }
            first_pid = i + 1;
        }
    }

    if (first_pid >= argc) {
        fprintf(stderr, "kill: nessun PID specificato\n"); return 1;
    }

    int errors = 0;
    for (int i = first_pid; i < argc; i++) {
        int pid = atoi(argv[i]);
        if (pid == 0) {
            fprintf(stderr, "kill: PID non valido: %s\n", argv[i]); errors++; continue;
        }
        if (sys_kill(pid, sig) < 0) {
            fprintf(stderr, "kill: (%d): %s\n", pid, strerror(errno)); errors++;
        }
    }
    return errors ? 1 : 0;
}
