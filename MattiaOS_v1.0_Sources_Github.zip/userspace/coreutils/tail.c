/*
 * tail.c — stampa le ultime N righe di un file
 * Flags: -n N, -c N (byte), -f follow
 */
#include "../include/userspace.h"

#define RING_LINES 8192

static void tail_fd(int fd, long long nlines, int follow) {
    /* Strategia: buffer circolare di righe */
    char **ring = xcalloc(RING_LINES, sizeof(char *));
    int head_idx = 0, count = 0;
    char line[65536]; int li = 0;

    /* Leggi tutto il file in ring buffer */
    char c;
    while (read(fd, &c, 1) == 1) {
        if (c == '\n' || li >= 65534) {
            line[li] = '\0';
            free(ring[head_idx]);
            ring[head_idx] = xstrdup(line);
            head_idx = (head_idx + 1) % RING_LINES;
            if (count < RING_LINES) count++;
            li = 0;
        } else {
            line[li++] = c;
        }
    }
    /* Eventuale riga finale senza newline */
    if (li > 0) {
        line[li] = '\0';
        free(ring[head_idx]);
        ring[head_idx] = xstrdup(line);
        head_idx = (head_idx + 1) % RING_LINES;
        if (count < RING_LINES) count++;
    }

    /* Stampa le ultime nlines righe */
    if (nlines > count) nlines = count;
    int start = (head_idx - (int)nlines + RING_LINES) % RING_LINES;
    for (long long i = 0; i < nlines; i++) {
        int idx = (start + i) % RING_LINES;
        if (ring[idx]) { printf("%s\n", ring[idx]); }
    }
    for (int i = 0; i < RING_LINES; i++) free(ring[i]);
    free(ring);

    /* Follow mode: continua a leggere */
    if (follow) {
        while (1) {
            char buf[4096]; ssize_t n;
            n = read(fd, buf, sizeof(buf));
            if (n > 0) write(1, buf, n);
            else {
                struct timespec ts = {0, 100000000}; /* 100ms */
                sys_nanosleep(&ts, (struct timespec*)0);
            }
        }
    }
}

int main(int argc, char **argv) {
    long long nlines = 10;
    int follow = 0, first = 1;
    for (int i = 1; i < argc; i++) {
        if (!strcmp(argv[i], "-n") && argv[i+1]) { nlines = atoll(argv[++i]); first=i+1; }
        else if (!strcmp(argv[i], "-f")) { follow = 1; first=i+1; }
        else if (argv[i][0]=='-' && argv[i][1]>='0' && argv[i][1]<='9') { nlines=atoll(argv[i]+1); first=i+1; }
        else if (argv[i][0]=='-' && argv[i][1]) {
            for (int j=1;argv[i][j];j++) if(argv[i][j]=='f') follow=1;
            first=i+1;
        }
    }
    int nf = argc - first;
    if (nf == 0) { tail_fd(0, nlines, follow); return 0; }
    for (int i = first; i < argc; i++) {
        if (nf > 1) printf("==> %s <==\n", argv[i]);
        int fd = open(argv[i], O_RDONLY, 0);
        if (fd < 0) { fprintf(stderr, "tail: %s: %s\n", argv[i], strerror(errno)); continue; }
        tail_fd(fd, nlines, follow);
        close(fd);
        if (nf > 1 && i < argc-1) printf("\n");
    }
    return 0;
}
