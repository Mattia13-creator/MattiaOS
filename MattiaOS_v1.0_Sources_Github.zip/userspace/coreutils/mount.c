/*
 * mount.c — monta filesystem o mostra mount attuali
 * Uso: mount [device mountpoint [tipo]] oppure mount senza argomenti
 */
#include "../include/userspace.h"

int main(int argc, char **argv) {
    if (argc == 1) {
        /* Lista i mount leggendo /proc/mounts */
        FILE *f = fopen("/proc/mounts", "r");
        if (!f) { fprintf(stderr, "mount: impossibile leggere /proc/mounts\n"); return 1; }
        char line[512];
        while (fgets(line, sizeof(line), f)) printf("%s", line);
        fclose(f);
        return 0;
    }
    if (argc < 3) {
        fprintf(stderr, "Uso: mount device mountpoint [tipo] [-o opzioni]\n"); return 1;
    }

    const char *src  = argv[1];
    const char *dst  = argv[2];
    const char *type = (argc >= 4 && argv[3][0] != '-') ? argv[3] : "auto";
    unsigned long flags = 0;

    /* Parsa -o opzioni */
    for (int i = 3; i < argc; i++) {
        if (strcmp(argv[i], "-o") == 0 && argv[i+1]) {
            char *opt = argv[++i];
            if (strstr(opt, "ro"))    flags |= (1UL << 0);
            if (strstr(opt, "remount")) flags |= (1UL << 5);
        }
        if (strcmp(argv[i], "-r") == 0) flags |= (1UL << 0);
    }

    if (sys_mount(src, dst, type, flags, (void*)0) < 0) {
        fprintf(stderr, "mount: %s: %s\n", dst, strerror(errno)); return 1;
    }
    printf("mount: %s montato su %s\n", src, dst);
    return 0;
}
