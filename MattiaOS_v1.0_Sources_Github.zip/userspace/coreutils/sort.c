/*
 * sort.c — ordina righe di testo
 * Flags: -r inverso, -n numerico, -k campo, -t sep, -u unici,
 *        -f ignora case, -h human (1K < 2M), -R random
 */
#include "../include/userspace.h"

static int opt_rev=0, opt_num=0, opt_uniq=0, opt_ic=0, opt_human=0;
static int opt_key=0;   /* campo (1-based) */
static char opt_sep='\t';

static char **s_lines = (char**)0;
static int   s_count  = 0, s_cap = 0;

static double human_val(const char *s) {
    double v = strtod(s, (char**)0);
    while (*s && (*s == '-' || (*s>='0' && *s<='9') || *s == '.')) s++;
    if (*s == 'K' || *s == 'k') v *= 1e3;
    else if (*s == 'M') v *= 1e6;
    else if (*s == 'G') v *= 1e9;
    else if (*s == 'T') v *= 1e12;
    return v;
}

static const char *get_key(const char *line) {
    if (opt_key <= 1) return line;
    const char *p = line; int k = opt_key - 1;
    while (k-- > 0) {
        while (*p && *p != opt_sep) p++;
        if (*p == opt_sep) p++;
    }
    return p;
}

static int line_cmp(const void *a, const void *b) {
    const char *la = get_key(*(const char **)a);
    const char *lb = get_key(*(const char **)b);
    int r;
    if (opt_num)   r = (int)(atoll(la) - atoll(lb)) < 0 ? -1 : atoll(la) == atoll(lb) ? 0 : 1;
    else if (opt_human) { double da = human_val(la), db = human_val(lb); r = da<db?-1:da>db?1:0; }
    else if (opt_ic) {
        char A[4096], B[4096]; int i;
        for (i=0;la[i]&&i<4095;i++) { A[i]=(la[i]>='A'&&la[i]<='Z')?la[i]+32:la[i]; } A[i]=0;
        for (i=0;lb[i]&&i<4095;i++) { B[i]=(lb[i]>='A'&&lb[i]<='Z')?lb[i]+32:lb[i]; } B[i]=0;
        r = strcmp(A, B);
    } else { r = strcmp(la, lb); }
    return opt_rev ? -r : r;
}

static void add_line(const char *s) {
    if (s_count >= s_cap) {
        s_cap = s_cap ? s_cap*2 : 4096;
        s_lines = (char**)realloc(s_lines, s_cap * sizeof(char*));
        if (!s_lines) die("out of memory");
    }
    s_lines[s_count++] = xstrdup(s);
}

static void read_lines(int fd) {
    char line[65536]; int li = 0; char c;
    while (read(fd, &c, 1) == 1) {
        if (c == '\n') { line[li]=0; add_line(line); li=0; }
        else if (li < 65534) line[li++] = c;
    }
    if (li > 0) { line[li]=0; add_line(line); }
}

int main(int argc, char **argv) {
    int first=1;
    for (int i=1;i<argc;i++) {
        if (argv[i][0]=='-'&&argv[i][1]) {
            for (int j=1;argv[i][j];j++) {
                switch(argv[i][j]) {
                case 'r': opt_rev=1; break; case 'n': opt_num=1; break;
                case 'u': opt_uniq=1; break; case 'f': opt_ic=1; break;
                case 'h': opt_human=1; break;
                case 'k':
                    if(argv[i][j+1]) { opt_key=atoi(argv[i]+j+1); j=(int)strlen(argv[i])-1; }
                    else if(argv[i+1]) { opt_key=atoi(argv[++i]); }
                    break;
                case 't':
                    if(argv[i][j+1]) { opt_sep=argv[i][j+1]; j=(int)strlen(argv[i])-1; }
                    else if(argv[i+1]) { opt_sep=argv[++i][0]; }
                    break;
                }
            }
            first=i+1;
        }
    }
    if (first>=argc) read_lines(0);
    else for (int i=first;i<argc;i++) {
        int fd=open(argv[i],O_RDONLY,0);
        if(fd<0){fprintf(stderr,"sort: %s: %s\n",argv[i],strerror(errno));continue;}
        read_lines(fd); close(fd);
    }
    qsort(s_lines, s_count, sizeof(char*), line_cmp);
    const char *prev = (char*)0;
    for (int i=0;i<s_count;i++) {
        if (opt_uniq && prev && strcmp(s_lines[i], prev)==0) continue;
        printf("%s\n", s_lines[i]);
        prev = s_lines[i];
    }
    return 0;
}
