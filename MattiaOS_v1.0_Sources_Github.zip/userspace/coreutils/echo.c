/*
 * echo.c — stampa argomenti su stdout
 * Flags: -n no newline, -e interpreta escape, -E disabilita escape (default)
 */
#include "../include/userspace.h"

int main(int argc, char **argv) {
    int newline = 1, interp = 0, i = 1;

    /* Processa flag */
    while (i < argc && argv[i][0] == '-' && argv[i][1]) {
        int ok = 1;
        for (int j = 1; argv[i][j]; j++) {
            if (argv[i][j] == 'n') newline = 0;
            else if (argv[i][j] == 'e') interp = 1;
            else if (argv[i][j] == 'E') interp = 0;
            else { ok = 0; break; }
        }
        if (!ok) break;
        i++;
    }

    for (; i < argc; i++) {
        if (i > (interp ? 1 : 1) && i > 1) write(1, " ", 1);
        /* Controlla se dobbiamo aggiungere spazio */
        /* (la condizione sopra è semplifcata — riscriviamo) */
        const char *s = argv[i];
        if (!interp) {
            write(1, s, strlen(s));
        } else {
            while (*s) {
                if (*s == '\\' && *(s+1)) {
                    s++;
                    switch (*s) {
                    case 'n':  write(1, "\n",  1); break;
                    case 't':  write(1, "\t",  1); break;
                    case 'r':  write(1, "\r",  1); break;
                    case '\\': write(1, "\\",  1); break;
                    case 'a':  write(1, "\a",  1); break;
                    case 'b':  write(1, "\b",  1); break;
                    case 'f':  write(1, "\f",  1); break;
                    case 'v':  write(1, "\v",  1); break;
                    case '0': {
                        /* Ottale \0NNN */
                        unsigned char oc = 0; int k = 0;
                        while (k < 3 && *(s+1) >= '0' && *(s+1) <= '7')
                            { s++; oc = oc*8 + (*s - '0'); k++; }
                        write(1, &oc, 1);
                        break;
                    }
                    case 'x': {
                        /* Esadecimale \xHH */
                        unsigned char hc = 0; int k = 0;
                        while (k < 2 && ((*(s+1)>='0'&&*(s+1)<='9')||
                               (*(s+1)>='a'&&*(s+1)<='f')||(*(s+1)>='A'&&*(s+1)<='F')))
                        {
                            s++; k++;
                            if (*s>='0'&&*s<='9')      hc=hc*16+(*s-'0');
                            else if(*s>='a'&&*s<='f')  hc=hc*16+(*s-'a'+10);
                            else                        hc=hc*16+(*s-'A'+10);
                        }
                        write(1, &hc, 1);
                        break;
                    }
                    case 'c': /* \c: stop output */ if (newline) {} return 0;
                    default:  { char tmp[2]={'\\',*s}; write(1,tmp,2); } break;
                    }
                } else {
                    write(1, s, 1);
                }
                s++;
            }
        }
        if (i < argc - 1) write(1, " ", 1);
    }
    if (newline) write(1, "\n", 1);
    return 0;
}
