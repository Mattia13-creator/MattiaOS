/*
 * cp.c — copia file e directory
 * Flags: -r/-R ricorsivo, -v verbose, -f forza, -p preserva metadati
 */
#include "../include/userspace.h"

static int opt_recursive = 0, opt_verbose = 0, opt_force = 0, opt_preserve = 0;
#define BUF_SIZE (64 * 1024)

static int copy_file(const char *src, const char *dst) {
    int fdin = open(src, O_RDONLY, 0);
    if (fdin < 0) { fprintf(stderr, "cp: %s: %s\n", src, strerror(errno)); return 1; }

    struct stat st;
    sys_fstat(fdin, &st);
    int mode = opt_preserve ? (int)st.st_mode : 0644;

    int fdout = open(dst, O_WRONLY | O_CREAT | O_TRUNC, mode);
    if (fdout < 0) {
        if (opt_force) {
            unlink(dst);
            fdout = open(dst, O_WRONLY | O_CREAT | O_TRUNC, mode);
        }
        if (fdout < 0) {
            fprintf(stderr, "cp: %s: %s\n", dst, strerror(errno));
            close(fdin); return 1;
        }
    }

    static char buf[BUF_SIZE];
    ssize_t n;
    while ((n = read(fdin, buf, BUF_SIZE)) > 0) {
        ssize_t written = 0;
        while (written < n) {
            ssize_t w = write(fdout, buf + written, n - written);
            if (w <= 0) {
                fprintf(stderr, "cp: scrittura su %s: %s\n", dst, strerror(errno));
                close(fdin); close(fdout); return 1;
            }
            written += w;
        }
    }
    close(fdin); close(fdout);

    if (opt_verbose) printf("'%s' -> '%s'\n", src, dst);
    return 0;
}

static int copy_recursive(const char *src, const char *dst) {
    struct stat st;
    if (sys_lstat(src, &st) < 0) {
        fprintf(stderr, "cp: %s: %s\n", src, strerror(errno)); return 1;
    }

    if (S_ISLNK(st.st_mode)) {
        char target[4096];
        int n = sys_readlink(src, target, sizeof(target) - 1);
        if (n < 0) { fprintf(stderr, "cp: readlink %s: %s\n", src, strerror(errno)); return 1; }
        target[n] = '\0';
        unlink(dst);
        if (sys_symlink(target, dst) < 0) {
            fprintf(stderr, "cp: symlink %s: %s\n", dst, strerror(errno)); return 1;
        }
        if (opt_verbose) printf("'%s' -> '%s'\n", src, dst);
        return 0;
    }

    if (!S_ISDIR(st.st_mode)) return copy_file(src, dst);

    /* Crea directory di destinazione */
    struct stat dst_st;
    if (sys_stat(dst, &dst_st) < 0) {
        if (mkdir(dst, st.st_mode & 0777) < 0) {
            fprintf(stderr, "cp: mkdir %s: %s\n", dst, strerror(errno)); return 1;
        }
    }

    int fd = open(src, O_RDONLY, 0);
    if (fd < 0) { fprintf(stderr, "cp: %s: %s\n", src, strerror(errno)); return 1; }

    char dbuf[4096]; int bytes; int errors = 0;
    while ((bytes = sys_getdents(fd, dbuf, sizeof(dbuf))) > 0) {
        int off = 0;
        while (off < bytes) {
            struct dirent *d = (struct dirent *)(dbuf + off);
            if (d->d_reclen == 0) break;
            if (strcmp(d->d_name, ".") != 0 && strcmp(d->d_name, "..") != 0) {
                char ssub[4096], dsub[4096];
                snprintf(ssub, sizeof(ssub), "%s/%s", src, d->d_name);
                snprintf(dsub, sizeof(dsub), "%s/%s", dst, d->d_name);
                errors += copy_recursive(ssub, dsub);
            }
            off += d->d_reclen;
        }
    }
    close(fd);
    if (opt_verbose) printf("directory '%s' -> '%s'\n", src, dst);
    return errors ? 1 : 0;
}

static char *build_dst_path(const char *src, const char *dst) {
    struct stat st;
    if (sys_stat(dst, &st) == 0 && S_ISDIR(st.st_mode)) {
        /* Destinazione è directory: aggiungi nome file */
        const char *base = strrchr(src, '/');
        base = base ? base + 1 : src;
        char *result = xmalloc(strlen(dst) + strlen(base) + 2);
        sprintf(result, "%s/%s", dst, base);
        return result;
    }
    return xstrdup(dst);
}

int main(int argc, char **argv) {
    int first_arg = 1;
    for (int i = 1; i < argc; i++) {
        if (argv[i][0] == '-' && argv[i][1]) {
            for (int j = 1; argv[i][j]; j++) {
                switch (argv[i][j]) {
                case 'r': case 'R': opt_recursive = 1; break;
                case 'v': opt_verbose = 1; break;
                case 'f': opt_force = 1; break;
                case 'p': opt_preserve = 1; break;
                }
            }
            first_arg = i + 1;
        }
    }

    int nfiles = argc - first_arg;
    if (nfiles < 2) { fprintf(stderr, "Uso: cp [-Rvfp] sorgente... destinazione\n"); return 1; }

    char *dst = argv[argc - 1];

    /* Caso: sorgenti multiple → destinazione deve essere directory */
    if (nfiles > 2) {
        struct stat st;
        if (sys_stat(dst, &st) < 0 || !S_ISDIR(st.st_mode)) {
            fprintf(stderr, "cp: destinazione '%s' non è una directory\n", dst);
            return 1;
        }
    }

    int errors = 0;
    for (int i = first_arg; i < argc - 1; i++) {
        char *real_dst = build_dst_path(argv[i], dst);
        struct stat st;
        if (sys_lstat(argv[i], &st) == 0 && S_ISDIR(st.st_mode)) {
            if (!opt_recursive) {
                fprintf(stderr, "cp: %s: è una directory (usa -r)\n", argv[i]);
                errors++; free(real_dst); continue;
            }
            errors += copy_recursive(argv[i], real_dst);
        } else {
            errors += copy_file(argv[i], real_dst);
        }
        free(real_dst);
    }
    return errors ? 1 : 0;
}
