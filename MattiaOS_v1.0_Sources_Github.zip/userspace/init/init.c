/*
 * init.c — PID 1 di MattiaOS
 *
 * Responsabilità:
 *  1. Montare devfs /dev, tmpfs /tmp, procfs /proc
 *  2. Creare i device node fondamentali (/dev/null, /dev/tty, ...)
 *  3. Impostare le variabili d'ambiente di sistema
 *  4. Lanciare /bin/sh su /dev/tty0 (TTY principale)
 *  5. Adottare i processi orfani
 *  6. Raccogliere i processi zombie tramite SIGCHLD / waitpid loop
 */

#include "../include/userspace.h"

/* =========================================================================
 * Costanti
 * ========================================================================= */
#define SHELL_PATH  "/bin/sh"
#define CONSOLE_DEV "/dev/tty0"
#define DEVFS_TYPE  "devfs"
#define TMPFS_TYPE  "tmpfs"
#define PROCFS_TYPE "procfs"
#define INIT_TTY    CONSOLE_DEV

/* =========================================================================
 * Variabili d'ambiente di default
 * ========================================================================= */
static char *s_default_env[] = {
    "PATH=/bin:/usr/bin:/sbin:/usr/sbin",
    "HOME=/root",
    "SHELL=" SHELL_PATH,
    "TERM=vt100",
    "LOGNAME=root",
    "USER=root",
    "HOSTNAME=mattiaos",
    "LANG=C",
    (char *)0
};

/* =========================================================================
 * shell_argv per execve
 * ========================================================================= */
static char *s_shell_argv[] = {
    SHELL_PATH,
    (char *)0
};

/* =========================================================================
 * SIGCHLD handler — raccoglie zombie senza bloccare
 * ========================================================================= */
static volatile int s_sigchld_received = 0;

static void sigchld_handler(int sig) {
    (void)sig;
    s_sigchld_received = 1;
}

static void reap_zombies(void) {
    int status;
    int pid;
    while ((pid = sys_wait4(-1, &status, WNOHANG)) > 0) {
        if (WIFEXITED(status)) {
            printf("[init] PID %d esited with code %d\n",
                   pid, WEXITSTATUS(status));
        } else if (WIFSIGNALED(status)) {
            printf("[init] PID %d killed by signal %d\n",
                   pid, WTERMSIG(status));
        }
    }
}

/* =========================================================================
 * mount_fs — monta un filesystem, stampa errore se fallisce
 * ========================================================================= */
static int mount_fs(const char *src, const char *target,
                    const char *type, unsigned long flags) {
    if (sys_mount(src, target, type, flags, (void *)0) < 0) {
        fprintf(stderr, "[init] mount %s su %s fallito: %s\n",
                type, target, strerror(errno));
        return -1;
    }
    printf("[init] montato %s su %s\n", type, target);
    return 0;
}

/* =========================================================================
 * make_dir — crea directory se non esiste
 * ========================================================================= */
static void make_dir(const char *path) {
    struct stat st;
    if (sys_stat(path, &st) < 0) {
        if (mkdir(path, 0755) < 0)
            fprintf(stderr, "[init] mkdir %s: %s\n", path, strerror(errno));
    }
}

/* =========================================================================
 * open_console — apre /dev/tty0 come stdin/stdout/stderr (fd 0,1,2)
 * ========================================================================= */
static void open_console(void) {
    /* Chiudi eventuali fd aperti dal kernel */
    close(0); close(1); close(2);

    int fd = open(CONSOLE_DEV, O_RDWR, 0);
    if (fd < 0) {
        /* Fallback su /dev/tty */
        fd = open("/dev/tty", O_RDWR, 0);
        if (fd < 0) {
            /* Ultimo tentativo: crea un fd su /dev/null */
            fd = open("/dev/null", O_RDWR, 0);
        }
    }
    if (fd < 0) return; /* Non c'è nulla da fare */

    if (fd != 0) { sys_dup2(fd, 0); close(fd); }
    sys_dup2(0, 1);
    sys_dup2(0, 2);
}

/* =========================================================================
 * setup_environment — scrive le variabili d'ambiente nel file /etc/environment
 * ========================================================================= */
static void setup_environment(void) {
    make_dir("/etc");
    FILE *f = fopen("/etc/environment", "w");
    if (!f) return;
    for (int i = 0; s_default_env[i]; i++)
        fprintf(f, "%s\n", s_default_env[i]);
    fclose(f);
}

/* =========================================================================
 * write_file — scrive contenuto in un file (crea se non esiste)
 * ========================================================================= */
static void write_file(const char *path, const char *content) {
    int fd = open(path, O_WRONLY | O_CREAT | O_TRUNC, 0644);
    if (fd < 0) return;
    write(fd, content, strlen(content));
    close(fd);
}

/* =========================================================================
 * setup_rootfs — crea la gerarchia /etc, /var, /tmp, ...
 * ========================================================================= */
static void setup_rootfs(void) {
    /* Directory di base */
    make_dir("/bin");
    make_dir("/sbin");
    make_dir("/usr");
    make_dir("/usr/bin");
    make_dir("/usr/sbin");
    make_dir("/etc");
    make_dir("/var");
    make_dir("/var/log");
    make_dir("/var/run");
    make_dir("/root");
    make_dir("/home");
    make_dir("/proc");
    make_dir("/dev");
    make_dir("/tmp");
    make_dir("/mnt");
    make_dir("/lib");
    make_dir("/sys");

    /* File di configurazione minimi */
    write_file("/etc/hostname", "mattiaos\n");
    write_file("/etc/os-release",
               "NAME=\"MattiaOS\"\n"
               "VERSION=\"2.8\"\n"
               "ID=mattiaos\n"
               "PRETTY_NAME=\"MattiaOS 2.8\"\n");
    write_file("/etc/fstab",
               "# <device>  <mountpoint>  <type>    <options>  <dump>  <pass>\n"
               "devfs       /dev          devfs     defaults   0       0\n"
               "tmpfs       /tmp          tmpfs     defaults   0       0\n"
               "procfs      /proc         procfs    defaults   0       0\n");

    setup_environment();
}

/* =========================================================================
 * spawn_shell — fork + execve /bin/sh
 * ========================================================================= */
static int spawn_shell(void) {
    int pid = fork();
    if (pid < 0) {
        fprintf(stderr, "[init] fork fallito: %s\n", strerror(errno));
        return -1;
    }
    if (pid == 0) {
        /* Figlio: diventa session leader */
        sys_setsid();
        sys_setpgid(0, 0);

        /* Riapri la console */
        open_console();

        /* Abilita il controllo del terminale */
        sys_ioctl(0, TIOCSPGRP, &(int){getpid()});

        printf("\n"
               " __  __       _   _   _       ___  ____  \n"
               "|  \\/  | __ _| |_| |_(_) __ _/ _ \\/ ___| \n"
               "| |\\/| |/ _` | __| __| |/ _` | | | \\___ \\ \n"
               "| |  | | (_| | |_| |_| | (_| | |_| |___) |\n"
               "|_|  |_|\\__,_|\\__|\\__|_|\\__,_|\\___/|____/ \n"
               "\n"
               "MattiaOS v2.8 — Sistema operativo custom\n"
               "Digita 'help' per la lista dei comandi.\n\n");

        execve(SHELL_PATH, s_shell_argv, s_default_env);
        /* execve non è tornato */
        fprintf(stderr, "[init] execve %s: %s\n", SHELL_PATH, strerror(errno));
        exit(1);
    }
    printf("[init] avviata shell PID %d\n", pid);
    return pid;
}

/* =========================================================================
 * main — PID 1
 * ========================================================================= */
int main(int argc, char **argv, char **envp) {
    (void)argc; (void)argv; (void)envp;

    printf("[init] MattiaOS init avviato (PID %d)\n", getpid());

    /* Monta i filesystem di sistema */
    mount_fs("devfs",  "/dev",  DEVFS_TYPE,  0);
    mount_fs("tmpfs",  "/tmp",  TMPFS_TYPE,  0);
    mount_fs("procfs", "/proc", PROCFS_TYPE, 0);

    /* Costruisce la gerarchia delle directory */
    setup_rootfs();

    /* Apri la console */
    open_console();

    /* Installa handler SIGCHLD per raccogliere zombie */
    signal(SIGCHLD, sigchld_handler);
    signal(SIGINT,  SIG_IGN);
    signal(SIGQUIT, SIG_IGN);
    signal(SIGHUP,  SIG_IGN);
    signal(SIGTERM, SIG_IGN);  /* init non viene terminato */

    /* Avvia la shell */
    int shell_pid = spawn_shell();

    /* Loop principale: raccoglie zombie e riavvia la shell se termina */
    for (;;) {
        /* Aspetta qualsiasi evento figlio */
        int status;
        int dead_pid = sys_wait4(-1, &status, 0);

        if (dead_pid < 0) {
            /* Nessun figlio — dormi e riprova */
            sleep(1);
            continue;
        }

        if (WIFEXITED(status) || WIFSIGNALED(status)) {
            if (dead_pid == shell_pid) {
                /* La shell principale è morta: riavvia dopo 1 secondo */
                printf("[init] shell (PID %d) terminata. Riavvio...\n", dead_pid);
                sleep(1);
                shell_pid = spawn_shell();
            }
        }

        /* Raccoglie altri eventuali zombie rimasti */
        reap_zombies();
    }

    /* Non si arriva mai qui */
    return 0;
}
