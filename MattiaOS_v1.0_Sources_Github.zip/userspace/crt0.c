/*
 * crt0.c — entry point userspace MattiaOS
 *
 * Il kernel salta a _start con lo stack allineato e argc/argv già presenti:
 *   [rsp+0]  = argc (int64)
 *   [rsp+8]  = argv[0] (char*)
 *   ...
 *   [rsp+8*(argc+1)] = NULL  (fine argv)
 *   [rsp+8*(argc+2)] = envp[0] ...
 *
 * _start prepara i registri rdi=argc, rsi=argv, rdx=envp,
 * allinea rsp a 16 byte e chiama main(). Al ritorno chiama exit().
 */

#include "../include/userspace.h"

extern int main(int argc, char **argv, char **envp);

__attribute__((naked, noreturn))
void _start(void) {
    __asm__ __volatile__(
        /* Azzera il frame pointer — ABI x86-64 lo richiede */
        "xorq  %%rbp, %%rbp\n\t"

        /* argc è in [rsp], argv parte da [rsp+8] */
        "movq  (%%rsp),  %%rdi\n\t"          /* rdi = argc              */
        "leaq  8(%%rsp), %%rsi\n\t"          /* rsi = argv              */
        "leaq  8(%%rsi,%%rdi,8), %%rdx\n\t"  /* rdx = envp = argv+argc+1 */

        /* Allinea rsp a 16 byte (obbligatorio prima di call) */
        "andq  $-16, %%rsp\n\t"

        /* Chiama main() */
        "call  main\n\t"

        /* Passa il codice di ritorno a exit() */
        "movq  %%rax, %%rdi\n\t"
        "call  exit\n\t"

        /* Non si dovrebbe mai arrivare qui */
        "hlt"
        ::: "memory"
    );
}
