/*
 * shell.c — mattiaos-sh
 *
 * Funzionalità implementate:
 *  - Tokenizer con gestione singole e doppie virgolette
 *  - Variabili d'ambiente: $VAR, ${VAR}, $$, $?, $!
 *  - Ridirezione I/O: < > >> 2> 2>&1 &> &>>
 *  - Pipe (|) — n stadi
 *  - Background (&) — job tracking
 *  - Builtins: cd, echo, export, unset, exit, pwd, history,
 *              source, alias, unalias, jobs, fg, bg, help, type
 *  - Glob: * ? — espansione tramite getdents
 *  - Ctrl+C interrompe il foreground, non la shell
 *  - History con frecce su/giù e ~/.mattiaos_history
 */

#include "../include/userspace.h"

/* =========================================================================
 * Costanti
 * ========================================================================= */
#define MAX_LINE    4096
#define MAX_ARGS    256
#define MAX_JOBS    64
#define HISTORY_MAX 1000
#define HIST_FILE   "/root/.mattiaos_history"

/* =========================================================================
 * Struttura job
 * ========================================================================= */
typedef enum { JOB_RUNNING, JOB_STOPPED, JOB_DONE } job_state_t;

typedef struct {
    int         pid;
    int         pgid;
    char        cmd[256];
    job_state_t state;
    int         active;
} job_t;

/* =========================================================================
 * Struttura variabile d'ambiente
 * ========================================================================= */
typedef struct {
    char *name;
    char *value;
} env_var_t;

/* =========================================================================
 * Struttura alias
 * ========================================================================= */
typedef struct {
    char *name;
    char *value;
} alias_t;

/* =========================================================================
 * Stato globale della shell
 * ========================================================================= */
static char      *s_history[HISTORY_MAX];
static int        s_history_count = 0;
static job_t      s_jobs[MAX_JOBS];
static int        s_job_count = 0;
static env_var_t  s_env[512];
static int        s_env_count = 0;
static alias_t    s_aliases[128];
static int        s_alias_count = 0;
static int        s_last_status = 0;
static int        s_last_bg_pid = 0;
static int        s_fg_pgid = 0;
static char       s_cwd[4096];
static int        s_interactive = 1;

/* =========================================================================
 * Terminale in modalità raw per editing della riga
 * ========================================================================= */
/* termios — struttura minimale compatibile Linux x86-64 */
struct termios {
    uint32_t c_iflag;
    uint32_t c_oflag;
    uint32_t c_cflag;
    uint32_t c_lflag;
    uint8_t  c_line;
    uint8_t  c_cc[19];
    uint32_t c_ispeed;
    uint32_t c_ospeed;
};
#define TCGETS  0x5401
#define TCSETS  0x5402
#define ICANON  0000002
#define ECHO    0000010
#define ISIG    0000001

static struct termios s_saved_term;
static int            s_raw_mode = 0;

static void term_raw(void) {
    struct termios raw;
    sys_ioctl(0, TCGETS, &s_saved_term);
    raw = s_saved_term;
    raw.c_lflag &= ~(ICANON | ECHO | ISIG);
    raw.c_cc[6] = 1;   /* VMIN = 1 */
    raw.c_cc[5] = 0;   /* VTIME = 0 */
    sys_ioctl(0, TCSETS, &raw);
    s_raw_mode = 1;
}

static void term_restore(void) {
    if (s_raw_mode) {
        sys_ioctl(0, TCSETS, &s_saved_term);
        s_raw_mode = 0;
    }
}

/* =========================================================================
 * Gestione variabili d'ambiente
 * ========================================================================= */
static const char *env_get(const char *name) {
    for (int i = 0; i < s_env_count; i++)
        if (strcmp(s_env[i].name, name) == 0)
            return s_env[i].value;
    return (char *)0;
}

static void env_set(const char *name, const char *value) {
    for (int i = 0; i < s_env_count; i++) {
        if (strcmp(s_env[i].name, name) == 0) {
            free(s_env[i].value);
            s_env[i].value = xstrdup(value);
            return;
        }
    }
    if (s_env_count < 512) {
        s_env[s_env_count].name  = xstrdup(name);
        s_env[s_env_count].value = xstrdup(value);
        s_env_count++;
    }
}

static void env_unset(const char *name) {
    for (int i = 0; i < s_env_count; i++) {
        if (strcmp(s_env[i].name, name) == 0) {
            free(s_env[i].name);
            free(s_env[i].value);
            s_env[i] = s_env[--s_env_count];
            return;
        }
    }
}

/* Costruisce array envp per execve */
static char **build_envp(void) {
    char **ep = xmalloc((s_env_count + 1) * sizeof(char *));
    for (int i = 0; i < s_env_count; i++) {
        size_t n = strlen(s_env[i].name) + strlen(s_env[i].value) + 2;
        ep[i] = xmalloc(n);
        snprintf(ep[i], n, "%s=%s", s_env[i].name, s_env[i].value);
    }
    ep[s_env_count] = (char *)0;
    return ep;
}

/* Popola s_env con le variabili d'ambiente passate a main */
static void init_env(char **envp) {
    if (!envp) return;
    for (int i = 0; envp[i]; i++) {
        char *eq = strchr(envp[i], '=');
        if (!eq) continue;
        *eq = '\0';
        env_set(envp[i], eq + 1);
        *eq = '=';
    }
}

/* =========================================================================
 * Gestione history
 * ========================================================================= */
static void history_add(const char *line) {
    if (!line || !*line) return;
    /* Non aggiungere duplicati consecutivi */
    if (s_history_count > 0 &&
        strcmp(s_history[s_history_count - 1], line) == 0)
        return;
    if (s_history_count == HISTORY_MAX) {
        free(s_history[0]);
        memmove(s_history, s_history + 1,
                (HISTORY_MAX - 1) * sizeof(char *));
        s_history_count--;
    }
    s_history[s_history_count++] = xstrdup(line);
}

static void history_load(void) {
    FILE *f = fopen(HIST_FILE, "r");
    if (!f) return;
    char buf[MAX_LINE];
    while (fgets(buf, sizeof(buf), f)) {
        int l = (int)strlen(buf);
        if (l > 0 && buf[l-1] == '\n') buf[l-1] = '\0';
        history_add(buf);
    }
    fclose(f);
}

static void history_save(void) {
    FILE *f = fopen(HIST_FILE, "w");
    if (!f) return;
    int start = s_history_count > 500 ? s_history_count - 500 : 0;
    for (int i = start; i < s_history_count; i++)
        fprintf(f, "%s\n", s_history[i]);
    fclose(f);
}

/* =========================================================================
 * Editor di riga con storia e editing Readline-like
 * ========================================================================= */
static int read_line_interactive(char *buf, int max) {
    int len = 0, cur = 0, hist_idx = s_history_count;
    char tmp[MAX_LINE] = {0};

    term_raw();

    for (;;) {
        /* Ridisegna riga */
        write(1, "\r", 1);
        char prompt_clear[64];
        snprintf(prompt_clear, sizeof(prompt_clear), "\033[2K");
        write(1, prompt_clear, strlen(prompt_clear));
        buf[len] = '\0';
        write(1, buf, len);
        /* Posiziona cursore */
        if (cur < len) {
            char mv[16];
            snprintf(mv, sizeof(mv), "\033[%dD", len - cur);
            write(1, mv, strlen(mv));
        }

        unsigned char c;
        if (read(0, &c, 1) <= 0) { term_restore(); return -1; }

        if (c == '\n' || c == '\r') {
            write(1, "\r\n", 2);
            break;
        } else if (c == 3) {  /* Ctrl+C */
            write(1, "^C\r\n", 4);
            buf[0] = '\0';
            len = cur = 0;
            break;
        } else if (c == 4 && len == 0) {  /* Ctrl+D su riga vuota */
            term_restore();
            return -1;
        } else if (c == 127 || c == 8) {  /* Backspace / DEL */
            if (cur > 0) {
                memmove(buf + cur - 1, buf + cur, len - cur);
                cur--; len--;
            }
        } else if (c == 27) {  /* Sequenza escape */
            unsigned char seq[3];
            read(0, &seq[0], 1);
            if (seq[0] == '[') {
                read(0, &seq[1], 1);
                if (seq[1] == 'A') {  /* Su — storia precedente */
                    if (hist_idx > 0) {
                        if (hist_idx == s_history_count)
                            strncpy(tmp, buf, MAX_LINE - 1);
                        hist_idx--;
                        strncpy(buf, s_history[hist_idx], max - 1);
                        len = cur = (int)strlen(buf);
                    }
                } else if (seq[1] == 'B') {  /* Giù — storia successiva */
                    if (hist_idx < s_history_count) {
                        hist_idx++;
                        if (hist_idx == s_history_count)
                            strncpy(buf, tmp, max - 1);
                        else
                            strncpy(buf, s_history[hist_idx], max - 1);
                        len = cur = (int)strlen(buf);
                    }
                } else if (seq[1] == 'C') {  /* Destra */
                    if (cur < len) cur++;
                } else if (seq[1] == 'D') {  /* Sinistra */
                    if (cur > 0) cur--;
                } else if (seq[1] == 'H' || seq[1] == '1') {  /* Home */
                    if (seq[1] == '1') read(0, &seq[2], 1);
                    cur = 0;
                } else if (seq[1] == 'F' || seq[1] == '4') {  /* End */
                    if (seq[1] == '4') read(0, &seq[2], 1);
                    cur = len;
                } else if (seq[1] == '3') {  /* Delete */
                    read(0, &seq[2], 1);
                    if (cur < len) {
                        memmove(buf + cur, buf + cur + 1, len - cur - 1);
                        len--;
                    }
                }
            }
        } else if (c >= 32 && c < 127) {  /* Carattere stampabile */
            if (len < max - 1) {
                memmove(buf + cur + 1, buf + cur, len - cur);
                buf[cur++] = (char)c;
                len++;
            }
        }
    }

    term_restore();
    buf[len] = '\0';
    return len;
}

/* =========================================================================
 * Espansione variabili in una stringa
 * ========================================================================= */
static char *expand_vars(const char *s) {
    char *out = xmalloc(MAX_LINE);
    int oi = 0, si = 0;
    int slen = (int)strlen(s);

    while (si < slen && oi < MAX_LINE - 64) {
        if (s[si] == '$') {
            si++;
            char name[256]; int ni = 0;
            if (s[si] == '{') {
                si++;
                while (s[si] && s[si] != '}' && ni < 255)
                    name[ni++] = s[si++];
                if (s[si] == '}') si++;
            } else if (s[si] == '$') {
                si++;
                int pid = getpid();
                char tmp[16];
                snprintf(tmp, sizeof(tmp), "%d", pid);
                int tl = (int)strlen(tmp);
                memcpy(out + oi, tmp, tl); oi += tl;
                continue;
            } else if (s[si] == '?') {
                si++;
                char tmp[8];
                snprintf(tmp, sizeof(tmp), "%d", s_last_status);
                int tl = (int)strlen(tmp);
                memcpy(out + oi, tmp, tl); oi += tl;
                continue;
            } else if (s[si] == '!') {
                si++;
                char tmp[16];
                snprintf(tmp, sizeof(tmp), "%d", s_last_bg_pid);
                int tl = (int)strlen(tmp);
                memcpy(out + oi, tmp, tl); oi += tl;
                continue;
            } else {
                while ((s[si] >= 'a' && s[si] <= 'z') ||
                       (s[si] >= 'A' && s[si] <= 'Z') ||
                       (s[si] >= '0' && s[si] <= '9') ||
                        s[si] == '_')
                    name[ni++] = s[si++];
            }
            name[ni] = '\0';
            const char *val = env_get(name);
            if (val) {
                int vl = (int)strlen(val);
                if (oi + vl < MAX_LINE - 1) { memcpy(out + oi, val, vl); oi += vl; }
            }
        } else if (s[si] == '~' && (si == 0 || s[si-1] == ' ' || s[si-1] == ':')) {
            const char *home = env_get("HOME");
            if (!home) home = "/root";
            int hl = (int)strlen(home);
            if (oi + hl < MAX_LINE - 1) { memcpy(out + oi, home, hl); oi += hl; }
            si++;
        } else {
            out[oi++] = s[si++];
        }
    }
    out[oi] = '\0';
    return out;
}

/* =========================================================================
 * Tokenizer
 * ========================================================================= */
static int tokenize(char *line, char **tokens, int max_tokens) {
    int n = 0;
    char *p = line;

    while (*p && n < max_tokens - 1) {
        while (*p == ' ' || *p == '\t') p++;
        if (!*p || *p == '#') break;

        char buf[MAX_LINE]; int bi = 0;
        int in_single = 0, in_double = 0;

        while (*p) {
            if (in_single) {
                if (*p == '\'') { in_single = 0; p++; continue; }
                buf[bi++] = *p++;
            } else if (in_double) {
                if (*p == '"') { in_double = 0; p++; continue; }
                if (*p == '\\' && (p[1] == '"' || p[1] == '\\' ||
                                    p[1] == '$' || p[1] == '`')) {
                    p++; buf[bi++] = *p++;
                } else if (*p == '$') {
                    /* Espansione dentro doppio apice */
                    char tmp[MAX_LINE]; int ti = 0;
                    tmp[ti++] = *p++;
                    while (*p && *p != ' ' && *p != '"' && *p != '$')
                        tmp[ti++] = *p++;
                    tmp[ti] = '\0';
                    char *exp = expand_vars(tmp);
                    int el = (int)strlen(exp);
                    if (bi + el < MAX_LINE - 1) { memcpy(buf + bi, exp, el); bi += el; }
                    free(exp);
                } else {
                    buf[bi++] = *p++;
                }
            } else {
                if (*p == '\'') { in_single = 1; p++; continue; }
                if (*p == '"')  { in_double = 1; p++; continue; }
                if (*p == '\\' && *(p+1)) { p++; buf[bi++] = *p++; continue; }
                if (*p == ' ' || *p == '\t') break;
                /* Metacaratteri separati */
                if (*p == '|' || *p == '&' || *p == ';' ||
                    *p == '<' || *p == '>') {
                    if (bi > 0) break;  /* Finisci token corrente */
                    /* Leggi il metacarattere come token */
                    char mc[4]; int mi = 0;
                    mc[mi++] = *p++;
                    if ((*p == '&' || *p == '>' || *p == '2') &&
                        (mc[0] == '>' || mc[0] == '&')) {
                        if (mc[0] == '&' && *p == '>' ) mc[mi++] = *p++;
                        else if (mc[0] == '>' && *p == '>') mc[mi++] = *p++;
                    }
                    mc[mi] = '\0';
                    buf[bi++] = '\0';
                    if (bi == 1 && buf[0] == '\0') bi = 0;
                    if (bi > 0) {
                        buf[bi] = '\0';
                        tokens[n++] = xstrdup(buf);
                        bi = 0;
                    }
                    tokens[n++] = xstrdup(mc);
                    break;
                }
                buf[bi++] = *p++;
            }
        }
        if (bi > 0) {
            buf[bi] = '\0';
            /* Espansione variabili (fuori da singole virgolette) */
            char *expanded = expand_vars(buf);
            tokens[n++] = expanded;
        }
    }
    tokens[n] = (char *)0;
    return n;
}

/* =========================================================================
 * Glob — espansione * e ? in una directory
 * ========================================================================= */
static int glob_match(const char *pat, const char *str) {
    while (*pat) {
        if (*pat == '*') {
            pat++;
            if (!*pat) return 1;
            while (*str) {
                if (glob_match(pat, str)) return 1;
                str++;
            }
            return 0;
        } else if (*pat == '?') {
            if (!*str) return 0;
            pat++; str++;
        } else {
            if (*pat != *str) return 0;
            pat++; str++;
        }
    }
    return *str == '\0';
}

/* Espande un pattern glob; ritorna array di stringhe, NULL-terminato */
static char **glob_expand(const char *pattern) {
    /* Dividi dir e base del pattern */
    char dir[4096] = ".";
    char base[256];
    const char *slash = strrchr(pattern, '/');
    if (slash) {
        memcpy(dir, pattern, slash - pattern);
        dir[slash - pattern] = '\0';
        strncpy(base, slash + 1, 255);
    } else {
        strncpy(base, pattern, 255);
    }

    /* Se non ci sono wildcards, ritorna il pattern stesso */
    if (!strchr(pattern, '*') && !strchr(pattern, '?')) {
        char **r = xmalloc(2 * sizeof(char *));
        r[0] = xstrdup(pattern); r[1] = (char *)0;
        return r;
    }

    int fd = open(dir, O_RDONLY, 0);
    if (fd < 0) {
        char **r = xmalloc(2 * sizeof(char *));
        r[0] = xstrdup(pattern); r[1] = (char *)0;
        return r;
    }

    char **matches = xmalloc(256 * sizeof(char *));
    int mc = 0;
    char dbuf[4096];
    int bytes;

    while ((bytes = sys_getdents(fd, dbuf, sizeof(dbuf))) > 0) {
        int off = 0;
        while (off < bytes && mc < 255) {
            struct dirent *d = (struct dirent *)(dbuf + off);
            if (d->d_reclen == 0) break;
            if (strcmp(d->d_name, ".") != 0 && strcmp(d->d_name, "..") != 0) {
                if (glob_match(base, d->d_name)) {
                    char full[4096];
                    if (strcmp(dir, ".") == 0)
                        snprintf(full, sizeof(full), "%s", d->d_name);
                    else
                        snprintf(full, sizeof(full), "%s/%s", dir, d->d_name);
                    matches[mc++] = xstrdup(full);
                }
            }
            off += d->d_reclen;
        }
    }
    close(fd);

    if (mc == 0) {
        free(matches);
        char **r = xmalloc(2 * sizeof(char *));
        r[0] = xstrdup(pattern); r[1] = (char *)0;
        return r;
    }

    /* Ordina i match */
    for (int i = 0; i < mc - 1; i++)
        for (int j = i + 1; j < mc; j++)
            if (strcmp(matches[i], matches[j]) > 0) {
                char *t = matches[i]; matches[i] = matches[j]; matches[j] = t;
            }

    matches[mc] = (char *)0;
    return matches;
}

/* Espande glob in tutto l'array argv */
static char **expand_globs(char **argv, int *argc) {
    char **out = xmalloc(MAX_ARGS * sizeof(char *));
    int oc = 0;
    for (int i = 0; argv[i] && oc < MAX_ARGS - 1; i++) {
        if (strchr(argv[i], '*') || strchr(argv[i], '?')) {
            char **gm = glob_expand(argv[i]);
            for (int j = 0; gm[j] && oc < MAX_ARGS - 1; j++)
                out[oc++] = gm[j];
            free(gm);
        } else {
            out[oc++] = argv[i];
        }
    }
    out[oc] = (char *)0;
    *argc = oc;
    return out;
}

/* =========================================================================
 * Alias
 * ========================================================================= */
static const char *alias_lookup(const char *name) {
    for (int i = 0; i < s_alias_count; i++)
        if (strcmp(s_aliases[i].name, name) == 0)
            return s_aliases[i].value;
    return (char *)0;
}

/* =========================================================================
 * Trovare un eseguibile in PATH
 * ========================================================================= */
static char *find_in_path(const char *name) {
    if (strchr(name, '/')) return xstrdup(name);
    const char *path_env = env_get("PATH");
    if (!path_env) path_env = "/bin:/usr/bin";

    char path_buf[4096];
    strncpy(path_buf, path_env, sizeof(path_buf) - 1);
    char *save, *dir = strtok_r(path_buf, ":", &save);
    while (dir) {
        char full[512];
        snprintf(full, sizeof(full), "%s/%s", dir, name);
        struct stat st;
        if (sys_stat(full, &st) == 0 && !S_ISDIR(st.st_mode))
            return xstrdup(full);
        dir = strtok_r((char *)0, ":", &save);
    }
    return (char *)0;
}

/* =========================================================================
 * Job control
 * ========================================================================= */
static int add_job(int pid, int pgid, const char *cmd) {
    for (int i = 0; i < MAX_JOBS; i++) {
        if (!s_jobs[i].active) {
            s_jobs[i].pid    = pid;
            s_jobs[i].pgid   = pgid;
            s_jobs[i].state  = JOB_RUNNING;
            s_jobs[i].active = 1;
            strncpy(s_jobs[i].cmd, cmd ? cmd : "?", 255);
            if (i >= s_job_count) s_job_count = i + 1;
            return i + 1;  /* job number (1-based) */
        }
    }
    return -1;
}

static void update_jobs(void) {
    int status;
    for (int i = 0; i < s_job_count; i++) {
        if (!s_jobs[i].active) continue;
        int r = sys_wait4(s_jobs[i].pid, &status, WNOHANG | WUNTRACED);
        if (r == s_jobs[i].pid) {
            if (WIFSTOPPED(status)) {
                s_jobs[i].state = JOB_STOPPED;
            } else {
                s_jobs[i].active = 0;
                if (s_interactive)
                    printf("[%d]+ Done    %s\n", i + 1, s_jobs[i].cmd);
            }
        }
    }
}

/* =========================================================================
 * Segnali della shell
 * ========================================================================= */
static void shell_sigchld(int sig) {
    (void)sig;
    update_jobs();
}

static void shell_sigint(int sig) {
    (void)sig;
    if (s_fg_pgid > 0) sys_kill(-s_fg_pgid, SIGINT);
}

static void shell_sigtstp(int sig) {
    (void)sig;
    if (s_fg_pgid > 0) sys_kill(-s_fg_pgid, SIGTSTP);
}

/* =========================================================================
 * Struttura comando singolo (segmento di una pipeline)
 * ========================================================================= */
typedef struct {
    char *argv[MAX_ARGS];
    int   argc;
    char *redir_in;    /* < file */
    char *redir_out;   /* > file */
    char *redir_app;   /* >> file */
    char *redir_err;   /* 2> file */
    int   redir_err2;  /* 2>&1 */
} cmd_t;

/* =========================================================================
 * Builtins forward declarations
 * ========================================================================= */
static int builtin_cd(char **argv);
static int builtin_echo(char **argv);
static int builtin_export(char **argv);
static int builtin_unset(char **argv);
static int builtin_pwd(char **argv);
static int builtin_history(char **argv);
static int builtin_alias(char **argv);
static int builtin_unalias(char **argv);
static int builtin_jobs(char **argv);
static int builtin_fg(char **argv);
static int builtin_bg(char **argv);
static int builtin_source(char **argv);
static int builtin_help(char **argv);
static int builtin_type(char **argv);

typedef struct { const char *name; int (*fn)(char **argv); } builtin_t;
static builtin_t s_builtins[] = {
    {"cd",      builtin_cd},
    {"echo",    builtin_echo},
    {"export",  builtin_export},
    {"unset",   builtin_unset},
    {"pwd",     builtin_pwd},
    {"history", builtin_history},
    {"alias",   builtin_alias},
    {"unalias", builtin_unalias},
    {"jobs",    builtin_jobs},
    {"fg",      builtin_fg},
    {"bg",      builtin_bg},
    {"source",  builtin_source},
    {".",       builtin_source},
    {"help",    builtin_help},
    {"type",    builtin_type},
    {(char*)0,  (void*)0}
};

/* =========================================================================
 * Builtins
 * ========================================================================= */
static int builtin_cd(char **argv) {
    const char *dir = argv[1];
    if (!dir || strcmp(dir, "~") == 0) {
        dir = env_get("HOME");
        if (!dir) dir = "/root";
    }
    if (chdir(dir) < 0) {
        fprintf(stderr, "cd: %s: %s\n", dir, strerror(errno));
        return 1;
    }
    getcwd(s_cwd, sizeof(s_cwd));
    env_set("PWD", s_cwd);
    return 0;
}

static int builtin_echo(char **argv) {
    int newline = 1, interpret = 0;
    int start = 1;
    while (argv[start] && argv[start][0] == '-') {
        if (strcmp(argv[start], "-n") == 0) { newline = 0; start++; }
        else if (strcmp(argv[start], "-e") == 0) { interpret = 1; start++; }
        else break;
    }
    for (int i = start; argv[i]; i++) {
        if (i > start) write(1, " ", 1);
        const char *s = argv[i];
        if (!interpret) {
            write(1, s, strlen(s));
        } else {
            while (*s) {
                if (*s == '\\' && *(s+1)) {
                    s++;
                    switch (*s) {
                    case 'n': write(1, "\n", 1); break;
                    case 't': write(1, "\t", 1); break;
                    case 'r': write(1, "\r", 1); break;
                    case '\\': write(1, "\\", 1); break;
                    case '0': write(1, "\0", 1); break;
                    default: write(1, "\\", 1); write(1, s, 1); break;
                    }
                } else {
                    write(1, s, 1);
                }
                s++;
            }
        }
    }
    if (newline) write(1, "\n", 1);
    return 0;
}

static int builtin_export(char **argv) {
    if (!argv[1]) {
        for (int i = 0; i < s_env_count; i++)
            printf("export %s=%s\n", s_env[i].name, s_env[i].value);
        return 0;
    }
    for (int i = 1; argv[i]; i++) {
        char *eq = strchr(argv[i], '=');
        if (eq) {
            *eq = '\0';
            env_set(argv[i], eq + 1);
            *eq = '=';
        } else {
            /* Solo esporta (già presente) */
        }
    }
    return 0;
}

static int builtin_unset(char **argv) {
    for (int i = 1; argv[i]; i++) env_unset(argv[i]);
    return 0;
}

static int builtin_pwd(char **argv) {
    (void)argv;
    getcwd(s_cwd, sizeof(s_cwd));
    printf("%s\n", s_cwd);
    return 0;
}

static int builtin_history(char **argv) {
    (void)argv;
    int start = s_history_count > 50 ? s_history_count - 50 : 0;
    for (int i = start; i < s_history_count; i++)
        printf("%4d  %s\n", i + 1, s_history[i]);
    return 0;
}

static int builtin_alias(char **argv) {
    if (!argv[1]) {
        for (int i = 0; i < s_alias_count; i++)
            printf("alias %s='%s'\n", s_aliases[i].name, s_aliases[i].value);
        return 0;
    }
    char *eq = strchr(argv[1], '=');
    if (!eq) {
        const char *v = alias_lookup(argv[1]);
        if (v) printf("alias %s='%s'\n", argv[1], v);
        return 0;
    }
    *eq = '\0';
    if (s_alias_count < 128) {
        /* Aggiorna se esiste */
        for (int i = 0; i < s_alias_count; i++) {
            if (strcmp(s_aliases[i].name, argv[1]) == 0) {
                free(s_aliases[i].value);
                s_aliases[i].value = xstrdup(eq + 1);
                *eq = '=';
                return 0;
            }
        }
        s_aliases[s_alias_count].name  = xstrdup(argv[1]);
        s_aliases[s_alias_count].value = xstrdup(eq + 1);
        s_alias_count++;
    }
    *eq = '=';
    return 0;
}

static int builtin_unalias(char **argv) {
    if (!argv[1]) { fprintf(stderr, "unalias: usage: unalias name\n"); return 1; }
    for (int i = 0; i < s_alias_count; i++) {
        if (strcmp(s_aliases[i].name, argv[1]) == 0) {
            free(s_aliases[i].name); free(s_aliases[i].value);
            s_aliases[i] = s_aliases[--s_alias_count];
            return 0;
        }
    }
    return 0;
}

static int builtin_jobs(char **argv) {
    (void)argv;
    for (int i = 0; i < s_job_count; i++) {
        if (!s_jobs[i].active) continue;
        const char *st = s_jobs[i].state == JOB_RUNNING  ? "Running"  :
                         s_jobs[i].state == JOB_STOPPED  ? "Stopped"  : "Done";
        printf("[%d]  %s\t%s\n", i + 1, st, s_jobs[i].cmd);
    }
    return 0;
}

static int builtin_fg(char **argv) {
    int jn = argv[1] ? atoi(argv[1]) - 1 : s_job_count - 1;
    if (jn < 0 || jn >= MAX_JOBS || !s_jobs[jn].active) {
        fprintf(stderr, "fg: no such job\n"); return 1;
    }
    s_jobs[jn].state = JOB_RUNNING;
    s_fg_pgid = s_jobs[jn].pgid;
    sys_kill(-s_jobs[jn].pgid, SIGCONT);
    int status;
    sys_wait4(-s_jobs[jn].pgid, &status, 0);
    s_fg_pgid = 0;
    s_jobs[jn].active = 0;
    return WIFEXITED(status) ? WEXITSTATUS(status) : 1;
}

static int builtin_bg(char **argv) {
    int jn = argv[1] ? atoi(argv[1]) - 1 : s_job_count - 1;
    if (jn < 0 || jn >= MAX_JOBS || !s_jobs[jn].active) {
        fprintf(stderr, "bg: no such job\n"); return 1;
    }
    s_jobs[jn].state = JOB_RUNNING;
    sys_kill(-s_jobs[jn].pgid, SIGCONT);
    printf("[%d] %d\n", jn + 1, s_jobs[jn].pid);
    return 0;
}

static int execute_file(const char *path);

static int builtin_source(char **argv) {
    if (!argv[1]) { fprintf(stderr, "source: usage: source file\n"); return 1; }
    return execute_file(argv[1]);
}

static int builtin_help(char **argv) {
    (void)argv;
    printf("mattiaos-sh — MattiaOS Shell\n\n");
    printf("Builtins:\n");
    for (int i = 0; s_builtins[i].name; i++)
        printf("  %s\n", s_builtins[i].name);
    printf("\nComandi in /bin: ls rm cp mv cat echo mkdir touch find stat ln\n");
    printf("  chmod chown ps kill top mount umount uname free df du dmesg\n");
    printf("  ping ifconfig grep sed wc head tail sort cut edit\n");
    return 0;
}

static int builtin_type(char **argv) {
    if (!argv[1]) return 1;
    for (int i = 0; s_builtins[i].name; i++)
        if (strcmp(s_builtins[i].name, argv[1]) == 0) {
            printf("%s is a shell builtin\n", argv[1]); return 0;
        }
    const char *al = alias_lookup(argv[1]);
    if (al) { printf("%s is aliased to '%s'\n", argv[1], al); return 0; }
    char *p = find_in_path(argv[1]);
    if (p) { printf("%s is %s\n", argv[1], p); free(p); return 0; }
    printf("%s: not found\n", argv[1]); return 1;
}

/* =========================================================================
 * Esecuzione di un comando singolo
 * ========================================================================= */
static int exec_cmd(cmd_t *cmd, int in_fd, int out_fd, int bg) {
    /* Controlla builtin */
    for (int i = 0; s_builtins[i].name; i++) {
        if (strcmp(s_builtins[i].name, cmd->argv[0]) == 0) {
            /* Redirige se necessario */
            int saved_in = -1, saved_out = -1, saved_err = -1;
            if (cmd->redir_in) {
                saved_in = sys_dup(0);
                int fd = open(cmd->redir_in, O_RDONLY, 0);
                if (fd < 0) { fprintf(stderr, "%s: %s\n", cmd->redir_in, strerror(errno)); return 1; }
                sys_dup2(fd, 0); close(fd);
            }
            if (cmd->redir_out) {
                saved_out = sys_dup(1);
                int fd = open(cmd->redir_out, O_WRONLY|O_CREAT|O_TRUNC, 0644);
                if (fd < 0) { fprintf(stderr, "%s: %s\n", cmd->redir_out, strerror(errno)); return 1; }
                sys_dup2(fd, 1); close(fd);
            }
            int r = s_builtins[i].fn(cmd->argv);
            if (saved_in  >= 0) { sys_dup2(saved_in,  0); close(saved_in);  }
            if (saved_out >= 0) { sys_dup2(saved_out, 1); close(saved_out); }
            if (saved_err >= 0) { sys_dup2(saved_err, 2); close(saved_err); }
            return r;
        }
    }

    /* Espansione alias */
    const char *al = alias_lookup(cmd->argv[0]);
    if (al) {
        char alias_line[MAX_LINE];
        snprintf(alias_line, sizeof(alias_line), "%s", al);
        char *atokens[MAX_ARGS];
        tokenize(alias_line, atokens, MAX_ARGS);
        /* Prepend alias tokens */
        char *new_argv[MAX_ARGS];
        int ai = 0;
        for (int i = 0; atokens[i]; i++) new_argv[ai++] = atokens[i];
        for (int i = 1; cmd->argv[i]; i++) new_argv[ai++] = cmd->argv[i];
        new_argv[ai] = (char *)0;
        for (int i = 0; i < ai; i++) cmd->argv[i] = new_argv[i];
        cmd->argv[ai] = (char *)0;
    }

    /* Trova eseguibile */
    char *path = find_in_path(cmd->argv[0]);
    if (!path) {
        fprintf(stderr, "%s: command not found\n", cmd->argv[0]);
        return 127;
    }

    int pid = fork();
    if (pid < 0) { free(path); perror("fork"); return 1; }

    if (pid == 0) {
        /* Figlio */
        sys_setpgid(0, 0);

        /* Collegamento pipe */
        if (in_fd != 0) { sys_dup2(in_fd, 0); close(in_fd); }
        if (out_fd != 1) { sys_dup2(out_fd, 1); close(out_fd); }

        /* Riduzioni I/O */
        if (cmd->redir_in) {
            int fd = open(cmd->redir_in, O_RDONLY, 0);
            if (fd < 0) { fprintf(stderr, "%s: %s\n", cmd->redir_in, strerror(errno)); exit(1); }
            sys_dup2(fd, 0); close(fd);
        }
        if (cmd->redir_out) {
            int fd = open(cmd->redir_out, O_WRONLY|O_CREAT|O_TRUNC, 0644);
            if (fd < 0) { fprintf(stderr, "%s: %s\n", cmd->redir_out, strerror(errno)); exit(1); }
            sys_dup2(fd, 1); close(fd);
        }
        if (cmd->redir_app) {
            int fd = open(cmd->redir_app, O_WRONLY|O_CREAT|O_APPEND, 0644);
            if (fd < 0) { fprintf(stderr, "%s: %s\n", cmd->redir_app, strerror(errno)); exit(1); }
            sys_dup2(fd, 1); close(fd);
        }
        if (cmd->redir_err) {
            int fd = open(cmd->redir_err, O_WRONLY|O_CREAT|O_TRUNC, 0644);
            if (fd < 0) { fprintf(stderr, "%s: %s\n", cmd->redir_err, strerror(errno)); exit(1); }
            sys_dup2(fd, 2); close(fd);
        }
        if (cmd->redir_err2) sys_dup2(1, 2);

        /* Segnali di default nel figlio */
        signal(SIGINT,  SIG_DFL);
        signal(SIGQUIT, SIG_DFL);
        signal(SIGTSTP, SIG_DFL);
        signal(SIGCHLD, SIG_DFL);

        char **envp = build_envp();
        execve(path, cmd->argv, envp);
        fprintf(stderr, "%s: exec: %s\n", path, strerror(errno));
        exit(127);
    }

    free(path);

    if (bg) {
        add_job(pid, pid, cmd->argv[0]);
        s_last_bg_pid = pid;
        printf("[%d] %d\n", s_job_count, pid);
        return 0;
    }

    /* Foreground: aspetta */
    s_fg_pgid = pid;
    int status;
    sys_wait4(pid, &status, 0);
    s_fg_pgid = 0;
    return WIFEXITED(status) ? WEXITSTATUS(status) : 128 + WTERMSIG(status);
}

/* =========================================================================
 * Parser e esecuzione di una riga intera (con pipe)
 * ========================================================================= */
static int execute_line(char *line);

static int execute_file(const char *path) {
    FILE *f = fopen(path, "r");
    if (!f) { fprintf(stderr, "%s: %s\n", path, strerror(errno)); return 1; }
    char buf[MAX_LINE];
    int ret = 0;
    while (fgets(buf, sizeof(buf), f)) {
        /* Rimuovi newline */
        int l = (int)strlen(buf);
        if (l > 0 && buf[l-1] == '\n') buf[l-1] = '\0';
        /* Salta commenti e righe vuote */
        char *p = buf;
        while (*p == ' ' || *p == '\t') p++;
        if (!*p || *p == '#') continue;
        ret = execute_line(buf);
    }
    fclose(f);
    return ret;
}

static int execute_line(char *line) {
    /* Rimuovi spazi iniziali */
    while (*line == ' ' || *line == '\t') line++;
    if (!*line || *line == '#') return 0;

    /* Background flag */
    int bg = 0;
    int len = (int)strlen(line);
    if (len > 0 && line[len-1] == '&') {
        bg = 1;
        line[len-1] = '\0';
    }

    /* Tokenizza */
    char *tokens[MAX_ARGS * 4];
    int tc = tokenize(line, tokens, MAX_ARGS * 4);
    if (tc == 0) return 0;

    /* Dividi per pipe */
    cmd_t cmds[64]; int ncmds = 0;
    memset(&cmds[0], 0, sizeof(cmd_t));
    int ai = 0;

    for (int i = 0; i < tc; i++) {
        if (strcmp(tokens[i], "|") == 0) {
            cmds[ncmds].argc = ai;
            cmds[ncmds].argv[ai] = (char *)0;
            ncmds++;
            memset(&cmds[ncmds], 0, sizeof(cmd_t));
            ai = 0;
        } else if (strcmp(tokens[i], "<") == 0 && tokens[i+1]) {
            cmds[ncmds].redir_in = tokens[++i];
        } else if (strcmp(tokens[i], ">") == 0 && tokens[i+1]) {
            cmds[ncmds].redir_out = tokens[++i];
        } else if (strcmp(tokens[i], ">>") == 0 && tokens[i+1]) {
            cmds[ncmds].redir_app = tokens[++i];
        } else if (strcmp(tokens[i], "2>") == 0 && tokens[i+1]) {
            cmds[ncmds].redir_err = tokens[++i];
        } else if (strcmp(tokens[i], "2>&1") == 0) {
            cmds[ncmds].redir_err2 = 1;
        } else if (strcmp(tokens[i], "&>") == 0 && tokens[i+1]) {
            cmds[ncmds].redir_out = tokens[i+1];
            cmds[ncmds].redir_err2 = 1; i++;
        } else {
            /* Espandi glob */
            if (ai == 0) {
                cmds[ncmds].argv[ai++] = tokens[i];
            } else {
                int gc; char **gexp = expand_globs(&tokens[i], &gc);
                for (int g = 0; g < gc && ai < MAX_ARGS - 1; g++)
                    cmds[ncmds].argv[ai++] = gexp[g];
                free(gexp);
            }
        }
    }
    cmds[ncmds].argc = ai;
    cmds[ncmds].argv[ai] = (char *)0;
    ncmds++;

    if (ncmds == 0 || cmds[0].argc == 0) return 0;

    /* Controllo exit/cd speciali prima della fork */
    if (strcmp(cmds[0].argv[0], "exit") == 0) {
        int code = cmds[0].argv[1] ? atoi(cmds[0].argv[1]) : s_last_status;
        history_save();
        term_restore();
        exit(code);
    }

    /* Pipeline con un solo comando */
    if (ncmds == 1) {
        s_last_status = exec_cmd(&cmds[0], 0, 1, bg);
        return s_last_status;
    }

    /* Pipeline multi-stadio */
    int pipes[63][2];
    for (int i = 0; i < ncmds - 1; i++) sys_pipe(pipes[i]);

    for (int i = 0; i < ncmds; i++) {
        int in_fd  = (i == 0)          ? 0 : pipes[i-1][0];
        int out_fd = (i == ncmds - 1)  ? 1 : pipes[i][1];

        int pid = fork();
        if (pid == 0) {
            /* Chiudi i pipe non usati in questo figlio */
            for (int j = 0; j < ncmds - 1; j++) {
                if (j != i - 1) close(pipes[j][0]);
                if (j != i)     close(pipes[j][1]);
            }
            if (in_fd  != 0) { sys_dup2(in_fd,  0); close(in_fd); }
            if (out_fd != 1) { sys_dup2(out_fd, 1); close(out_fd); }

            signal(SIGINT, SIG_DFL);
            char *path = find_in_path(cmds[i].argv[0]);
            if (!path) { fprintf(stderr, "%s: command not found\n", cmds[i].argv[0]); exit(127); }
            char **envp = build_envp();
            execve(path, cmds[i].argv, envp);
            exit(127);
        }
    }

    /* Genitore: chiude tutti i pipe */
    for (int i = 0; i < ncmds - 1; i++) { close(pipes[i][0]); close(pipes[i][1]); }

    /* Aspetta tutti i figli */
    int last_status = 0;
    for (int i = 0; i < ncmds; i++) {
        int st;
        sys_wait4(-1, &st, 0);
        if (i == ncmds - 1)
            last_status = WIFEXITED(st) ? WEXITSTATUS(st) : 1;
    }
    s_last_status = last_status;
    return last_status;
}

/* =========================================================================
 * Prompt
 * ========================================================================= */
static void print_prompt(void) {
    const char *user = env_get("USER");
    const char *host = env_get("HOSTNAME");
    if (!user) user = "root";
    if (!host) host = "mattiaos";
    getcwd(s_cwd, sizeof(s_cwd));

    /* Abbrevia home */
    const char *home = env_get("HOME");
    char cwd_disp[256];
    if (home && strncmp(s_cwd, home, strlen(home)) == 0) {
        snprintf(cwd_disp, sizeof(cwd_disp), "~%s", s_cwd + strlen(home));
    } else {
        strncpy(cwd_disp, s_cwd, 255);
    }

    int is_root = (getuid() == 0);
    printf("\033[1;32m%s@%s\033[0m:\033[1;34m%s\033[0m%c ",
           user, host, cwd_disp, is_root ? '#' : '$');
    fflush(stdout);
}

/* =========================================================================
 * main
 * ========================================================================= */
int main(int argc, char **argv, char **envp) {
    /* Non-interattiva: esegue un file script */
    int script_mode = 0;
    const char *script_file = (char *)0;

    if (argc >= 2) {
        if (strcmp(argv[1], "-c") == 0 && argc >= 3) {
            /* sh -c 'comando' */
            init_env(envp);
            s_interactive = 0;
            char line[MAX_LINE];
            strncpy(line, argv[2], MAX_LINE - 1);
            return execute_line(line);
        } else {
            script_file = argv[1];
            script_mode = 1;
        }
    }

    init_env(envp);
    getcwd(s_cwd, sizeof(s_cwd));
    env_set("PWD", s_cwd);

    if (script_mode) {
        s_interactive = 0;
        return execute_file(script_file);
    }

    /* Modalità interattiva */
    s_interactive = 1;
    history_load();

    /* Installa alias di default */
    builtin_alias((char*[]){"alias", "ll=ls -la", (char*)0});
    builtin_alias((char*[]){"alias", "la=ls -a", (char*)0});
    builtin_alias((char*[]){"alias", "..=cd ..", (char*)0});
    builtin_alias((char*[]){"alias", "...=cd ../..", (char*)0});

    signal(SIGINT,  shell_sigint);
    signal(SIGTSTP, shell_sigtstp);
    signal(SIGCHLD, shell_sigchld);
    signal(SIGQUIT, SIG_IGN);

    char line[MAX_LINE];
    while (1) {
        update_jobs();
        print_prompt();

        int r = read_line_interactive(line, MAX_LINE);
        if (r < 0) {
            printf("\nexit\n");
            break;
        }
        if (r == 0) continue;

        history_add(line);
        s_last_status = execute_line(line);
    }

    history_save();
    return s_last_status;
}
