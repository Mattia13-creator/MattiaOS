#include "gdt.h"

static gdt_t   s_gdt;
static gdtr_t  s_gdtr;
tss_t          g_tss;

/* Stack statici per IST — 8KB ciascuno, allineati 16 byte */
#define IST_STACK_SIZE 8192
static uint8_t s_ist1_stack[IST_STACK_SIZE] __attribute__((aligned(16))); /* double fault */
static uint8_t s_ist2_stack[IST_STACK_SIZE] __attribute__((aligned(16))); /* NMI          */
static uint8_t s_ist3_stack[IST_STACK_SIZE] __attribute__((aligned(16))); /* machine check */
static uint8_t s_kernel_stack[IST_STACK_SIZE] __attribute__((aligned(16))); /* RSP0        */

static void gdt_set_entry(int index, uint32_t base, uint32_t limit, uint8_t access, uint8_t gran) {
    s_gdt.entries[index].base_low   = base & 0xFFFF;
    s_gdt.entries[index].base_mid   = (base >> 16) & 0xFF;
    s_gdt.entries[index].base_high  = (base >> 24) & 0xFF;
    s_gdt.entries[index].limit_low  = limit & 0xFFFF;
    s_gdt.entries[index].granularity = ((limit >> 16) & 0x0F) | (gran & 0xF0);
    s_gdt.entries[index].access     = access;
}

static void gdt_set_tss(int index, uint64_t base, uint32_t limit) {
    s_gdt.entries[index].limit_low   = limit & 0xFFFF;
    s_gdt.entries[index].base_low    = base & 0xFFFF;
    s_gdt.entries[index].base_mid    = (base >> 16) & 0xFF;
    s_gdt.entries[index].access      = 0x89;
    s_gdt.entries[index].granularity = ((limit >> 16) & 0x0F);
    s_gdt.entries[index].base_high   = (base >> 24) & 0xFF;
    s_gdt.tss_high.base_higher       = (base >> 32) & 0xFFFFFFFF;
    s_gdt.tss_high.reserved          = 0;
}

extern void gdt_flush(gdtr_t *gdtr);
extern void tss_flush(uint16_t sel);

void gdt_init(void) {
    gdt_set_entry(0, 0, 0,          0x00, 0x00); /* null */
    gdt_set_entry(1, 0, 0xFFFFF,    0x9A, 0xA0); /* kernel code 64-bit */
    gdt_set_entry(2, 0, 0xFFFFF,    0x92, 0xC0); /* kernel data */
    gdt_set_entry(3, 0, 0xFFFFF,    0xFA, 0xC0); /* user code 32-bit */
    gdt_set_entry(4, 0, 0xFFFFF,    0xF2, 0xC0); /* user data */
    gdt_set_entry(5, 0, 0xFFFFF,    0xFA, 0xA0); /* user code 64-bit */

    __builtin_memset(&g_tss, 0, sizeof(tss_t));
    g_tss.iopb_offset = sizeof(tss_t);

    /* IST stacks: top-of-stack = base + size (stack cresce verso il basso) */
    g_tss.ist[0] = (uint64_t)(s_ist1_stack + IST_STACK_SIZE); /* IST1: double fault  */
    g_tss.ist[1] = (uint64_t)(s_ist2_stack + IST_STACK_SIZE); /* IST2: NMI           */
    g_tss.ist[2] = (uint64_t)(s_ist3_stack + IST_STACK_SIZE); /* IST3: machine check */

    /* RSP0: stack del kernel per interrupt da ring 3 */
    g_tss.rsp[0] = (uint64_t)(s_kernel_stack + IST_STACK_SIZE);

    gdt_set_tss(6, (uint64_t)&g_tss, sizeof(tss_t) - 1);

    s_gdtr.size   = sizeof(s_gdt) - 1;
    s_gdtr.offset = (uint64_t)&s_gdt;

    gdt_flush(&s_gdtr);
    tss_flush(TSS_SEL);
}

void tss_set_rsp0(uint64_t rsp0) {
    g_tss.rsp[0] = rsp0;
}
