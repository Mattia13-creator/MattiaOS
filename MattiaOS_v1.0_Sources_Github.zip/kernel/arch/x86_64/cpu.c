#include "cpu.h"
#include <stdarg.h>

/* ─────────────────────────────────────────────────────────────────────────────
 * Serial / logging — MattiaOS v3.3
 * Livelli:  [BOOT] [OK] [INFO] [WARN] [ERROR] [PANIC]
 * Output:   COM1 (0x3F8) a 38400 baud + porta 0xE9 (VirtualBox/QEMU debug)
 * ───────────────────────────────────────────────────────────────────────── */

/* ─────────────────────────────────────────────────────────────────────────────
 * PIC 8259 — rimappaggio e mascheratura
 *
 * Il BIOS configura il PIC master con IRQ0-7 → vettori 0x08-0x0F, che
 * si sovrappongono esattamente alle eccezioni CPU (Double Fault, NMI, ecc.).
 * In particolare IRQ1 (tastiera PS/2) verrebbe mappato al vettore 0x09
 * (Coprocessor Segment Overrun) causando un KERNEL PANIC ad ogni keypress.
 *
 * Soluzione: rimappare entrambi i PIC prima di sti(), poi mascherare
 * tutti gli IRQ inutilizzati.  Il sistema usa il LAPIC per il timer
 * (vettore 0x20) e il PIC legacy per gli IRQ periferici (kbd/mouse).
 *
 * Registri PIC:
 *   Master: command=0x20, data=0x21
 *   Slave:  command=0xA0, data=0xA1
 * ───────────────────────────────────────────────────────────────────────── */

#define PIC_MASTER_CMD   0x20
#define PIC_MASTER_DATA  0x21
#define PIC_SLAVE_CMD    0xA0
#define PIC_SLAVE_DATA   0xA1
#define PIC_EOI          0x20

void pic_init(void) {
    /*
     * ICW1 — avvio sequenza di inizializzazione.
     * 0x11 = bit0 (ICW4 necessario) + bit4 (init command).
     * io_wait() dopo ogni write: il PIC 8259 fisico richiede ~1µs tra comandi.
     * In VirtualBox è meno critico ma rispettare i timing evita bug.
     */
    outb(PIC_MASTER_CMD,  0x11); io_wait();
    outb(PIC_SLAVE_CMD,   0x11); io_wait();

    /*
     * ICW2 — offset vettore.
     * Master: IRQ0-7 → vettori 0x20-0x27.
     * Slave:  IRQ8-15 → vettori 0x28-0x2F → IRQ12 = 0x28+4 = 0x2C (mouse).
     */
    outb(PIC_MASTER_DATA, 0x20); io_wait();
    outb(PIC_SLAVE_DATA,  0x28); io_wait();

    /*
     * ICW3 — configurazione cascata.
     * Master: bit2=1 → slave collegato su linea IRQ2.
     * Slave:  0x02   → cascade identity number = 2.
     */
    outb(PIC_MASTER_DATA, 0x04); io_wait();
    outb(PIC_SLAVE_DATA,  0x02); io_wait();

    /*
     * ICW4 — modalità operativa.
     * 0x01 = modalità 8086/88 (non MCS-80).
     */
    outb(PIC_MASTER_DATA, 0x01); io_wait();
    outb(PIC_SLAVE_DATA,  0x01); io_wait();

    /*
     * OCW1 — Interrupt Mask Register.
     * Bit=1 maschera l'IRQ corrispondente, bit=0 lo abilita.
     *
     * Master (porta 0x21):
     *   IRQ0 PIT timer  → mascherato (usiamo LAPIC timer)
     *   IRQ1 kbd PS/2   → ATTIVO (vettore 0x21)
     *   IRQ2 cascata    → ATTIVO (necessario per slave)
     *   IRQ3-7          → mascherati
     *   Valore: 11111001b = 0xF9
     *
     * Slave (porta 0xA1):
     *   IRQ12 mouse PS/2 → ATTIVO (vettore 0x2C)
     *   tutti gli altri  → mascherati
     *   Valore: 11101111b = 0xEF
     */
    outb(PIC_MASTER_DATA, 0xF9); io_wait();
    outb(PIC_SLAVE_DATA,  0xEF); io_wait();

    serial_puts("[PIC] 8259 rimappato: master=0x20, slave=0x28. IMR: master=0xF9 slave=0xEF\r\n");
}

void serial_init(void) {
    outb(COM1_PORT + 1, 0x00);
    outb(COM1_PORT + 3, 0x80);
    outb(COM1_PORT + 0, 0x03);   /* 38400 baud */
    outb(COM1_PORT + 1, 0x00);
    outb(COM1_PORT + 3, 0x03);   /* 8N1 */
    outb(COM1_PORT + 2, 0xC7);   /* FIFO */
    outb(COM1_PORT + 4, 0x0B);
}

void serial_putchar(char c) {
    while (!(inb(COM1_PORT + 5) & 0x20));
    outb(COM1_PORT, (uint8_t)c);
    outb(0xE9, (uint8_t)c);   /* Porta debug VirtualBox/QEMU */
}

void serial_puts(const char *s) {
    while (*s) serial_putchar(*s++);
}

static void serial_put_hex64(uint64_t v, int width) {
    static const char hex[] = "0123456789ABCDEF";
    char buf[17];
    int i;
    for (i = 15; i >= 0; i--) { buf[i] = hex[v & 0xF]; v >>= 4; }
    buf[16] = '\0';
    int start = 0;
    while (start < 15 && buf[start] == '0' && (16 - start) > width) start++;
    serial_puts(buf + start);
}

static void serial_put_dec(int64_t v) {
    char buf[22]; int i = 21; int neg = 0; buf[21] = '\0';
    if (v < 0) { neg = 1; v = -v; }
    if (v == 0) { serial_putchar('0'); return; }
    while (v > 0) { buf[--i] = '0' + (int)(v % 10); v /= 10; }
    if (neg) buf[--i] = '-';
    serial_puts(buf + i);
}

static void serial_put_udec(uint64_t v) {
    char buf[21]; int i = 20; buf[20] = '\0';
    if (v == 0) { serial_putchar('0'); return; }
    while (v > 0) { buf[--i] = '0' + (int)(v % 10); v /= 10; }
    serial_puts(buf + i);
}

/* serial_printf: %s %c %d %u %x %X %lx %lX %p %% */
void serial_printf(const char *fmt, ...) {
    va_list ap; va_start(ap, fmt);
    for (const char *p = fmt; *p; p++) {
        if (*p != '%') { serial_putchar(*p); continue; }
        p++; int il = 0;
        if (*p == 'l') { il = 1; p++; }
        switch (*p) {
        case 's': { const char *s = va_arg(ap, const char *); serial_puts(s ? s : "(null)"); break; }
        case 'c': serial_putchar((char)va_arg(ap, int)); break;
        case 'd': serial_put_dec(il ? va_arg(ap,int64_t) : (int64_t)va_arg(ap,int)); break;
        case 'u': serial_put_udec(il ? va_arg(ap,uint64_t) : (uint64_t)va_arg(ap,unsigned int)); break;
        case 'x': case 'X': { uint64_t v = il ? va_arg(ap,uint64_t):(uint64_t)va_arg(ap,unsigned int); serial_put_hex64(v,il?16:8); break; }
        case 'p': serial_puts("0x"); serial_put_hex64((uint64_t)(uintptr_t)va_arg(ap,void*),16); break;
        case '%': serial_putchar('%'); break;
        default:  serial_putchar('%'); serial_putchar(*p); break;
        }
    }
    va_end(ap);
}

/* klog: log con livello + sottosistema */
void klog(int level, const char *sub, const char *fmt, ...) {
    static const char * const pfx[] = {
        "\r\n[ BOOT ] ", "\r\n[  OK  ] ", "\r\n[ INFO ] ",
        "\r\n[ WARN ] ", "\r\n[ERROR ] ", "\r\n[PANIC ] ",
    };
    if ((unsigned)level > 5) level = 2;
    serial_puts(pfx[level]);
    if (sub) { serial_putchar('['); serial_puts(sub); serial_puts("] "); }
    va_list ap; va_start(ap, fmt);
    for (const char *p = fmt; *p; p++) {
        if (*p != '%') { serial_putchar(*p); continue; }
        p++; int il = 0;
        if (*p == 'l') { il = 1; p++; }
        switch (*p) {
        case 's': { const char *s = va_arg(ap,const char *); serial_puts(s?s:"(null)"); break; }
        case 'c': serial_putchar((char)va_arg(ap,int)); break;
        case 'd': serial_put_dec(il?va_arg(ap,int64_t):(int64_t)va_arg(ap,int)); break;
        case 'u': serial_put_udec(il?va_arg(ap,uint64_t):(uint64_t)va_arg(ap,unsigned int)); break;
        case 'x': case 'X': { uint64_t v=il?va_arg(ap,uint64_t):(uint64_t)va_arg(ap,unsigned int); serial_put_hex64(v,il?16:8); break; }
        case 'p': serial_puts("0x"); serial_put_hex64((uint64_t)(uintptr_t)va_arg(ap,void*),16); break;
        case '%': serial_putchar('%'); break;
        default:  serial_putchar('%'); serial_putchar(*p); break;
        }
    }
    va_end(ap);
}

/* ─────────────────────────────────────────────────────────────────────────────
 * VGA text mode driver — 80×25, mappa a 0xB8000 (identity-mapped)
 * Usato per output su schermo prima che il framebuffer sia disponibile.
 * ───────────────────────────────────────────────────────────────────────── */

#define VGA_BASE       ((volatile uint16_t *)0xB8000)
#define VGA_COLS       80
#define VGA_ROWS       25
#define VGA_ATTR_KERN  0x0F00   /* bright white: messaggi kernel */
#define VGA_ATTR_OK    0x0A00   /* light green: OK */
#define VGA_ATTR_WARN  0x0E00   /* yellow: WARN */
#define VGA_ATTR_ERR   0x0C00   /* light red: ERROR/PANIC */

static int vga_row = 0;
static int vga_col = 0;

/* ── Scrollback buffer ───────────────────────────────────────────────────
 * Ogni volta che vga_scroll() fa scivolare una riga fuori dallo schermo,
 * la salviamo qui. Ring buffer di SB_LINES righe × 80 celle (uint16_t).
 * Budget BSS: 100 × 80 × 2 = 16KB.
 * SB_LINES deve essere potenza di 2 per la logica modulo. */
#define SB_LINES  128
#define SB_MASK   (SB_LINES - 1)
static uint16_t s_sb_buf[SB_LINES][VGA_COLS];   /* ring buffer righe */
static int      s_sb_head = 0;   /* prossimo slot di scrittura */
static int      s_sb_count = 0;  /* quante righe salvate (max SB_LINES) */

/* ── Cursore hardware VGA ────────────────────────────────────────────────
 * Il VGA text mode ha un cursore hardware programmabile via I/O 0x3D4/0x3D5.
 * Registro 0x0E = byte alto posizione, 0x0F = byte basso (offset in celle).
 * va chiamata ogni volta che vga_row/vga_col cambiano. */
void vga_update_cursor(void) {
    uint16_t pos = (uint16_t)(vga_row * VGA_COLS + vga_col);
    outb(0x3D4, 0x0F); outb(0x3D5, (uint8_t)(pos & 0xFF));
    outb(0x3D4, 0x0E); outb(0x3D5, (uint8_t)(pos >> 8));
}

/* Legge la posizione corrente del cursore software */
void vga_get_pos(int *row, int *col) {
    if (row) *row = vga_row;
    if (col) *col = vga_col;
}

/* Imposta la posizione cursore software + hardware */
void vga_set_pos(int row, int col) {
    if (row < 0) row = 0;
    if (col < 0) col = 0;
    if (row >= VGA_ROWS) row = VGA_ROWS - 1;
    if (col >= VGA_COLS) col = VGA_COLS - 1;
    vga_row = row; vga_col = col;
    vga_update_cursor();
}

/* Scrive un carattere direttamente a una posizione assoluta (row, col)
 * senza muovere il cursore software. Usato per line editing. */
void vga_write_at(int row, int col, char c, uint16_t attr) {
    if (row < 0 || row >= VGA_ROWS || col < 0 || col >= VGA_COLS) return;
    VGA_BASE[row * VGA_COLS + col] = attr | (uint8_t)c;
}

/* Posiziona SOLO il cursore hardware (senza cambiare row/col software).
 * Usato dalla console per posizionare il cursore dentro la riga di input. */
void vga_set_cursor_hw(int row, int col) {
    if (row < 0) row = 0;
    if (col < 0) col = 0;
    if (row >= VGA_ROWS) row = VGA_ROWS-1;
    if (col >= VGA_COLS) col = VGA_COLS-1;
    uint16_t pos = (uint16_t)(row * VGA_COLS + col);
    outb(0x3D4, 0x0F); outb(0x3D5, (uint8_t)(pos & 0xFF));
    outb(0x3D4, 0x0E); outb(0x3D5, (uint8_t)(pos >> 8));
}

static void vga_scroll(void) {
    /* Salva la riga 0 (quella che sta per scomparire) nel scrollback */
    for (int c = 0; c < VGA_COLS; c++)
        s_sb_buf[s_sb_head][c] = VGA_BASE[c];
    s_sb_head = (s_sb_head + 1) & SB_MASK;
    if (s_sb_count < SB_LINES) s_sb_count++;

    for (int r = 0; r < VGA_ROWS - 1; r++)
        for (int c = 0; c < VGA_COLS; c++)
            VGA_BASE[r * VGA_COLS + c] = VGA_BASE[(r+1) * VGA_COLS + c];
    for (int c = 0; c < VGA_COLS; c++)
        VGA_BASE[(VGA_ROWS-1) * VGA_COLS + c] = VGA_ATTR_KERN | ' ';
    vga_row = VGA_ROWS - 1;
    vga_col = 0;
}

/* Ritorna quante righe di scrollback sono disponibili */
int vga_sb_lines(void) { return s_sb_count; }

/* Renderizza la vista scrollback partendo `offset` righe prima della
 * riga più recente (offset=1 = ultima riga salvata, offset=SB_LINES = la più vecchia).
 * Mostra VGA_ROWS-1 righe di storia + riga 24 con status bar gialla.
 * Non modifica vga_row/vga_col — il cursore rimane dove era. */
void vga_scrollback_render(int offset) {
    if (offset < 1) offset = 1;
    if (offset > s_sb_count) offset = s_sb_count;

    /* Le righe da mostrare: le più recenti sono le più alte in schermo.
     * Riga VGA 0 = la più vecchia, riga VGA ROWS-2 = la più recente visibile. */
    int rows_to_show = VGA_ROWS - 1;  /* ultima riga = status bar */
    for (int vrow = 0; vrow < rows_to_show; vrow++) {
        /* vrow=0 corrisponde alla riga (offset + rows_to_show - 1 - vrow) righe fa */
        int ago = offset + (rows_to_show - 1 - vrow);
        if (ago > s_sb_count) {
            /* Fuori range: riga vuota */
            for (int c = 0; c < VGA_COLS; c++)
                VGA_BASE[vrow * VGA_COLS + c] = 0x0800 | ' ';
        } else {
            /* ago=1 → ultima riga salvata → indice (s_sb_head-1) & MASK */
            int idx = (s_sb_head - ago + SB_LINES) & SB_MASK;
            for (int c = 0; c < VGA_COLS; c++)
                VGA_BASE[vrow * VGA_COLS + c] = s_sb_buf[idx][c];
        }
    }
    /* Status bar riga 24 */
    uint16_t bar = 0x8E00;  /* giallo su sfondo grigio scuro */
    const char *msg = " [SCROLL] frecce su/giu   ESC/Invio = esci ";
    int col = 0;
    for (int i = 0; msg[i] && col < VGA_COLS; i++, col++)
        VGA_BASE[24 * VGA_COLS + col] = bar | (uint8_t)msg[i];
    /* Stampa offset/count a destra */
    char tmp[12]; int ti = 0;
    tmp[ti++] = ' ';
    if (s_sb_count == 0) { tmp[ti++] = '0'; } else {
        int n = s_sb_count; char d[6]; int di = 0;
        while (n > 0) { d[di++] = '0' + n % 10; n /= 10; }
        while (di > 0) tmp[ti++] = d[--di];
    }
    tmp[ti++] = '/';
    {
        int n = offset; char d[6]; int di = 0;
        if (n == 0) { tmp[ti++] = '0'; } else {
            while (n > 0) { d[di++] = '0' + n % 10; n /= 10; }
            while (di > 0) tmp[ti++] = d[--di];
        }
    }
    tmp[ti++] = ' '; tmp[ti] = '\0';
    /* stampa a destra */
    int start = VGA_COLS - ti;
    for (int i = 0; i < ti && start + i < VGA_COLS; i++)
        VGA_BASE[24 * VGA_COLS + start + i] = bar | (uint8_t)tmp[i];
}

void vga_putchar_attr(char c, uint16_t attr) {
    if (c == '\r') { vga_col = 0; vga_update_cursor(); return; }
    if (c == '\n') {
        vga_col = 0; vga_row++;
        if (vga_row >= VGA_ROWS) vga_scroll();
        vga_update_cursor(); return;
    }
    if (c == '\b') {
        /* Backspace: muovi cursore a sinistra senza cancellare (la console
         * fa da sola la sequenza \b ' ' \b per cancellare) */
        if (vga_col > 0) { vga_col--; }
        else if (vga_row > 0) { vga_row--; vga_col = VGA_COLS - 1; }
        vga_update_cursor(); return;
    }
    if (vga_row >= VGA_ROWS) vga_scroll();
    VGA_BASE[vga_row * VGA_COLS + vga_col] = attr | (uint8_t)c;
    if (++vga_col >= VGA_COLS) { vga_col = 0; vga_row++; }
    vga_update_cursor();
}

void vga_puts_attr(const char *s, uint16_t attr) {
    while (*s) vga_putchar_attr(*s++, attr);
}

/* Pulisce lo schermo e resetta il cursore */
void vga_clear(void) {
    for (int i = 0; i < VGA_ROWS * VGA_COLS; i++)
        VGA_BASE[i] = VGA_ATTR_KERN | ' ';
    vga_row = vga_col = 0;
    vga_update_cursor();
}

/* Stampa un banner iniziale */
void vga_banner(const char *version) {
    vga_clear();
    /* Riga 0: barra orizzontale */
    uint16_t bar_attr = 0x1F00;  /* bright white on blue */
    for (int i = 0; i < VGA_COLS; i++)
        VGA_BASE[i] = bar_attr | ' ';
    /* Riga 0: testo centrato */
    const char *title = "  MattiaOS :: Kernel Boot  ";
    int tlen = 0;
    while (title[tlen]) tlen++;
    int start = (VGA_COLS - tlen) / 2;
    for (int i = 0; i < tlen; i++)
        VGA_BASE[start + i] = bar_attr | (uint8_t)title[i];
    /* Versione a destra */
    int vlen = 0;
    while (version[vlen]) vlen++;
    for (int i = 0; i < vlen && i < 15; i++)
        VGA_BASE[VGA_COLS - vlen - 1 + i] = bar_attr | (uint8_t)version[i];
    vga_row = 1;
    vga_col = 0;
    /* Riga vuota */
    vga_puts_attr("\n", VGA_ATTR_KERN);
}
