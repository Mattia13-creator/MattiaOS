#ifndef MATTIAOS_ENTRY_H
#define MATTIAOS_ENTRY_H

/*
 * kernel/arch/x86_64/entry.h — punto di ingresso kernel
 *
 * entry.c implementa kernel_main() chiamata direttamente dal boot loader
 * (Limine) tramite il linker script.  Non ha API pubblica: le strutture
 * dati Limine (fb_request, memmap_request, …) usate da altri moduli
 * sono dichiarate extern nei rispettivi header (fb.h, pmm.h, vmm.h).
 */

/* Dichiarazione simbolo di entrata — usata dal linker script */
void kernel_main(void);

#endif /* MATTIAOS_ENTRY_H */
