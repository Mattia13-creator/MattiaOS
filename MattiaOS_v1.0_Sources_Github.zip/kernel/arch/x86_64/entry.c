#include <limine.h>
#include "gdt.h"
#include "idt.h"
#include "apic.h"
#include "cpu.h"
#include "../mm/pmm.h"
#include "../mm/vmm.h"
#include "../mm/slab.h"
#include "../acpi/acpi.h"
#include "../fs/vfs.h"
#include "../fs/tmpfs.h"
#include "../fs/devfs.h"
#include "../drivers/pci.h"
#include "../drivers/input/keyboard.h"
#include "../drivers/input/ps2.h"

/* ── Limine boot protocol requests ─────────────────────────────────────── */
__attribute__((used, section(".limine_requests_start")))
static volatile LIMINE_REQUESTS_START_MARKER;
__attribute__((used, section(".limine_requests")))
static volatile LIMINE_BASE_REVISION(2);
__attribute__((used, section(".limine_requests")))
volatile struct limine_framebuffer_request fb_request = {
    .id = LIMINE_FRAMEBUFFER_REQUEST, .revision = 0 };
__attribute__((used, section(".limine_requests")))
static volatile struct limine_memmap_request memmap_request = {
    .id = LIMINE_MEMMAP_REQUEST, .revision = 0 };
__attribute__((used, section(".limine_requests")))
static volatile struct limine_kernel_address_request kaddr_request = {
    .id = LIMINE_KERNEL_ADDRESS_REQUEST, .revision = 0 };
__attribute__((used, section(".limine_requests")))
static volatile struct limine_hhdm_request hhdm_request = {
    .id = LIMINE_HHDM_REQUEST, .revision = 0 };
__attribute__((used, section(".limine_requests")))
static volatile struct limine_rsdp_request rsdp_request = {
    .id = LIMINE_RSDP_REQUEST, .revision = 0 };
__attribute__((used, section(".limine_requests")))
static volatile struct limine_smp_request smp_request = {
    .id = LIMINE_SMP_REQUEST, .revision = 0 };
__attribute__((used, section(".limine_requests_end")))
static volatile LIMINE_REQUESTS_END_MARKER;

extern void pci_enumerate(void);
extern void drivers_init(void);

#include "../proc/process.h"

#define MATTIAOS_VERSION "v5.7"

/* ═══════════════════════════════════════════════════════════════════════════
 * UTILITY INTERNE (no libc)
 * ═══════════════════════════════════════════════════════════════════════════ */

static void u64_to_dec(uint64_t v, char *out) {
    char tmp[22]; int i = 20; tmp[21] = 0;
    if (v == 0) { out[0] = '0'; out[1] = 0; return; }
    while (v > 0) { tmp[--i] = '0' + (int)(v % 10); v /= 10; }
    int j = 0; while (tmp[i]) out[j++] = tmp[i++]; out[j] = 0;
}

/* Converte int con segno in stringa decimale (per codici errno negativi) */
static void int_to_dec(int v, char *out) {
    if (v >= 0) { u64_to_dec((uint64_t)v, out); return; }
    out[0] = '-'; u64_to_dec((uint64_t)(-v), out + 1);
}

static int kstrcmp(const char *a, const char *b) {
    while (*a && *b && *a == *b) { a++; b++; }
    return (unsigned char)*a - (unsigned char)*b;
}

static int kstrncmp(const char *a, const char *b, size_t n) {
    for (size_t i = 0; i < n; i++) {
        if (a[i] != b[i]) return (unsigned char)a[i] - (unsigned char)b[i];
        if (!a[i]) return 0;
    }
    return 0;
}

/* ═══════════════════════════════════════════════════════════════════════════
 * LOGGING: klog_vga + klog_detail
 * ═══════════════════════════════════════════════════════════════════════════ */

void klog_vga(int level, const char *sub, const char *msg) {
    static const char * const pfx_ser[] = {
        "[BOOT] ", "[OK]   ", "[INFO] ", "[WARN] ", "[ERROR]", "[PANIC]" };
    static const uint16_t pfx_vga[] = {
        0x0700, 0x0A00, 0x0B00, 0x0E00, 0x0C00, 0x0C00 };
    if ((unsigned)level > 5) level = 2;

    /* VGA PRIMA — garantisce output visuale anche se serial si blocca */
    uint16_t a = pfx_vga[level];
    vga_puts_attr(pfx_ser[level], a); vga_putchar_attr(' ', a);
    if (sub) {
        vga_putchar_attr('[', 0x0800); vga_puts_attr(sub, 0x0800);
        vga_putchar_attr(']', 0x0800); vga_putchar_attr(' ', 0x0700);
    }
    vga_puts_attr(msg, 0x0F00); vga_putchar_attr('\n', 0x0700);

    /* Serial dopo */
    serial_puts("\r\n"); serial_puts(pfx_ser[level]); serial_putchar(' ');
    if (sub) { serial_putchar('['); serial_puts(sub); serial_puts("] "); }
    serial_puts(msg);
}

static void klog_detail(const char *label, const char *val) {
    vga_puts_attr("         +-- ", 0x0800);
    vga_puts_attr(label, 0x0700); vga_puts_attr(val, 0x0B00);
    vga_putchar_attr('\n', 0x0700);
    serial_puts("\r\n         +-- "); serial_puts(label); serial_puts(val);
}

/* ═══════════════════════════════════════════════════════════════════════════
 * PANIC PRECOCE
 * ═══════════════════════════════════════════════════════════════════════════ */

static void __attribute__((noreturn)) kpanic_early(const char *msg) {
    vga_puts_attr("\n\n  *** KERNEL PANIC ***\n  ", 0x4F00);
    vga_puts_attr(msg, 0x4F00);
    vga_puts_attr("\n  Sistema bloccato.\n", 0x4F00);
    serial_printf("\r\n[PANIC] %s\r\n", msg);
    for (;;) asm volatile("cli; hlt");
}

/* ═══════════════════════════════════════════════════════════════════════════
 * DUMP HELPERS
 * ═══════════════════════════════════════════════════════════════════════════ */

static void dump_pci_vga(void) {
    static const char hx[] = "0123456789ABCDEF";
    char buf[8];
    u64_to_dec(g_pci_device_count, buf);
    klog_detail("Dispositivi trovati: ", buf);

    for (uint32_t i = 0; i < g_pci_device_count; i++) {
        pci_device_t *d = &g_pci_devices[i];
        serial_printf("    [%02u] %02x:%02x.%x  ven=%04x dev=%04x  cls=%02x/%02x\r\n",
            i, d->bus, d->dev, d->func,
            d->vendor_id, d->device_id, d->class_code, d->subclass);
    }

    /* Mostra su VGA i device non-bridge (max 4) */
    uint32_t shown = 0;
    for (uint32_t i = 0; i < g_pci_device_count && shown < 4; i++) {
        pci_device_t *d = &g_pci_devices[i];
        if (d->class_code == 0x06 && d->subclass == 0x00) continue;

        const char *cls = "?";
        if      (d->class_code==0x01 && d->subclass==0x06) cls = "AHCI";
        else if (d->class_code==0x01 && d->subclass==0x08) cls = "NVMe";
        else if (d->class_code==0x02)                       cls = "NIC";
        else if (d->class_code==0x03)                       cls = "VGA";
        else if (d->class_code==0x0C && d->subclass==0x03) cls = "USB";
        else if (d->class_code==0x06 && d->subclass==0x01) cls = "ISA Bridge";
        else if (d->class_code==0x01)                       cls = "Storage";

        vga_puts_attr("         +-- ", 0x0800);
        char h[5]; h[4]=0;
        h[0]=hx[(d->vendor_id>>12)&0xF]; h[1]=hx[(d->vendor_id>>8)&0xF];
        h[2]=hx[(d->vendor_id>>4)&0xF];  h[3]=hx[d->vendor_id&0xF];
        vga_puts_attr(h, 0x0B00); vga_putchar_attr(':', 0x0700);
        h[0]=hx[(d->device_id>>12)&0xF]; h[1]=hx[(d->device_id>>8)&0xF];
        h[2]=hx[(d->device_id>>4)&0xF];  h[3]=hx[d->device_id&0xF];
        vga_puts_attr(h, 0x0B00);
        vga_putchar_attr(' ', 0x0700); vga_puts_attr(cls, 0x0F00);
        vga_putchar_attr('\n', 0x0700);
        shown++;
    }
}

/* ═══════════════════════════════════════════════════════════════════════════
 * CONSOLE KERNEL — terminale interattivo v3.12 (clean input architecture)
 *
 * ARCHITETTURA INPUT:
 *   - IRQ1 handler: deposita byte grezzi SOLO, non chiama keyboard_process.
 *   - Timer LAPIC (vec 0x20): incrementa g_con_ms ogni millisecondo.
 *   - Console loop: sti;hlt → keyboard_process() → poll events → autorepeat.
 * ═══════════════════════════════════════════════════════════════════════════ */

#define CON_MAX 256

static char s_line[CON_MAX];
static int  s_len = 0;
static int  s_cur = 0;
static int  s_input_row = 0;
static int  s_input_col = 0;

/* ── History comandi ─────────────────────────────────────────────────────
 * Ring buffer di HIST_MAX stringhe. s_hist_tail punta all'ultima voce
 * aggiunta. s_hist_idx è l'indice di navigazione (−1 = nessuna, 0 = ultima,
 * 1 = penultima, …). Reset a −1 a ogni Enter o Ctrl+C. */
#define HIST_MAX 32
static char s_hist[HIST_MAX][CON_MAX];
static int  s_hist_count = 0;   /* voci valide, max HIST_MAX */
static int  s_hist_tail  = -1;  /* indice ring dell'ultima voce aggiunta */
static int  s_hist_idx   = -1;  /* −1 = non in navigazione */
static char s_hist_saved[CON_MAX]; /* salva la riga corrente durante navigazione */

/* Aggiunge una riga alla history (se non vuota e diversa dall'ultima) */
static void hist_push(const char *line) {
    if (!line || !line[0]) return;
    /* Non duplicare l'ultima voce */
    if (s_hist_count > 0) {
        int last = (s_hist_tail + HIST_MAX) % HIST_MAX;
        int eq = 1;
        for (int i = 0; line[i] || s_hist[last][i]; i++)
            if (line[i] != s_hist[last][i]) { eq = 0; break; }
        if (eq) return;
    }
    s_hist_tail = (s_hist_tail + 1) % HIST_MAX;
    int j = 0;
    while (line[j] && j < CON_MAX - 1) { s_hist[s_hist_tail][j] = line[j]; j++; }
    s_hist[s_hist_tail][j] = '\0';
    if (s_hist_count < HIST_MAX) s_hist_count++;
}

/* ── Scrollback ──────────────────────────────────────────────────────────
 * g_sb_active: true quando siamo in modalità scrollback.
 * g_sb_offset: quante righe indietro stiamo guardando (1=ultima). */
static bool s_sb_active = false;
static int  s_sb_offset = 0;

/* ── Directory di lavoro corrente ────────────────────────────────────── */
static char s_cwd[256] = "/";

/* Costruisce path assoluto: se arg inizia con '/' è già assoluto,
 * altrimenti viene concatenato a s_cwd. */
static void con_build_path(const char *arg, char *out, size_t sz) {
    if (!arg || !*arg) {
        /* nessun argomento: usa cwd */
        size_t i = 0;
        while (s_cwd[i] && i < sz - 1) { out[i] = s_cwd[i]; i++; }
        out[i] = '\0';
        return;
    }
    if (arg[0] == '/') {
        /* path assoluto */
        size_t i = 0;
        while (arg[i] && i < sz - 1) { out[i] = arg[i]; i++; }
        out[i] = '\0';
        return;
    }
    /* path relativo: cwd + "/" + arg */
    size_t clen = 0; while (s_cwd[clen]) clen++;
    size_t alen = 0; while (arg[alen])   alen++;
    if (clen == 1 && s_cwd[0] == '/') {
        /* cwd è root: evita doppio slash */
        out[0] = '/';
        size_t i = 0;
        while (arg[i] && i + 1 < sz - 1) { out[i + 1] = arg[i]; i++; }
        out[i + 1] = '\0';
    } else {
        size_t i = 0;
        while (s_cwd[i] && i < sz - 1) { out[i] = s_cwd[i]; i++; }
        if (i < sz - 1) { out[i++] = '/'; }
        size_t j = 0;
        while (arg[j] && i < sz - 1) { out[i++] = arg[j++]; }
        out[i] = '\0';
    }
}

/* Semplice kstrcpy locale (no libc in kernel) */
static void con_strcpy(char *d, const char *s, size_t n) {
    size_t i=0; while(s[i] && i<n-1){d[i]=s[i];i++;} d[i]='\0';
}

/* Timer LAPIC → ms counter.
 * GLOBALE (non static): visibile da keyboard.c se necessario. */
volatile uint32_t g_con_ms  = 0;
volatile int      g_ctrlc   = 0;   /* settato da Ctrl+C; letto nel loop e nei cmd */

static void con_timer_handler(interrupt_frame_t *frame) {
    (void)frame;
    g_con_ms++;
}

/* ── Autorepeat software ──────────────────────────────────────────────────
 *
 * VirtualBox NEM manda MAKE codes ripetuti durante il typematic hardware
 * (non coppie MAKE+BREAK+MAKE). Il bitset s_pressed in keyboard.c filtra
 * tutti i MAKE duplicati. Un BREAK corrisponde SEMPRE a un rilascio reale.
 *
 * Macchina a stati semplice a 3 stati:
 *   AR_IDLE   → nessun tasto tenuto
 *   AR_DELAY  → tasto premuto, in attesa del delay iniziale (1/8 s)
 *   AR_REPEAT → delay scaduto, inserisce 10 caratteri al secondo
 *
 * NON usiamo AR_HOLDOFF: causerebbe falsi negativi su ri-pressioni rapide
 * (< ~15ms tra rilascio e ri-pressione, normalissimo per chi scrive veloce).
 */
#define AR_DELAY_MS   250U   /* 1/4 secondo prima che parta il repeat   */
#define AR_REPEAT_MS   50U   /* 50ms tra repeat = 20 cps                */

typedef enum { AR_IDLE=0, AR_DELAY, AR_REPEAT } ar_state_t;
static ar_state_t s_ar_state = AR_IDLE;
static vk_t       s_ar_key   = VK_NONE;
static char       s_ar_ascii = 0;
static uint32_t   s_ar_ms    = 0;


static void con_puts(const char *s, uint16_t a) {
    vga_puts_attr(s, a); serial_puts(s);
}
static void con_putc(char c) {
    vga_putchar_attr(c, 0x0F00); serial_putchar(c);
}
static void con_nl(void) {
    vga_putchar_attr('\n', 0x0700); serial_puts("\r\n");
}
static void con_hex16(uint16_t v) {
    static const char h[] = "0123456789ABCDEF";
    char b[5]; b[4]=0;
    b[0]=h[(v>>12)&0xF]; b[1]=h[(v>>8)&0xF];
    b[2]=h[(v>>4)&0xF];  b[3]=h[v&0xF];
    vga_puts_attr(b, 0x0B00); serial_puts(b);
}
static void con_prompt(void) {
    vga_puts_attr("\nMattiaOS:", 0x0A00);
    vga_puts_attr(s_cwd,        0x0B00);
    vga_puts_attr("> ",         0x0F00);
    serial_puts("\r\nMattiaOS:");
    serial_puts(s_cwd);
    serial_puts("> ");
    s_len = 0;
    s_cur = 0;
    vga_get_pos(&s_input_row, &s_input_col);
}

/* ── comandi ──────────────────────────────────────────────────────────── */

/* ── Easter egg — ASCII art "MattiaOS" ────────────────────────────────────
 *
 * Font: 5×5 pixel block letters (I = 3 wide), 1-space gap between letters.
 * Layout "M A T T I A O S":
 *   M(5) + gap(1) + A(5) + gap(1) + T(5) + gap(1) + T(5) + gap(1) +
 *   I(3) + gap(1) + A(5) + gap(1) + O(5) + gap(1) + S(5) = 44 chars content
 *   + 2-space indent = 46 chars per row (fits in 80-col VGA).
 *
 * Letter bitmaps (5 rows each, '#' = pixel on, ' ' = pixel off):
 *   M: #   #  ## ##  # # #  #   #  #   #
 *   A:  ###   #   #  #####  #   #  #   #
 *   T: #####    #      #      #      #
 *   I: ###    #     #     #    ###
 *   O:  ###   #   #  #   #  #   #   ###
 *   S:  ####  #      ###      #  ####
 */
static void cmd_easteregg(void) {
    con_nl();
    /* Row 1: M=`#   #`  A=` ### `  T=`#####`  T=`#####`  I=`###`  A=` ### `  O=` ### `  S=` ####` */
    con_puts("  #   #  ###  ##### #####  ###  ###   ###   ####\n", 0x0B00);
    /* Row 2: M=`## ##`  A=`#   #`  T=`  #  `  T=`  #  `  I=` # `  A=`#   #`  O=`#   #`  S=`#    ` */
    con_puts("  ## ## #   #   #     #     #  #   # #   # #    \n", 0x0A00);
    /* Row 3: M=`# # #`  A=`#####`  T=`  #  `  T=`  #  `  I=` # `  A=`#####`  O=`#   #`  S=` ### ` */
    con_puts("  # # # #####   #     #     #  ##### #   #  ### \n", 0x0E00);
    /* Row 4: M=`#   #`  A=`#   #`  T=`  #  `  T=`  #  `  I=` # `  A=`#   #`  O=`#   #`  S=`    #` */
    con_puts("  #   # #   #   #     #     #  #   # #   #     #\n", 0x0D00);
    /* Row 5: M=`#   #`  A=`#   #`  T=`  #  `  T=`  #  `  I=`###`  A=`#   #`  O=` ### `  S=`#### ` */
    con_puts("  #   # #   #   #     #   ###  #   #  ###  #### \n", 0x0900);
    con_nl();
    con_puts("        il tuo OS scritto da zero. buone cose, Mattia.\n", 0x0800);
    con_nl();
}

static void cmd_help(void) {
    con_nl();
    con_puts("  Comandi disponibili:\n",            0x0B00);
    con_puts("    help         — questo messaggio\n",    0x0700);
    con_puts("    ver          — versione e build info\n",0x0700);
    con_puts("    mem          — memoria + processi\n",  0x0700);
    con_puts("    pci          — lista dispositivi PCI\n",0x0700);
    con_puts("    ls [path]    — elenca directory\n",    0x0700);
    con_puts("    cd <path>    — cambia directory\n\n",  0x0700);
    con_puts("    open <path>  — visualizza file (pager)\n", 0x0700);
    con_puts("                   frecce=scorri  q/ESC=esci\n", 0x0800);
    con_puts("    edit <path>  — editor testo  Ctrl+S=salva  ESC=esci\n", 0x0700);
    con_puts("    tree [path]  — albero ricorsivo filesystem\n\n", 0x0700);
    con_puts("    clear        — pulisce lo schermo\n",  0x0700);
    con_puts("    reboot       — riavvia la macchina\n", 0x0700);
    con_puts("    halt         — spegne il sistema\n",   0x0700);
    con_puts("    easteregg    — ?\n",                   0x0800);
    con_puts("    diag         — diagnostica VFS interna\n", 0x0800);
    con_puts("  Tasti speciali:\n", 0x0B00);
    con_puts("    Ctrl+C       — annulla comando/input corrente\n", 0x0800);
    con_puts("    SU/GIU       — history comandi\n", 0x0800);
    con_puts("    Shift+SU     — scrollback terminale\n", 0x0800);
}

static void cmd_ver(void) {
    char buf[16];
    con_nl();
    con_puts("  MattiaOS " MATTIAOS_VERSION " — Kernel debug build\n", 0x0B00);
    con_puts("  Entry point:   0xFFFFFFFF80000000+\n", 0x0700);
    con_puts("  APIC timer:    ", 0x0700);
    u64_to_dec(g_apic_ticks_per_ms, buf);
    con_puts(buf, 0x0B00); con_puts(" ticks/ms\n", 0x0700);
    con_puts("  Toolchain:     GCC 13.3 x86_64-elf + NASM 3.01\n", 0x0700);
    con_puts("  PMM total:     ", 0x0700);
    u64_to_dec(pmm_total_memory()/(1024*1024), buf);
    con_puts(buf, 0x0B00); con_puts(" MB\n", 0x0700);
}

static void cmd_mem(void) {
    char buf[16];
    con_nl();
    uint64_t total = pmm_total_memory();
    uint64_t free  = pmm_free_memory();
    uint64_t used  = total - free;

    con_puts("  \xC4\xC4 Memoria fisica \xC4\xC4\xC4\xC4\xC4\xC4\xC4\xC4\xC4\xC4\xC4\xC4\xC4\xC4\xC4\xC4\xC4\xC4\xC4\xC4\n", 0x0800);
    con_puts("  RAM totale:  ", 0x0700);
    u64_to_dec(total/(1024*1024), buf); con_puts(buf, 0x0B00);
    con_puts(" MB\n", 0x0700);

    con_puts("  RAM libera:  ", 0x0700);
    u64_to_dec(free/(1024*1024), buf);  con_puts(buf, 0x0A00);
    con_puts(" MB\n", 0x0700);

    con_puts("  RAM usata:   ", 0x0700);
    u64_to_dec(used/(1024*1024), buf);  con_puts(buf, 0x0E00);
    con_puts(" MB\n", 0x0700);

    uint64_t pct = total ? (used * 40) / total : 0;
    con_puts("  [", 0x0700);
    for (uint64_t i = 0; i < 40; i++) {
        if (i < pct) { vga_putchar_attr('#', 0x0C00); serial_putchar('#'); }
        else         { vga_putchar_attr('-', 0x0800); serial_putchar('-'); }
    }
    con_puts("] ", 0x0700);
    u64_to_dec(total ? (used*100)/total : 0, buf);
    con_puts(buf, 0x0E00); con_puts("%\n", 0x0700);

    /* ── Processi in esecuzione ── */
    con_puts("\n  \xC4\xC4 Processi \xC4\xC4\xC4\xC4\xC4\xC4\xC4\xC4\xC4\xC4\xC4\xC4\xC4\xC4\xC4\xC4\xC4\xC4\xC4\xC4\xC4\xC4\xC4\xC4\n", 0x0800);
    con_puts("  PID  STATO       NOME\n", 0x0B00);

    process_t *p = process_get_list();
    if (!p) {
        con_puts("  (nessun processo nel sistema)\n", 0x0800);
    } else {
        while (p) {
            /* PID */
            u64_to_dec((uint64_t)p->pid, buf);
            /* pad to 4 chars */
            size_t blen = 0; while(buf[blen]) blen++;
            con_puts("  ", 0x0700);
            for (size_t i = blen; i < 4; i++) vga_putchar_attr(' ', 0x0700);
            con_puts(buf, 0x0B00);
            con_puts("  ", 0x0700);
            /* Stato */
            const char *st = "?          ";
            switch(p->state) {
            case PROCESS_RUNNING:  st = "RUNNING    "; break;
            case PROCESS_READY:    st = "READY      "; break;
            case PROCESS_BLOCKED:  st = "BLOCKED    "; break;
            case PROCESS_ZOMBIE:   st = "ZOMBIE     "; break;
            case PROCESS_SLEEPING: st = "SLEEPING   "; break;
            }
            uint16_t sc = (p->state == PROCESS_RUNNING) ? 0x0A00 :
                          (p->state == PROCESS_ZOMBIE)  ? 0x0C00 : 0x0E00;
            con_puts(st, sc);
            /* Nome */
            con_puts(p->name[0] ? p->name : "(unnamed)", 0x0F00);
            con_putc('\n');
            p = p->next;
        }
    }
}

static void cmd_pci(void) {
    char buf[8];
    con_nl();
    con_puts("  Dispositivi PCI (", 0x0700);
    u64_to_dec(g_pci_device_count, buf);
    con_puts(buf, 0x0B00); con_puts("):\n", 0x0700);

    for (uint32_t i = 0; i < g_pci_device_count; i++) {
        pci_device_t *d = &g_pci_devices[i];
        const char *cls = "?";
        if      (d->class_code==0x01 && d->subclass==0x06) cls = "AHCI";
        else if (d->class_code==0x01 && d->subclass==0x08) cls = "NVMe";
        else if (d->class_code==0x01)                       cls = "Storage";
        else if (d->class_code==0x02)                       cls = "NIC";
        else if (d->class_code==0x03)                       cls = "VGA";
        else if (d->class_code==0x06 && d->subclass==0x00) cls = "Host bridge";
        else if (d->class_code==0x06 && d->subclass==0x01) cls = "ISA bridge";
        else if (d->class_code==0x06)                       cls = "PCI bridge";
        else if (d->class_code==0x0C && d->subclass==0x03) cls = "USB";
        else if (d->class_code==0x04)                       cls = "Multimedia";

        con_puts("  ven=", 0x0700); con_hex16(d->vendor_id);
        con_puts(" dev=", 0x0700);  con_hex16(d->device_id);
        con_puts("  ", 0x0700);
        vga_puts_attr(cls, 0x0B00); serial_puts(cls);
        vga_putchar_attr('\n', 0x0700); serial_puts("\r\n");
    }
}

/* ═══════════════════════════════════════════════════════════════════════════
 * con_check_ctrlc — controlla Ctrl+C senza bloccare
 *
 * Chiama keyboard_process() per drenare la porta PS/2, poi drena l'event
 * ring cercando ascii==3 (ETX). Se trovato, setta g_ctrlc=1.
 * Va chiamata dentro tutti i loop lunghi (cmd_ls, cmd_tree, ecc.) in modo
 * che Ctrl+C interrompa il comando immediatamente senza aspettare il ritorno
 * al loop principale di kernel_console.
 *
 * Perché non funzionava prima:
 *   I comandi giravano dentro con_exec() → il loop di kernel_console era
 *   bloccato → keyboard_poll_event() non veniva mai chiamato → g_ctrlc
 *   restava 0 → i loop interni non si interrompevano mai.
 * ═══════════════════════════════════════════════════════════════════════════ */
static bool con_check_ctrlc(void) {
    keyboard_process();
    key_event_t ev;
    while (keyboard_poll_event(&ev)) {
        if (ev.pressed && ev.ascii == 3) {   /* ETX = Ctrl+C */
            g_ctrlc = 1;
            vga_puts_attr("^C\n", 0x0C00);
            serial_puts("^C\r\n");
        }
    }
    return g_ctrlc != 0;
}

/* ═══════════════════════════════════════════════════════════════════════════
 * cmd_open — visualizzatore file a schermo intero con scorrimento
 *
 * Entra in modalità full-screen (salva e ripristina il buffer VGA).
 * Supporta tre tipi:
 *   TESTO  → righe con numero riga a sinistra, wrapping a 72 colonne
 *   BINARY → hex dump a 4 byte/riga: offset | bit×32 | hex | ASCII
 *   ELF64  → come BINARY con header colorato
 *
 * Navigazione:
 *   ↑ / ↓         — scorre di 1 riga
 *   PgUp / PgDn   — scorre di OPEN_ROWS righe
 *   Home / End    — inizio / fine file
 *   q / ESC / ^C  — esce e ripristina schermo console
 *
 * Caricamento lazy (solo testo):
 *   s_ol_off[] memorizza l'offset di inizio di ogni riga visiva.
 *   Le righe oltre lo schermo corrente vengono indicizzate on-demand
 *   quando si scorre verso il basso (mai tutto il file in RAM).
 *   Budget BSS: OPEN_MAX_LINES × 8B = 16KB.
 * ═══════════════════════════════════════════════════════════════════════════ */

#define OPEN_MAX_LINES  2000   /* max righe indicizzate    — 16KB BSS */
#define OPEN_ROWS         23   /* righe contenuto visibili (25-1-1)   */
#define OPEN_TEXT_W       72   /* larghezza contenuto testo (80-8)    */
#define OPEN_BIN_COLS      4   /* byte per riga hex dump              */

/* Buffer statici — BSS */
static uint16_t s_ol_vga[80 * 25];        /* salvataggio schermo VGA         */
static off_t    s_ol_off[OPEN_MAX_LINES];  /* offset inizio di ogni riga testo */
static uint8_t  s_ol_rbuf[4096];          /* buffer di lettura generale       */

/* Salvataggio schermo per scrollback (16KB BSS, separato da s_ol_vga) */
static uint16_t s_sb_live[80 * 25];

/* ── Editor buffer (usato da cmd_open in edit mode) ─────────────────────
 * Budget BSS: 8192 byte.  Limite file modificabile: ED_MAX_SIZE-1 byte. */
#define ED_MAX_SIZE 8192
static char s_ed_buf[ED_MAX_SIZE];

/* ── Helper VGA per open: scrive stringa a posizione assoluta ───────────── */
static int open_at(int row, int col, const char *s, uint16_t attr) {
    while (*s && col < 80) { vga_write_at(row, col++, *s++, attr); }
    return col;
}
static int open_at_u32(int row, int col, uint32_t v, uint16_t attr) {
    char b[12]; u64_to_dec((uint64_t)v, b); return open_at(row, col, b, attr);
}
static int open_at_hex8(int row, int col, uint8_t v, uint16_t attr) {
    static const char h[] = "0123456789abcdef";
    if (col < 80) vga_write_at(row, col++, h[v >> 4], attr);
    if (col < 80) vga_write_at(row, col++, h[v & 0xF], attr);
    return col;
}
static int open_at_hex32(int row, int col, uint32_t v, uint16_t attr) {
    for (int i = 28; i >= 0; i -= 4) {
        static const char h[] = "0123456789abcdef";
        if (col < 80) vga_write_at(row, col++, h[(v >> i) & 0xF], attr);
    }
    return col;
}
static void open_fill(int row, char c, uint16_t attr) {
    for (int col = 0; col < 80; col++) vga_write_at(row, col, c, attr);
}

/* ── Aspetta un tasto (blocca) — usato solo dentro cmd_open ─────────────── */
static key_event_t open_wait_key(void) {
    key_event_t ev;
    for (;;) {
        asm volatile("pause");
        keyboard_process();
        if (keyboard_poll_event(&ev) && ev.pressed) return ev;
    }
}

/* ── Indicizza righe testo fino a `target` (lazy, append-only) ──────────── */
/* Stato persistente tra chiamate successive — azzerato all'apertura file */
static int  s_ol_cnt;    /* righe già indicizzate */
static bool s_ol_eof;    /* EOF raggiunto durante indicizzazione */
static off_t s_ol_scan;  /* prossimo offset da scansionare */

static void open_index_until(file_t *f, int target) {
    if (s_ol_eof || s_ol_cnt >= target || s_ol_cnt >= OPEN_MAX_LINES) return;

    int col = 0;

    /* Conta colonne nell'ultima riga parzialmente indicizzata: */
    /* Se s_ol_cnt>0, s_ol_off[s_ol_cnt-1] è l'inizio dell'ultima riga.
     * Dobbiamo sapere a quale colonna siamo arrivati. Rileggiamo da lì. */
    if (s_ol_cnt > 0 && s_ol_scan > s_ol_off[s_ol_cnt - 1]) {
        /* Già oltre la riga — col = 0 della prossima (s_ol_scan già avanzato) */
        col = 0;
    }

    off_t read_off = s_ol_scan;

    while (s_ol_cnt < target && s_ol_cnt < OPEN_MAX_LINES) {
        /* Leggi un chunk */
        f->offset = read_off;
        ssize_t nr = vfs_read(f, s_ol_rbuf, sizeof(s_ol_rbuf));
        if (nr <= 0) { s_ol_eof = true; break; }

        for (ssize_t i = 0; i < nr; i++) {
            uint8_t c = s_ol_rbuf[i];
            if (c == '\n') {
                /* Fine riga: registra inizio riga successiva */
                off_t next = read_off + i + 1;
                s_ol_scan = next;
                if (s_ol_cnt < OPEN_MAX_LINES) {
                    /* Prossima riga parte qui (la registriamo solo se c'è spazio) */
                    if (s_ol_cnt + 1 < OPEN_MAX_LINES) {
                        s_ol_off[s_ol_cnt + 1] = next;
                    }
                    s_ol_cnt++;
                    col = 0;
                }
                if (s_ol_cnt >= target || s_ol_cnt >= OPEN_MAX_LINES) goto done;
            } else if (c == '\r') {
                /* Ignora \r (CRLF support) */
            } else {
                col++;
                if (col >= OPEN_TEXT_W) {
                    /* Wrap: riga visiva completa senza \n */
                    off_t next = read_off + i + 1;
                    s_ol_scan = next;
                    if (s_ol_cnt + 1 < OPEN_MAX_LINES) {
                        s_ol_off[s_ol_cnt + 1] = next;
                    }
                    s_ol_cnt++;
                    col = 0;
                    if (s_ol_cnt >= target || s_ol_cnt >= OPEN_MAX_LINES) goto done;
                }
            }
        }
        read_off += nr;
        s_ol_scan = read_off;
    }
done:;
}

/* ── Disegna una riga di contenuto testo (riga VGA 1..OPEN_ROWS) ─────────── */
static void open_draw_text_row(int vga_row, int line_idx, file_t *f) {
    open_fill(vga_row, ' ', 0x0700);

    /* Numero riga (1-indexed, 5 cifre + ": ") */
    int col = 1;
    char lnbuf[8]; u64_to_dec((uint64_t)(line_idx + 1), lnbuf);
    /* Padding a destra: stampa numero allineato a 5 cifre */
    int lnlen = 0; while (lnbuf[lnlen]) lnlen++;
    for (int pad = lnlen; pad < 5; pad++)
        vga_write_at(vga_row, col++, ' ', 0x0800);
    col = open_at(vga_row, col, lnbuf, 0x0800);
    vga_write_at(vga_row, col++, ':', 0x0800);
    vga_write_at(vga_row, col++, ' ', 0x0700);

    /* Leggi il contenuto della riga dal file */
    f->offset = s_ol_off[line_idx];
    ssize_t nr = vfs_read(f, s_ol_rbuf, (size_t)OPEN_TEXT_W);
    if (nr <= 0) return;

    /* Stampa caratteri fino a \n o fine colonne */
    for (ssize_t i = 0; i < nr && col < 80; i++) {
        uint8_t c = s_ol_rbuf[i];
        if (c == '\n' || c == '\r') break;
        if (c < 0x20 || c > 0x7E) c = '.';
        vga_write_at(vga_row, col++, (char)c, 0x0F00);
    }
}

/* ── Disegna una riga di contenuto binario/ELF ──────────────────────────── */
static void open_draw_bin_row(int vga_row, int bin_row, file_t *f, bool is_elf) {
    open_fill(vga_row, ' ', 0x0700);

    f->offset = (off_t)(bin_row * OPEN_BIN_COLS);
    ssize_t nr = vfs_read(f, s_ol_rbuf, (size_t)OPEN_BIN_COLS);
    if (nr <= 0) return;

    uint16_t bit_attr = is_elf ? 0x0B00 : 0x0A00;
    static const char hx[] = "0123456789abcdef";

    int col = 1;

    /* Colonna 1: offset 8 hex digit */
    col = open_at_hex32(vga_row, col, (uint32_t)(bin_row * OPEN_BIN_COLS), 0x0800);
    vga_write_at(vga_row, col++, ':', 0x0800);
    vga_write_at(vga_row, col++, ' ', 0x0700);

    /* Colonna 2: gruppi di 8 bit */
    for (ssize_t j = 0; j < OPEN_BIN_COLS; j++) {
        uint8_t byte = (j < nr) ? s_ol_rbuf[j] : 0;
        uint16_t ba  = (j < nr) ? bit_attr : 0x0800;
        for (int b = 7; b >= 0; b--) {
            if (col < 80)
                vga_write_at(vga_row, col++, ((byte >> b) & 1) ? '1' : '0', ba);
        }
        if (j < OPEN_BIN_COLS - 1 && col < 80)
            vga_write_at(vga_row, col++, ' ', 0x0700);
    }

    /* Separatore */
    if (col < 80) { vga_write_at(vga_row, col++, ' ', 0x0700); }
    if (col < 80) { vga_write_at(vga_row, col++, '|', 0x0800); }
    if (col < 80) { vga_write_at(vga_row, col++, ' ', 0x0700); }

    /* Colonna 3: hex bytes */
    for (ssize_t j = 0; j < OPEN_BIN_COLS; j++) {
        if (j < nr) {
            col = open_at_hex8(vga_row, col, s_ol_rbuf[j], 0x0B00);
        } else {
            if (col < 80) vga_write_at(vga_row, col++, ' ', 0x0700);
            if (col < 80) vga_write_at(vga_row, col++, ' ', 0x0700);
        }
        if (j < OPEN_BIN_COLS - 1 && col < 80) vga_write_at(vga_row, col++, ' ', 0x0700);
    }

    /* Separatore */
    if (col < 80) vga_write_at(vga_row, col++, ' ', 0x0700);
    if (col < 80) vga_write_at(vga_row, col++, '|', 0x0800);
    if (col < 80) vga_write_at(vga_row, col++, ' ', 0x0700);

    /* Colonna 4: ASCII */
    for (ssize_t j = 0; j < nr && col < 80; j++) {
        uint8_t c = s_ol_rbuf[j];
        char d = (c >= 0x20 && c <= 0x7E) ? (char)c : '.';
        vga_write_at(vga_row, col++, d, 0x0F00);
    }

    (void)hx; /* usato implicitamente via hex functions */
}

/* ── Ridisegna tutta la schermata del pager ─────────────────────────────── */
static void open_repaint(file_t *f, bool is_text, bool is_elf,
                          int top, int total, const char *name) {
    /* ── Header (riga 0) ── */
    open_fill(0, ' ', 0x1F00);
    int col = 1;
    col = open_at(0, col, "[OPEN] ", 0x1E00);
    col = open_at(0, col, name,     0x1F00);
    col = open_at(0, col, "  ",     0x1F00);
    if      (is_elf)   col = open_at(0, col, "ELF64",  0x1B00);
    else if (!is_text) col = open_at(0, col, "BINARIO", 0x1A00);
    else               col = open_at(0, col, "TESTO",   0x1F00);
    col = open_at(0, col, "  riga ", 0x1700);
    col = open_at_u32(0, col, (uint32_t)(top + 1), 0x1E00);
    col = open_at(0, col, "/", 0x1700);
    col = open_at_u32(0, col, (uint32_t)total,     0x1E00);
    /* Hint tasti — allineato a destra */
    const char *hint = "ESC/q=esci  \x18\x19=riga  PgUp/Dn=pag  Home/End ";
    int hlen = 0; while (hint[hlen]) hlen++;
    int hcol = 80 - hlen - 1; if (hcol < col) hcol = col;
    open_at(0, hcol, hint, 0x1700);

    /* ── Contenuto (righe 1..OPEN_ROWS) ── */
    for (int r = 0; r < OPEN_ROWS; r++) {
        int line = top + r;
        int vga_row = r + 1;
        if (line >= total) {
            open_fill(vga_row, ' ', 0x0700);
            if (line == total) open_at(vga_row, 1, "~", 0x0800);
        } else if (is_text) {
            open_draw_text_row(vga_row, line, f);
        } else {
            open_draw_bin_row(vga_row, line, f, is_elf);
        }
    }

    /* ── Footer (riga 24) ── */
    open_fill(24, ' ', 0x7000);
    col = 1;
    col = open_at(24, col, " Righe ", 0x7000);
    col = open_at_u32(24, col, (uint32_t)(top + 1), 0x7000);
    col = open_at(24, col, "-", 0x7000);
    int bot = top + OPEN_ROWS; if (bot > total) bot = total;
    col = open_at_u32(24, col, (uint32_t)bot, 0x7000);
    col = open_at(24, col, " di ", 0x7000);
    col = open_at_u32(24, col, (uint32_t)total, 0x7000);
    if (total > 0) {
        uint32_t pct = (uint32_t)((uint64_t)top * 100 / (uint64_t)total);
        col = open_at(24, col, "  (", 0x7000);
        col = open_at_u32(24, col, pct, 0x7000);
        col = open_at(24, col, "%)", 0x7000);
    }
    bool more = (top + OPEN_ROWS) < total;
    open_at(24, col, more ? "  \x19 continua..." : "  [FINE]", 0x7000);

    /* Nascondi cursore HW durante il pager (posizionalo fuori schermo) */
    vga_set_cursor_hw(24, 79);
}

/* ── Comando principale ──────────────────────────────────────────────────── */
static void cmd_open(const char *arg) {
    if (!arg || !*arg) {
        con_nl();
        con_puts("  uso: open <percorso>\n", 0x0C00);
        return;
    }
    char path[256];
    con_build_path(arg, path, sizeof(path));
    con_nl();

    file_t *f = vfs_open(path, 0);
    if (!f) {
        con_puts("  open: '", 0x0C00); con_puts(path, 0x0C00);
        con_puts("': file non trovato\n", 0x0C00);
        return;
    }

    /* ── Rileva tipo dal primo chunk ── */
    f->offset = 0;
    ssize_t probe = vfs_read(f, s_ol_rbuf, 16);
    if (probe <= 0) {
        con_puts("  open: file vuoto\n", 0x0800);
        vfs_close(f); return;
    }
    bool is_elf = (probe >= 4 &&
                   s_ol_rbuf[0] == 0x7F && s_ol_rbuf[1] == 'E' &&
                   s_ol_rbuf[2] == 'L'  && s_ol_rbuf[3] == 'F');
    bool is_text = false;
    if (!is_elf) {
        /* Campiona i primi 512 byte per decidere testo/binario */
        f->offset = 0;
        ssize_t sample = vfs_read(f, s_ol_rbuf, 512);
        is_text = true;
        for (ssize_t i = 0; i < sample && is_text; i++) {
            uint8_t c = s_ol_rbuf[i];
            if (c != '\t' && c != '\n' && c != '\r' && (c < 0x20 || c > 0x7E))
                is_text = false;
        }
    }

    uint64_t fsize = f->vnode->size;

    /* ── Inizializza stato indexer (testo) ── */
    s_ol_cnt   = 1;           /* riga 0 inizia a offset 0 */
    s_ol_eof   = false;
    s_ol_scan  = 0;
    s_ol_off[0] = 0;

    /* ── Calcola total rows ── */
    int total;
    if (is_text) {
        /* Index le prime OPEN_ROWS righe per riempire la prima schermata */
        open_index_until(f, OPEN_ROWS + 1);
        total = s_ol_cnt;
    } else {
        total = (int)((fsize + OPEN_BIN_COLS - 1) / OPEN_BIN_COLS);
        if (total == 0) total = 1;
    }

    /* ── Salva schermo VGA e cursore ── */
    volatile uint16_t *vga_base = (volatile uint16_t *)0xB8000;
    for (int i = 0; i < 80 * 25; i++) s_ol_vga[i] = vga_base[i];

    /* ── Loop pager ── */
    int top = 0;

    for (;;) {
        /* Aggiorna total per testo (lazy index) */
        if (is_text) {
            if (!s_ol_eof) open_index_until(f, top + OPEN_ROWS + 2);
            total = s_ol_cnt;
            if (s_ol_eof && total > 0) {
                /* Verifica se l'ultima riga ha contenuto */
            }
        }

        /* Clamp top */
        int max_top = total - OPEN_ROWS;
        if (max_top < 0) max_top = 0;
        if (top > max_top) top = max_top;
        if (top < 0)       top = 0;

        open_repaint(f, is_text, is_elf, top, total, path);

        /* Aspetta un tasto */
        key_event_t ev = open_wait_key();

        /* Esci */
        if (ev.ascii == 'q' || ev.ascii == 'Q' ||
            ev.ascii == 3   ||                     /* Ctrl+C */
            ev.keycode == VK_ESCAPE) {
            break;
        }

        /* Navigazione */
        if (ev.keycode == VK_UP)   { top--; }
        if (ev.keycode == VK_DOWN) { top++; }
        if (ev.keycode == VK_PGUP) { top -= OPEN_ROWS; }
        if (ev.keycode == VK_PGDN) { top += OPEN_ROWS; }
        if (ev.keycode == VK_HOME) { top = 0; }
        if (ev.keycode == VK_END)  {
            if (is_text) {
                /* Index tutto fino all'EOF */
                while (!s_ol_eof && s_ol_cnt < OPEN_MAX_LINES)
                    open_index_until(f, s_ol_cnt + OPEN_ROWS);
                total = s_ol_cnt;
            }
            top = total - OPEN_ROWS;
        }
    }

    /* ── Ripristina schermo VGA ── */
    for (int i = 0; i < 80 * 25; i++) vga_base[i] = s_ol_vga[i];
    /* Ripristina cursore HW alla fine dell'ultima riga input visibile */
    int crow, ccol;
    vga_get_pos(&crow, &ccol);
    vga_set_cursor_hw(crow, ccol);

    /* Svuota ring buffer kbd e AR: open consuma tasti con open_wait_key(),
     * ma potrebbe aver lasciato eventi residui. Senza questo flush il loop
     * principale vede tasti "vecchi" (es. ESC/q → Enter) → Enter spurio.
     * BUG v4.14: mancava questo flush → newline a raffica dopo open. */
    g_kbd_events.head = g_kbd_events.tail = 0;
    s_ar_state = AR_IDLE;
    s_ar_key   = VK_NONE;

    vfs_close(f);
}

/* ═══════════════════════════════════════════════════════════════════════════
 * cmd_edit — editor di testo full-screen
 *
 * Funziona su file testo ≤ ED_MAX_SIZE byte (8KB).
 * Carica il file in s_ed_buf, lo mostra riga per riga.
 * Tasti in edit mode:
 *   Frecce     — muove cursore
 *   Backspace  — cancella carattere prima del cursore
 *   Delete     — cancella carattere sotto il cursore
 *   Invio      — inserisce newline
 *   Ctrl+S     — salva (truncate+rewrite)
 *   ESC        — esce senza salvare
 *   Ctrl+C     — esce senza salvare
 * Header riga 0:  path | EDIT | istruzioni
 * Footer riga 24: riga:colonna | stato
 * Contenuto righe 1..23 (23 righe visibili).
 * ═══════════════════════════════════════════════════════════════════════════ */
#define ED_ROWS   23
#define ED_COLS   78   /* max colonne visibili per riga */

static void cmd_edit(const char *arg) {
    if (!arg || !*arg) {
        con_nl();
        con_puts("  uso: edit <percorso>\n", 0x0C00);
        return;
    }
    char path[256];
    con_build_path(arg, path, sizeof(path));
    con_nl();

    /* ── Carica il file in s_ed_buf ── */
    int ed_len = 0;   /* lunghezza contenuto in s_ed_buf (byte) */
    int ed_cur = 0;   /* posizione cursore nel buffer (byte) */

    /* Prova ad aprire in lettura */
    file_t *f = vfs_open(path, 0);
    if (f) {
        ssize_t nr = vfs_read(f, (uint8_t*)s_ed_buf, ED_MAX_SIZE - 1);
        vfs_close(f);
        if (nr < 0) nr = 0;
        /* Tronca solo a testo ASCII stampabile + \n\r\t */
        int ok = 1;
        for (ssize_t i = 0; i < nr && ok; i++) {
            uint8_t c = (uint8_t)s_ed_buf[i];
            if (c != '\n' && c != '\r' && c != '\t' && (c < 0x20 || c > 0x7E)) ok = 0;
        }
        if (!ok) {
            con_puts("  edit: file binario — usa 'open' per visualizzare\n", 0x0C00);
            return;
        }
        ed_len = (int)nr;
        s_ed_buf[ed_len] = '\0';
        ed_cur = ed_len;  /* cursore alla fine */
    } else {
        /* File non esiste: crea vuoto */
        s_ed_buf[0] = '\0';
        ed_len = 0; ed_cur = 0;
    }

    /* ── Salva schermo ── */
    volatile uint16_t *vga_base = (volatile uint16_t *)0xB8000;
    for (int i = 0; i < 80 * 25; i++) s_ol_vga[i] = vga_base[i];

    /* ── Helper: calcola riga/colonna del cursore nel buffer ── */
    /* ed_row_of_cur: riga logica (0-based) del cursore */
    /* ed_col_of_cur: colonna logica (0-based) */

    /* ── Helper: trova inizio riga visiva `row` (0-based nel buffer) ── */
    /* Le righe sono separate da '\n'. */

    bool ed_dirty = false;
    bool ed_quit  = false;

    for (;;) {
        /* ── Calcola top_row (prima riga visibile) e posizione cursore ── */
        /* Primo passaggio: calcola riga e colonna logica del cursore */
        int cur_line = 0, cur_col = 0;
        for (int i = 0; i < ed_cur; i++) {
            if (s_ed_buf[i] == '\n') { cur_line++; cur_col = 0; }
            else cur_col++;
        }
        /* Total lines */
        int total_lines = 0;
        for (int i = 0; i < ed_len; i++) if (s_ed_buf[i] == '\n') total_lines++;
        if (ed_len == 0 || (ed_len > 0 && s_ed_buf[ed_len-1] != '\n')) total_lines++;

        /* Scroll verticale: top_row */
        static int ed_top = 0;
        if (cur_line < ed_top) ed_top = cur_line;
        if (cur_line >= ed_top + ED_ROWS) ed_top = cur_line - ED_ROWS + 1;

        /* ── Ridisegna header ── */
        uint16_t hattr = 0x1700; /* bianco su blu scuro */
        for (int c = 0; c < 80; c++) vga_base[c] = hattr | ' ';
        {
            int c = 1;
            for (int i = 0; path[i] && c < 40; i++, c++)
                vga_base[c] = hattr | (uint8_t)path[i];
            const char *em = ed_dirty ? " [EDIT*]  Ctrl+S=salva  ESC=esci" :
                                        " [EDIT]   Ctrl+S=salva  ESC=esci";
            for (int i = 0; em[i] && c < 78; i++, c++)
                vga_base[c] = hattr | (uint8_t)em[i];
        }

        /* ── Ridisegna contenuto (righe 1..ED_ROWS) ── */
        /* Trova inizio del blocco di righe da visualizzare */
        int line = 0, bi = 0;
        /* Avanza bi fino alla riga ed_top */
        while (line < ed_top && bi < ed_len) {
            if (s_ed_buf[bi++] == '\n') line++;
        }
        for (int vrow = 1; vrow <= ED_ROWS; vrow++) {
            int base = vrow * 80;
            /* Numero riga a sinistra (4 cifre + ':' + spazio) */
            uint16_t lnattr = 0x0800;
            int lnum = ed_top + (vrow - 1) + 1;
            char lbuf[6];
            lbuf[0] = '0' + (lnum / 1000) % 10;
            lbuf[1] = '0' + (lnum / 100)  % 10;
            lbuf[2] = '0' + (lnum / 10)   % 10;
            lbuf[3] = '0' +  lnum          % 10;
            lbuf[4] = ':'; lbuf[5] = ' ';
            for (int c = 0; c < 6; c++) vga_base[base + c] = lnattr | (uint8_t)lbuf[c];
            /* Contenuto riga */
            int col = 0;
            if (line < total_lines) {
                while (bi < ed_len && s_ed_buf[bi] != '\n' && col < ED_COLS) {
                    vga_base[base + 6 + col] = 0x0F00 | (uint8_t)s_ed_buf[bi];
                    bi++; col++;
                }
                if (bi < ed_len && s_ed_buf[bi] == '\n') { bi++; line++; }
            }
            while (col < ED_COLS) { vga_base[base + 6 + col] = 0x0700 | ' '; col++; }
        }

        /* ── Footer riga 24 ── */
        uint16_t fattr = 0x7000;
        for (int c = 0; c < 80; c++) vga_base[24*80 + c] = fattr | ' ';
        {
            char fbuf[32];
            int fi = 0;
            fbuf[fi++] = ' ';
            fbuf[fi++] = 'r'; fbuf[fi++] = ':';
            int n = cur_line + 1;
            char d[6]; int di = 0;
            do { d[di++] = '0' + n % 10; n /= 10; } while (n);
            while (di > 0) fbuf[fi++] = d[--di];
            fbuf[fi++] = ' '; fbuf[fi++] = 'c'; fbuf[fi++] = ':';
            n = cur_col + 1;
            di = 0;
            do { d[di++] = '0' + n % 10; n /= 10; } while (n);
            while (di > 0) fbuf[fi++] = d[--di];
            fbuf[fi++] = ' '; fbuf[fi] = '\0';
            for (int i = 0; fbuf[i] && i < 20; i++)
                vga_base[24*80 + i] = fattr | (uint8_t)fbuf[i];
            const char *st = ed_dirty ? "  modificato  " : "  salvato  ";
            int si = 20;
            for (int i = 0; st[i] && si < 78; i++, si++)
                vga_base[24*80 + si] = fattr | (uint8_t)st[i];
        }

        /* ── Posiziona cursore hardware ── */
        int vis_row = (cur_line - ed_top) + 1;
        int vis_col = (cur_col < ED_COLS) ? cur_col + 6 : 6 + ED_COLS - 1;
        if (vis_row < 1) vis_row = 1;
        if (vis_row > ED_ROWS) vis_row = ED_ROWS;
        vga_set_cursor_hw(vis_row, vis_col);

        if (ed_quit) break;

        /* ── Aspetta tasto ── */
        key_event_t ev = open_wait_key();
        uint8_t ev_mods = ev.modifiers;

        /* ESC o Ctrl+C: esci senza salvare */
        if (ev.keycode == VK_ESCAPE || ev.ascii == 3) { ed_quit = true; continue; }

        /* Ctrl+S: salva */
        if (ev.ascii == 0x13) {  /* ascii 19 = Ctrl+S */
            /* Crea o tronca il file */
            vfs_unlink(path);
            vfs_create_file(path, 0x81A4U);
            file_t *wf = vfs_open(path, 1);
            if (wf) {
                vfs_write(wf, s_ed_buf, (size_t)ed_len);
                vfs_close(wf);
                ed_dirty = false;
            }
            continue;
        }

        /* Frecce */
        if (ev.keycode == VK_UP) {
            /* Vai alla stessa colonna nella riga precedente */
            if (ed_cur == 0) continue;
            /* Trova inizio riga corrente */
            int sol = ed_cur - 1;
            while (sol > 0 && s_ed_buf[sol-1] != '\n') sol--;
            if (sol == 0) { ed_cur = 0; continue; }
            /* Trova inizio riga precedente */
            int prev_eol = sol - 1;  /* il '\n' della riga precedente */
            int prev_sol = prev_eol - 1;
            while (prev_sol > 0 && s_ed_buf[prev_sol-1] != '\n') prev_sol--;
            /* Lunghezza riga precedente */
            int prev_len = prev_eol - prev_sol;
            int target_col = (cur_col < prev_len) ? cur_col : prev_len;
            ed_cur = prev_sol + target_col;
            continue;
        }
        if (ev.keycode == VK_DOWN) {
            /* Trova fine riga corrente */
            int sol = ed_cur;
            while (sol > 0 && s_ed_buf[sol-1] != '\n') sol--;
            int eol = sol;
            while (eol < ed_len && s_ed_buf[eol] != '\n') eol++;
            if (eol >= ed_len) continue;  /* ultima riga */
            int next_sol = eol + 1;
            int next_eol = next_sol;
            while (next_eol < ed_len && s_ed_buf[next_eol] != '\n') next_eol++;
            int next_len = next_eol - next_sol;
            int target_col = (cur_col < next_len) ? cur_col : next_len;
            ed_cur = next_sol + target_col;
            continue;
        }
        if (ev.keycode == VK_LEFT)  { if (ed_cur > 0) ed_cur--; continue; }
        if (ev.keycode == VK_RIGHT) { if (ed_cur < ed_len) ed_cur++; continue; }
        if (ev.keycode == VK_HOME)  {
            while (ed_cur > 0 && s_ed_buf[ed_cur-1] != '\n') ed_cur--;
            continue;
        }
        if (ev.keycode == VK_END) {
            while (ed_cur < ed_len && s_ed_buf[ed_cur] != '\n') ed_cur++;
            continue;
        }
        if (ev.keycode == VK_PGUP) {
            for (int i = 0; i < ED_ROWS; i++) {
                int sol = ed_cur;
                while (sol > 0 && s_ed_buf[sol-1] != '\n') sol--;
                if (sol == 0) break;
                int prev_eol = sol - 1;
                int prev_sol = prev_eol - 1;
                while (prev_sol > 0 && s_ed_buf[prev_sol-1] != '\n') prev_sol--;
                int prev_len = prev_eol - prev_sol;
                int cc = ed_cur - sol;
                int target = (cc < prev_len) ? cc : prev_len;
                ed_cur = prev_sol + target;
            }
            continue;
        }
        if (ev.keycode == VK_PGDN) {
            for (int i = 0; i < ED_ROWS; i++) {
                int sol = ed_cur;
                while (sol > 0 && s_ed_buf[sol-1] != '\n') sol--;
                int eol = sol;
                while (eol < ed_len && s_ed_buf[eol] != '\n') eol++;
                if (eol >= ed_len) break;
                int next_sol = eol + 1;
                int next_eol = next_sol;
                while (next_eol < ed_len && s_ed_buf[next_eol] != '\n') next_eol++;
                int next_len = next_eol - next_sol;
                int cc = ed_cur - sol;
                int target = (cc < next_len) ? cc : next_len;
                ed_cur = next_sol + target;
            }
            continue;
        }

        /* Backspace */
        if (ev.keycode == VK_BACKSPACE || ev.ascii == '\b') {
            if (ed_cur > 0 && ed_len > 0) {
                ed_cur--;
                for (int i = ed_cur; i < ed_len - 1; i++) s_ed_buf[i] = s_ed_buf[i+1];
                ed_len--;
                s_ed_buf[ed_len] = '\0';
                ed_dirty = true;
            }
            continue;
        }
        /* Delete */
        if (ev.keycode == VK_DELETE) {
            if (ed_cur < ed_len) {
                for (int i = ed_cur; i < ed_len - 1; i++) s_ed_buf[i] = s_ed_buf[i+1];
                ed_len--;
                s_ed_buf[ed_len] = '\0';
                ed_dirty = true;
            }
            continue;
        }

        /* Carattere stampabile o \n */
        char ch = ev.ascii;
        if ((ch == '\n') || ((unsigned char)ch >= 0x20 && (unsigned char)ch != 0x7F)) {
            if (ed_len < ED_MAX_SIZE - 1) {
                /* Shift+right per inserire */
                for (int i = ed_len; i > ed_cur; i--) s_ed_buf[i] = s_ed_buf[i-1];
                s_ed_buf[ed_cur++] = ch;
                ed_len++;
                s_ed_buf[ed_len] = '\0';
                ed_dirty = true;
            }
        }
        (void)ev_mods;
    }

    /* ── Ripristina schermo ── */
    for (int i = 0; i < 80 * 25; i++) vga_base[i] = s_ol_vga[i];
    int crow, ccol; vga_get_pos(&crow, &ccol);
    vga_set_cursor_hw(crow, ccol);
    g_kbd_events.head = g_kbd_events.tail = 0;
    s_ar_state = AR_IDLE; s_ar_key = VK_NONE;
}

/* ── cmd_tree: stampa albero ricorsivo del filesystem ─────────────────────
 *
 * Output stile unix tree:
 *   /
 *   ├── etc/
 *   │   └── hostname
 *   ├── Dipendenze/
 *   │   ├── dipendenze.cfg
 *   └── tmp/
 *
 * Implementato con stack esplicito (no ricorsione kernel — stack limitato).
 * Profondità massima: TREE_MAX_DEPTH livelli.
 */

#define TREE_MAX_DEPTH   8    /* profondità max ricorsione (era 16 — BSS troppo grande) */
#define TREE_MAX_ITEMS  32    /* entry max per directory   (era 256 — BSS troppo grande)
                               * Con TREE_MAX_DEPTH*TREE_MAX_ITEMS=256 entry nel tree_frame_t
                               * il BSS totale per cmd_tree scende da ~1.1MB a ~68KB. */

/* ── cmd_tree: stampa albero ricorsivo del filesystem ─────────────────────
 * Output stile unix tree con rami box-drawing. Stack iterativo, no ricorsione.
 */
typedef struct {
    char path[256];
    int  depth;
    int  parent_idx;   /* indice entry nel parent */
    bool last;
} tree_frame_t;

static void cmd_tree(const char *arg) {
    char root_path[256];
    /* Se nessun argomento: usa la directory corrente (non sempre /)
     * BUG v4.14: hardcodato "/" anziché NULL → tree ignorava la cwd. */
    con_build_path((arg && *arg) ? arg : NULL, root_path, sizeof(root_path));
    con_nl();

    if (!vfs_is_dir(root_path)) {
        con_puts("  tree: '", 0x0C00); con_puts(root_path, 0x0C00);
        con_puts("': non è una directory\n", 0x0C00);
        return;
    }

    /* Stampa la radice */
    con_puts("  ", 0x0700);
    con_puts(root_path[1] == '\0' ? "/" : root_path, 0x0E00);
    con_putc('\n');

    /* Stack per DFS iterativa */
    static tree_frame_t s_stack[TREE_MAX_DEPTH * TREE_MAX_ITEMS];
    int sp = 0;           /* stack pointer */
    int total_dirs  = 0;
    int total_files = 0;

    /* Enum directory root e metti le entry in stack in ordine inverso */
    /* Prima contiamo quante entry ci sono */
    static char   e_name[TREE_MAX_ITEMS][64]; /* static: evita 2KB sullo stack kernel */
    int    e_count = 0;

    for (size_t idx = 0; idx < (size_t)TREE_MAX_ITEMS && !con_check_ctrlc(); idx++) {
        char name[64];
        int is_dir = 0;
        int r = vfs_readdir_entry(root_path, idx, name, sizeof(name), &is_dir);
        if (r < 0) break;
        if (e_count < TREE_MAX_ITEMS) {
            /* copia nome */
            int ni = 0;
            while (name[ni] && ni < 63) { e_name[e_count][ni] = name[ni]; ni++; }
            e_name[e_count][ni] = '\0';
            e_count++;
        }
    }

    /* Push in ordine inverso così il primo pop darà la prima entry */
    for (int i = e_count - 1; i >= 0 && sp < TREE_MAX_DEPTH * TREE_MAX_ITEMS; i--) {
        tree_frame_t *fr = &s_stack[sp++];
        /* Costruisci path */
        int pi = 0;
        const char *rp = root_path;
        if (rp[0] == '/' && rp[1] == '\0') {
            fr->path[pi++] = '/';
        } else {
            while (*rp && pi < 250) fr->path[pi++] = *rp++;
            fr->path[pi++] = '/';
        }
        int ni = 0;
        while (e_name[i][ni] && pi < 254) fr->path[pi++] = e_name[i][ni++];
        fr->path[pi] = '\0';
        fr->depth      = 1;
        fr->last       = (i == e_count - 1);
        fr->parent_idx = i;
    }

    while (sp > 0 && !con_check_ctrlc()) {
        tree_frame_t frame = s_stack[--sp];

        /* Trova il nome dell'entry (ultima componente del path) */
        const char *name = frame.path;
        const char *slash = frame.path;
        for (const char *p = frame.path; *p; p++) if (*p == '/') slash = p;
        name = slash + 1;
        if (!*name) name = frame.path;  /* radice */

        bool is_dir = vfs_is_dir(frame.path);

        if (is_dir) total_dirs++;
        else        total_files++;

        /* Stampa indentazione */
        con_puts("  ", 0x0700);
        for (int d = 1; d < frame.depth; d++) {
            con_puts("\xB3   ", 0x0800);
        }
        con_puts(frame.last ? "\xC0\xC4\xC4 " : "\xC3\xC4\xC4 ", 0x0800);
        if (is_dir) {
            con_puts(name, 0x0A00); con_puts("/\n", 0x0A00);
        } else {
            con_puts(name, 0x0F00); con_putc('\n');
        }

        /* Se è directory, enum i suoi figli e pushali */
        if (is_dir && frame.depth < TREE_MAX_DEPTH) {
            /* Enum figli */
            static char   c_name[TREE_MAX_ITEMS][64];
            int    c_count = 0;

            for (size_t idx = 0; idx < (size_t)TREE_MAX_ITEMS && !con_check_ctrlc(); idx++) {
                char nm[64];
                int isd = 0;
                int r = vfs_readdir_entry(frame.path, idx, nm, sizeof(nm), &isd);
                if (r < 0) break;
                if (c_count < TREE_MAX_ITEMS) {
                    int ni = 0;
                    while (nm[ni] && ni < 63) { c_name[c_count][ni] = nm[ni]; ni++; }
                    c_name[c_count][ni] = '\0';
                    c_count++;
                }
            }

            /* Push in ordine inverso */
            for (int i = c_count - 1; i >= 0 && sp < TREE_MAX_DEPTH * TREE_MAX_ITEMS - 1; i--) {
                tree_frame_t *fr = &s_stack[sp++];
                /* path = frame.path + "/" + c_name[i] */
                int pi = 0;
                const char *pp = frame.path;
                while (*pp && pi < 248) fr->path[pi++] = *pp++;
                fr->path[pi++] = '/';
                int ni = 0;
                while (c_name[i][ni] && pi < 254) fr->path[pi++] = c_name[i][ni++];
                fr->path[pi] = '\0';
                fr->depth = frame.depth + 1;
                fr->last  = (i == c_count - 1);
                fr->parent_idx = i;
            }
        }
    }

    /* Sommario */
    char buf[12];
    con_nl();
    con_puts("  ", 0x0700);
    u64_to_dec((uint64_t)total_dirs,  buf); con_puts(buf, 0x0A00);
    con_puts(" dir", 0x0700);
    con_puts(", ", 0x0700);
    u64_to_dec((uint64_t)total_files, buf); con_puts(buf, 0x0F00);
    con_puts(" file\n", 0x0700);
}

static void cmd_ls(const char *arg) {
    char path[256];
    con_build_path(arg, path, sizeof(path));
    con_nl();

    int count = 0;
    for (size_t idx = 0; idx < 512; idx++) {
        char name[256];
        int is_dir = 0;
        int r = vfs_readdir_entry(path, idx, name, sizeof(name), &is_dir);
        if (r < 0) {
            char dbuf[16];
            serial_puts("[LS] readdir('"); serial_puts(path);
            serial_puts("', "); int_to_dec((int)idx, dbuf); serial_puts(dbuf);
            serial_puts(") = "); int_to_dec(r, dbuf); serial_puts(dbuf);
            serial_puts("\r\n");
            break;
        }
        con_puts("  ", 0x0700);
        if (is_dir) { con_puts(name, 0x0A00); con_puts("/", 0x0A00); }
        else          con_puts(name, 0x0F00);
        con_putc('\n');
        count++;
        if (con_check_ctrlc()) break;
    }

    if (count == 0 && !g_ctrlc) {
        if (!vfs_is_dir(path)) {
            con_puts("  ls: '", 0x0C00); con_puts(path, 0x0C00);
            con_puts("': non trovato\n", 0x0C00);
        } else {
            /* ── Diagnostica inline VGA: stampa sullo schermo cosa sta succedendo ── */
            extern int  vfs_diag_mount_count(void);
            extern int  vfs_diag_root_children(void);
            extern int  vfs_diag_synth_count(const char *path);
            char dbuf[16];
            con_puts("  (vuota) diag: mounts=", 0x0E00);
            int_to_dec(vfs_diag_mount_count(), dbuf); con_puts(dbuf, 0x0F00);
            con_puts(" root_children=", 0x0E00);
            int_to_dec(vfs_diag_root_children(), dbuf); con_puts(dbuf, 0x0F00);
            con_puts(" synth=", 0x0E00);
            int_to_dec(vfs_diag_synth_count(path), dbuf); con_puts(dbuf, 0x0F00);
            con_putc('\n');
        }
    }
}

/* ── diag: diagnostica VFS interna ─────────────────────────────────────── */
static void cmd_diag(void) {
    extern void vfs_debug_dump(void);
    con_nl();
    con_puts("  [DIAG] dump VFS interno...\n", 0x0E00);
    vfs_debug_dump();
    con_puts("  [DIAG] done. Output completo su seriale.\n", 0x0E00);
}

static void cmd_cd(const char *arg) {
    if (!arg || !*arg) {
        /* cd senza argomenti → torna a root */
        s_cwd[0] = '/'; s_cwd[1] = '\0';
        return;
    }
    char path[256];
    con_build_path(arg, path, sizeof(path));

    if (!vfs_is_dir(path)) {
        con_nl();
        con_puts("  cd: '", 0x0C00);
        con_puts(path, 0x0C00);
        con_puts("': directory non trovata\n", 0x0C00);
        return;
    }
    con_strcpy(s_cwd, path, sizeof(s_cwd));
}

static void cmd_clear(void) {
    for (int i = 0; i < 25; i++) vga_putchar_attr('\n', 0x0700);
    serial_puts("\r\n\033[2J\033[H");
    vga_banner(MATTIAOS_VERSION);
}

/* ── halt: helper per trovare RSDP localmente ─────────────────────────────
 *
 * stage2 non patcha la risposta Limine RSDP, quindi acpi_init() non viene
 * mai chiamata e acpi_find_table("FACP") restituisce NULL.
 * Scansiona manualmente l'EBDA e la BIOS ROM per trovare "RSD PTR ".
 */
static uint8_t *halt_find_rsdp(void) {
    /* EBDA: indirizzo segmento a 0x40E, shiftato di 4 */
    volatile uint16_t *bda_ebda = (volatile uint16_t *)(g_hhdm_offset + 0x40EUL);
    uint64_t ebda_phys = (uint64_t)(*bda_ebda) << 4;
    if (ebda_phys >= 0x80000UL && ebda_phys < 0xA0000UL) {
        uint8_t *p = (uint8_t *)(g_hhdm_offset + ebda_phys);
        for (int i = 0; i < 1024; i += 16) {
            if (p[i]=='R'&&p[i+1]=='S'&&p[i+2]=='D'&&p[i+3]==' '&&
                p[i+4]=='P'&&p[i+5]=='T'&&p[i+6]=='R'&&p[i+7]==' ')
                return p + i;
        }
    }
    /* BIOS ROM 0xE0000–0xFFFFF */
    uint8_t *rom = (uint8_t *)(g_hhdm_offset + 0xE0000UL);
    for (int i = 0; i < 0x20000; i += 16) {
        if (rom[i]=='R'&&rom[i+1]=='S'&&rom[i+2]=='D'&&rom[i+3]==' '&&
            rom[i+4]=='P'&&rom[i+5]=='T'&&rom[i+6]=='R'&&rom[i+7]==' ')
            return rom + i;
    }
    return NULL;
}

static void cmd_halt(void) {
    con_nl();
    con_puts("  Arresto sistema via ACPI S5...\n", 0x0E00);
    asm volatile("cli");

    /*
     * Spegnimento ACPI S5 (power off) — procedura robusta.
     *
     * VirtualBox PIIX3:
     *   pm1a_cnt_blk = 0x4004  (dal FADT, oppure hardcoded come default)
     *   DSDT _S5_ = {5, 5, 0, 0}  → SLP_TYP_A = 5
     *   Valore corretto: (5 << 10) | SLP_EN(bit13) = 0x1400 | 0x2000 = 0x3400
     *
     * Sequenza:
     *   1. Tenta di trovare FADT tramite RSDP scan per avere pm1a esatto
     *   2. Prova tutti i SLP_TYP plausibili su pm1a: 5,0,3,6,7
     *   3. Fallback porta QEMU 0x604
     */

    /* --- Step 1: trova pm1a_cnt_blk dal FADT (se disponibile) --- */
    uint16_t pm1a = 0x4004;   /* default VirtualBox PIIX3 */
    uint16_t pm1b = 0x0000;

    uint8_t *rsdp_ptr = halt_find_rsdp();
    if (rsdp_ptr) {
        serial_puts("[HALT] RSDP trovato via scan\r\n");
        /* leggi rsdt_address a offset +16 (uint32_t) */
        uint32_t rsdt_phys = 0;
        for (int b = 0; b < 4; b++)
            rsdt_phys |= (uint32_t)rsdp_ptr[16 + b] << (b * 8);

        if (rsdt_phys) {
            uint8_t *rsdt = (uint8_t *)(g_hhdm_offset + rsdt_phys);
            /* RSDT length a offset +4 (uint32_t) */
            uint32_t rsdt_len = 0;
            for (int b = 0; b < 4; b++)
                rsdt_len |= (uint32_t)rsdt[4 + b] << (b * 8);

            uint32_t num_entries = (rsdt_len - 36) / 4;
            for (uint32_t e = 0; e < num_entries && e < 32; e++) {
                uint32_t tbl_phys = 0;
                for (int b = 0; b < 4; b++)
                    tbl_phys |= (uint32_t)rsdt[36 + e*4 + b] << (b * 8);
                if (!tbl_phys) continue;
                uint8_t *tbl = (uint8_t *)(g_hhdm_offset + tbl_phys);
                /* Controlla signature "FACP" */
                if (tbl[0]=='F'&&tbl[1]=='A'&&tbl[2]=='C'&&tbl[3]=='P') {
                    /* pm1a_cnt_blk a offset 64 (uint32_t) */
                    uint32_t v = 0;
                    for (int b = 0; b < 4; b++) v |= (uint32_t)tbl[64+b]<<(b*8);
                    if (v) pm1a = (uint16_t)v;
                    /* pm1b_cnt_blk a offset 68 (uint32_t) */
                    v = 0;
                    for (int b = 0; b < 4; b++) v |= (uint32_t)tbl[68+b]<<(b*8);
                    if (v) pm1b = (uint16_t)v;
                    serial_puts("[HALT] FADT trovato, pm1a=0x");
                    /* stampa hex pm1a */
                    const char *hx = "0123456789ABCDEF";
                    char h[5]; h[4]='\0';
                    h[0]=hx[(pm1a>>12)&0xF]; h[1]=hx[(pm1a>>8)&0xF];
                    h[2]=hx[(pm1a>>4)&0xF];  h[3]=hx[pm1a&0xF];
                    serial_puts(h); serial_puts("\r\n");
                    break;
                }
            }
        }
    } else {
        serial_puts("[HALT] RSDP non trovato, uso pm1a=0x4004\r\n");
    }

    /* --- Step 2: prova tutti i SLP_TYP plausibili --- */
    /* SLP_EN = bit 13 = 0x2000.  SLP_TYP_A = bits 10-12. */
    /* Ordine: 5 (VirtualBox), 0 (generic), 3, 6, 7 */
    static const uint16_t slp_types[] = { 5, 0, 3, 6, 7 };
    for (int t = 0; t < 5; t++) {
        uint16_t val = (uint16_t)((slp_types[t] << 10) | 0x2000U);
        outw(pm1a, val);
        if (pm1b) outw(pm1b, val);
        /* Breve busy-wait tra i tentativi */
        for (volatile int d = 0; d < 100000; d++) asm volatile("pause");
    }

    /* --- Step 3: fallback QEMU/Bochs --- */
    outw(0x604, 0x2000);
    for (volatile int d = 0; d < 100000; d++) asm volatile("pause");

    /* --- Step 4: Triple-fault fallback --- */
    con_puts("  (ACPI non ha risposto — CPU ferma)\n", 0x0C00);
    for (;;) asm volatile("cli; hlt");
}

static void cmd_reboot(void) {
    con_nl(); con_puts("  Riavvio...\n", 0x0E00);
    outb(0x64, 0xFE);
    asm volatile("cli");
    /* triple fault fallback */
    asm volatile("lidt %0" :: "m"(*(uint8_t*)0));
    asm volatile("int $0");
    for (;;);
}

static void con_exec(void) {
    int s = 0; while (s_line[s] == ' ') s++;
    char *line = s_line + s;
    if (!*line) return;

    /* Estrai il comando (primo token) */
    int cmdlen = 0;
    while (line[cmdlen] && line[cmdlen] != ' ') cmdlen++;

    /* Estrai l'argomento (secondo token, opzionale) */
    const char *arg = line + cmdlen;
    while (*arg == ' ') arg++;

    /* Confronto sul solo comando */
    char cmd[32]; int i=0;
    while (i < cmdlen && i < (int)sizeof(cmd)-1) { cmd[i]=line[i]; i++; }
    cmd[i] = '\0';

    if      (kstrcmp(cmd,"help")      == 0) { g_ctrlc=0; cmd_help(); }
    else if (kstrcmp(cmd,"ver")       == 0) { g_ctrlc=0; cmd_ver(); }
    else if (kstrcmp(cmd,"mem")       == 0) { g_ctrlc=0; cmd_mem(); }
    else if (kstrcmp(cmd,"pci")       == 0) { g_ctrlc=0; cmd_pci(); }
    else if (kstrcmp(cmd,"ls")        == 0) { g_ctrlc=0; cmd_ls(*arg ? arg : NULL); }
    else if (kstrcmp(cmd,"cd")        == 0) { g_ctrlc=0; cmd_cd(*arg ? arg : NULL); }
    else if (kstrcmp(cmd,"open")      == 0) { g_ctrlc=0; cmd_open(*arg ? arg : NULL); }
    else if (kstrcmp(cmd,"edit")      == 0) { g_ctrlc=0; cmd_edit(*arg ? arg : NULL); }
    else if (kstrcmp(cmd,"tree")      == 0) { g_ctrlc=0; cmd_tree(*arg ? arg : NULL); }
    else if (kstrcmp(cmd,"clear")     == 0) { g_ctrlc=0; cmd_clear(); }
    else if (kstrcmp(cmd,"halt")      == 0) { g_ctrlc=0; cmd_halt(); }
    else if (kstrcmp(cmd,"reboot")    == 0) { g_ctrlc=0; cmd_reboot(); }
    else if (kstrcmp(cmd,"easteregg") == 0) { g_ctrlc=0; cmd_easteregg(); }
    else if (kstrcmp(cmd,"diag")      == 0) { g_ctrlc=0; cmd_diag(); }
    else {
        /* Comando non built-in: cerca in /sys/PATH.
         * FORMATO v5.7: nome=percorso_exe:dep1:dep2:...
         *   - Il primo campo dopo '=' è il percorso dell'eseguibile.
         *   - I campi successivi separati da ':' sono le dipendenze.
         * Mostra exe + deps; Phase 13 eseguirà davvero il binario. */
        con_nl();
        bool found_in_path = false;
        file_t *pf = vfs_open("/sys/PATH", 0);
        if (pf) {
            static uint8_t s_pathbuf[2048];
            ssize_t pn = vfs_read(pf, s_pathbuf, sizeof(s_pathbuf) - 1);
            vfs_close(pf);
            if (pn > 0) {
                s_pathbuf[pn] = '\0';
                size_t ci = 0;
                while (ci < (size_t)pn && !found_in_path) {
                    /* Salta commenti e righe vuote */
                    if (s_pathbuf[ci] == '#' || s_pathbuf[ci] == '\n') {
                        while (ci < (size_t)pn && s_pathbuf[ci] != '\n') ci++;
                        ci++; continue;
                    }
                    /* Nome fino a '=' */
                    size_t ns = ci;
                    while (ci < (size_t)pn && s_pathbuf[ci] != '=' && s_pathbuf[ci] != '\n') ci++;
                    if (ci >= (size_t)pn || s_pathbuf[ci] == '\n') { ci++; continue; }
                    size_t nl = ci - ns;
                    ci++; /* salta '=' */
                    /* Tutta la riga dopo '=' fino a '\n' */
                    size_t val_start = ci;
                    while (ci < (size_t)pn && s_pathbuf[ci] != '\n') ci++;
                    size_t val_end = ci;
                    ci++;

                    if (nl != (size_t)i) continue; /* lunghezza diversa → skip */
                    if (kstrncmp((char*)s_pathbuf + ns, cmd, nl) != 0) continue;

                    /* Trovato. Ora estrai exe e deps dal valore "exe:dep1:dep2" */
                    /* Primo campo = exe (fino a ':' o fine) */
                    size_t fp = val_start;
                    while (fp < val_end && s_pathbuf[fp] != ':') fp++;
                    /* Stampa */
                    char exepath[128];
                    size_t el = fp - val_start;
                    if (el > 127) el = 127;
                    for (size_t k = 0; k < el; k++) exepath[k] = (char)s_pathbuf[val_start+k];
                    exepath[el] = '\0';

                    con_puts("  Comando: ", 0x0E00); con_puts(cmd, 0x0B00); con_puts("\n", 0x0700);
                    con_puts("  Eseguibile: ", 0x0700); con_puts(exepath, 0x0F00); con_puts("\n", 0x0700);

                    /* Deps: campi separati da ':' dopo il primo */
                    size_t dp = fp;
                    bool has_deps = false;
                    while (dp < val_end) {
                        dp++; /* salta ':' */
                        size_t dep_start = dp;
                        while (dp < val_end && s_pathbuf[dp] != ':') dp++;
                        size_t dep_len = dp - dep_start;
                        if (dep_len == 0) continue;
                        if (!has_deps) {
                            con_puts("  Dipendenze:\n", 0x0700);
                            has_deps = true;
                        }
                        char deppath[128];
                        if (dep_len > 127) dep_len = 127;
                        for (size_t k = 0; k < dep_len; k++) deppath[k] = (char)s_pathbuf[dep_start+k];
                        deppath[dep_len] = '\0';
                        con_puts("    - ", 0x0800); con_puts(deppath, 0x0A00); con_puts("\n", 0x0700);
                    }
                    if (!has_deps) con_puts("  Dipendenze: nessuna\n", 0x0800);
                    con_puts("  [Phase 13: ELF loader non ancora attivo]\n", 0x0800);
                    found_in_path = true;
                }
            }
        }
        if (!found_in_path) {
            con_puts("  Comando non riconosciuto: '", 0x0C00);
            con_puts(cmd, 0x0C00);
            con_puts("'  (digita 'help')\n", 0x0C00);
        }
    }
}

/* ── Ridisegna la riga di input da s_input_row/col, posiziona il cursore ── */
static void con_redraw_line(void) {
    int row = s_input_row, col = s_input_col;
    for (int i = 0; i < s_len; i++) {
        vga_write_at(row, col, s_line[i], 0x0F00);
        if (++col >= 80) { col = 0; row++; }
    }
    /* Pulisce i caratteri residui fino alla fine della riga VGA corrente
     * (serve quando la nuova riga è più corta della precedente — es. history) */
    int clear_col = col, clear_row = row;
    while (clear_col < 80) {
        vga_write_at(clear_row, clear_col, ' ', 0x0700);
        clear_col++;
    }
    /* Posiziona cursore hardware alla posizione s_cur */
    int crow = s_input_row, ccol = s_input_col + s_cur;
    crow += ccol / 80; ccol %= 80;
    vga_set_cursor_hw(crow, ccol);
}

/* ── Helper: carica voce history in s_line ───────────────────────────── */
static void hist_load(int idx) {
    /* idx = s_hist_idx corrente (0=ultima, 1=penultima, …) */
    if (s_hist_count == 0) return;
    if (idx < 0 || idx >= s_hist_count) return;
    /* Converti idx (0=ultima) in indice ring */
    int ring = (s_hist_tail - idx + HIST_MAX) % HIST_MAX;
    int j = 0;
    while (s_hist[ring][j] && j < CON_MAX - 1) { s_line[j] = s_hist[ring][j]; j++; }
    s_line[j] = '\0';
    s_len = j; s_cur = j;
    con_redraw_line();
}

/* ── Helper: esci dal modo scrollback ripristinando lo schermo reale ─── */
static void sb_exit(void) {
    if (!s_sb_active) return;
    s_sb_active = false;
    s_sb_offset = 0;
    /* Ripristina lo schermo che avevamo salvato prima di entrare */
    volatile uint16_t *vga_base = (volatile uint16_t *)0xB8000;
    for (int i = 0; i < 80 * 25; i++) vga_base[i] = s_sb_live[i];
    /* Ripristina cursore HW nella riga di input */
    int crow = s_input_row, ccol = s_input_col + s_cur;
    crow += ccol / 80; ccol %= 80;
    vga_set_cursor_hw(crow, ccol);
}

/* ── Processa un singolo tasto (pressione o autorepeat) ─────────────────── */
static void con_handle_key(vk_t vk, char ascii) {
    uint8_t mods = keyboard_get_modifiers();

    /* ── Scrollback mode ─────────────────────────────────────────────────
     * Shift+UP: scorri su.  Shift+DOWN: scorri giù o esci.
     * Qualsiasi altro tasto: esci e processa normalmente. */
    if (s_sb_active) {
        bool shift = (mods & MOD_SHIFT) != 0;
        if (vk == VK_UP && shift) {
            s_sb_offset++;
            if (s_sb_offset > vga_sb_lines()) s_sb_offset = vga_sb_lines();
            vga_scrollback_render(s_sb_offset);
            return;
        }
        if (vk == VK_DOWN && shift) {
            s_sb_offset--;
            if (s_sb_offset <= 0) { sb_exit(); return; }
            vga_scrollback_render(s_sb_offset);
            return;
        }
        /* Qualsiasi altro tasto (incluso ESC) esce dal scrollback */
        sb_exit();
        /* Poi processa normalmente il tasto ricevuto (fall-through) */
    }

    /* ── Shift+UP: entra in scrollback ──────────────────────────────────── */
    {
        bool shift = (mods & MOD_SHIFT) != 0;
        if (vk == VK_UP && shift) {
            if (vga_sb_lines() > 0) {
                /* Salva lo schermo corrente PRIMA di sovrascriverlo */
                volatile uint16_t *vga_base = (volatile uint16_t *)0xB8000;
                for (int i = 0; i < 80 * 25; i++) s_sb_live[i] = vga_base[i];
                s_sb_active = true;
                s_sb_offset = 1;
                vga_scrollback_render(s_sb_offset);
            }
            return;
        }
    }

    /* Ctrl+C */
    if (ascii == 3) {
        con_puts("^C\n", 0x0C00);
        s_len = 0; s_cur = 0; s_line[0] = '\0';
        g_ctrlc = 1;
        s_hist_idx = -1;
        s_ar_state = AR_IDLE; s_ar_key = VK_NONE;
        con_prompt();
        return;
    }

    /* Enter */
    if (vk == VK_ENTER || ascii == '\n' || ascii == '\r') {
        s_ar_state = AR_IDLE;
        s_ar_key   = VK_NONE;
        s_line[s_len] = '\0';
        /* Salva in history */
        hist_push(s_line);
        s_hist_idx = -1;
        int erow = s_input_row, ecol = s_input_col + s_len;
        erow += ecol / 80; ecol %= 80;
        vga_set_pos(erow, ecol);
        con_nl(); con_exec(); con_prompt();
        return;
    }

    /* UP senza Shift = history precedente */
    if (vk == VK_UP) {
        if (s_hist_count == 0) return;
        if (s_hist_idx == -1) {
            /* Prima pressione: salva riga corrente */
            int j = 0;
            while (s_line[j] && j < CON_MAX - 1) { s_hist_saved[j] = s_line[j]; j++; }
            s_hist_saved[j] = '\0';
            s_hist_idx = 0;
        } else if (s_hist_idx < s_hist_count - 1) {
            s_hist_idx++;
        }
        hist_load(s_hist_idx);
        return;
    }

    /* DOWN senza Shift = history successiva */
    if (vk == VK_DOWN) {
        if (s_hist_idx < 0) return;
        s_hist_idx--;
        if (s_hist_idx < 0) {
            /* Torna alla riga salvata */
            int j = 0;
            while (s_hist_saved[j] && j < CON_MAX - 1) { s_line[j] = s_hist_saved[j]; j++; }
            s_line[j] = '\0';
            s_len = j; s_cur = j;
            con_redraw_line();
        } else {
            hist_load(s_hist_idx);
        }
        return;
    }

    /* Backspace */
    if (vk == VK_BACKSPACE || ascii == '\b') {
        if (s_cur > 0) {
            s_cur--;
            for (int i = s_cur; i < s_len - 1; i++) s_line[i] = s_line[i+1];
            s_len--;
            con_redraw_line();
        }
        return;
    }

    /* Delete */
    if (vk == VK_DELETE) {
        if (s_cur < s_len) {
            for (int i = s_cur; i < s_len - 1; i++) s_line[i] = s_line[i+1];
            s_len--;
            con_redraw_line();
        }
        return;
    }

    if (vk == VK_LEFT)  { if (s_cur > 0)     { s_cur--; con_redraw_line(); } return; }
    if (vk == VK_RIGHT) { if (s_cur < s_len)  { s_cur++; con_redraw_line(); } return; }
    if (vk == VK_HOME)  { s_cur = 0;           con_redraw_line(); return; }
    if (vk == VK_END)   { s_cur = s_len;        con_redraw_line(); return; }

    if ((unsigned char)ascii >= 0x20 && (unsigned char)ascii != 0x7F) {
        /* Qualsiasi carattere digitato resetta la navigazione history */
        s_hist_idx = -1;
        if (s_len < CON_MAX - 1) {
            for (int i = s_len; i > s_cur; i--) s_line[i] = s_line[i-1];
            s_line[s_cur++] = ascii;
            s_len++;
            con_redraw_line();
        }
    }
}

static void __attribute__((noreturn)) kernel_console(void) {
    /* Registra handler timer LAPIC vec 0x20 → incrementa g_con_ms ogni 1ms */
    register_irq_handler(0x20, con_timer_handler);

    vga_puts_attr("\n", 0x0700);
    vga_puts_attr("  \xC4\xC4\xC4\xC4\xC4\xC4\xC4\xC4\xC4\xC4\xC4\xC4\xC4\xC4\xC4\xC4\xC4\xC4\xC4\xC4\xC4\xC4\xC4\xC4\xC4\xC4\xC4\xC4\xC4\xC4\xC4\xC4\xC4\xC4\xC4\xC4\n", 0x0800);
    vga_puts_attr("  MattiaOS " MATTIAOS_VERSION
                  " - Boot OK. Tastiera IT. Digita 'help' per i comandi.\n", 0x0A00);
    vga_puts_attr("  \xC4\xC4\xC4\xC4\xC4\xC4\xC4\xC4\xC4\xC4\xC4\xC4\xC4\xC4\xC4\xC4\xC4\xC4\xC4\xC4\xC4\xC4\xC4\xC4\xC4\xC4\xC4\xC4\xC4\xC4\xC4\xC4\xC4\xC4\xC4\xC4\n", 0x0800);
    serial_puts("\r\n[CONSOLE] Boot OK.\r\n");

    con_prompt();

    /* Abilita interrupt UNA volta: timer LAPIC + keyboard IRQ arriveranno
     * a interrupt handler. Non usiamo `hlt` per evitare race conditions
     * in VirtualBox NEM (Hyper-V): hlt può tornare per interrupt spuri,
     * causando iterazioni spurie del loop che corrompono il timing AR. */
    asm volatile("sti");

    for (;;) {
        /* pause: hint al processore che siamo in spin loop.
         * Gli interrupt sono abilitati (sti fuori dal loop): il timer LAPIC
         * ISR incrementa g_con_ms ogni 1ms, il keyboard IRQ fa solo EOI. */
        asm volatile("pause");

        /* Decodifica byte PS/2 → eventi. Unico consumer: nessuna race. */
        keyboard_process();

        /* Drena TUTTI gli eventi disponibili in questa iterazione. */
        key_event_t ev;
        while (keyboard_poll_event(&ev)) {
            if (ev.pressed) {
                /* Ogni MAKE genuino (i duplicati sono già filtrati dal
                 * bitset s_pressed in keyboard.c): avvia/riavvia AR. */
                s_ar_key   = ev.keycode;
                s_ar_ascii = ev.ascii;
                s_ar_state = AR_DELAY;
                s_ar_ms    = g_con_ms;
                con_handle_key(ev.keycode, ev.ascii);
            } else {
                /* BREAK = rilascio reale (VirtualBox manda MAKE ripetuti,
                 * non BREAK+MAKE, durante il typematic). Cancella AR. */
                if (ev.keycode == s_ar_key) {
                    s_ar_state = AR_IDLE;
                    s_ar_key   = VK_NONE;
                }
            }
        }

        /* Macchina a stati autorepeat. */
        if (s_ar_state != AR_IDLE) {
            uint32_t elapsed = g_con_ms - s_ar_ms;
            if (s_ar_state == AR_DELAY && elapsed >= AR_DELAY_MS) {
                s_ar_state = AR_REPEAT;
                s_ar_ms    = g_con_ms;
                con_handle_key(s_ar_key, s_ar_ascii);
            } else if (s_ar_state == AR_REPEAT && elapsed >= AR_REPEAT_MS) {
                s_ar_ms = g_con_ms;
                con_handle_key(s_ar_key, s_ar_ascii);
            }
        }
    }
}

/* ═══════════════════════════════════════════════════════════════════════════
 * kernel_main — entry point
 * ═══════════════════════════════════════════════════════════════════════════ */


/* Stack di boot dedicato: 128KB, allineato a 16 byte.
 * Stage2 salta al kernel con RSP=0x7C00 (solo 3KB di stack).
 * ORDINE CRITICO:
 *   1. BSS clear (usa ancora lo stack stage2 di 3KB — sufficiente per il loop)
 *   2. Stack switch al g_boot_stack appena azzerato
 * NON invertire: g_boot_stack è nel BSS, se switchiamo prima il BSS clear
 * azzera lo stack attivo → corruzione dello stack → crash immediato. */
static uint8_t g_boot_stack[131072] __attribute__((aligned(16)));

void kernel_main(void) {
    /* 1a. BSS clear — PRIMA dello stack switch, usa ancora RSP=0x7C00 */
    extern char _bss_start[], _bss_end[];
    for (char *p = _bss_start; p < _bss_end; p++) *p = 0;

    /* 1b. Switch allo stack dedicato (ora sicuro: BSS già azzerato) */
    asm volatile(
        "lea %0, %%rax\n\t"
        "add %1, %%rax\n\t"
        "mov %%rax, %%rsp\n\t"
        :
        : "m"(g_boot_stack), "i"(sizeof(g_boot_stack))
        : "rax", "memory"
    );

    /* 1. GDT / IDT / Serial / VGA banner */
    gdt_init(); idt_init(); serial_init();
    vga_banner(MATTIAOS_VERSION);

    klog_vga(KLOG_OK,   "GDT",    "Descriptor tables (6 entry + TSS 128-bit)");
    klog_vga(KLOG_OK,   "IDT",    "256 interrupt vectors — IST1 DF, IST2 NMI, IST3 MCE");
    klog_vga(KLOG_OK,   "SERIAL", "COM1 @ 38400 baud + VGA text 80x25");

    /*
     * PIC 8259 — DEVE essere rimappato prima di sti().
     *
     * Senza pic_init() il PIC master ha IRQ1 (tastiera) mappato al vettore
     * CPU 0x09 (Coprocessor Segment Overrun). Ogni keypress genera un'eccezione
     * CPU invece di chiamare il nostro handler → KERNEL PANIC immediato.
     *
     * pic_init() rimappa il PIC a 0x20/0x28 e maschera tutti gli IRQ eccetto
     * IRQ1 (kbd) e IRQ12 (mouse).  Chiamata PRIMA di lapic_init() e sti().
     */
    pic_init();
    klog_vga(KLOG_OK, "PIC", "8259 rimappato: IRQ0-7→0x20, IRQ8-15→0x28. IRQ1/IRQ12 attivi");

    /* 2. Limine responses */
    klog_vga(KLOG_INFO, "LIMINE", "Verifica boot protocol responses...");
    if (!memmap_request.response) kpanic_early("Limine memmap response NULL");
    if (!hhdm_request.response)   kpanic_early("Limine HHDM response NULL");
    if (!kaddr_request.response)  kpanic_early("Limine kernel address response NULL");
    klog_vga(KLOG_OK, "LIMINE", "Responses valide");
    klog_detail("Kernel phys:  ", "0x200000  virt: 0xFFFFFFFF80000000");
    klog_detail("HHDM offset:  ", "0xFFFF800000000000");
    /* dump_memmap rimosso */

    /* 3. PMM */
    klog_vga(KLOG_INFO, "PMM", "Physical Memory Manager...");

    /*
     * Calcola kernel_phys_end PRIMA di pmm_init.
     *
     * BUG v4.12 ROOT CAUSE: con BSS grande (cmd_tree statiche = 2.2MB) il
     * kernel fisico si estendeva oltre PMM_RESERVED_BELOW=0x400000.
     * pmm_init posizionava il bitmap PMM a 0x400000 (dentro il BSS!) e lo
     * azzerava con memset(0xFF) → corruzione BSS → triple fault all'STI.
     * FIX v4.13: passiamo ke_phys a pmm_init → bitmap sempre DOPO il kernel.
     */
    {
        extern char _kernel_end[];
        const uint64_t KBASE_VIRT = 0xFFFFFFFF80000000ULL;
        const uint64_t KBASE_PHYS = 0x200000ULL;
        uint64_t ke_phys = (uint64_t)_kernel_end - KBASE_VIRT + KBASE_PHYS;
        ke_phys = (ke_phys + 0xFFFULL) & ~0xFFFULL;

        pmm_init(memmap_request.response, ke_phys);

        /* Riserva regioni critiche non marcate da E820/Limine:
         *   [A] 0x000000–0x200000: PT stage2, Limine responses, ELF staging
         *   [B] 0x200000–ke_phys:  kernel ELF + BSS (E820 li vede come USABLE) */
        pmm_mark_used(0x000000ULL, 0x200000ULL);
        pmm_mark_used(0x200000ULL, ke_phys);
    }

    klog_vga(KLOG_OK,   "PMM", "Bitmap PMM pronto");
    {
        char b[12];
        u64_to_dec(pmm_total_memory()/(1024*1024), b);
        klog_detail("RAM totale: ", b);
        u64_to_dec(pmm_free_memory()/(1024*1024), b);
        klog_detail("RAM libera: ", b);
    }

    /* 4. VMM */
    klog_vga(KLOG_INFO, "VMM", "Virtual Memory Manager (4-level paging)...");
    vmm_init(hhdm_request.response->offset, kaddr_request.response);
    klog_vga(KLOG_OK,   "VMM", "PML4 attivo — EFER.NXE + EFER.SCE abilitati");
    klog_detail("Kernel:  ", "0xFFFFFFFF80000000 (higher half)");
    klog_detail("HHDM:    ", "0xFFFF800000000000 — 4GB identity");
    klog_detail("Low mem: ", "0x0000–0xFFFFF identity (boot stack + VGA 0xB8000)");

    /* 5. Slab */
    klog_vga(KLOG_INFO, "SLAB", "Slab allocator...");
    slab_init();
    klog_vga(KLOG_OK,   "SLAB", "kmalloc/kfree — 9 cache (16-4096B) + large");

    /* 6. ACPI */
    if (rsdp_request.response && rsdp_request.response->address) {
        klog_vga(KLOG_INFO, "ACPI", "RSDP trovato — parsing RSDT/XSDT...");
        acpi_init(rsdp_request.response->address);
        klog_vga(KLOG_OK,   "ACPI", "MADT + HPET parsati");
    } else {
        klog_vga(KLOG_WARN, "ACPI", "RSDP non disponibile — timer usa fallback 1M");
    }

    /* 7. LAPIC + timer APIC + I/O APIC */
    klog_vga(KLOG_INFO, "APIC", "LAPIC init + calibrazione timer...");
    lapic_init();
    apic_timer_init();
    klog_vga(KLOG_OK,   "APIC", "LAPIC attivo — timer periodico 1ms (vec 0x20)");
    {
        char b[12];
        u64_to_dec(g_apic_ticks_per_ms, b);
        klog_detail("Calibrazione HPET: ", b);
        klog_detail("  ticks/ms", "");
    }

    /*
     * I/O APIC — inizializzazione redirect table.
     *
     * In modalità APIC (dopo lapic_init), gli IRQ hardware (tastiera, mouse,
     * ecc.) passano per l'I/O APIC prima di arrivare al LAPIC.  Senza questa
     * inizializzazione, IRQ1 (tastiera) non arriva mai alla CPU indipendentemente
     * da quanto correttamente sia configurato il PIC 8259.
     *
     * ioapic_init() programma INTIN#1 → vector 0x21 (kbd) e maschera tutti
     * gli altri intin non usati per evitare interrupt spuri.
     */
    klog_vga(KLOG_INFO, "IOAPIC", "Programmazione I/O APIC redirect table...");
    ioapic_init();
    klog_vga(KLOG_OK,   "IOAPIC", "IRQ1→0x21(kbd) IRQ12→0x2C(mouse) attivi");

    /* 8. PCI */
    klog_vga(KLOG_INFO, "PCI", "Enumerazione bus PCI (I/O port 0xCF8/0xCFC)...");
    pci_enumerate();
    klog_vga(KLOG_OK,   "PCI", "Bus PCI enumerato");
    dump_pci_vga();

    /* 9. VFS */
    klog_vga(KLOG_INFO, "VFS", "Montaggio Virtual Filesystem...");
    vfs_init();
    vfs_mount("/",    tmpfs_get_fs(), NULL);   /* root tmpfs */
    vfs_mount("/dev", devfs_get_fs(), NULL);   /* device fs  */

    /* ── Directory struttura base ─────────────────────────────────────────── */
    vfs_mkdir("/tmp",  0x41EDU);
    vfs_mkdir("/etc",  0x41EDU);
    vfs_mkdir("/home", 0x41EDU);
    vfs_mkdir("/var",  0x41EDU);
    vfs_mkdir("/sys",  0x41EDU);

    /* /home/ciao.txt — file di benvenuto */
    vfs_create_file("/home/ciao.txt", 0x81A4U);
    {
        file_t *f = vfs_open("/home/ciao.txt", 1);
        if (f) { vfs_write(f, "ciao\n", 5); vfs_close(f); }
    }

    /* ── /home/mattia_hello — programma demo eseguibile ─────────────────── *
     * Sarà il primo "eseguibile" di MattiaOS (Phase 13: ELF loader).        *
     * Per ora è un file testo che descrive cosa farebbe.                    */
    vfs_create_file("/home/mattia_hello", 0x81EDU); /* -rwxr-xr-x */
    {
        static const char s_hello[] =
            "#!/mattiaos\n"
            "# mattia_hello — programma demo MattiaOS v5.7\n"
            "# Autore: Mattia\n"
            "#\n"
            "# Quando Phase 13 (ELF loader) sarà pronta, questo file\n"
            "# verrà sostituito da un vero ELF x86-64 che stampa:\n"
            "#   \"Ciao dal primo programma userspace di MattiaOS!\"\n"
            "print \"Ciao dal primo programma userspace di MattiaOS!\"\n";
        file_t *f = vfs_open("/home/mattia_hello", 1);
        if (f) { vfs_write(f, s_hello, sizeof(s_hello)-1); vfs_close(f); }
    }

    /* ── /Binari_Eseguibili — comandi built-in + link a /home/mattia_hello ─ */
    vfs_mkdir("/Binari_Eseguibili", 0x41EDU);
    {
        static const struct { const char *name; const char *desc; } s_cmds[] = {
            { "help",        "# built-in\nUSAGE: help\n" },
            { "ver",         "# built-in\nUSAGE: ver\n" },
            { "mem",         "# built-in\nUSAGE: mem\n" },
            { "pci",         "# built-in\nUSAGE: pci\n" },
            { "ls",          "# built-in\nUSAGE: ls [path]\n" },
            { "cd",          "# built-in\nUSAGE: cd <path>\n" },
            { "open",        "# built-in\nUSAGE: open <path>\n" },
            { "edit",        "# built-in\nUSAGE: edit <path>\n" },
            { "tree",        "# built-in\nUSAGE: tree [path]\n" },
            { "clear",       "# built-in\nUSAGE: clear\n" },
            { "reboot",      "# built-in\nUSAGE: reboot\n" },
            { "halt",        "# built-in\nUSAGE: halt\n" },
            { "easteregg",   "# built-in\nUSAGE: easteregg\n" },
            { "mattia_hello","# demo Phase 13\nSRC: /home/mattia_hello\nUSAGE: mattia_hello\n" },
        };
        char bp[72];
        for (int i = 0; i < 14; i++) {
            int pi = 0;
            const char *pre = "/Binari_Eseguibili/";
            while (pre[pi] && pi < 40) { bp[pi] = pre[pi]; pi++; }
            int ni = 0;
            while (s_cmds[i].name[ni] && pi < 70) { bp[pi] = s_cmds[i].name[ni]; pi++; ni++; }
            bp[pi] = '\0';
            vfs_create_file(bp, 0x81A4U);
            file_t *f = vfs_open(bp, 1);
            if (f) {
                size_t dl = 0; while (s_cmds[i].desc[dl]) dl++;
                vfs_write(f, s_cmds[i].desc, dl); vfs_close(f);
            }
        }
    }

    /* ── /Dipendenze — librerie di sistema ───────────────────────────────── *
     * Una libreria per programma demo. I built-in non ne hanno bisogno.     */
    vfs_mkdir("/Dipendenze", 0x41EDU);
    vfs_create_file("/Dipendenze/libmattiac.so", 0x81A4U);
    {
        static const char s_lib[] =
            "# libmattiac.so — libreria standard MattiaOS\n"
            "# Fornisce: print, input, open, close, read, write\n"
            "# Versione: 1.0  (stub — Phase 13)\n";
        file_t *f = vfs_open("/Dipendenze/libmattiac.so", 1);
        if (f) { vfs_write(f, s_lib, sizeof(s_lib)-1); vfs_close(f); }
    }

    /* ── /sys/PATH — formato v5.7 ─────────────────────────────────────────
     * FORMATO LINEA: nome=percorso_exe:dep1:dep2:...
     *   nome          = nome del comando
     *   percorso_exe  = path assoluto all'eseguibile in /Binari_Eseguibili/
     *   dep1,dep2,... = path assoluti alle dipendenze in /Dipendenze/
     *                   (separati da ':'; assenti = nessuna dep)
     * L'interprete (con_exec) legge questa linea per:
     *   1. trovare il percorso dell'eseguibile
     *   2. caricare le dipendenze prima dell'esecuzione
     * I built-in del kernel non hanno deps; mattia_hello dipende da libmattiac. */
    vfs_create_file("/sys/PATH", 0x81A4U);
    {
        static const char s_path[] =
            "# MattiaOS /sys/PATH v5.7\n"
            "# FORMATO: nome=percorso_exe:dep1:dep2\n"
            "# I built-in kernel non hanno dipendenze.\n"
            "#\n"
            "help=/Binari_Eseguibili/help\n"
            "ver=/Binari_Eseguibili/ver\n"
            "mem=/Binari_Eseguibili/mem\n"
            "pci=/Binari_Eseguibili/pci\n"
            "ls=/Binari_Eseguibili/ls\n"
            "cd=/Binari_Eseguibili/cd\n"
            "open=/Binari_Eseguibili/open\n"
            "edit=/Binari_Eseguibili/edit\n"
            "tree=/Binari_Eseguibili/tree\n"
            "clear=/Binari_Eseguibili/clear\n"
            "reboot=/Binari_Eseguibili/reboot\n"
            "halt=/Binari_Eseguibili/halt\n"
            "easteregg=/Binari_Eseguibili/easteregg\n"
            "mattia_hello=/home/mattia_hello:/Dipendenze/libmattiac.so\n";
        file_t *f = vfs_open("/sys/PATH", 1);
        if (f) { vfs_write(f, s_path, sizeof(s_path)-1); vfs_close(f); }
    }

    klog_vga(KLOG_OK,   "VFS", "/ (tmpfs) + /dev (devfs) montati");
    klog_detail("/sys/PATH: ", "14 voci (built-in + mattia_hello)");
    klog_detail("/Binari_Eseguibili: ", "14 stub | /home/mattia_hello: demo");
    klog_detail("/Dipendenze/libmattiac.so: ", "libreria standard stub");

    /* 10. Interrupt abilitati */
    asm volatile("sti");
    klog_vga(KLOG_OK, "CPU", "Interrupt abilitati (STI — RFLAGS.IF=1)");

    /* 11. Driver hardware */
    klog_vga(KLOG_INFO, "DRV", "Inizializzazione driver hardware...");
    drivers_init();
    klog_vga(KLOG_OK,   "DRV", "Driver pronti");
    klog_detail("fb:      ", "/dev/fb0 (framebuffer GOP)");
    klog_detail("kbd:     ", "PS/2 IRQ1 — keyboard_process() su ogni keypress");
    klog_detail("storage: ", "AHCI + NVMe (se presenti)");
    klog_detail("net:     ", "virtio-net + e1000 (se presenti)");

    /* 12. Console interattiva (noreturn) */
    kernel_console();
}
