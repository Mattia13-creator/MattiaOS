#ifndef MATTIAOS_GDT_H
#define MATTIAOS_GDT_H

#include "../../include/types.h"
#include "cpu.h"

#define KERNEL_CS    0x08
#define KERNEL_DS    0x10
#define USER_CS_32   0x18
#define USER_DS      0x23
#define USER_CS_64   0x2B
#define TSS_SEL      0x30

typedef struct {
    uint16_t limit_low;
    uint16_t base_low;
    uint8_t  base_mid;
    uint8_t  access;
    uint8_t  granularity;
    uint8_t  base_high;
} __attribute__((packed)) gdt_entry_t;

typedef struct {
    uint32_t base_higher;
    uint32_t reserved;
} __attribute__((packed)) gdt_entry_high_t;

typedef struct {
    uint16_t size;
    uint64_t offset;
} __attribute__((packed)) gdtr_t;

typedef struct {
    gdt_entry_t      entries[8];
    gdt_entry_high_t tss_high;
} __attribute__((packed)) gdt_t;

void gdt_init(void);
void tss_set_rsp0(uint64_t rsp0);

extern tss_t g_tss;

#endif
