#ifndef MATTIAOS_IDT_H
#define MATTIAOS_IDT_H

#include "../../include/types.h"

#define IDT_ENTRIES 256

#define IDT_GATE_INT  0x8E
#define IDT_GATE_TRAP 0x8F
#define IDT_GATE_USER 0xEE

typedef struct {
    uint16_t offset_low;
    uint16_t selector;
    uint8_t  ist;
    uint8_t  type_attr;
    uint16_t offset_mid;
    uint32_t offset_high;
    uint32_t reserved;
} __attribute__((packed)) idt_entry_t;

typedef struct {
    uint16_t size;
    uint64_t offset;
} __attribute__((packed)) idtr_t;

typedef struct {
    uint64_t r15, r14, r13, r12;
    uint64_t r11, r10, r9, r8;
    uint64_t rbp, rdi, rsi, rdx, rcx, rbx, rax;
    uint64_t vector;
    uint64_t error_code;
    uint64_t rip;
    uint64_t cs;
    uint64_t rflags;
    uint64_t rsp;
    uint64_t ss;
} __attribute__((packed)) interrupt_frame_t;

void idt_init(void);
void idt_set_handler(uint8_t vector, void *handler, uint8_t type, uint8_t ist);

void isr_handler(interrupt_frame_t *frame);

#endif
