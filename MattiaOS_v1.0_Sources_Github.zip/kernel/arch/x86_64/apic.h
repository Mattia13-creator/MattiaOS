#ifndef MATTIAOS_APIC_H
#define MATTIAOS_APIC_H

#include "../../include/types.h"

#define LAPIC_BASE         0xFEE00000ULL
#define LAPIC_ID           0x020
#define LAPIC_VERSION      0x030
#define LAPIC_TPR          0x080
#define LAPIC_EOI          0x0B0
#define LAPIC_SPURIOUS     0x0F0
#define LAPIC_ICR_LOW      0x300
#define LAPIC_ICR_HIGH     0x310
#define LAPIC_LVT_TIMER    0x320
#define LAPIC_LVT_LINT0    0x350   /* Local Vector Table: LINT0 pin — collegato al PIC via virtual wire */
#define LAPIC_LVT_LINT1    0x360   /* Local Vector Table: LINT1 pin — NMI */
#define LAPIC_TIMER_INITCNT 0x380
#define LAPIC_TIMER_CURCNT 0x390
#define LAPIC_TIMER_DIV    0x3E0

#define LAPIC_SPURIOUS_ENABLE (1 << 8)
#define LAPIC_TIMER_PERIODIC  (1 << 17)
#define LAPIC_TIMER_VECTOR    0x20
#define LAPIC_TIMER_DIV16     0x03

/* LVT LINT delivery mode field (bits 10:8) */
#define LAPIC_LVT_DELIVERY_FIXED  (0 << 8)  /* vettore fisso              */
#define LAPIC_LVT_DELIVERY_NMI    (4 << 8)  /* NMI, ignora il campo vector */
#define LAPIC_LVT_DELIVERY_EXTINT (7 << 8)  /* ExtINT: INTA dal PIC esterno */
#define LAPIC_LVT_MASKED          (1 << 16) /* maschera il pin */

#define MSR_IA32_APIC_BASE 0x1B
#define APIC_BASE_ENABLE   (1 << 11)

void lapic_init(void);
void lapic_eoi(void);
void lapic_send_ipi(uint8_t cpu, uint8_t vector);
uint32_t lapic_id(void);

void apic_timer_init(void);
void apic_timer_calibrate(void);

/*
 * ioapic_init — inizializza l'I/O APIC per le periferiche legacy.
 *
 * DEVE essere chiamata dopo acpi_init() (usa l'indirizzo I/O APIC dalla MADT)
 * e dopo lapic_init() (usa lapic_id() per il campo destination).
 *
 * Programma la redirect table I/O APIC per:
 *   IRQ1 (keyboard PS/2) → vector 0x21, CPU 0, edge, active high, unmasked
 *   IRQ12 (mouse PS/2)   → vector 0x2C, CPU 0, edge, active high, unmasked
 *   tutte le altre entrate → masked
 *
 * In VirtualBox con I/O APIC abilitato (obbligatorio per MattiaOS), gli IRQ
 * hardware passano per l'I/O APIC, non per il percorso PIC→LINT0. Senza
 * questa funzione, IRQ1 non arriva mai alla CPU e la tastiera non risponde.
 */
void ioapic_init(void);

/*
 * g_apic_ticks_per_ms — calcolato da apic_timer_calibrate() tramite HPET.
 * Corrisponde al numero di decrementi del LAPIC timer in 1 millisecondo
 * con divisore LAPIC_TIMER_DIV16.  Usato dallo scheduler per tick da 1ms.
 */
extern uint32_t g_apic_ticks_per_ms;

#endif
