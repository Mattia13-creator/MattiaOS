#ifndef MATTIAOS_MSGQ_H
#define MATTIAOS_MSGQ_H

#include "../include/types.h"
#include "../proc/process.h"

/* =========================================================================
 * msgq.h — Message Queues IPC
 *
 * Code di messaggi kernel-side con semantica POSIX-like.  Ogni coda è
 * identificata da un nome stringa (percorso virtuale, es. "/myqueue").
 * I messaggi hanno dimensione variabile (max MQ_MSG_DATA_MAX) e priorità
 * numerica: valori più alti → consegnati prima (ordine max-first).
 *
 * Blocco e sblocco avvengono tramite scheduler_block/scheduler_unblock del
 * modulo mlfq.  Quando la coda è piena, mq_send() blocca il thread
 * mittente finché non c'è spazio.  Quando è vuota, mq_receive() blocca il
 * thread ricevente finché non arriva un messaggio.
 *
 * Uso del prefisso mq_ per tutte le funzioni pubbliche.
 * ========================================================================= */

/* Limiti di sistema */
#define MQ_MAX_QUEUES     32      /* Code attive contemporaneamente */
#define MQ_NAME_MAX       128     /* Lunghezza massima del nome (con '\0') */
#define MQ_MSG_DATA_MAX   4096    /* Payload massimo per messaggio in byte */
#define MQ_DEFAULT_DEPTH  64      /* Profondità default se depth=0 a mq_open */
#define MQ_MAX_DEPTH      256     /* Profondità massima assoluta */
#define MQ_MAX_WAITERS    32      /* Thread in attesa (send o receive) per coda */

/* Flags per mq_open */
#define MQ_OFLAG_CREAT    0x01    /* Crea la coda se non esiste */
#define MQ_OFLAG_EXCL     0x02    /* Errore se la coda esiste già (con CREAT) */
#define MQ_OFLAG_RDONLY   0x04    /* Apri solo per receive */
#define MQ_OFLAG_WRONLY   0x08    /* Apri solo per send */
#define MQ_OFLAG_RDWR     0x0C    /* Apri per send e receive */
#define MQ_OFLAG_NONBLOCK 0x10    /* Operazioni non bloccanti */

/* Priorità di default per messaggi inviati senza priorità esplicita */
#define MQ_PRIO_DEFAULT   0

/* -------------------------------------------------------------------------
 * mq_msg_t — un singolo messaggio nella coda
 * ------------------------------------------------------------------------- */
typedef struct {
    uint32_t prio;                  /* Priorità: valore maggiore → prima */
    size_t   size;                  /* Dimensione effettiva del payload */
    uint8_t  data[MQ_MSG_DATA_MAX]; /* Payload */
} mq_msg_t;

/* -------------------------------------------------------------------------
 * msgq_t — descrittore interno di una coda di messaggi
 * ------------------------------------------------------------------------- */
typedef struct {
    char     name[MQ_NAME_MAX]; /* Nome della coda (es. "/myqueue") */
    bool     valid;             /* true se il record è in uso */
    bool     unlinked;          /* true dopo mq_unlink: chiusa all'ultimo close */

    /* Ring buffer di messaggi (allocato dinamicamente con kmalloc) */
    mq_msg_t *ring;             /* Array di `capacity` elementi */
    uint32_t  capacity;         /* Capacità massima (depth) */
    uint32_t  head;             /* Indice prossima lettura */
    uint32_t  tail;             /* Indice prossima scrittura */
    uint32_t  count;            /* Messaggi presenti */

    /* Numero di fd/descrittori aperti che referenziano questa coda */
    int32_t  open_count;

    spinlock_t lock;            /* Protegge head/tail/count/ring */

    /* Thread bloccati in attesa di spazio (mq_send su coda piena) */
    thread_t *waiters_send[MQ_MAX_WAITERS];
    uint32_t  waiters_send_count;

    /* Thread bloccati in attesa di un messaggio (mq_receive su coda vuota) */
    thread_t *waiters_recv[MQ_MAX_WAITERS];
    uint32_t  waiters_recv_count;
} msgq_t;

/* =========================================================================
 * API pubblica
 * ========================================================================= */

/*
 * mq_open — apre (o crea) una coda di messaggi.
 *
 * @name:   nome della coda, deve iniziare con '/'.
 * @flags:  combinazione di MQ_OFLAG_*. MQ_OFLAG_CREAT richiesto per creare.
 * @depth:  profondità della coda (0 = MQ_DEFAULT_DEPTH). Ignorato se la
 *          coda già esiste senza MQ_OFLAG_EXCL.
 * @return: mqd (message queue descriptor) >= 0; EINVAL, ENOMEM, EEXIST,
 *          ENOENT (se CREAT non specificato e coda non esiste).
 */
int mq_open(const char *name, uint32_t flags, uint32_t depth);

/*
 * mq_close — chiude un descrittore di coda.
 *
 * @mqd: descrittore restituito da mq_open.
 * @return: EOK, EBADF se mqd non valido.
 *
 * Se open_count scende a 0 e la coda è stata mq_unlink'd, la coda
 * viene distrutta e il ring buffer liberato.
 */
int mq_close(int mqd);

/*
 * mq_send — invia un messaggio nella coda.
 *
 * @mqd:   descrittore della coda.
 * @data:  puntatore al payload.
 * @size:  dimensione del payload (max MQ_MSG_DATA_MAX).
 * @prio:  priorità del messaggio (maggiore = consegnato prima).
 * @return: EOK, EBADF, EINVAL (size troppo grande), EAGAIN (coda piena
 *          con MQ_OFLAG_NONBLOCK).
 *
 * Se la coda è piena e il flag NONBLOCK non è impostato, il thread
 * corrente viene bloccato tramite scheduler_block() finché un receiver
 * non consuma almeno un messaggio.
 */
int mq_send(int mqd, const void *data, size_t size, uint32_t prio);

/*
 * mq_receive — riceve il messaggio a priorità più alta dalla coda.
 *
 * @mqd:      descrittore della coda.
 * @buf:      buffer di output per il payload.
 * @buf_size: dimensione del buffer (deve essere >= MQ_MSG_DATA_MAX
 *            per non troncare; viene comunque scritto min(msg.size, buf_size)).
 * @prio_out: se non NULL, riceve la priorità del messaggio letto.
 * @return:   numero di byte copiati in buf (>= 0); EBADF, EAGAIN (coda
 *            vuota con NONBLOCK), EINVAL.
 *
 * Se la coda è vuota e il flag NONBLOCK non è impostato, il thread
 * viene bloccato tramite scheduler_block() finché un sender non inserisce
 * un messaggio.
 */
int mq_receive(int mqd, void *buf, size_t buf_size, uint32_t *prio_out);

/*
 * mq_unlink — segna la coda per eliminazione al prossimo close.
 *
 * @name: nome della coda da eliminare.
 * @return: EOK, ENOENT se non trovata.
 *
 * Dopo mq_unlink la coda non è più apribile da nuovi chiamanti ma rimane
 * funzionante per i descrittori già aperti.  Distrutta all'ultimo mq_close().
 */
int mq_unlink(const char *name);

#endif /* MATTIAOS_MSGQ_H */
