#ifndef MATTIAOS_SHM_H
#define MATTIAOS_SHM_H

#include "../include/types.h"
#include "../proc/process.h"

/* =========================================================================
 * shm.h — Shared Memory IPC
 *
 * Regioni di memoria condivisa identificate da chiave numerica (shm_key_t).
 * Implementazione: le pagine fisiche di ogni regione vengono mappate con
 * vmm_map() in ogni spazio di indirizzi dei processi che eseguono attach.
 * Uso principale: compositor GUI → condivisione buffer di rendering con
 * le applicazioni (Fase 13+).
 *
 * Nota sul refcount: shm_region_t mantiene un contatore di attach attivi
 * (attach_count) per sapere quando liberare le pagine fisiche.  Questo non
 * viola il Principio 2 del blueprint, che riguarda i file su disco.  La
 * memoria condivisa è un dominio separato: le pagine fisiche devono
 * esistere finché almeno un processo le usa.
 * ========================================================================= */

/* Chiave identificativa di una regione condivisa — scelta dal chiamante */
typedef uint64_t shm_key_t;

/* Limiti di sistema */
#define SHM_MAX_REGIONS        64    /* Numero massimo di regioni attive */
#define SHM_MAX_PAGES_PER_REGION 256 /* Max pagine per regione = 1 MB */
#define SHM_MAX_ATTACHMENTS    32    /* Max attacchi simultanei per regione */

/* Flags per shm_create */
#define SHM_FLAG_NONE          0x00
#define SHM_FLAG_EXCL          0x01  /* Errore se la chiave esiste già */

/* Flags di protezione per shm_attach (combinabili) */
#define SHM_PROT_READ          0x01
#define SHM_PROT_WRITE         0x02
#define SHM_PROT_RW            (SHM_PROT_READ | SHM_PROT_WRITE)

/* -------------------------------------------------------------------------
 * shm_region_t — descrittore interno di una regione condivisa.
 * Non esposto direttamente all'utente: si accede tramite shmid (indice).
 * ------------------------------------------------------------------------- */
typedef struct {
    shm_key_t  key;               /* Chiave univoca assegnata dal chiamante */
    bool       valid;             /* true se il record è in uso */

    size_t     size;              /* Dimensione in byte (arrotondata a PAGE_SIZE) */
    uint32_t   n_pages;           /* Numero di pagine fisiche allocate */
    uint64_t   phys_pages[SHM_MAX_PAGES_PER_REGION]; /* Indirizzi fisici */

    /* Processi attualmente attaccati + indirizzo virtuale nel loro spazio */
    process_t *attach_procs[SHM_MAX_ATTACHMENTS];
    uint64_t   attach_vaddrs[SHM_MAX_ATTACHMENTS];
    uint32_t   attach_count;      /* Numero di attacchi attivi */

    spinlock_t lock;              /* Protegge i campi sopra */
} shm_region_t;

/* =========================================================================
 * API pubblica
 * ========================================================================= */

/*
 * shm_create — crea una nuova regione di memoria condivisa.
 *
 * @key:   chiave numerica univoca scelta dal chiamante.
 * @size:  dimensione richiesta in byte (arrotondata internamente a PAGE_SIZE).
 * @flags: SHM_FLAG_NONE oppure SHM_FLAG_EXCL.
 * @return: shmid >= 0 in caso di successo; EINVAL, ENOMEM, EEXIST se errore.
 *
 * Se la chiave esiste già e flags non include SHM_FLAG_EXCL, restituisce
 * il shmid della regione esistente (semantica get-or-create).
 */
int shm_create(shm_key_t key, size_t size, uint32_t flags);

/*
 * shm_attach — mappa la regione nel pagemap del processo chiamante.
 *
 * @shmid:     identificatore restituito da shm_create.
 * @proc:      processo che richiede l'attach.
 * @prot:      SHM_PROT_READ | SHM_PROT_WRITE (combinazione).
 * @vaddr_out: riceve l'indirizzo virtuale nel pagemap del processo.
 * @return:    EOK, EINVAL (shmid non valido), ENOMEM, EBUSY (troppi attach).
 *
 * Le pagine vengono mappate a partire dalla prima VMA libera sopra 0x10000
 * nello spazio utente del processo.  Il kernel NON tiene traccia del vaddr
 * dopo detach — è responsabilità del processo non usarlo più.
 */
int shm_attach(int shmid, process_t *proc, uint32_t prot, uint64_t *vaddr_out);

/*
 * shm_detach — rimuove il mapping dal pagemap del processo.
 *
 * @shmid: identificatore della regione.
 * @proc:  processo che esegue il detach.
 * @return: EOK, EINVAL se shmid non valido o processo non attaccato.
 *
 * Se attach_count scende a 0 e la regione non è più referenced da nessuno,
 * le pagine fisiche vengono liberate immediatamente.
 */
int shm_detach(int shmid, process_t *proc);

/*
 * shm_destroy — marca la regione per eliminazione.
 *
 * @shmid: identificatore della regione.
 * @return: EOK, EINVAL se shmid non valido.
 *
 * Se nessun processo è attaccato, le pagine fisiche sono liberate subito.
 * Se ci sono attach attivi, la regione viene marcata come pending-destroy:
 * le pagine saranno liberate all'ultimo shm_detach().
 */
int shm_destroy(int shmid);

/*
 * shm_find — cerca una regione per chiave.
 *
 * @key:    chiave da cercare.
 * @return: shmid >= 0 se trovata, ENOENT se non esiste.
 */
int shm_find(shm_key_t key);

#endif /* MATTIAOS_SHM_H */
