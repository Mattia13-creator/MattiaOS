#include "shm.h"
#include "../mm/pmm.h"
#include "../mm/vmm.h"
#include "../mm/slab.h"
#include "../include/errno.h"
#include "../arch/x86_64/cpu.h"   /* serial_puts — debug logging */

/* =========================================================================
 * Indirizzo virtuale base per i mapping SHM in userspace.
 * Iniziamo a 256 MB per lasciare spazio a stack e heap del processo.
 * Ogni regione viene mappata immediatamente dopo la precedente con passo
 * PAGE_SIZE * n_pages + PAGE_SIZE (guard page tra le regioni).
 * In Fase 13+ il compositor stabilirà una convenzione specifica; per ora
 * usiamo un range fisso che non collide con stack (tipicamente al top) e
 * heap (cresce verso l'alto da heap_start).
 * ========================================================================= */
#define SHM_VADDR_BASE  0x0000000010000000ULL  /* 256 MB */
#define SHM_VADDR_STEP  0x0000000000200000ULL  /* 2 MB per regione — allineato a hugepage */

/* =========================================================================
 * Tabella globale delle regioni condivise
 * ========================================================================= */
static shm_region_t s_regions[SHM_MAX_REGIONS];
static spinlock_t   s_table_lock = {0};   /* Protegge l'indice globale */

/* Flag "pending destroy": la regione deve essere eliminata al prossimo detach */
static bool s_pending_destroy[SHM_MAX_REGIONS];

/* =========================================================================
 * Helper no-libc
 * ========================================================================= */
static inline void shm_memset(void *dst, int val, size_t n) {
    uint8_t *p = (uint8_t *)dst;
    for (size_t i = 0; i < n; i++) p[i] = (uint8_t)val;
}

/* =========================================================================
 * Alloca un vaddr libero nel pagemap del processo per n_pages pagine.
 * Strategia semplice: scorri da SHM_VADDR_BASE a passi di SHM_VADDR_STEP
 * finché trovi un range non mappato.
 * ========================================================================= */
static uint64_t find_free_vaddr(process_t *proc, uint32_t n_pages) {
    uint64_t candidate = SHM_VADDR_BASE;
    uint64_t limit     = 0x00007FFF00000000ULL;  /* Limite userspace sicuro */

    while (candidate + (uint64_t)n_pages * PAGE_SIZE < limit) {
        bool free = true;
        for (uint32_t i = 0; i < n_pages; i++) {
            if (vmm_virt_to_phys(proc->pagemap,
                                  candidate + (uint64_t)i * PAGE_SIZE) != 0) {
                free = false;
                break;
            }
        }
        if (free) return candidate;
        candidate += SHM_VADDR_STEP;
    }
    return 0;  /* Spazio esaurito */
}

/* =========================================================================
 * Libera le pagine fisiche di una regione
 * ========================================================================= */
static void free_region_pages(shm_region_t *r) {
    for (uint32_t i = 0; i < r->n_pages; i++) {
        if (r->phys_pages[i]) {
            pmm_free_frame(r->phys_pages[i]);
            r->phys_pages[i] = 0;
        }
    }
}

/* =========================================================================
 * API — shm_create
 * ========================================================================= */
int shm_create(shm_key_t key, size_t size, uint32_t flags) {
    if (size == 0) return EINVAL;

    uint64_t f = spinlock_irqsave(&s_table_lock);

    /* Cerca se la chiave esiste già */
    for (int i = 0; i < SHM_MAX_REGIONS; i++) {
        if (s_regions[i].valid && s_regions[i].key == key) {
            if (flags & SHM_FLAG_EXCL) {
                spinlock_irqrestore(&s_table_lock, f);
                return EEXIST;
            }
            spinlock_irqrestore(&s_table_lock, f);
            return i;  /* Restituisce shmid esistente */
        }
    }

    /* Cerca slot libero */
    int slot = -1;
    for (int i = 0; i < SHM_MAX_REGIONS; i++) {
        if (!s_regions[i].valid) { slot = i; break; }
    }
    if (slot < 0) {
        spinlock_irqrestore(&s_table_lock, f);
        return ENOMEM;
    }

    /* Dimensione arrotondata a PAGE_SIZE */
    size_t aligned = (size + PAGE_SIZE - 1) & ~(PAGE_SIZE - 1);
    uint32_t n = (uint32_t)(aligned / PAGE_SIZE);
    if (n > SHM_MAX_PAGES_PER_REGION) {
        spinlock_irqrestore(&s_table_lock, f);
        return EINVAL;
    }

    shm_region_t *r = &s_regions[slot];
    shm_memset(r, 0, sizeof(*r));
    r->key    = key;
    r->valid  = true;
    r->size   = aligned;
    r->n_pages = n;

    /* Alloca le pagine fisiche — azzerate tramite HHDM */
    for (uint32_t i = 0; i < n; i++) {
        uint64_t phys = pmm_alloc_frame();
        if (!phys) {
            /* Rollback */
            for (uint32_t j = 0; j < i; j++) pmm_free_frame(r->phys_pages[j]);
            shm_memset(r, 0, sizeof(*r));
            spinlock_irqrestore(&s_table_lock, f);
            return ENOMEM;
        }
        r->phys_pages[i] = phys;
        /* Azzera la pagina via HHDM */
        shm_memset(phys_to_virt(phys), 0, PAGE_SIZE);
    }

    s_pending_destroy[slot] = false;
    spinlock_irqrestore(&s_table_lock, f);

    serial_puts("[SHM] Regione creata, id=");
    serial_putchar('0' + slot);
    serial_puts("\n");
    return slot;
}

/* =========================================================================
 * API — shm_find
 * ========================================================================= */
int shm_find(shm_key_t key) {
    uint64_t f = spinlock_irqsave(&s_table_lock);
    for (int i = 0; i < SHM_MAX_REGIONS; i++) {
        if (s_regions[i].valid && s_regions[i].key == key) {
            spinlock_irqrestore(&s_table_lock, f);
            return i;
        }
    }
    spinlock_irqrestore(&s_table_lock, f);
    return ENOENT;
}

/* =========================================================================
 * API — shm_attach
 * ========================================================================= */
int shm_attach(int shmid, process_t *proc, uint32_t prot, uint64_t *vaddr_out) {
    if (shmid < 0 || shmid >= SHM_MAX_REGIONS) return EINVAL;
    if (!proc || !vaddr_out)                    return EINVAL;

    shm_region_t *r = &s_regions[shmid];
    uint64_t f = spinlock_irqsave(&r->lock);

    if (!r->valid) {
        spinlock_irqrestore(&r->lock, f);
        return EINVAL;
    }
    if (r->attach_count >= SHM_MAX_ATTACHMENTS) {
        spinlock_irqrestore(&r->lock, f);
        return EBUSY;
    }

    /* Trova vaddr libero nel pagemap del processo */
    uint64_t vaddr = find_free_vaddr(proc, r->n_pages);
    if (!vaddr) {
        spinlock_irqrestore(&r->lock, f);
        return ENOMEM;
    }

    /* Costruisce i flag PTE in base alla protezione richiesta */
    uint64_t pte_flags = PTE_PRESENT | PTE_USER;
    if (prot & SHM_PROT_WRITE)  pte_flags |= PTE_WRITABLE;
    /* NX se non si richiede execute (sempre per dati SHM) */
    pte_flags |= PTE_NX;

    /* Mappa ogni pagina fisica nel pagemap del processo */
    for (uint32_t i = 0; i < r->n_pages; i++) {
        vmm_map(proc->pagemap,
                vaddr + (uint64_t)i * PAGE_SIZE,
                r->phys_pages[i],
                pte_flags);
    }

    /* Registra l'attach */
    r->attach_procs[r->attach_count]  = proc;
    r->attach_vaddrs[r->attach_count] = vaddr;
    r->attach_count++;

    *vaddr_out = vaddr;
    spinlock_irqrestore(&r->lock, f);
    return EOK;
}

/* =========================================================================
 * API — shm_detach
 * ========================================================================= */
int shm_detach(int shmid, process_t *proc) {
    if (shmid < 0 || shmid >= SHM_MAX_REGIONS) return EINVAL;
    if (!proc)                                   return EINVAL;

    shm_region_t *r = &s_regions[shmid];
    uint64_t f = spinlock_irqsave(&r->lock);

    if (!r->valid) {
        spinlock_irqrestore(&r->lock, f);
        return EINVAL;
    }

    /* Cerca il processo nella lista degli attach */
    int idx = -1;
    for (uint32_t i = 0; i < r->attach_count; i++) {
        if (r->attach_procs[i] == proc) { idx = (int)i; break; }
    }
    if (idx < 0) {
        spinlock_irqrestore(&r->lock, f);
        return EINVAL;
    }

    uint64_t vaddr = r->attach_vaddrs[idx];

    /* Rimuovi il mapping dal pagemap del processo */
    for (uint32_t i = 0; i < r->n_pages; i++) {
        vmm_unmap(proc->pagemap, vaddr + (uint64_t)i * PAGE_SIZE);
    }

    /* Rimuovi il record compact (sostituisci con l'ultimo) */
    uint32_t last = r->attach_count - 1;
    if ((uint32_t)idx != last) {
        r->attach_procs[idx]  = r->attach_procs[last];
        r->attach_vaddrs[idx] = r->attach_vaddrs[last];
    }
    r->attach_procs[last]  = NULL;
    r->attach_vaddrs[last] = 0;
    r->attach_count--;

    /* Se pending destroy e nessun processo rimasto, libera le pagine */
    if (s_pending_destroy[shmid] && r->attach_count == 0) {
        free_region_pages(r);
        shm_memset(r, 0, sizeof(*r));
        s_pending_destroy[shmid] = false;
    }

    spinlock_irqrestore(&r->lock, f);
    return EOK;
}

/* =========================================================================
 * API — shm_destroy
 * ========================================================================= */
int shm_destroy(int shmid) {
    if (shmid < 0 || shmid >= SHM_MAX_REGIONS) return EINVAL;

    shm_region_t *r = &s_regions[shmid];
    uint64_t f = spinlock_irqsave(&r->lock);

    if (!r->valid) {
        spinlock_irqrestore(&r->lock, f);
        return EINVAL;
    }

    if (r->attach_count == 0) {
        /* Nessun processo attaccato: libera subito */
        free_region_pages(r);
        shm_memset(r, 0, sizeof(*r));
        s_pending_destroy[shmid] = false;
    } else {
        /* Processi ancora attaccati: defer all'ultimo detach */
        s_pending_destroy[shmid] = true;
    }

    spinlock_irqrestore(&r->lock, f);
    return EOK;
}
