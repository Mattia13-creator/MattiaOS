/* limine.h — Limine Boot Protocol v8 (reconstructed from spec)
 * Self-contained: no #include of system headers. Uses compiler builtins.
 * Compatible with freestanding -ffreestanding kernel compilation.
 */
#ifndef LIMINE_H
#define LIMINE_H 1

/* Use compiler-provided type macros, not system headers */
typedef __UINT8_TYPE__   __limine_u8;
typedef __UINT16_TYPE__  __limine_u16;
typedef __UINT32_TYPE__  __limine_u32;
typedef __UINT64_TYPE__  __limine_u64;

/* ─── Base revision ───────────────────────────────────────────────── */
#define LIMINE_BASE_REVISION(n) \
    volatile __limine_u64 limine_base_revision[3] = { \
        0xf9562b2d5c95a6c8ULL, 0x6a7b384944536bdcULL, (n) }

/* ─── Request section markers ────────────────────────────────────── */
#define LIMINE_REQUESTS_START_MARKER \
    volatile __limine_u64 limine_requests_start_marker[2] = { \
        0xf6b8f4b39de7d1aeULL, 0xfab91a6940fcb9cfULL }

#define LIMINE_REQUESTS_END_MARKER \
    volatile __limine_u64 limine_requests_end_marker[2] = { \
        0xadc0e0531bb10d03ULL, 0x9572709f31764c62ULL }

/* ─── Request IDs (4×u64 initialiser) ────────────────────────────── */
#define LIMINE_FRAMEBUFFER_REQUEST \
    { 0x9d5827dcd881dd75ULL, 0xa3148604f6fab11bULL, 0x0ULL, 0x0ULL }

#define LIMINE_MEMMAP_REQUEST \
    { 0x67cf3d9d378a806fULL, 0xe304acdfc50c3c62ULL, 0x0ULL, 0x0ULL }

#define LIMINE_HHDM_REQUEST \
    { 0x48dcf1cb8ad2b852ULL, 0x63984e959a98244bULL, 0x0ULL, 0x0ULL }

#define LIMINE_KERNEL_ADDRESS_REQUEST \
    { 0x71ba76863cc55f63ULL, 0xb2644a48c516a487ULL, 0x0ULL, 0x0ULL }

#define LIMINE_RSDP_REQUEST \
    { 0xc5e77b6b397e7b43ULL, 0x27637845accdcf3cULL, 0x0ULL, 0x0ULL }

#define LIMINE_SMP_REQUEST \
    { 0x95a67b819a1b857eULL, 0xa0b61b723b6a73e0ULL, 0x0ULL, 0x0ULL }

/* ─── Memory map types ────────────────────────────────────────────── */
#define LIMINE_MEMMAP_USABLE             0
#define LIMINE_MEMMAP_RESERVED           1
#define LIMINE_MEMMAP_ACPI_RECLAIMABLE   2
#define LIMINE_MEMMAP_ACPI_NVS           3
#define LIMINE_MEMMAP_BAD_MEMORY         4
#define LIMINE_MEMMAP_BOOTLOADER_RECLAIMABLE 5
#define LIMINE_MEMMAP_KERNEL_AND_MODULES 6
#define LIMINE_MEMMAP_FRAMEBUFFER        7

/* ─── Framebuffer ─────────────────────────────────────────────────── */
struct limine_video_mode {
    __limine_u64 pitch;
    __limine_u64 width;
    __limine_u64 height;
    __limine_u16 bpp;
    __limine_u8  memory_model;
    __limine_u8  red_mask_size;
    __limine_u8  red_mask_shift;
    __limine_u8  green_mask_size;
    __limine_u8  green_mask_shift;
    __limine_u8  blue_mask_size;
    __limine_u8  blue_mask_shift;
};

struct limine_framebuffer {
    void         *address;
    __limine_u64  width;
    __limine_u64  height;
    __limine_u64  pitch;
    __limine_u16  bpp;
    __limine_u8   memory_model;
    __limine_u8   red_mask_size;
    __limine_u8   red_mask_shift;
    __limine_u8   green_mask_size;
    __limine_u8   green_mask_shift;
    __limine_u8   blue_mask_size;
    __limine_u8   blue_mask_shift;
    __limine_u8   unused[7];
    __limine_u64  edid_size;
    void         *edid;
    __limine_u64  mode_count;
    struct limine_video_mode **modes;
};

struct limine_framebuffer_response {
    __limine_u64  revision;
    __limine_u64  framebuffer_count;
    struct limine_framebuffer **framebuffers;
};

struct limine_framebuffer_request {
    __limine_u64  id[4];
    __limine_u64  revision;
    struct limine_framebuffer_response *response;
};

/* ─── Memory map ──────────────────────────────────────────────────── */
struct limine_memmap_entry {
    __limine_u64 base;
    __limine_u64 length;
    __limine_u64 type;
};

struct limine_memmap_response {
    __limine_u64  revision;
    __limine_u64  entry_count;
    struct limine_memmap_entry **entries;
};

struct limine_memmap_request {
    __limine_u64  id[4];
    __limine_u64  revision;
    struct limine_memmap_response *response;
};

/* ─── HHDM ────────────────────────────────────────────────────────── */
struct limine_hhdm_response {
    __limine_u64 revision;
    __limine_u64 offset;
};

struct limine_hhdm_request {
    __limine_u64  id[4];
    __limine_u64  revision;
    struct limine_hhdm_response *response;
};

/* ─── Kernel address ──────────────────────────────────────────────── */
struct limine_kernel_address_response {
    __limine_u64 revision;
    __limine_u64 physical_base;
    __limine_u64 virtual_base;
};

struct limine_kernel_address_request {
    __limine_u64  id[4];
    __limine_u64  revision;
    struct limine_kernel_address_response *response;
};

/* ─── RSDP ────────────────────────────────────────────────────────── */
struct limine_rsdp_response {
    __limine_u64 revision;
    __limine_u64 address;
};

struct limine_rsdp_request {
    __limine_u64  id[4];
    __limine_u64  revision;
    struct limine_rsdp_response *response;
};

/* ─── SMP ─────────────────────────────────────────────────────────── */
struct limine_smp_info {
    __limine_u32 processor_id;
    __limine_u32 lapic_id;
    __limine_u64 reserved;
    void (*goto_address)(struct limine_smp_info *);
    __limine_u64 extra_argument;
};

struct limine_smp_response {
    __limine_u64  revision;
    __limine_u32  flags;
    __limine_u32  bsp_lapic_id;
    __limine_u64  cpu_count;
    struct limine_smp_info **cpus;
};

struct limine_smp_request {
    __limine_u64  id[4];
    __limine_u64  revision;
    struct limine_smp_response *response;
    __limine_u64  flags;
};

#endif /* LIMINE_H */
