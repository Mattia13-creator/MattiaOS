#ifndef MATTIAOS_DEVFS_H
#define MATTIAOS_DEVFS_H

/*
 * devfs.h — device filesystem (/dev) for MattiaOS
 *
 * devnode_t is the /dev file-system entry for a device.
 * It is DISTINCT from device_t (driver.h), which is the kernel device-tree
 * node.  A driver creates one devnode_t per device_t at init time.
 *
 * dev_type_t and spinlock primitives come from driver.h.
 */

#include "../include/types.h"
#include "vfs.h"
#include "../drivers/driver.h"   /* dev_type_t, spinlock_*, mutex_* */

/*
 * devnode_t — a /dev entry registered by a driver.
 *
 * Fields:
 *   name        : basename in /dev (e.g. "fb0", "sda", "kbd0")
 *   type        : DEV_TYPE_CHAR, DEV_TYPE_BLOCK, or DEV_TYPE_NET
 *   ops         : VFS operation table (read/write/ioctl/mmap/…)
 *   driver_data : opaque pointer to driver-private state
 *   next        : linked list of all registered devnodes
 */
typedef struct devnode {
    char            name[64];
    dev_type_t      type;
    vfs_ops_t      *ops;
    void           *driver_data;
    struct devnode *next;
} devnode_t;

/*
 * devfs_register   — add a devnode_t to the /dev filesystem.
 *                    The node must remain valid until devfs_unregister().
 * devfs_unregister — remove a devnode by name.
 */
int           devfs_register  (devnode_t *dev);
int           devfs_unregister(const char *name);

filesystem_t *devfs_get_fs    (void);
vnode_t      *devfs_mount     (const char *device);
void          devfs_unmount   (vnode_t   *root);

#endif /* MATTIAOS_DEVFS_H */
