#ifndef MATTIAOS_VFS_H
#define MATTIAOS_VFS_H

#include "../include/types.h"
#include "../include/errno.h"

typedef struct vnode vnode_t;
typedef struct file  file_t;

typedef struct vfs_ops {
    int     (*open)   (vnode_t *node, int flags);
    int     (*close)  (vnode_t *node);
    ssize_t (*read)   (vnode_t *node, void *buf, size_t count, off_t offset);
    ssize_t (*write)  (vnode_t *node, const void *buf, size_t count, off_t offset);
    int     (*readdir)(vnode_t *node, void *entry, size_t index);
    int     (*stat)   (vnode_t *node, void *st);
    int     (*create) (vnode_t *parent, const char *name, mode_t mode);
    int     (*mkdir)  (vnode_t *parent, const char *name, mode_t mode);
    int     (*unlink) (vnode_t *parent, const char *name);
    int     (*mmap)   (vnode_t *node, void *addr, size_t len, int prot, off_t offset);
    int     (*ioctl)  (vnode_t *node, uint64_t request, void *arg);
} vfs_ops_t;

/*
 * vnode — there is NO refcount field.
 * VFS does not delay or block unlink() based on open file descriptors.
 * Deletion is immediate and complete. See blueprint Principle 2.
 */
struct vnode {
    uint64_t    inode;
    uint64_t    size;
    uint32_t    mode;
    uid_t       uid;
    gid_t       gid;
    time_t      atime, mtime, ctime;
    vfs_ops_t  *ops;
    void       *fs_data;
    char        name[256];
};

struct file {
    vnode_t *vnode;
    off_t    offset;
    int      flags;
};

typedef struct filesystem {
    char         name[32];
    vnode_t     *(*mount)(const char *device);
    void         (*unmount)(vnode_t *root);
    struct filesystem *next;
} filesystem_t;

typedef struct mount {
    char         mountpoint[256];
    vnode_t     *root;
    filesystem_t *fs;
    struct mount *next;
} mount_t;

void     vfs_init(void);
int      vfs_mount(const char *path, filesystem_t *fs, const char *device);
int      vfs_unmount(const char *path);
vnode_t *vfs_lookup(const char *path);
file_t  *vfs_open(const char *path, int flags);
int      vfs_close(file_t *file);
ssize_t  vfs_read(file_t *file, void *buf, size_t count);
ssize_t  vfs_write(file_t *file, const void *buf, size_t count);
int      vfs_unlink(const char *path);
int      vfs_mkdir(const char *path, mode_t mode);
int      vfs_stat(const char *path, void *st);

void     vfs_register_fs(filesystem_t *fs);

/* Directory enumeration — does not expose vnode pointers to callers */
int      vfs_readdir_entry(const char *path, size_t idx,
                           char *name_out, size_t name_sz, int *is_dir_out);
bool     vfs_is_dir(const char *path);

/* File creation */
int      vfs_create_file(const char *path, mode_t mode);

/* Debug: stampa stato mount table e root tmpfs su VGA — solo per diagnosi */
void     vfs_debug_dump(void);
/* Diagnostica inline per cmd_ls */
int      vfs_diag_mount_count(void);
int      vfs_diag_root_children(void);
int      vfs_diag_synth_count(const char *path);

#endif
