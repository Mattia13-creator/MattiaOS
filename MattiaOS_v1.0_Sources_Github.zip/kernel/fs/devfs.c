#include "devfs.h"
#include "../mm/slab.h"
#include "../include/errno.h"

/*
 * devfs.c — device filesystem implementation.
 *
 * Maintains a linked list of devnode_t instances registered by drivers.
 * Mounted on /dev by init.c.  Provides read-only directory enumeration
 * (readdir) and delegates all device I/O to the per-device ops table.
 *
 * Locking: s_dev_lock (spinlock_irqsave) protects the devnode list because
 * drivers may register devices from interrupt context during init.
 */

/* --- List of registered device nodes ------------------------------------ */
static devnode_t  *s_devices    = NULL;
static spinlock_t  s_dev_lock   = {0};   /* {0} required — spinlock_t is a struct */
static vnode_t    *s_devfs_root = NULL;

/* --- Minimal string helpers (no libc in kernel yet) --------------------- */
static inline size_t dv_strlen(const char *s) {
    size_t n = 0; while (s[n]) n++; return n;
}
static inline int dv_strcmp(const char *a, const char *b) {
    while (*a && *a == *b) { a++; b++; }
    return (unsigned char)*a - (unsigned char)*b;
}
static inline void dv_strncpy(char *d, const char *s, size_t n) {
    size_t i = 0;
    while (i < n - 1 && s[i]) { d[i] = s[i]; i++; }
    d[i] = '\0';
}
static inline void *dv_memset(void *d, int c, size_t n) {
    uint8_t *p = (uint8_t*)d;
    while (n--) *p++ = (uint8_t)c;
    return d;
}

/* --- Built-in /dev/null ops --------------------------------------------- */
static ssize_t null_read(vnode_t *n, void *buf, size_t c, off_t o) {
    (void)n; (void)buf; (void)c; (void)o;
    return 0;   /* EOF */
}
static ssize_t null_write(vnode_t *n, const void *buf, size_t c, off_t o) {
    (void)n; (void)buf; (void)o;
    return (ssize_t)c;  /* silently discard */
}
static vfs_ops_t s_null_ops = {
    .read = null_read, .write = null_write,
    .open = NULL, .close = NULL, .readdir = NULL, .stat = NULL,
    .create = NULL, .mkdir = NULL, .unlink = NULL, .mmap = NULL, .ioctl = NULL
};

/* --- Built-in /dev/zero ops --------------------------------------------- */
static ssize_t zero_read(vnode_t *n, void *buf, size_t c, off_t o) {
    (void)n; (void)o;
    dv_memset(buf, 0, c);
    return (ssize_t)c;
}
static vfs_ops_t s_zero_ops = {
    .read = zero_read, .write = null_write,
    .open = NULL, .close = NULL, .readdir = NULL, .stat = NULL,
    .create = NULL, .mkdir = NULL, .unlink = NULL, .mmap = NULL, .ioctl = NULL
};

/* --- devfs directory ops ------------------------------------------------ */
static int devfs_readdir(vnode_t *node, void *entry_out, size_t index) {
    (void)node;
    uint64_t flags = spinlock_irqsave(&s_dev_lock);
    devnode_t *d = s_devices;
    size_t i = 0;
    while (d) {
        if (i == index) {
            vnode_t *out = (vnode_t*)entry_out;
            dv_memset(out, 0, sizeof(*out));
            out->inode   = (uint64_t)(uintptr_t)d;
            out->ops     = d->ops;
            out->fs_data = d->driver_data;
            dv_strncpy(out->name, d->name, sizeof(out->name));
            spinlock_irqrestore(&s_dev_lock, flags);
            return EOK;
        }
        i++;
        d = d->next;
    }
    spinlock_irqrestore(&s_dev_lock, flags);
    return ENOENT;
}

static int devfs_open(vnode_t *n, int f) { (void)n; (void)f; return EOK; }

static vfs_ops_t s_devfs_dir_ops = {
    .open = devfs_open, .close = NULL,
    .read = NULL, .write = NULL,
    .readdir = devfs_readdir,
    .stat = NULL, .create = NULL, .mkdir = NULL,
    .unlink = NULL, .mmap = NULL, .ioctl = NULL
};

/* --- Public API ---------------------------------------------------------- */

/*
 * devfs_register — add a device node to the /dev list.
 *
 * Uses spinlock_irqsave because drivers can call this during interrupt-
 * driven init paths.  The devnode must remain allocated until unregister.
 */
int devfs_register(devnode_t *dev) {
    if (!dev) return EINVAL;
    uint64_t flags = spinlock_irqsave(&s_dev_lock);
    dev->next  = s_devices;
    s_devices  = dev;
    spinlock_irqrestore(&s_dev_lock, flags);
    return EOK;
}

/*
 * devfs_unregister — remove a device node by name.
 */
int devfs_unregister(const char *name) {
    if (!name) return EINVAL;
    uint64_t flags = spinlock_irqsave(&s_dev_lock);
    devnode_t **prev = &s_devices;
    devnode_t  *cur  = s_devices;
    while (cur) {
        if (dv_strcmp(cur->name, name) == 0) {
            *prev = cur->next;
            spinlock_irqrestore(&s_dev_lock, flags);
            return EOK;
        }
        prev = &cur->next;
        cur  = cur->next;
    }
    spinlock_irqrestore(&s_dev_lock, flags);
    return ENOENT;
}

/* --- Built-in device nodes (null, zero) --------------------------------- */
/*
 * These are static devnode_t instances; they are registered separately so
 * that devfs_register() can correctly set .next on each one.
 * Registration order (last registered = first in list):
 *   devfs_register(&s_dev_zero)  → s_devices = zero
 *   devfs_register(&s_dev_null)  → s_devices = null → zero → NULL
 *
 * NOTE: do NOT pre-set .next before calling devfs_register — the function
 * overwrites .next with the current list head.
 */
static devnode_t s_dev_null = {
    .name = "null", .type = DEV_TYPE_CHAR, .ops = &s_null_ops, .driver_data = NULL, .next = NULL
};
static devnode_t s_dev_zero = {
    .name = "zero", .type = DEV_TYPE_CHAR, .ops = &s_zero_ops, .driver_data = NULL, .next = NULL
};

vnode_t *devfs_mount(const char *device) {
    (void)device;
    vnode_t *root = (vnode_t*)kzalloc(sizeof(vnode_t));
    if (!root) return NULL;

    root->inode   = 0xDE05U;   /* arbitrary non-zero devfs magic inode */
    root->mode    = 0x41EDU;   /* drwxr-xr-x */
    root->ops     = &s_devfs_dir_ops;
    root->name[0] = '/';
    root->name[1] = '\0';
    s_devfs_root  = root;

    /* Register built-in devices — order matters: last in = first in list */
    devfs_register(&s_dev_zero);
    devfs_register(&s_dev_null);

    return root;
}

void devfs_unmount(vnode_t *root) {
    if (root) kfree(root);
    s_devfs_root = NULL;
}

static filesystem_t s_devfs = {
    .name    = "devfs",
    .mount   = devfs_mount,
    .unmount = devfs_unmount,
    .next    = NULL,
};

filesystem_t *devfs_get_fs(void) { return &s_devfs; }
