#include "mattiafs.h"
#include "../mm/slab.h"
#include "../../include/errno.h"

/*
 * MattiaFS — native filesystem.
 *
 * unlink() is IMMEDIATE and UNCONDITIONAL.
 * No refcounting. No delay. No check for open file descriptors.
 * See blueprint Principle 2.
 */

typedef struct mattiafs_priv {
    mattiafs_superblock_t  sb;
    mattiafs_bgd_t        *bgd_table;
    uint32_t               num_groups;
    /* Block device I/O callbacks */
    int (*read_block)(uint64_t block, void *buf);
    int (*write_block)(uint64_t block, const void *buf);
} mattiafs_priv_t;

typedef struct {
    mattiafs_priv_t *priv;
    mattiafs_inode_t inode;
    uint64_t         inode_num;
} mattiafs_vnode_data_t;

/* ── helpers ── */
static inline void *mf_memset(void *d, int c, size_t n) {
    uint8_t *p=(uint8_t*)d; while(n--)*p++=(uint8_t)c; return d;
}
static inline void *mf_memcpy(void *d, const void *s, size_t n) {
    uint8_t *dd=(uint8_t*)d; const uint8_t *ss=(const uint8_t*)s;
    while(n--) { *dd++=*ss++; } return d;
}
static inline int mf_strcmp(const char *a, const char *b) {
    while(*a&&*a==*b){a++;b++;} return (unsigned char)*a-(unsigned char)*b;
}
static inline size_t mf_strlen_n(const char *s, size_t max) {
    size_t n=0; while(n<max&&s[n])n++; return n;
}

static inline void mf_strncpy(char *d, const char *s, size_t n) {
    size_t i=0; while(i<n-1&&s[i]){d[i]=s[i];i++;} d[i]='\0';
}

/* ── inode I/O ── */

static int mf_read_inode(mattiafs_priv_t *priv, uint64_t ino,
                          mattiafs_inode_t *out) {
    uint64_t group  = (ino - 1) / MATTIAFS_BLOCKS_PER_GRP;
    uint64_t index  = (ino - 1) % MATTIAFS_BLOCKS_PER_GRP;
    uint64_t block  = priv->bgd_table[group].inode_table_block
                    + (index * MATTIAFS_INODE_SIZE) / MATTIAFS_BLOCK_SIZE;
    uint64_t offset = (index * MATTIAFS_INODE_SIZE) % MATTIAFS_BLOCK_SIZE;

    uint8_t buf[MATTIAFS_BLOCK_SIZE];
    if (priv->read_block(block, buf) < 0) return EIO;
    mf_memcpy(out, buf + offset, sizeof(mattiafs_inode_t));
    return EOK;
}

static int mf_write_inode(mattiafs_priv_t *priv, uint64_t ino,
                           const mattiafs_inode_t *in) {
    uint64_t group  = (ino - 1) / MATTIAFS_BLOCKS_PER_GRP;
    uint64_t index  = (ino - 1) % MATTIAFS_BLOCKS_PER_GRP;
    uint64_t block  = priv->bgd_table[group].inode_table_block
                    + (index * MATTIAFS_INODE_SIZE) / MATTIAFS_BLOCK_SIZE;
    uint64_t offset = (index * MATTIAFS_INODE_SIZE) % MATTIAFS_BLOCK_SIZE;

    uint8_t buf[MATTIAFS_BLOCK_SIZE];
    if (priv->read_block(block, buf) < 0) return EIO;
    mf_memcpy(buf + offset, in, sizeof(mattiafs_inode_t));
    return priv->write_block(block, buf);
}

/* ── block bitmap: mark free ── */

static int mf_free_block(mattiafs_priv_t *priv, uint64_t block_num) {
    uint64_t group  = block_num / MATTIAFS_BLOCKS_PER_GRP;
    uint64_t bit    = block_num % MATTIAFS_BLOCKS_PER_GRP;

    uint8_t bitmap[MATTIAFS_BLOCK_SIZE];
    uint64_t bmap_block = priv->bgd_table[group].block_bitmap_block;
    if (priv->read_block(bmap_block, bitmap) < 0) return EIO;

    bitmap[bit / 8] &= ~(1u << (bit % 8));
    priv->bgd_table[group].free_blocks++;
    priv->sb.free_blocks++;

    return priv->write_block(bmap_block, bitmap);
}

/* ── inode bitmap: mark free ── */

static int mf_free_inode_entry(mattiafs_priv_t *priv, uint64_t ino) {
    uint64_t group = (ino - 1) / MATTIAFS_BLOCKS_PER_GRP;
    uint64_t bit   = (ino - 1) % MATTIAFS_BLOCKS_PER_GRP;

    uint8_t bitmap[MATTIAFS_BLOCK_SIZE];
    uint64_t bmap_block = priv->bgd_table[group].inode_bitmap_block;
    if (priv->read_block(bmap_block, bitmap) < 0) return EIO;

    bitmap[bit / 8] &= ~(1u << (bit % 8));
    priv->bgd_table[group].free_inodes++;
    priv->sb.free_inodes++;

    return priv->write_block(bmap_block, bitmap);
}

/* ── free all blocks of an inode ── */

static int mf_free_inode_blocks(mattiafs_priv_t *priv,
                                  mattiafs_inode_t *inode) {
    /* Direct blocks */
    for (int i = 0; i < MATTIAFS_DIRECT_BLOCKS; i++) {
        if (inode->direct_blocks[i])
            mf_free_block(priv, inode->direct_blocks[i]);
    }
    /* Indirect block */
    if (inode->indirect_block) {
        uint8_t buf[MATTIAFS_BLOCK_SIZE];
        if (priv->read_block(inode->indirect_block, buf) == EOK) {
            uint64_t *ptrs = (uint64_t*)buf;
            size_t count = MATTIAFS_BLOCK_SIZE / sizeof(uint64_t);
            for (size_t i = 0; i < count; i++)
                if (ptrs[i]) mf_free_block(priv, ptrs[i]);
        }
        mf_free_block(priv, inode->indirect_block);
    }
    /* Double-indirect (simplified: free the block itself only) */
    if (inode->double_indirect)
        mf_free_block(priv, inode->double_indirect);
    /* Triple-indirect */
    if (inode->triple_indirect)
        mf_free_block(priv, inode->triple_indirect);

    return EOK;
}

/* ── readdir ── */

static int mattiafs_readdir(vnode_t *node, void *entry_out, size_t index) {
    mattiafs_vnode_data_t *vd = (mattiafs_vnode_data_t*)node->fs_data;
    if (!vd) return EINVAL;

    mattiafs_priv_t *priv = vd->priv;
    mattiafs_inode_t *inode = &vd->inode;

    uint8_t block_buf[MATTIAFS_BLOCK_SIZE];
    size_t entry_count = 0;

    for (int b = 0; b < MATTIAFS_DIRECT_BLOCKS; b++) {
        if (!inode->direct_blocks[b]) continue;
        if (priv->read_block(inode->direct_blocks[b], block_buf) < 0) continue;

        size_t off = 0;
        while (off + sizeof(mattiafs_dirent_t) <= MATTIAFS_BLOCK_SIZE) {
            mattiafs_dirent_t *de = (mattiafs_dirent_t*)(block_buf + off);
            if (!de->inode || !de->rec_len) break;

            if (entry_count == index) {
                mattiafs_inode_t child_inode;
                if (mf_read_inode(priv, de->inode, &child_inode) < 0)
                    return EIO;

                vnode_t *out = (vnode_t*)entry_out;
                mf_memset(out, 0, sizeof(*out));
                out->inode   = de->inode;
                out->size    = child_inode.size;
                out->mode    = child_inode.mode;
                out->uid     = child_inode.uid;
                out->gid     = child_inode.gid;
                out->atime   = (time_t)child_inode.atime;
                out->mtime   = (time_t)child_inode.mtime;
                out->ctime   = (time_t)child_inode.ctime;
                out->fs_data = NULL; /* populated on open */
                mf_strncpy(out->name, de->name, de->name_len + 1);
                out->name[de->name_len < 255 ? de->name_len : 255] = '\0';
                return EOK;
            }
            entry_count++;
            off += de->rec_len;
        }
    }
    return ENOENT;
}

/* ── read ── */

static ssize_t mattiafs_read(vnode_t *node, void *buf, size_t count,
                               off_t offset) {
    mattiafs_vnode_data_t *vd = (mattiafs_vnode_data_t*)node->fs_data;
    if (!vd) return EINVAL;

    mattiafs_inode_t *inode = &vd->inode;
    if ((uint64_t)offset >= inode->size) return 0;

    size_t avail   = (size_t)(inode->size - (uint64_t)offset);
    size_t to_read = count < avail ? count : avail;

    uint8_t block_buf[MATTIAFS_BLOCK_SIZE];
    size_t done  = 0;
    uint64_t pos = (uint64_t)offset;

    while (done < to_read) {
        uint64_t block_idx = pos / MATTIAFS_BLOCK_SIZE;
        uint64_t block_off = pos % MATTIAFS_BLOCK_SIZE;
        uint64_t phys_block = 0;

        if (block_idx < MATTIAFS_DIRECT_BLOCKS)
            phys_block = inode->direct_blocks[block_idx];

        if (!phys_block) break;
        if (vd->priv->read_block(phys_block, block_buf) < 0) break;

        size_t copy = MATTIAFS_BLOCK_SIZE - (size_t)block_off;
        if (copy > to_read - done) copy = to_read - done;
        mf_memcpy((uint8_t*)buf + done, block_buf + block_off, copy);
        done += copy;
        pos  += copy;
    }

    inode->atime = 0; /* real: get timestamp */
    return (ssize_t)done;
}

/* ── write ── (stub — full impl requires block allocation) ── */

static ssize_t mattiafs_write(vnode_t *node, const void *buf, size_t count,
                                off_t offset) {
    (void)node;(void)buf;(void)count;(void)offset;
    return ENOSYS; /* Block allocator needed — to be completed */
}

/* ── unlink — IMMEDIATE, NO REFCOUNT ── */

int mattiafs_unlink(vnode_t *parent, const char *name) {
    mattiafs_vnode_data_t *pvd = (mattiafs_vnode_data_t*)parent->fs_data;
    if (!pvd) return EINVAL;

    mattiafs_priv_t  *priv   = pvd->priv;
    mattiafs_inode_t *dir_in = &pvd->inode;

    uint8_t block_buf[MATTIAFS_BLOCK_SIZE];
    uint64_t target_ino = 0;

    /* Step 1: Find and remove directory entry */
    for (int b = 0; b < MATTIAFS_DIRECT_BLOCKS && !target_ino; b++) {
        if (!dir_in->direct_blocks[b]) continue;
        uint64_t blk = dir_in->direct_blocks[b];
        if (priv->read_block(blk, block_buf) < 0) continue;

        size_t off = 0;
        while (off + sizeof(mattiafs_dirent_t) <= MATTIAFS_BLOCK_SIZE) {
            mattiafs_dirent_t *de = (mattiafs_dirent_t*)(block_buf + off);
            if (!de->inode || !de->rec_len) break;

            if (de->name_len == (uint8_t)mf_strlen_n(name, 255)
             && mf_strcmp(de->name, name) == 0) {
                target_ino = de->inode;
                /* Zero the directory entry */
                de->inode = 0;
                priv->write_block(blk, block_buf);
                break;
            }
            off += de->rec_len;
        }
    }

    if (!target_ino) return ENOENT;

    /* Step 2: Read the inode */
    mattiafs_inode_t target_inode;
    if (mf_read_inode(priv, target_ino, &target_inode) < 0) return EIO;

    /* Step 3: Free all data blocks — immediately, no refcount check */
    mf_free_inode_blocks(priv, &target_inode);

    /* Step 4: Free the inode — immediately */
    mf_memset(&target_inode, 0, sizeof(target_inode));
    mf_write_inode(priv, target_ino, &target_inode);
    mf_free_inode_entry(priv, target_ino);

    /* Step 5: Update superblock on disk */
    /* (write_block at block 0 for superblock — abbreviated) */

    return EOK;
}

static int mattiafs_unlink_wrapper(vnode_t *parent, const char *name) {
    return mattiafs_unlink(parent, name);
}

static vfs_ops_t s_mattiafs_ops = {
    .open    = NULL,
    .close   = NULL,
    .read    = mattiafs_read,
    .write   = mattiafs_write,
    .readdir = mattiafs_readdir,
    .stat    = NULL,
    .create  = NULL,
    .mkdir   = NULL,
    .unlink  = mattiafs_unlink_wrapper,
    .mmap    = NULL,
    .ioctl   = NULL,
};

/* ── mount ── */

vnode_t *mattiafs_mount(const char *device) {
    (void)device;
    /*
     * Real mount: read sector 0 → superblock, validate magic,
     * read BGD table, build vnode for root inode (#2).
     * For now, return a stub root vnode so the filesystem is registered.
     */
    vnode_t *root = (vnode_t*)kzalloc(sizeof(vnode_t));
    if (!root) return NULL;

    mattiafs_vnode_data_t *vd = (mattiafs_vnode_data_t*)kzalloc(
                                     sizeof(mattiafs_vnode_data_t));
    if (!vd) { kfree(root); return NULL; }

    root->inode   = 2; /* root inode is always #2 in MattiaFS */
    root->mode    = 0x41ED;
    root->ops     = &s_mattiafs_ops;
    root->fs_data = vd;
    root->name[0] = '/'; root->name[1] = '\0';

    return root;
}

void mattiafs_unmount(vnode_t *root) {
    if (!root) return;
    if (root->fs_data) kfree(root->fs_data);
    kfree(root);
}

static filesystem_t s_mattiafs = {
    .name    = "mattiafs",
    .mount   = mattiafs_mount,
    .unmount = mattiafs_unmount,
    .next    = NULL,
};

filesystem_t *mattiafs_get_fs(void) { return &s_mattiafs; }
