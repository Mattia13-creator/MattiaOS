#ifndef MATTIAOS_MATTIAFS_H
#define MATTIAOS_MATTIAFS_H

#include "../../include/types.h"
#include "../vfs.h"

#define MATTIAFS_MAGIC       0x4D415446  /* 'MATF' */
#define MATTIAFS_BLOCK_SIZE  4096
#define MATTIAFS_INODE_SIZE  256

#define MATTIAFS_DIRECT_BLOCKS  12
#define MATTIAFS_BLOCKS_PER_GRP 32768   /* 128 MB per block group */

typedef struct {
    uint32_t magic;
    uint32_t block_size;
    uint64_t total_blocks;
    uint64_t free_blocks;
    uint64_t total_inodes;
    uint64_t free_inodes;
    uint32_t mount_count;
    uint64_t last_mount_time;
    uint64_t journal_inode;
    uint8_t  padding[4028];
} __attribute__((packed)) mattiafs_superblock_t;

typedef struct {
    uint64_t block_bitmap_block;
    uint64_t inode_bitmap_block;
    uint64_t inode_table_block;
    uint64_t data_blocks_start;
    uint32_t free_blocks;
    uint32_t free_inodes;
} __attribute__((packed)) mattiafs_bgd_t;

typedef struct {
    uint32_t mode;
    uint32_t uid;
    uint32_t gid;
    uint64_t size;
    uint64_t atime;
    uint64_t mtime;
    uint64_t ctime;
    uint64_t dtime;
    uint64_t direct_blocks[MATTIAFS_DIRECT_BLOCKS];
    uint64_t indirect_block;
    uint64_t double_indirect;
    uint64_t triple_indirect;
    uint32_t flags;
    uint8_t  xattr[100];
    uint8_t  padding[4];
} __attribute__((packed)) mattiafs_inode_t;

typedef struct {
    uint64_t inode;
    uint16_t rec_len;
    uint8_t  name_len;
    uint8_t  file_type;
    char     name[255];
} __attribute__((packed)) mattiafs_dirent_t;

/*
 * mattiafs_unlink() MUST:
 *   1. Remove the directory entry immediately
 *   2. Free all data blocks immediately
 *   3. Free the inode immediately
 *
 * mattiafs_unlink() MUST NOT:
 *   - Check if the file is open by any process
 *   - Use reference counting to delay freeing
 *   - Block for any reason related to running processes
 *
 * See blueprint Principle 2.
 */

filesystem_t *mattiafs_get_fs(void);
vnode_t      *mattiafs_mount(const char *device);
void          mattiafs_unmount(vnode_t *root);

int mattiafs_unlink(vnode_t *parent, const char *name);

#endif
