#ifndef MATTIAOS_ACPI_H
#define MATTIAOS_ACPI_H

#include "../include/types.h"

/* =========================================================================
 * acpi.h — Parser tabelle ACPI (ACPI Specification 6.4)
 *
 * Parsifica il RSDP fornito da Limine, supporta sia RSDT (32-bit, legacy)
 * che XSDT (64-bit, preferito quando revision >= 2).  Espone MADT, HPET,
 * MCFG, FADT tramite l'indice interno di tabelle.
 *
 * ORDINE DI CHIAMATA OBBLIGATORIO in entry.c:
 *   vmm_init() → acpi_init() → lapic_init() → apic_timer_init()
 * acpi_init() deve precedere lapic_init() perché apic_timer_calibrate()
 * usa il timer HPET scoperto da acpi_init().
 * ========================================================================= */

/* -------------------------------------------------------------------------
 * RSDP — Root System Description Pointer (ACPI §5.2.5)
 * Signature: "RSD PTR " (8 byte con spazio finale)
 * ------------------------------------------------------------------------- */
typedef struct __attribute__((packed)) {
    char     signature[8];    /* "RSD PTR " */
    uint8_t  checksum;        /* Somma di tutti i byte dei campi v1.0 = 0 */
    char     oem_id[6];
    uint8_t  revision;        /* 0 = ACPI 1.0 (solo RSDT); >= 2 = XSDT presente */
    uint32_t rsdt_address;    /* Indirizzo fisico 32-bit RSDT */
    /* Campi ACPI 2.0+ — presenti solo quando revision >= 2 */
    uint32_t length;          /* Lunghezza totale RSDP v2 */
    uint64_t xsdt_address;    /* Indirizzo fisico 64-bit XSDT */
    uint8_t  xchecksum;       /* Checksum esteso su tutti i campi v2 */
    uint8_t  reserved[3];
} acpi_rsdp_t;

/* -------------------------------------------------------------------------
 * SDT header — comune a tutte le tabelle di sistema (ACPI §5.2.6)
 * ------------------------------------------------------------------------- */
typedef struct __attribute__((packed)) {
    char     signature[4];        /* Identificatore tabella (4 char, non NULL-terminated) */
    uint32_t length;              /* Lunghezza totale della tabella in byte */
    uint8_t  revision;
    uint8_t  checksum;            /* Somma di tutti i byte della tabella = 0 */
    char     oem_id[6];
    char     oem_table_id[8];
    uint32_t oem_revision;
    uint32_t creator_id;
    uint32_t creator_revision;
} acpi_sdt_header_t;

/* -------------------------------------------------------------------------
 * RSDT — Root System Description Table (ACPI 1.0, 32-bit)
 * Signature: "RSDT"
 * ------------------------------------------------------------------------- */
typedef struct __attribute__((packed)) {
    acpi_sdt_header_t header;
    uint32_t          entries[];  /* Array di indirizzi fisici 32-bit delle SDT */
} acpi_rsdt_t;

/* -------------------------------------------------------------------------
 * XSDT — Extended System Description Table (ACPI 2.0+, 64-bit)
 * Signature: "XSDT"
 * ------------------------------------------------------------------------- */
typedef struct __attribute__((packed)) {
    acpi_sdt_header_t header;
    uint64_t          entries[];  /* Array di indirizzi fisici 64-bit delle SDT */
} acpi_xsdt_t;

/* =========================================================================
 * MADT — Multiple APIC Description Table (ACPI §5.2.12)
 * Signature: "APIC"
 * Contiene la lista dei Local APIC (uno per core) e degli I/O APIC.
 * Necessaria per SMP e per il corretto routing degli interrupt.
 * ========================================================================= */

/* Tipi di struttura variabile all'interno della MADT */
#define MADT_TYPE_LOCAL_APIC        0   /* Processor Local APIC */
#define MADT_TYPE_IO_APIC           1   /* I/O APIC */
#define MADT_TYPE_ISO               2   /* Interrupt Source Override */
#define MADT_TYPE_NMI_SOURCE        3   /* NMI Source */
#define MADT_TYPE_LOCAL_APIC_NMI    4   /* Local APIC NMI connection */
#define MADT_TYPE_LOCAL_APIC_OVR    5   /* Local APIC Address Override (64-bit) */
#define MADT_TYPE_IO_SAPIC          6   /* I/O SAPIC */
#define MADT_TYPE_LOCAL_SAPIC       7   /* Local SAPIC */
#define MADT_TYPE_PLATFORM_INT      8   /* Platform Interrupt Sources */
#define MADT_TYPE_LOCAL_X2APIC      9   /* Processor Local x2APIC */
#define MADT_TYPE_LOCAL_X2APIC_NMI  10  /* Local x2APIC NMI */

/* Header comune a tutte le strutture variabili della MADT */
typedef struct __attribute__((packed)) {
    uint8_t type;
    uint8_t length;
} acpi_madt_entry_hdr_t;

/* Tipo 0: Processor Local APIC — un record per ogni core logico */
typedef struct __attribute__((packed)) {
    acpi_madt_entry_hdr_t hdr;   /* type=0, length=8 */
    uint8_t  acpi_processor_uid;
    uint8_t  apic_id;
    uint32_t flags;              /* bit 0: Enabled; bit 1: Online Capable */
} acpi_madt_lapic_t;

#define MADT_LAPIC_FLAG_ENABLED        (1u << 0)
#define MADT_LAPIC_FLAG_ONLINE_CAPABLE (1u << 1)

/* Tipo 1: I/O APIC */
typedef struct __attribute__((packed)) {
    acpi_madt_entry_hdr_t hdr;   /* type=1, length=12 */
    uint8_t  io_apic_id;
    uint8_t  reserved;
    uint32_t io_apic_address;    /* Indirizzo fisico base MMIO I/O APIC */
    uint32_t gsi_base;           /* Global System Interrupt base di questo I/O APIC */
} acpi_madt_ioapic_t;

/* Tipo 2: Interrupt Source Override
 * Ridefinisce il mapping tra IRQ legacy ISA e Global System Interrupt */
typedef struct __attribute__((packed)) {
    acpi_madt_entry_hdr_t hdr;   /* type=2, length=10 */
    uint8_t  bus;                /* 0 = ISA */
    uint8_t  source;             /* Numero IRQ sorgente (IRQ bus) */
    uint32_t gsi;                /* Global System Interrupt destinazione */
    uint16_t flags;              /* Bit 0-1: Polarity; bit 2-3: Trigger Mode */
} acpi_madt_iso_t;

/* Tipo 4: Local APIC NMI — specifica quale LINT# di ogni CPU è connesso a NMI */
typedef struct __attribute__((packed)) {
    acpi_madt_entry_hdr_t hdr;   /* type=4, length=6 */
    uint8_t  acpi_processor_uid; /* 0xFF = tutti i processori */
    uint16_t flags;
    uint8_t  lint;               /* LINT# numero (0 o 1) */
} acpi_madt_lapic_nmi_t;

/* Tabella MADT — header fisso + stream di strutture variabili */
typedef struct __attribute__((packed)) {
    acpi_sdt_header_t header;
    uint32_t          local_apic_address;  /* Indirizzo fisico LAPIC di default */
    uint32_t          flags;               /* bit 0: PCAT_COMPAT (8259A presente) */
    /* Seguito immediatamente dalle strutture variabili di tipo MADT_TYPE_* */
} acpi_madt_t;

/* =========================================================================
 * HPET — High Precision Event Timer (HPET Spec 1.0a)
 * Signature: "HPET"
 * Usata per calibrare il timer APIC con precisione femtosecondo.
 * ========================================================================= */
typedef struct __attribute__((packed)) {
    acpi_sdt_header_t header;
    uint32_t          event_timer_block_id;  /* Hardware rev e numero timer */
    uint8_t           address_space_id;      /* 0 = System Memory; 1 = System I/O */
    uint8_t           register_bit_width;
    uint8_t           register_bit_offset;
    uint8_t           reserved;
    uint64_t          base_address;          /* Indirizzo fisico base MMIO del blocco HPET */
    uint8_t           hpet_number;           /* Numero del blocco HPET (0 = primo) */
    uint16_t          minimum_tick;          /* Periodo minimo in unità del clock principale */
    uint8_t           page_protection;
} acpi_hpet_t;

/* Offset registri HPET (relativi al base_address MMIO, registri a 64-bit) */
#define HPET_REG_CAP_ID     0x000   /* General Capabilities and ID */
#define HPET_REG_CONFIG     0x010   /* General Configuration */
#define HPET_REG_INT_STS    0x020   /* General Interrupt Status */
#define HPET_REG_MAIN_CNT   0x0F0   /* Main Counter Value */

/* Bit del registro General Configuration */
#define HPET_CFG_ENABLE     (1ULL << 0)  /* Abilita il main counter */
#define HPET_CFG_LEGACY     (1ULL << 1)  /* Legacy IRQ routing (ridefinisce IRQ0/IRQ8) */

/* Il periodo del clock in femtosecondi è nei bit 63:32 del registro CAP_ID */
#define HPET_CAP_PERIOD_SHIFT   32

/* Macro accesso MMIO HPET (byte offset, puntatore void*) */
#define HPET_READ(base, off)  \
    (*(volatile uint64_t *)((uint8_t *)(base) + (off)))
#define HPET_WRITE(base, off, val)  \
    (*(volatile uint64_t *)((uint8_t *)(base) + (off)) = (uint64_t)(val))

/* =========================================================================
 * MCFG — PCI Express Memory Mapped Configuration Space (PCIe Spec §7.2.2)
 * Signature: "MCFG"
 * Necessaria per abilitare PCIe ECAM (extended config space oltre 256 byte).
 * ========================================================================= */
typedef struct __attribute__((packed)) {
    uint64_t base_address;   /* Indirizzo fisico base ECAM per questo segmento */
    uint16_t pci_segment;    /* Numero segmento PCI (0 per la maggior parte dei sistemi) */
    uint8_t  start_bus;      /* Numero bus iniziale (di solito 0) */
    uint8_t  end_bus;        /* Numero bus finale */
    uint32_t reserved;
} acpi_mcfg_alloc_t;

typedef struct __attribute__((packed)) {
    acpi_sdt_header_t header;
    uint64_t          reserved;
    acpi_mcfg_alloc_t allocations[];  /* Array di record ECAM (n = (length - 44) / 16) */
} acpi_mcfg_t;

/* =========================================================================
 * FADT — Fixed ACPI Description Table (ACPI §5.2.9)
 * Signature: "FACP"
 * Contiene indirizzi dei registri hardware PM e la posizione del DSDT.
 * Solo i campi necessari sono dichiarati qui.
 * ========================================================================= */
typedef struct __attribute__((packed)) {
    acpi_sdt_header_t header;
    uint32_t firmware_ctrl;       /* Indirizzo fisico FACS */
    uint32_t dsdt;                /* Indirizzo fisico DSDT */
    uint8_t  reserved0;
    uint8_t  preferred_pm_profile;
    uint16_t sci_int;             /* Numero IRQ SCI (System Control Interrupt) */
    uint32_t smi_cmd;             /* Porta I/O SMI Command */
    uint8_t  acpi_enable;         /* Valore da scrivere in smi_cmd per attivare ACPI */
    uint8_t  acpi_disable;        /* Valore da scrivere in smi_cmd per disattivare ACPI */
    uint8_t  s4bios_req;
    uint8_t  pstate_cnt;
    uint32_t pm1a_evt_blk;
    uint32_t pm1b_evt_blk;
    uint32_t pm1a_cnt_blk;
    uint32_t pm1b_cnt_blk;
    uint32_t pm2_cnt_blk;
    uint32_t pm_tmr_blk;
    uint32_t gpe0_blk;
    uint32_t gpe1_blk;
    /* Campi aggiuntivi non utilizzati attualmente — omessi per brevità */
} acpi_fadt_t;

/* =========================================================================
 * Dati estratti dalla MADT — disponibili dopo acpi_init()
 * ========================================================================= */

/* Numero massimo di CPU (Local APIC) e I/O APIC supportati */
#define ACPI_MAX_CPUS    256
#define ACPI_MAX_IOAPICS 8

/* Informazioni su ogni CPU rilevata nel MADT */
typedef struct {
    uint8_t apic_id;    /* APIC ID usato per IPI e identificazione core */
    uint8_t acpi_uid;   /* ACPI Processor UID */
    bool    enabled;    /* true se il processore è attivo all'avvio */
} acpi_cpu_info_t;

/* Informazioni su ogni I/O APIC rilevato nel MADT */
typedef struct {
    uint8_t  id;        /* I/O APIC ID */
    uint32_t address;   /* Indirizzo fisico base MMIO I/O APIC */
    uint32_t gsi_base;  /* Primo GSI gestito da questo I/O APIC */
} acpi_ioapic_info_t;

/* =========================================================================
 * API pubblica
 * ========================================================================= */

/*
 * acpi_init — parsifica tutte le tabelle ACPI dal RSDP.
 *
 * Deve essere chiamata in entry.c PRIMA di lapic_init() e
 * apic_timer_init(), perché apic_timer_calibrate() dipende dall'HPET
 * che viene scoperto qui.
 *
 * @rsdp_phys: indirizzo FISICO del RSDP (da rsdp_request.response->address
 *             di Limine).  acpi_init() converte internamente via g_hhdm_offset.
 */
void acpi_init(uint64_t rsdp_phys);

/*
 * acpi_find_table — cerca una tabella ACPI per signature a 4 caratteri.
 *
 * @sig: puntatore a 4 caratteri (non necessariamente NULL-terminated).
 * @return: puntatore virtuale all'header della tabella, NULL se non trovata.
 */
acpi_sdt_header_t *acpi_find_table(const char *sig);

/*
 * acpi_get_madt — restituisce le informazioni estratte dalla MADT.
 *
 * @cpus_out:     array di output di almeno ACPI_MAX_CPUS elementi.
 * @nioapics_out: riceve il numero di I/O APIC trovati.
 * @ioapics_out:  array di output di almeno ACPI_MAX_IOAPICS elementi.
 * @return: numero di CPU trovate (>= 1), 0 se MADT non disponibile.
 *
 * I dati sono copiati dagli array statici interni — sicuro chiamare più volte.
 */
int acpi_get_madt(acpi_cpu_info_t    *cpus_out,
                  int                *nioapics_out,
                  acpi_ioapic_info_t *ioapics_out);

/*
 * acpi_get_hpet — restituisce il puntatore virtuale al blocco MMIO HPET.
 *
 * Usa la macro HPET_READ/HPET_WRITE per accedere ai registri.
 * @return: indirizzo virtuale base del primo blocco HPET, NULL se non trovato.
 */
void *acpi_get_hpet(void);

/*
 * acpi_hpet_period_fs — periodo del clock HPET in femtosecondi.
 *
 * Tipicamente ~69841279 fs (~14.318 MHz).  Usato da apic_timer_calibrate()
 * per calcolare l'intervallo di attesa preciso.
 * @return: periodo in fs, 0 se HPET non disponibile.
 */
uint64_t acpi_hpet_period_fs(void);

#endif /* MATTIAOS_ACPI_H */
