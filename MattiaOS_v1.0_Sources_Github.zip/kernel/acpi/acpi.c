#include "acpi.h"
#include "../arch/x86_64/cpu.h"   /* serial_puts / serial_putchar per klog */
#include "../mm/vmm.h"            /* g_hhdm_offset */

/* =========================================================================
 * Helper no-libc — convenzione prefisso ac_ per evitare conflitti
 * ========================================================================= */

static inline int ac_memcmp(const void *a, const void *b, size_t n) {
    const uint8_t *pa = (const uint8_t *)a;
    const uint8_t *pb = (const uint8_t *)b;
    for (size_t i = 0; i < n; i++) {
        if (pa[i] != pb[i]) return (int)pa[i] - (int)pb[i];
    }
    return 0;
}

static inline void ac_memcpy(void *dst, const void *src, size_t n) {
    uint8_t       *d = (uint8_t *)dst;
    const uint8_t *s = (const uint8_t *)src;
    for (size_t i = 0; i < n; i++) d[i] = s[i];
}

/* Converte indirizzo fisico in virtuale tramite HHDM */
/* phys_to_virt provided by vmm.h */
static inline void *ac_phys_to_virt(uint64_t phys) {
    return (void *)(phys + g_hhdm_offset);
}

/* =========================================================================
 * Stato interno del modulo
 * ========================================================================= */

#define ACPI_MAX_TABLES 64

/* Indice delle tabelle trovate (puntatori virtuali agli SDT header) */
static acpi_sdt_header_t *s_tables[ACPI_MAX_TABLES];
static int                s_num_tables = 0;

/* Dati estratti dalla MADT */
static acpi_cpu_info_t    s_cpus[ACPI_MAX_CPUS];
static int                s_num_cpus = 0;
static acpi_ioapic_info_t s_ioapics[ACPI_MAX_IOAPICS];
static int                s_num_ioapics = 0;

/* HPET */
static void    *s_hpet_base      = NULL;   /* Indirizzo virtuale base MMIO */
static uint64_t s_hpet_period_fs = 0;      /* Periodo clock in femtosecondi */

/* Flag di inizializzazione */
static bool s_initialized = false;

/* =========================================================================
 * Validazione checksum ACPI (somma di tutti i byte = 0)
 * ========================================================================= */

static bool validate_checksum(const void *data, size_t length) {
    const uint8_t *p = (const uint8_t *)data;
    uint8_t sum = 0;
    for (size_t i = 0; i < length; i++) {
        sum = (uint8_t)(sum + p[i]);
    }
    return sum == 0;
}

/* =========================================================================
 * Aggiunta di una tabella all'indice interno
 * ========================================================================= */

static void register_table(uint64_t phys_addr) {
    if (s_num_tables >= ACPI_MAX_TABLES) return;
    if (phys_addr == 0) return;

    acpi_sdt_header_t *hdr = (acpi_sdt_header_t *)ac_phys_to_virt(phys_addr);

    /* Sanity check lunghezza minima */
    if (hdr->length < sizeof(acpi_sdt_header_t)) return;

    /* Verifica checksum */
    if (!validate_checksum(hdr, hdr->length)) {
        serial_puts("[ACPI] WARN: tabella con checksum errato ignorata\n");
        return;
    }

    s_tables[s_num_tables++] = hdr;
}

/* =========================================================================
 * Parsing MADT
 * ========================================================================= */

static void parse_madt(acpi_madt_t *madt) {
    uint8_t *ptr = (uint8_t *)madt + sizeof(acpi_madt_t);
    uint8_t *end = (uint8_t *)madt + madt->header.length;

    while (ptr + sizeof(acpi_madt_entry_hdr_t) <= end) {
        acpi_madt_entry_hdr_t *eh = (acpi_madt_entry_hdr_t *)ptr;

        /* Protezione contro entry malformate */
        if (eh->length < 2 || ptr + eh->length > end) break;

        switch (eh->type) {
        case MADT_TYPE_LOCAL_APIC: {
            acpi_madt_lapic_t *lapic = (acpi_madt_lapic_t *)ptr;
            /* Considera sia Enabled che Online Capable (hot-plug) */
            uint32_t active = MADT_LAPIC_FLAG_ENABLED | MADT_LAPIC_FLAG_ONLINE_CAPABLE;
            if ((lapic->flags & active) && s_num_cpus < ACPI_MAX_CPUS) {
                s_cpus[s_num_cpus].apic_id  = lapic->apic_id;
                s_cpus[s_num_cpus].acpi_uid = lapic->acpi_processor_uid;
                s_cpus[s_num_cpus].enabled  = (bool)(lapic->flags & MADT_LAPIC_FLAG_ENABLED);
                s_num_cpus++;
            }
            break;
        }
        case MADT_TYPE_IO_APIC: {
            acpi_madt_ioapic_t *ioa = (acpi_madt_ioapic_t *)ptr;
            if (s_num_ioapics < ACPI_MAX_IOAPICS) {
                s_ioapics[s_num_ioapics].id       = ioa->io_apic_id;
                s_ioapics[s_num_ioapics].address   = ioa->io_apic_address;
                s_ioapics[s_num_ioapics].gsi_base  = ioa->gsi_base;
                s_num_ioapics++;
            }
            break;
        }
        case MADT_TYPE_ISO:
        case MADT_TYPE_LOCAL_APIC_NMI:
        case MADT_TYPE_LOCAL_APIC_OVR:
        case MADT_TYPE_LOCAL_X2APIC:
        case MADT_TYPE_LOCAL_X2APIC_NMI:
            /* Strutture valide ma non utilizzate in questa fase */
            break;
        default:
            break;
        }

        ptr += eh->length;
    }
}

/* =========================================================================
 * Parsing HPET
 * ========================================================================= */

static void parse_hpet(acpi_hpet_t *hpet) {
    /* Richiede Memory address space (id == 0) */
    if (hpet->address_space_id != 0) {
        serial_puts("[ACPI] WARN: HPET non in Memory space, ignorato\n");
        return;
    }
    if (hpet->base_address == 0) return;

    s_hpet_base = ac_phys_to_virt(hpet->base_address);

    /* Legge General Capabilities and ID: bit 63:32 = periodo clock in fs */
    uint64_t cap = HPET_READ(s_hpet_base, HPET_REG_CAP_ID);
    s_hpet_period_fs = cap >> HPET_CAP_PERIOD_SHIFT;

    /*
     * Abilita il main counter (bit 0 di HPET_REG_CONFIG).
     * Non usiamo legacy routing (bit 1) per non interferire con l'IOAPIC.
     */
    HPET_WRITE(s_hpet_base, HPET_REG_MAIN_CNT, 0ULL);  /* reset counter */
    HPET_WRITE(s_hpet_base, HPET_REG_CONFIG, HPET_CFG_ENABLE);
}

/* =========================================================================
 * Parsing XSDT (ACPI 2.0+, indirizzi 64-bit)
 * ========================================================================= */

static void parse_xsdt(acpi_xsdt_t *xsdt) {
    uint32_t num_entries = (xsdt->header.length - sizeof(acpi_sdt_header_t)) / 8;
    for (uint32_t i = 0; i < num_entries; i++) {
        register_table(xsdt->entries[i]);
    }
}

/* =========================================================================
 * Parsing RSDT (ACPI 1.0, indirizzi 32-bit)
 * ========================================================================= */

static void parse_rsdt(acpi_rsdt_t *rsdt) {
    uint32_t num_entries = (rsdt->header.length - sizeof(acpi_sdt_header_t)) / 4;
    for (uint32_t i = 0; i < num_entries; i++) {
        register_table((uint64_t)rsdt->entries[i]);
    }
}

/* =========================================================================
 * API pubblica — acpi_init
 * ========================================================================= */

void acpi_init(uint64_t rsdp_phys) {
    serial_puts("[ACPI] Inizializzazione...\n");

    acpi_rsdp_t *rsdp = (acpi_rsdp_t *)ac_phys_to_virt(rsdp_phys);

    /* Verifica signature "RSD PTR " */
    if (ac_memcmp(rsdp->signature, "RSD PTR ", 8) != 0) {
        serial_puts("[ACPI] PANIC: firma RSDP non valida\n");
        return;
    }

    /* Verifica checksum RSDP (versione 1.0: primi 20 byte) */
    if (!validate_checksum(rsdp, 20)) {
        serial_puts("[ACPI] PANIC: checksum RSDP v1 non valido\n");
        return;
    }

    serial_puts("[ACPI] RSDP trovato, revisione: ");
    serial_putchar('0' + rsdp->revision);
    serial_puts("\n");

    /* Preferisce XSDT (64-bit) se ACPI 2.0+ */
    if (rsdp->revision >= 2 && rsdp->xsdt_address != 0) {
        if (!validate_checksum(rsdp, rsdp->length)) {
            serial_puts("[ACPI] WARN: checksum RSDP v2 non valido, uso RSDT\n");
            goto use_rsdt;
        }
        acpi_xsdt_t *xsdt = (acpi_xsdt_t *)ac_phys_to_virt(rsdp->xsdt_address);
        if (ac_memcmp(xsdt->header.signature, "XSDT", 4) == 0 &&
            validate_checksum(xsdt, xsdt->header.length)) {
            serial_puts("[ACPI] Uso XSDT\n");
            parse_xsdt(xsdt);
            goto tables_built;
        }
        serial_puts("[ACPI] WARN: XSDT non valida, fallback a RSDT\n");
    }

use_rsdt:
    if (rsdp->rsdt_address != 0) {
        acpi_rsdt_t *rsdt = (acpi_rsdt_t *)ac_phys_to_virt((uint64_t)rsdp->rsdt_address);
        if (ac_memcmp(rsdt->header.signature, "RSDT", 4) == 0 &&
            validate_checksum(rsdt, rsdt->header.length)) {
            serial_puts("[ACPI] Uso RSDT\n");
            parse_rsdt(rsdt);
        } else {
            serial_puts("[ACPI] PANIC: RSDT non valida, ACPI non disponibile\n");
            return;
        }
    }

tables_built:
    serial_puts("[ACPI] Tabelle trovate: ");
    /* Stampa numero tabelle in decimale (max 2 cifre) */
    if (s_num_tables >= 10) serial_putchar('0' + s_num_tables / 10);
    serial_putchar('0' + s_num_tables % 10);
    serial_puts("\n");

    /* Parsifica MADT per CPU e I/O APIC */
    acpi_sdt_header_t *madt_hdr = acpi_find_table("APIC");
    if (madt_hdr) {
        parse_madt((acpi_madt_t *)madt_hdr);
        serial_puts("[ACPI] MADT: CPU=");
        serial_putchar('0' + (s_num_cpus % 10));
        serial_puts(", IOAPIC=");
        serial_putchar('0' + s_num_ioapics);
        serial_puts("\n");
    } else {
        serial_puts("[ACPI] WARN: MADT non trovata\n");
    }

    /* Parsifica HPET per calibrazione timer APIC */
    acpi_sdt_header_t *hpet_hdr = acpi_find_table("HPET");
    if (hpet_hdr) {
        parse_hpet((acpi_hpet_t *)hpet_hdr);
        if (s_hpet_base) {
            serial_puts("[ACPI] HPET trovato e abilitato\n");
        }
    } else {
        serial_puts("[ACPI] WARN: HPET non trovato — calibrazione timer degradata\n");
    }

    s_initialized = true;
    serial_puts("[ACPI] Inizializzazione completata\n");
}

/* =========================================================================
 * API pubblica — acpi_find_table
 * ========================================================================= */

acpi_sdt_header_t *acpi_find_table(const char *sig) {
    for (int i = 0; i < s_num_tables; i++) {
        if (ac_memcmp(s_tables[i]->signature, sig, 4) == 0) {
            return s_tables[i];
        }
    }
    return NULL;
}

/* =========================================================================
 * API pubblica — acpi_get_madt
 * ========================================================================= */

int acpi_get_madt(acpi_cpu_info_t    *cpus_out,
                  int                *nioapics_out,
                  acpi_ioapic_info_t *ioapics_out) {
    if (!s_initialized || s_num_cpus == 0) return 0;

    ac_memcpy(cpus_out, s_cpus, (size_t)s_num_cpus * sizeof(acpi_cpu_info_t));

    if (nioapics_out) *nioapics_out = s_num_ioapics;
    if (ioapics_out) {
        ac_memcpy(ioapics_out, s_ioapics,
                  (size_t)s_num_ioapics * sizeof(acpi_ioapic_info_t));
    }

    return s_num_cpus;
}

/* =========================================================================
 * API pubblica — acpi_get_hpet
 * ========================================================================= */

void *acpi_get_hpet(void) {
    return s_hpet_base;
}

/* =========================================================================
 * API pubblica — acpi_hpet_period_fs
 * ========================================================================= */

uint64_t acpi_hpet_period_fs(void) {
    return s_hpet_period_fs;
}
