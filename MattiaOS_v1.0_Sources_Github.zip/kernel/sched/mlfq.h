#ifndef MATTIAOS_MLFQ_H
#define MATTIAOS_MLFQ_H

#include "../include/types.h"
#include "../proc/process.h"

#define NUM_QUEUES        8
#define PRIORITY_BOOST_MS 1000

/*
 * Quantum per level (ms):
 *   Level 0:   5  (highest priority — GUI, input events)
 *   Level 1:  10
 *   Level 2:  20
 *   Level 3:  40
 *   Level 4:  80
 *   Level 5: 160
 *   Level 6: 320
 *   Level 7: 640  (lowest — batch/background)
 */
extern const uint32_t MLFQ_QUANTUM_MS[NUM_QUEUES];

typedef struct {
    thread_t *head;
    thread_t *tail;
    uint32_t  quantum_ms;
    uint32_t  thread_count;
} run_queue_t;

void      scheduler_init(void);
void      scheduler_add(thread_t *thread);
void      scheduler_remove(thread_t *thread);
thread_t *scheduler_next(void);
void      scheduler_tick(void);
void      scheduler_yield(void);
void      scheduler_block(thread_t *thread);
void      scheduler_unblock(thread_t *thread);
void      scheduler_priority_boost(void);

extern run_queue_t g_mlfq[NUM_QUEUES];
extern thread_t   *g_idle_thread;

#endif
