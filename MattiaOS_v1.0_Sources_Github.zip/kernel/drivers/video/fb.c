#include <limine.h>
#include "fb.h"
#include "../../fs/devfs.h"
#include "../../mm/slab.h"
#include "../../include/errno.h"

/*
 * fb.c — driver framebuffer GOP per MattiaOS
 *
 * Il bootloader Limine fornisce gia' il framebuffer con indirizzo virtuale
 * HHDM-mappato; non e' richiesta nessuna traduzione phys→virt a runtime.
 *
 * Struttura interna:
 *   s_fb        — stato del driver (una sola istanza: un solo framebuffer)
 *   s_fb_lock   — spinlock che protegge i campi di s_fb
 *   s_dev_node  — devnode_t registrato in devfs → /dev/fb0
 *   s_dev       — device_t nel device tree
 *
 * Operazioni VFS su /dev/fb0:
 *   read()      — copia i pixel dal framebuffer nel buffer utente (offset = byte offset)
 *   write()     — copia i pixel dal buffer utente nel framebuffer
 *   ioctl()     — GET_INFO, FILL_RECT, BLIT, CLEAR
 *
 * Thread safety:
 *   write_pixel e fill_rect usano spinlock_irqsave per garantire
 *   l'assenza di race su operazioni concorrenti al framebuffer.
 *   Il lock NON copre l'intera operazione blit (potrebbe essere lunga):
 *   le singole scritture di riga sono atomiche a livello di word.
 */

/* =========================================================================
 * Stato driver — file-scope
 * ========================================================================= */

/* fb_state_t — stato interno del driver framebuffer */
typedef struct {
    volatile uint32_t *addr;   /* indirizzo virtuale HHDM del framebuffer */
    uint32_t           width;  /* pixel                                   */
    uint32_t           height; /* pixel                                   */
    uint32_t           pitch;  /* byte per scanline                       */
    uint16_t           bpp;    /* bit per pixel (sempre 32)               */
    bool               ready;  /* true dopo fb_init() completato          */
} fb_state_t;

static fb_state_t  s_fb       = {0};
static spinlock_t  s_fb_lock  = {0};

/* devnode statico per /dev/fb0 — valido per tutta la vita del kernel */
static devnode_t   s_dev_node = {0};

/* device_t nel device tree */
static device_t    s_dev      = {0};

/* =========================================================================
 * Helper interni
 * ========================================================================= */

/*
 * fb_row_ptr — ritorna il puntatore alla riga y del framebuffer.
 * pitch e' in byte, ma il framebuffer e' uint32_t* → divido per 4.
 */
static inline volatile uint32_t *fb_row_ptr(uint32_t y) {
    return s_fb.addr + (uint64_t)y * (s_fb.pitch / 4);
}

/*
 * fb_memset32 — riempie n word da dst con val (equivalente di memset per uint32_t).
 * Non usa libc per non creare dipendenze circolari prima della libc.
 */
static void fb_memset32(volatile uint32_t *dst, uint32_t val, uint32_t n) {
    for (uint32_t i = 0; i < n; i++)
        dst[i] = val;
}

/*
 * fb_memcpy32 — copia n word da src a dst.
 */
static void fb_memcpy32(volatile uint32_t *dst, const uint32_t *src, uint32_t n) {
    for (uint32_t i = 0; i < n; i++)
        dst[i] = src[i];
}

/* =========================================================================
 * Operazioni VFS per /dev/fb0
 *
 * I parametri vnode_t* sono ignorati: lo stato e' in s_fb (singleton).
 * ========================================================================= */

static int fb_vfs_open(vnode_t *node, int flags) {
    (void)node; (void)flags;
    if (!s_fb.ready) return -ENOENT;
    return EOK;
}

static int fb_vfs_close(vnode_t *node) {
    (void)node;
    return EOK;
}

/*
 * fb_vfs_read — copia byte dal framebuffer nel buffer utente.
 * offset: byte offset nel framebuffer lineare.
 * Ritorna il numero di byte copiati oppure errore negativo.
 */
static ssize_t fb_vfs_read(vnode_t *node, void *buf, size_t count, off_t offset) {
    (void)node;
    if (!s_fb.ready) return -ENOENT;
    if (!buf)        return -EINVAL;

    uint64_t fb_size = (uint64_t)s_fb.pitch * s_fb.height;
    if ((uint64_t)offset >= fb_size) return 0; /* EOF */

    /* Clip count al confine del framebuffer */
    uint64_t avail = fb_size - (uint64_t)offset;
    if ((uint64_t)count > avail) count = (size_t)avail;

    /*
     * Il framebuffer e' volatile uint32_t*; copiamo byte per byte
     * tramite un cast a uint8_t* per gestire offset non allineati.
     */
    const uint8_t *src  = (const uint8_t *)s_fb.addr + offset;
    uint8_t       *dst  = (uint8_t *)buf;
    for (size_t i = 0; i < count; i++)
        dst[i] = src[i];

    return (ssize_t)count;
}

/*
 * fb_vfs_write — copia byte dal buffer utente nel framebuffer.
 * offset: byte offset nel framebuffer lineare.
 */
static ssize_t fb_vfs_write(vnode_t *node, const void *buf, size_t count,
                            off_t offset) {
    (void)node;
    if (!s_fb.ready) return -ENOENT;
    if (!buf)        return -EINVAL;

    uint64_t fb_size = (uint64_t)s_fb.pitch * s_fb.height;
    if ((uint64_t)offset >= fb_size) return 0;

    uint64_t avail = fb_size - (uint64_t)offset;
    if ((uint64_t)count > avail) count = (size_t)avail;

    const uint8_t    *src  = (const uint8_t *)buf;
    volatile uint8_t *dst  = (volatile uint8_t *)s_fb.addr + offset;
    for (size_t i = 0; i < count; i++)
        dst[i] = src[i];

    return (ssize_t)count;
}

/*
 * fb_vfs_ioctl — comandi specifici del framebuffer.
 * request: FB_IOCTL_* (da fb.h)
 * arg:     puntatore alla struttura argomento (vedi fb.h)
 */
static int fb_vfs_ioctl(vnode_t *node, uint64_t request, void *arg) {
    (void)node;
    if (!s_fb.ready) return -ENOENT;

    switch (request) {

    case FB_IOCTL_GET_INFO: {
        if (!arg) return -EINVAL;
        fb_info_t *info = (fb_info_t *)arg;
        info->addr     = (uint64_t)s_fb.addr;
        info->width    = s_fb.width;
        info->height   = s_fb.height;
        info->pitch    = s_fb.pitch;
        info->bpp      = s_fb.bpp;
        info->reserved = 0;
        return EOK;
    }

    case FB_IOCTL_FILL_RECT: {
        if (!arg) return -EINVAL;
        const fb_fillrect_t *r = (const fb_fillrect_t *)arg;
        fb_fill_rect(r->x, r->y, r->w, r->h, r->color);
        return EOK;
    }

    case FB_IOCTL_BLIT: {
        if (!arg) return -EINVAL;
        const fb_blit_t *b = (const fb_blit_t *)arg;
        fb_blit(b->x, b->y, b->w, b->h, (const uint32_t *)b->src);
        return EOK;
    }

    case FB_IOCTL_CLEAR: {
        /* arg viene interpretato come uint32_t color per valore */
        fb_clear((uint32_t)(uint64_t)arg);
        return EOK;
    }

    default:
        return -EINVAL;
    }
}

/* Tabella operazioni VFS per /dev/fb0 */
static vfs_ops_t s_fb_vfs_ops = {
    .open    = fb_vfs_open,
    .close   = fb_vfs_close,
    .read    = fb_vfs_read,
    .write   = fb_vfs_write,
    .ioctl   = fb_vfs_ioctl,
    .readdir = NULL,
    .stat    = NULL,
    .create  = NULL,
    .mkdir   = NULL,
    .unlink  = NULL,
    .mmap    = NULL,
};

/* =========================================================================
 * API pubblica
 * ========================================================================= */

/*
 * fb_write_pixel — scrive un singolo pixel con protezione spinlock.
 * I pixel fuori dai bordi sono ignorati silenziosamente.
 */
void fb_write_pixel(uint32_t x, uint32_t y, uint32_t color) {
    if (!s_fb.ready || x >= s_fb.width || y >= s_fb.height) return;

    uint64_t flags = spinlock_irqsave(&s_fb_lock);
    fb_row_ptr(y)[x] = color;
    spinlock_irqrestore(&s_fb_lock, flags);
}

/*
 * fb_fill_rect — riempie un rettangolo con colore uniforme.
 * Clip automatico: le porzioni fuori schermo vengono ignorate.
 */
void fb_fill_rect(uint32_t x, uint32_t y, uint32_t w, uint32_t h,
                  uint32_t color) {
    if (!s_fb.ready || w == 0 || h == 0) return;

    /* Clip x */
    if (x >= s_fb.width) return;
    if (x + w > s_fb.width)  w = s_fb.width  - x;

    /* Clip y */
    if (y >= s_fb.height) return;
    if (y + h > s_fb.height) h = s_fb.height - y;

    uint64_t flags = spinlock_irqsave(&s_fb_lock);
    for (uint32_t row = y; row < y + h; row++)
        fb_memset32(fb_row_ptr(row) + x, color, w);
    spinlock_irqrestore(&s_fb_lock, flags);
}

/*
 * fb_clear — riempie l'intero schermo con color.
 * Piu' efficiente di fb_fill_rect(0, 0, w, h, color) perche' non fa clip.
 */
void fb_clear(uint32_t color) {
    if (!s_fb.ready) return;

    uint64_t flags = spinlock_irqsave(&s_fb_lock);
    for (uint32_t row = 0; row < s_fb.height; row++)
        fb_memset32(fb_row_ptr(row), color, s_fb.width);
    spinlock_irqrestore(&s_fb_lock, flags);
}

/*
 * fb_blit — copia un pixel buffer contiguo sullo schermo.
 * src: array di w*h uint32_t, riga per riga senza gap (stride = w).
 * Clip automatico ai bordi del framebuffer.
 */
void fb_blit(uint32_t x, uint32_t y, uint32_t w, uint32_t h,
             const uint32_t *src) {
    if (!s_fb.ready || !src || w == 0 || h == 0) return;

    /* Clip orizzontale */
    uint32_t src_x_offset = 0;
    uint32_t blit_w = w;
    if (x >= s_fb.width) return;
    if (x + blit_w > s_fb.width) blit_w = s_fb.width - x;

    /* Clip verticale */
    uint32_t src_y_offset = 0;
    uint32_t blit_h = h;
    if (y >= s_fb.height) return;
    if (y + blit_h > s_fb.height) blit_h = s_fb.height - y;

    /*
     * Nessun lock sull'intera operazione blit (potrebbe essere molto lunga:
     * ~3.7 MB per 1280x720x32).  Le singole righe sono copiate atomicamente.
     * Il compositor userspace e' responsabile della sincronizzazione
     * a livello applicativo (doppio buffer / vsync).
     */
    for (uint32_t row = 0; row < blit_h; row++) {
        const uint32_t *src_row = src + (src_y_offset + row) * w + src_x_offset;
        fb_memcpy32(fb_row_ptr(y + row) + x, src_row, blit_w);
    }
}

/*
 * fb_get_info — copia le informazioni sul framebuffer in *out.
 */
int fb_get_info(fb_info_t *out) {
    if (!out)          return -EINVAL;
    if (!s_fb.ready)   return -ENOENT;

    out->addr     = (uint64_t)s_fb.addr;
    out->width    = s_fb.width;
    out->height   = s_fb.height;
    out->pitch    = s_fb.pitch;
    out->bpp      = s_fb.bpp;
    out->reserved = 0;
    return EOK;
}

/*
 * fb_is_ready — ritorna true se il driver e' inizializzato.
 */
bool fb_is_ready(void) {
    return s_fb.ready;
}

/* =========================================================================
 * fb_init — entry point del driver (chiamato da drivers_init in irq.c)
 *
 * Sequenza:
 *   1. Verifica la risposta Limine (fb_request.response != NULL)
 *   2. Seleziona il primo framebuffer disponibile
 *   3. Popola s_fb con indirizzo, dimensioni, pitch, bpp
 *   4. Azzera il framebuffer (schermo nero all'avvio)
 *   5. Alloca e registra /dev/fb0 in devfs
 *   6. Inserisce s_dev nel device tree
 * ========================================================================= */

/* fb_request e' definito in entry.c (non piu' static) */
extern volatile struct limine_framebuffer_request fb_request;

void fb_init(void) {
    /* 1 — Verifica risposta Limine */
    if (!fb_request.response ||
        fb_request.response->framebuffer_count == 0) {
        /* Nessun framebuffer disponibile — continua senza /dev/fb0 */
        return;
    }

    struct limine_framebuffer *fb = fb_request.response->framebuffers[0];
    if (!fb || !fb->address) return;

    /* 2/3 — Popola lo stato interno */
    s_fb.addr   = (volatile uint32_t *)fb->address;
    s_fb.width  = (uint32_t)fb->width;
    s_fb.height = (uint32_t)fb->height;
    s_fb.pitch  = (uint32_t)fb->pitch;
    s_fb.bpp    = fb->bpp;
    s_fb.ready  = true;

    /* 4 — Schermo nero all'avvio */
    fb_clear(0x00000000);

    /* 5 — Registra /dev/fb0 in devfs */
    /* nome */
    const char *name = "fb0";
    uint32_t i = 0;
    while (name[i] && i < sizeof(s_dev_node.name) - 1) {
        s_dev_node.name[i] = name[i]; i++;
    }
    s_dev_node.name[i]        = '\0';
    s_dev_node.type           = DEV_TYPE_CHAR;
    s_dev_node.ops            = &s_fb_vfs_ops;
    s_dev_node.driver_data    = &s_fb;

    devfs_register(&s_dev_node);

    /* 6 — device_t nel device tree */
    const char *dname = "fb0";
    i = 0;
    while (dname[i] && i < sizeof(s_dev.name) - 1) {
        s_dev.name[i] = dname[i]; i++;
    }
    s_dev.name[i]      = '\0';
    s_dev.type         = DEV_TYPE_CHAR;
    s_dev.state        = DEV_STATE_ACTIVE;
    s_dev.driver_data  = &s_fb;

    /* char_ops mappate dall'API pubblica */
    static char_ops_t s_char_ops = {
        .open  = NULL,
        .close = NULL,
        .read  = NULL,   /* accesso tramite vfs_ops; char_ops usate da futuri layer */
        .write = NULL,
        .ioctl = NULL,
    };
    s_dev.char_ops = &s_char_ops;

    device_add(&s_dev, NULL);   /* figlio della radice del device tree */
}
