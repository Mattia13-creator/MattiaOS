#ifndef MATTIAOS_FB_H
#define MATTIAOS_FB_H

/*
 * kernel/drivers/video/fb.h — framebuffer GOP driver
 *
 * Il framebuffer e' fornito da Limine al boot tramite GOP (Graphics Output
 * Protocol) UEFI.  Questo driver lo espone come character device /dev/fb0.
 *
 * Formato colore: uint32_t = 0x00RRGGBB  (alpha ignorato, bpp = 32)
 * Risoluzione:    1280 x 720 (configurata in boot/limine.cfg)
 * Pitch:          >= width * 4 bytes (allineato da firmware)
 *
 * Principi rispettati:
 *   Principio 3 — accesso diretto al framebuffer fisico tramite HHDM;
 *                 nessuna astrazione software tra il driver e il firmware.
 *   Principio 4 — questo driver non sa nulla di GUI.
 *                 Espone solo pixel grezzi; la composizione vive in userspace.
 *
 * Dipendenze:
 *   driver.h   — device_t, dev_type_t, spinlock_*
 *   devfs.h    — devnode_t, devfs_register
 *   types.h    — tipi primitivi
 */

#include "../driver.h"

/* =========================================================================
 * Costanti
 * ========================================================================= */

/*
 * Ioctl commands per /dev/fb0.
 * Inviati da userspace via ioctl(fd, FB_IOCTL_*, &arg).
 */
#define FB_IOCTL_GET_INFO    0xFB00   /* arg → fb_info_t * (out) */
#define FB_IOCTL_FILL_RECT   0xFB01   /* arg → fb_fillrect_t * (in) */
#define FB_IOCTL_BLIT        0xFB02   /* arg → fb_blit_t *     (in) */
#define FB_IOCTL_CLEAR       0xFB03   /* arg = color (uint32_t), schermo intero */

/* =========================================================================
 * Strutture dati pubbliche
 *
 * Usate sia internamente (fb.c) sia dalle syscall ioctl in userspace.
 * Devono avere layout fisso: nessun padding implicito tra i campi.
 * ========================================================================= */

/*
 * fb_info_t — informazioni sul framebuffer fisico.
 * Restituita da FB_IOCTL_GET_INFO.
 */
typedef struct {
    uint64_t addr;       /* indirizzo virtuale HHDM del buffer (per mmap) */
    uint32_t width;      /* larghezza in pixel                            */
    uint32_t height;     /* altezza in pixel                              */
    uint32_t pitch;      /* byte per scanline (>= width * bpp/8)          */
    uint16_t bpp;        /* bit per pixel — sempre 32 su MattiaOS         */
    uint16_t reserved;   /* padding — deve essere 0                       */
} __attribute__((packed)) fb_info_t;

/*
 * fb_fillrect_t — argomento per FB_IOCTL_FILL_RECT.
 * Riempie il rettangolo [x, x+w) x [y, y+h) con color (0x00RRGGBB).
 */
typedef struct {
    uint32_t x, y;       /* angolo top-left in pixel */
    uint32_t w, h;       /* larghezza e altezza      */
    uint32_t color;      /* 0x00RRGGBB               */
} __attribute__((packed)) fb_fillrect_t;

/*
 * fb_blit_t — argomento per FB_IOCTL_BLIT.
 * Copia src (buffer ARGB contiguo, w*h pixel) sullo schermo a (x, y).
 * src deve essere un indirizzo virtuale userspace valido.
 */
typedef struct {
    uint32_t  x, y;      /* destinazione sullo schermo          */
    uint32_t  w, h;      /* dimensioni del buffer sorgente      */
    uint64_t  src;       /* indirizzo virtuale del pixel buffer */
} __attribute__((packed)) fb_blit_t;

/* =========================================================================
 * API pubblica del driver
 *
 * Chiamate da altri moduli kernel (es. early output prima che /dev esista).
 * Tutte le coordinate sono in pixel (0-based, origine top-left).
 * ========================================================================= */

/*
 * fb_init — inizializza il driver framebuffer.
 *   Legge la risposta Limine, popola lo stato interno, registra /dev/fb0.
 *   Deve essere chiamata dopo slab_init() e devfs_mount().
 *   Firma void/void per compatibilita' con irq.c (extern void fb_init(void)).
 */
void fb_init(void);

/*
 * fb_write_pixel — scrive un singolo pixel.
 *   x, y:  coordinate (0-based); ignorati se fuori schermo.
 *   color: 0x00RRGGBB.
 */
void fb_write_pixel(uint32_t x, uint32_t y, uint32_t color);

/*
 * fb_fill_rect — riempie un rettangolo con colore uniforme.
 *   Clip automatico ai bordi del framebuffer.
 */
void fb_fill_rect(uint32_t x, uint32_t y, uint32_t w, uint32_t h,
                  uint32_t color);

/*
 * fb_clear — riempie l'intero schermo con color.
 */
void fb_clear(uint32_t color);

/*
 * fb_blit — copia un buffer di pixel (w*h uint32_t, 0x00RRGGBB) sullo schermo.
 *   src:  puntatore al buffer sorgente contiguo (riga per riga, senza gap).
 *   Clip automatico: i pixel fuori dallo schermo vengono ignorati.
 */
void fb_blit(uint32_t x, uint32_t y, uint32_t w, uint32_t h,
             const uint32_t *src);

/*
 * fb_get_info — popola *out con le informazioni sul framebuffer corrente.
 *   Ritorna EOK, oppure EINVAL se il framebuffer non e' ancora inizializzato.
 */
int fb_get_info(fb_info_t *out);

/*
 * fb_is_ready — ritorna true se fb_init() e' stato completato con successo.
 */
bool fb_is_ready(void);

#endif /* MATTIAOS_FB_H */
