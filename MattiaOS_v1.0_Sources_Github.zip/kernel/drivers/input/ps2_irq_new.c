/* PS/2 IRQ handler — SOLO deposita bytes, NESSUNA altra logica */
