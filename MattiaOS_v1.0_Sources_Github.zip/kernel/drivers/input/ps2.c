/*
 * ps2.c — driver controller PS/2 Intel 8042  (v3.13 — polling diretto)
 *
 * Differenze rispetto a v3.12:
 *   - Rimosso IRQ handler per la tastiera: isr_handler in idt.c fa l'EOI
 *     automaticamente quando arriva IRQ1 senza handler registrato.
 *   - Rimosso ring buffer g_ps2_kbd_buf e ps2_kbd_read_byte.
 *   - keyboard_process() legge direttamente la porta 0x60 via
 *     ps2_kbd_has_data() / ps2_kbd_read_raw() (inline in ps2.h).
 *   - Rimosso ps2_kbd_poll_hardware (ora integrato in keyboard_process).
 *
 * La sequenza di init rimane identica (OSDev standard):
 *   1. Disabilita porte
 *   2. Flush output buffer
 *   3. Disabilita translation (scan code set 2 puro)
 *   4. Self-test controller
 *   5. Test porta 1
 *   6. Abilita porta 1
 *   7. Reset tastiera
 *   8. Imposta scan code set 2
 *   9. Abilita scanning
 *  10. Configura typematic (massimo delay/minimo rate)
 *  11. Abilita IRQ1 nel CFG byte (necessario per ricevere OBF interrupt)
 */

#include "ps2.h"
#include "keyboard.h"
#include "../driver.h"
#include "../../arch/x86_64/cpu.h"
#include "../../mm/slab.h"
#include "../../include/errno.h"

/* =========================================================================
 * Helper I/O con timeout
 * ========================================================================= */

#define PS2_TIMEOUT_LOOPS  100000

static bool ps2_wait_read(void) {
    for (uint32_t i = 0; i < PS2_TIMEOUT_LOOPS; i++) {
        if (inb(PS2_STATUS_PORT) & PS2_STATUS_OBF) return true;
        asm volatile("pause");
    }
    return false;
}

static bool ps2_wait_write(void) {
    for (uint32_t i = 0; i < PS2_TIMEOUT_LOOPS; i++) {
        if (!(inb(PS2_STATUS_PORT) & PS2_STATUS_IBF)) return true;
        asm volatile("pause");
    }
    return false;
}

static uint8_t ps2_read_data(void) {
    if (!ps2_wait_read()) return 0xFF;
    return inb(PS2_DATA_PORT);
}

static void ps2_write_cmd(uint8_t cmd) {
    ps2_wait_write();
    outb(PS2_CMD_PORT, cmd);
}

static void ps2_write_data(uint8_t data) {
    ps2_wait_write();
    outb(PS2_DATA_PORT, data);
}

static bool ps2_kbd_send(uint8_t cmd) {
    ps2_write_data(cmd);
    return ps2_read_data() == PS2_DEV_ACK;
}

/* =========================================================================
 * ps2_flush — svuota output buffer
 * ========================================================================= */

void ps2_flush(void) {
    for (uint32_t i = 0; i < 16; i++) {
        if (!(inb(PS2_STATUS_PORT) & PS2_STATUS_OBF)) break;
        inb(PS2_DATA_PORT);
        for (volatile uint32_t j = 0; j < 1000; j++) asm volatile("pause");
    }
}

/* =========================================================================
 * ps2_kbd_set_leds
 * ========================================================================= */

void ps2_kbd_set_leds(uint8_t led_mask) {
    ps2_kbd_send(KBD_CMD_SET_LEDS);
    ps2_kbd_send(led_mask & 0x07);
}

/* =========================================================================
 * Device tree
 * ========================================================================= */

static device_t s_ps2_ctrl_dev = {0};
static device_t s_ps2_kbd_dev  = {0};

/* =========================================================================
 * ps2_init
 * ========================================================================= */

void ps2_init(void) {
    serial_puts("[PS2] Init controller 8042...\r\n");

    /* 1. Disabilita porte */
    ps2_write_cmd(PS2_CMD_DISABLE_P1);
    ps2_write_cmd(PS2_CMD_DISABLE_P2);

    /* 2. Flush */
    ps2_flush();

    /* 3. Leggi e modifica CFG: disabilita translation, disabilita IRQ durante init */
    ps2_write_cmd(PS2_CMD_READ_CFG);
    uint8_t cfg = ps2_read_data();
    serial_printf("[PS2] CFG originale: 0x%x\r\n", (unsigned)cfg);

    cfg &= ~(PS2_CFG_IRQ1_EN | PS2_CFG_IRQ12_EN | PS2_CFG_XLAT);
    ps2_write_cmd(PS2_CMD_WRITE_CFG);
    ps2_write_data(cfg);

    /* 4. Self-test */
    ps2_write_cmd(PS2_CMD_SELF_TEST);
    uint8_t st = ps2_read_data();
    serial_printf("[PS2] Self-test: 0x%x (%s)\r\n",
                  (unsigned)st, st == PS2_SELF_TEST_OK ? "OK" : "WARN");

    /* Riscrivi CFG dopo self-test (alcuni controller lo resettano) */
    ps2_write_cmd(PS2_CMD_WRITE_CFG);
    ps2_write_data(cfg);

    /* 5. Test porta 1 */
    ps2_write_cmd(PS2_CMD_TEST_P1);
    uint8_t p1 = ps2_read_data();
    serial_printf("[PS2] Test P1: 0x%x (%s)\r\n",
                  (unsigned)p1, p1 == PS2_PORT_TEST_OK ? "OK" : "WARN");

    /* 6. Abilita porta 1 */
    ps2_write_cmd(PS2_CMD_ENABLE_P1);

    /* 7. Reset tastiera */
    ps2_write_data(KBD_CMD_RESET);
    uint8_t ack  = ps2_read_data();
    uint8_t self = ps2_read_data();
    serial_printf("[PS2] Reset kbd: ack=0x%x self=0x%x (%s)\r\n",
                  (unsigned)ack, (unsigned)self,
                  (ack == PS2_DEV_ACK && self == 0xAA) ? "OK" : "WARN");
    ps2_flush();

    /* 8. Imposta scan code set 2 */
    ps2_write_data(KBD_CMD_SCANCODE);
    ps2_read_data();   /* ACK */
    ps2_write_data(0x02);
    ps2_read_data();   /* ACK */

    /* Verifica set attivo */
    ps2_flush();
    ps2_write_data(KBD_CMD_SCANCODE);
    ps2_read_data();   /* ACK */
    ps2_write_data(0x00);
    ps2_read_data();   /* ACK */
    uint8_t sc = ps2_read_data();
    serial_printf("[PS2] Scan code attivo: 0x%x\r\n", (unsigned)sc);
    if (sc == 0x43)
        serial_puts("[PS2] WARN: translation forzata ON\r\n");

    /* 9. Abilita scanning */
    ps2_write_data(KBD_CMD_ENABLE);
    uint8_t ena = ps2_read_data();
    serial_printf("[PS2] Enable scanning: 0x%x\r\n", (unsigned)ena);

    /* 10. Typematic: delay massimo (1s), rate minimo (2cps) = quasi-disabilitato.
     *     L'autorepeat software in kernel_console gestisce il repeat.
     *     Byte: bits[6:5]=delay, bits[4:0]=rate → 0b11_11111 = 0xFF
     *     (0xDF = delay 1s rate 2cps secondo spec, ma 0xFF è più aggressivo) */
    ps2_write_data(KBD_CMD_SET_RATE);
    ps2_read_data();   /* ACK */
    ps2_write_data(0xFF);
    ps2_read_data();   /* ACK */

    /* 11. Abilita IRQ1 nel CFG
     *
     * NOTA: anche con IRQ1 abilitato, NON registriamo un IRQ handler.
     * isr_handler() in idt.c fa EOI automaticamente quando arriva IRQ1
     * (g_irq_handlers[0x21] == NULL → skip handler, poi EOI).
     * Il byte rimane nel buffer OBF dell'8042 finché keyboard_process()
     * lo legge con ps2_kbd_has_data() / ps2_kbd_read_raw(). */
    ps2_write_cmd(PS2_CMD_READ_CFG);
    cfg = ps2_read_data();
    cfg |= PS2_CFG_IRQ1_EN;
    cfg &= ~PS2_CFG_XLAT;   /* assicura translation OFF */
    ps2_write_cmd(PS2_CMD_WRITE_CFG);
    ps2_write_data(cfg);

    ps2_write_cmd(PS2_CMD_READ_CFG);
    uint8_t cfg_final = ps2_read_data();
    serial_printf("[PS2] CFG finale: 0x%x (IRQ1=%u XLAT=%u)\r\n",
                  (unsigned)cfg_final,
                  (unsigned)(cfg_final & 1),
                  (unsigned)((cfg_final >> 6) & 1));

    /* Device tree */
    const char *cn = "ps2_ctrl";
    for (uint32_t i = 0; i < sizeof(s_ps2_ctrl_dev.name)-1 && cn[i]; i++)
        s_ps2_ctrl_dev.name[i] = cn[i];
    s_ps2_ctrl_dev.type  = DEV_TYPE_BUS;
    s_ps2_ctrl_dev.state = DEV_STATE_ACTIVE;
    device_add(&s_ps2_ctrl_dev, NULL);

    const char *kn = "kbd0";
    for (uint32_t i = 0; i < sizeof(s_ps2_kbd_dev.name)-1 && kn[i]; i++)
        s_ps2_kbd_dev.name[i] = kn[i];
    s_ps2_kbd_dev.type  = DEV_TYPE_INPUT;
    s_ps2_kbd_dev.state = DEV_STATE_ACTIVE;
    device_add(&s_ps2_kbd_dev, &s_ps2_ctrl_dev);

    serial_puts("[PS2] Init completo\r\n");
}
