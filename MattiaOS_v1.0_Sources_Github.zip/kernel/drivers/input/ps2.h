#ifndef MATTIAOS_PS2_H
#define MATTIAOS_PS2_H

/*
 * ps2.h — controller PS/2 Intel 8042  (v3.13 — polling diretto)
 *
 * Architettura semplificata:
 *   Nessun ring buffer intermedio. keyboard_process() legge direttamente
 *   dalla porta 0x60 tramite ps2_kbd_has_data() / ps2_kbd_read_raw().
 *   Quando arriva IRQ1, isr_handler() in idt.c fa l'EOI automaticamente.
 *   Il byte rimane nel buffer OBF finché keyboard_process() lo legge.
 */

#include "../driver.h"
#include "../../arch/x86_64/cpu.h"   /* inb per ps2_kbd_has_data / ps2_kbd_read_raw */

/* I/O port map */
#define PS2_DATA_PORT    0x60
#define PS2_STATUS_PORT  0x64
#define PS2_CMD_PORT     0x64

/* Bit registro di stato */
#define PS2_STATUS_OBF   (1 << 0)   /* Output Buffer Full */
#define PS2_STATUS_IBF   (1 << 1)   /* Input Buffer Full  */
#define PS2_STATUS_SYS   (1 << 2)
#define PS2_STATUS_CD    (1 << 3)
#define PS2_STATUS_AUXB  (1 << 5)   /* Dato dal mouse     */
#define PS2_STATUS_TOUT  (1 << 6)
#define PS2_STATUS_PERR  (1 << 7)

/* Comandi controller */
#define PS2_CMD_READ_CFG     0x20
#define PS2_CMD_WRITE_CFG    0x60
#define PS2_CMD_DISABLE_P2   0xA7
#define PS2_CMD_ENABLE_P2    0xA8
#define PS2_CMD_TEST_P2      0xA9
#define PS2_CMD_SELF_TEST    0xAA
#define PS2_CMD_TEST_P1      0xAB
#define PS2_CMD_DISABLE_P1   0xAD
#define PS2_CMD_ENABLE_P1    0xAE
#define PS2_CMD_WRITE_P2     0xD4

/* Configuration Byte */
#define PS2_CFG_IRQ1_EN   (1 << 0)
#define PS2_CFG_IRQ12_EN  (1 << 1)
#define PS2_CFG_XLAT      (1 << 6)

/* Risposte dispositivi */
#define PS2_DEV_ACK       0xFA
#define PS2_DEV_RESEND    0xFE
#define PS2_SELF_TEST_OK  0x55
#define PS2_PORT_TEST_OK  0x00

/* Comandi tastiera */
#define KBD_CMD_RESET        0xFF
#define KBD_CMD_ECHO         0xEE
#define KBD_CMD_SET_LEDS     0xED
#define KBD_CMD_SCANCODE     0xF0
#define KBD_CMD_ENABLE       0xF4
#define KBD_CMD_DISABLE      0xF5
#define KBD_CMD_SET_RATE     0xF3
#define KBD_LED_SCROLL  (1 << 0)
#define KBD_LED_NUM     (1 << 1)
#define KBD_LED_CAPS    (1 << 2)

/* Vettori IRQ */
#define PS2_KBD_VECTOR   0x21
#define PS2_MOUSE_VECTOR 0x2C

/* =========================================================================
 * Polling diretto porta 0x60
 *
 * Chiamato esclusivamente da keyboard_process() nel console loop.
 * ps2_kbd_has_data(): OBF=1 e non è dato mouse (AUXB=0).
 * ps2_kbd_read_raw(): legge il byte (chiamare solo se has_data()==true).
 * ========================================================================= */

static inline bool ps2_kbd_has_data(void) {
    uint8_t s = inb(PS2_STATUS_PORT);
    return (s & (PS2_STATUS_OBF | PS2_STATUS_AUXB)) == PS2_STATUS_OBF;
}

static inline uint8_t ps2_kbd_read_raw(void) {
    return inb(PS2_DATA_PORT);
}

/* API pubblica */
void ps2_init(void);
void ps2_kbd_set_leds(uint8_t led_mask);
void ps2_flush(void);

#endif /* MATTIAOS_PS2_H */
