/*
 * keyboard.c — decoder scan code set 2 → key_event_t  (v3.13)
 *
 * Architettura (v3.13):
 *   keyboard_process() legge direttamente ps2_kbd_has_data() / ps2_kbd_read_raw().
 *   Nessun ring buffer PS/2 intermedio, nessun spinlock, nessun IRQ handler
 *   per la tastiera. Stato completamente determinista.
 *
 * CapsLock spurio (VirtualBox):
 *   Al boot VirtualBox invia un fake CapsLock make+break per sincronizzare
 *   il LED guest con l'host. Lo scartamo tramite:
 *   1. Settle period: i primi KBD_SETTLE_EVENTS eventi di qualsiasi tasto
 *      vengono processati normalmente TRANNE CapsLock.
 *   2. In pratica: s_capslock_settled = false al boot; il PRIMO make di
 *      CapsLock viene scartato e setta s_capslock_settled = true.
 *      Tutti i CapsLock successivi funzionano normalmente.
 *
 * s_pressed bitset (anti-typematic):
 *   VirtualBox genera make codes ripetuti (typematic hardware) anche dopo
 *   KBD_CMD_SET_RATE 0xFF. Il bitset traccia i tasti fisicamente premuti:
 *   un make code per un tasto già "premuto" viene scartato silenziosamente.
 *   L'autorepeat software in kernel_console gestisce il repeat.
 */

#include "keyboard.h"

/* ── Ring buffer globale eventi ─────────────────────────────────────────── */
kbd_event_ring_t g_kbd_events = { .head=0, .tail=0, .lock={0} };

/* ── Tabella scan code set 2 → vk_t (byte singoli) ─────────────────────── */
static const vk_t s_sc2_normal[256] = {
    [0x01]=VK_F9,    [0x03]=VK_F5,    [0x04]=VK_F3,    [0x05]=VK_F1,
    [0x06]=VK_F2,    [0x07]=VK_F12,   [0x09]=VK_F10,   [0x0A]=VK_F8,
    [0x0B]=VK_F6,    [0x0C]=VK_F4,    [0x0D]=VK_TAB,   [0x0E]=VK_GRAVE,
    [0x11]=VK_LALT,  [0x12]=VK_LSHIFT,[0x14]=VK_LCTRL, [0x15]=VK_Q,
    [0x16]=VK_1,     [0x1A]=VK_Z,     [0x1B]=VK_S,     [0x1C]=VK_A,
    [0x1D]=VK_W,     [0x1E]=VK_2,     [0x21]=VK_C,     [0x22]=VK_X,
    [0x23]=VK_D,     [0x24]=VK_E,     [0x25]=VK_4,     [0x26]=VK_3,
    [0x29]=VK_SPACE, [0x2A]=VK_V,     [0x2B]=VK_F,     [0x2C]=VK_T,
    [0x2D]=VK_R,     [0x2E]=VK_5,     [0x31]=VK_N,     [0x32]=VK_B,
    [0x33]=VK_H,     [0x34]=VK_G,     [0x35]=VK_Y,     [0x36]=VK_6,
    [0x3A]=VK_M,     [0x3B]=VK_J,     [0x3C]=VK_U,     [0x3D]=VK_7,
    [0x3E]=VK_8,     [0x41]=VK_COMMA, [0x42]=VK_K,     [0x43]=VK_I,
    [0x44]=VK_O,     [0x45]=VK_0,     [0x46]=VK_9,     [0x49]=VK_PERIOD,
    [0x4A]=VK_SLASH, [0x4B]=VK_L,     [0x4C]=VK_SEMICOLON,
    [0x4D]=VK_P,     [0x4E]=VK_MINUS, [0x52]=VK_APOSTROPHE,
    [0x54]=VK_LBRACKET,[0x55]=VK_EQUALS,[0x58]=VK_CAPSLOCK,
    [0x59]=VK_RSHIFT,[0x5A]=VK_ENTER, [0x5B]=VK_RBRACKET,
    [0x5D]=VK_BACKSLASH,[0x66]=VK_BACKSPACE,
    [0x69]=VK_KP1,   [0x6B]=VK_KP4,   [0x6C]=VK_KP7,
    [0x70]=VK_KP0,   [0x71]=VK_KP_DOT,[0x72]=VK_KP2,
    [0x73]=VK_KP5,   [0x74]=VK_KP6,   [0x75]=VK_KP8,
    [0x76]=VK_ESCAPE,[0x77]=VK_NUMLOCK,[0x78]=VK_F11,
    [0x79]=VK_KP_PLUS,[0x7A]=VK_KP3,  [0x7B]=VK_KP_MINUS,
    [0x7C]=VK_KP_STAR,[0x7D]=VK_KP9,  [0x7E]=VK_SCROLLLOCK,
    [0x83]=VK_F7,
};

/* ── Tabella scan code set 2 → vk_t (byte dopo prefisso E0) ─────────────── */
static const vk_t s_sc2_extended[256] = {
    [0x11]=VK_RALT,  [0x14]=VK_RCTRL, [0x1F]=VK_LMETA, [0x27]=VK_RMETA,
    [0x48]=VK_UP,    [0x4A]=VK_KP_SLASH,[0x50]=VK_DOWN, [0x5A]=VK_KP_ENTER,
    [0x69]=VK_END,   [0x6B]=VK_LEFT,  [0x6C]=VK_HOME,  [0x70]=VK_INSERT,
    [0x71]=VK_DELETE,[0x74]=VK_RIGHT, [0x7A]=VK_PGDN,  [0x7C]=VK_PRINT_SCREEN,
    [0x7D]=VK_PGUP,
};

/* ── Tabelle ASCII — layout tastiera ITALIANA ───────────────────────────
 *
 * Valori CP437 per caratteri accentati:
 *   à=0x85  è=0x8A  é=0x82  ì=0x8D  ò=0x95  ù=0x97
 *   ç=0x87  §=0x15  °=0xF8  £=0x9C
 *
 * Riga numeri shiftata: !"£$%&/()=
 * Tasti simbolo remappati rispetto al layout US:
 *   fisica `  → \   (shift: |)
 *   fisica -  → '   (shift: ?)
 *   fisica =  → ì   (shift: ^)
 *   fisica [  → è   (shift: é)
 *   fisica ]  → +   (shift: *)
 *   fisica \  → ù   (shift: §)
 *   fisica ;  → ò   (shift: ç)
 *   fisica '  → à   (shift: °)
 *   fisica ,  → ,   (shift: ;)
 *   fisica .  → .   (shift: :)
 *   fisica /  → -   (shift: _)
 */
static const char s_ascii_base[128] = {
    [' ']=' ', ['\n']='\n', ['\t']='\t', ['\b']='\b', [0x1B]=0x1B,
    ['0']='0',['1']='1',['2']='2',['3']='3',['4']='4',
    ['5']='5',['6']='6',['7']='7',['8']='8',['9']='9',
    [VK_GRAVE] ='\\',
    [VK_MINUS] ='\'',
    [VK_EQUALS]=(char)0x8D,     /* ì */
    [VK_LBRACKET]=(char)0x8A,   /* è */
    [VK_RBRACKET]='+',
    [VK_BACKSLASH]=(char)0x97,  /* ù */
    [VK_SEMICOLON]=(char)0x95,  /* ò */
    [VK_APOSTROPHE]=(char)0x85, /* à */
    [VK_COMMA]=',',
    [VK_PERIOD]='.',
    [VK_SLASH]='-',
};
static const char s_ascii_shift[128] = {
    [' ']=' ', ['\n']='\n', ['\t']='\t', ['\b']='\b',
    /* Riga numeri italiana: !"£$%&/()= */
    ['0']='=',  ['1']='!',          ['2']='"',           ['3']=(char)0x9C,
    ['4']='$',  ['5']='%',          ['6']='&',           ['7']='/',
    ['8']='(',  ['9']=')',
    /* Simboli shiftati */
    [VK_GRAVE] ='|',
    [VK_MINUS] ='?',
    [VK_EQUALS]='^',
    [VK_LBRACKET]=(char)0x82,   /* é */
    [VK_RBRACKET]='*',
    [VK_BACKSLASH]=(char)0x15,  /* § */
    [VK_SEMICOLON]=(char)0x87,  /* ç */
    [VK_APOSTROPHE]=(char)0xF8, /* ° */
    [VK_COMMA]=';',
    [VK_PERIOD]=':',
    [VK_SLASH]='_',
};

/* ── Stato decoder ──────────────────────────────────────────────────────── */
typedef enum {
    STATE_NORMAL = 0,
    STATE_E0,        /* ricevuto 0xE0 */
    STATE_F0,        /* ricevuto 0xF0 (release byte singolo) */
    STATE_E0F0,      /* ricevuto 0xE0 0xF0 (release esteso) */
} decode_state_t;

static decode_state_t s_state     = STATE_NORMAL;
static uint8_t        s_modifiers = 0;
static bool           s_capslock  = false;
static bool           s_numlock   = true;
static bool           s_scrolllock= false;

/*
 * s_capslock_settled:
 *   false al boot → il PRIMO make di CapsLock viene scartato (fake VirtualBox)
 *   true dopo → CapsLock funziona normalmente
 */
static bool s_capslock_settled = false;

/*
 * s_pressed[32]: bitset 256 bit — un bit per vk_t.
 * Scarta make codes ripetuti (typematic hardware).
 */
static uint8_t s_pressed[32];

static inline void pressed_set(vk_t v) { s_pressed[(int)v>>3] |=  (uint8_t)(1u<<((int)v&7)); }
static inline void pressed_clr(vk_t v) { s_pressed[(int)v>>3] &= (uint8_t)~(1u<<((int)v&7)); }
static inline bool pressed_get(vk_t v) { return (s_pressed[(int)v>>3]>>((int)v&7))&1; }

/* ── Helpers ─────────────────────────────────────────────────────────────── */
static void update_leds(void) {
    uint8_t leds = 0;
    if (s_capslock)    leds |= KBD_LED_CAPS;
    if (s_numlock)     leds |= KBD_LED_NUM;
    if (s_scrolllock)  leds |= KBD_LED_SCROLL;
    ps2_kbd_set_leds(leds);
}

static void update_modifiers(vk_t vk, bool pressed) {
    switch (vk) {
    case VK_LSHIFT:    if(pressed) s_modifiers|=MOD_LSHIFT; else s_modifiers&=~MOD_LSHIFT; break;
    case VK_RSHIFT:    if(pressed) s_modifiers|=MOD_RSHIFT; else s_modifiers&=~MOD_RSHIFT; break;
    case VK_LCTRL:     if(pressed) s_modifiers|=MOD_LCTRL;  else s_modifiers&=~MOD_LCTRL;  break;
    case VK_RCTRL:     if(pressed) s_modifiers|=MOD_RCTRL;  else s_modifiers&=~MOD_RCTRL;  break;
    case VK_LALT:      if(pressed) s_modifiers|=MOD_LALT;   else s_modifiers&=~MOD_LALT;   break;
    case VK_RALT:      if(pressed) s_modifiers|=MOD_RALT;   else s_modifiers&=~MOD_RALT;   break;
    case VK_CAPSLOCK:
        if (pressed) {
            if (!s_capslock_settled) {
                /* Primo CapsLock dopo boot: è il fake VirtualBox. Scarta. */
                s_capslock_settled = true;
                break;
            }
            s_capslock = !s_capslock;
            if (s_capslock) s_modifiers |= MOD_CAPSLOCK;
            else            s_modifiers &= ~MOD_CAPSLOCK;
            update_leds();
        }
        break;
    case VK_NUMLOCK:
        if (pressed) {
            s_numlock = !s_numlock;
            if (s_numlock) s_modifiers |= MOD_NUMLOCK;
            else           s_modifiers &= ~MOD_NUMLOCK;
            update_leds();
        }
        break;
    case VK_SCROLLLOCK:
        if (pressed) { s_scrolllock = !s_scrolllock; update_leds(); }
        break;
    default: break;
    }
}

static char ascii_from_vk(vk_t vk, uint8_t mods) {
    if (vk == VK_ENTER)     return '\n';
    if (vk == VK_TAB)       return '\t';
    if (vk == VK_BACKSPACE) return '\b';
    if (vk == VK_ESCAPE)    return 0x1B;
    if (vk == VK_SPACE)     return ' ';

    /* ── Ctrl+lettera: DEVE essere prima del check lettera normale ──────────
     * Se Ctrl è premuto e il tasto è una lettera, restituiamo il codice
     * di controllo (1=Ctrl+A … 26=Ctrl+Z).
     * BUG v4.14: questo check era DOPO il check lettera → Ctrl+C dava 'c'. */
    if ((mods & MOD_CTRL) && vk >= (vk_t)'a' && vk <= (vk_t)'z')
        return (char)(vk - 'a' + 1);   /* Ctrl+C → 3 (ETX) */

    bool shift = (mods & MOD_SHIFT) != 0;

    /* Lettere: CapsLock XOR Shift */
    if (vk >= (vk_t)'a' && vk <= (vk_t)'z') {
        return (s_capslock ^ shift) ? (char)(vk - 'a' + 'A') : (char)vk;
    }

    /* Punteggiatura e cifre */
    if ((int)vk < 128) {
        if (shift && s_ascii_shift[(int)vk]) return s_ascii_shift[(int)vk];
        return s_ascii_base[(int)vk];
    }

    /* Tastierino numerico — operatori SEMPRE attivi (indipendente da NumLock).
     * BUG v5.6: VK_KP_SLASH era dentro if(s_numlock) → con NumLock off dava 0.
     * Gli operatori (+,-,*,/) e KP_ENTER non dipendono mai da NumLock. */
    switch (vk) {
    case VK_KP_PLUS:  return '+';
    case VK_KP_MINUS: return '-';
    case VK_KP_STAR:  return '*';
    case VK_KP_SLASH: return '/';
    case VK_KP_ENTER: return '\n';
    default: break;
    }

    /* Cifre del tastierino — solo se NumLock attivo */
    if (s_numlock && !shift) {
        switch (vk) {
        case VK_KP0: return '0'; case VK_KP1: return '1';
        case VK_KP2: return '2'; case VK_KP3: return '3';
        case VK_KP4: return '4'; case VK_KP5: return '5';
        case VK_KP6: return '6'; case VK_KP7: return '7';
        case VK_KP8: return '8'; case VK_KP9: return '9';
        case VK_KP_DOT: return '.';
        default: break;
        }
    }

    return 0;
}

/*
 * emit_event — deposita un key_event_t nel ring buffer g_kbd_events.
 *
 * Per i make codes (pressed=true): se il tasto è già "premuto" nel bitset
 * s_pressed, scarta silenziosamente (è autorepeat hardware non desiderato).
 * Per i break codes (pressed=false): azzera il bit nel bitset.
 */
static void emit_event(vk_t vk, bool pressed) {
    if (vk == VK_NONE) return;

    if (pressed) {
        if (pressed_get(vk)) return;   /* make duplicato → scarta */
        pressed_set(vk);
    } else {
        pressed_clr(vk);
    }

    update_modifiers(vk, pressed);

    key_event_t ev = {
        .keycode   = vk,
        .pressed   = pressed,
        .modifiers = s_modifiers,
        .ascii     = pressed ? ascii_from_vk(vk, s_modifiers) : 0,
    };

    /* Ring buffer eventi — no spinlock: chiamato solo dal console loop */
    uint32_t next = (g_kbd_events.head + 1) & (KBD_EVENT_BUF_SIZE - 1);
    if (next != g_kbd_events.tail) {
        g_kbd_events.events[g_kbd_events.head] = ev;
        g_kbd_events.head = next;
    }
}

/* ── API pubblica ────────────────────────────────────────────────────────── */

void keyboard_init(void) {
    s_state      = STATE_NORMAL;
    s_modifiers  = 0;
    s_capslock   = false;
    s_numlock    = true;
    s_scrolllock = false;
    s_capslock_settled = false;

    for (int i = 0; i < 32; i++) s_pressed[i] = 0;

    g_kbd_events.head = 0;
    g_kbd_events.tail = 0;

    ps2_kbd_set_leds(KBD_LED_NUM);
}

/*
 * keyboard_process — legge i byte grezzi dalla porta 0x60 e li decodifica.
 *
 * Deve essere chiamata SOLO dal console loop (single-threaded).
 * Drena tutto ciò che è disponibile in OBF in un singolo ciclo.
 * Non bloccante: esce quando OBF è vuoto.
 */
void keyboard_process(void) {
    while (ps2_kbd_has_data()) {
        uint8_t byte = ps2_kbd_read_raw();

        switch (s_state) {
        case STATE_NORMAL:
            if      (byte == 0xE0) { s_state = STATE_E0;   }
            else if (byte == 0xF0) { s_state = STATE_F0;   }
            else {
                emit_event(s_sc2_normal[byte], true);
                s_state = STATE_NORMAL;
            }
            break;

        case STATE_E0:
            if (byte == 0xF0) { s_state = STATE_E0F0; }
            else {
                emit_event(s_sc2_extended[byte], true);
                s_state = STATE_NORMAL;
            }
            break;

        case STATE_F0:
            emit_event(s_sc2_normal[byte], false);
            s_state = STATE_NORMAL;
            break;

        case STATE_E0F0:
            emit_event(s_sc2_extended[byte], false);
            s_state = STATE_NORMAL;
            break;
        }
    }
}

bool keyboard_poll_event(key_event_t *out) {
    if (!out) return false;
    if (g_kbd_events.head == g_kbd_events.tail) return false;
    *out = g_kbd_events.events[g_kbd_events.tail];
    g_kbd_events.tail = (g_kbd_events.tail + 1) & (KBD_EVENT_BUF_SIZE - 1);
    return true;
}

char keyboard_getchar(void) {
    keyboard_process();
    key_event_t ev;
    while (keyboard_poll_event(&ev))
        if (ev.pressed && ev.ascii) return ev.ascii;
    return 0;
}

uint8_t keyboard_get_modifiers(void) { return s_modifiers; }
