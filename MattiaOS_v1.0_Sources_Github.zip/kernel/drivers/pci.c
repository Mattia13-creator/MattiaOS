#include "pci.h"
#include "../arch/x86_64/cpu.h"

pci_device_t g_pci_devices[PCI_MAX_DEVICES];
uint32_t     g_pci_device_count = 0;

static inline uint32_t pci_addr(uint8_t bus, uint8_t dev, uint8_t func, uint8_t offset) {
    return (1U<<31)|((uint32_t)bus<<16)|((uint32_t)dev<<11)|((uint32_t)func<<8)|(offset&0xFC);
}
uint32_t pci_read32(uint8_t b,uint8_t d,uint8_t f,uint8_t o){
    outl(PCI_ADDR_PORT,pci_addr(b,d,f,o)); return inl(PCI_DATA_PORT);
}
uint16_t pci_read16(uint8_t b,uint8_t d,uint8_t f,uint8_t o){
    outl(PCI_ADDR_PORT,pci_addr(b,d,f,o));
    return (uint16_t)(inl(PCI_DATA_PORT)>>((o&2)*8));
}
uint8_t pci_read8(uint8_t b,uint8_t d,uint8_t f,uint8_t o){
    outl(PCI_ADDR_PORT,pci_addr(b,d,f,o));
    return (uint8_t)(inl(PCI_DATA_PORT)>>((o&3)*8));
}
void pci_write32(uint8_t b,uint8_t d,uint8_t f,uint8_t o,uint32_t v){
    outl(PCI_ADDR_PORT,pci_addr(b,d,f,o)); outl(PCI_DATA_PORT,v);
}
void pci_write16(uint8_t b,uint8_t d,uint8_t f,uint8_t o,uint16_t v){
    uint32_t tmp=pci_read32(b,d,f,o&0xFC); uint8_t sh=(o&2)*8;
    pci_write32(b,d,f,o&0xFC,(tmp&~(0xFFFFU<<sh))|((uint32_t)v<<sh));
}
bool pci_bar_is_mmio(uint8_t b,uint8_t d,uint8_t f,uint8_t i){
    return (pci_read32(b,d,f,PCI_BAR0+i*4)&1)==0;
}
bool pci_bar_is_64bit(uint8_t b,uint8_t d,uint8_t f,uint8_t i){
    return (pci_read32(b,d,f,PCI_BAR0+i*4)&0x7)==0x4;
}
uint64_t pci_get_bar(uint8_t b,uint8_t d,uint8_t f,uint8_t i){
    uint8_t o=PCI_BAR0+i*4; uint32_t bar=pci_read32(b,d,f,o);
    if(bar&1) return (uint64_t)(bar&0xFFFFFFFC);
    if(pci_bar_is_64bit(b,d,f,i)){uint32_t hi=pci_read32(b,d,f,o+4);return((uint64_t)hi<<32)|(bar&0xFFFFFFF0);}
    return (uint64_t)(bar&0xFFFFFFF0);
}
uint64_t pci_bar_size(uint8_t b,uint8_t d,uint8_t f,uint8_t i){
    uint8_t o=PCI_BAR0+i*4; uint32_t orig=pci_read32(b,d,f,o);
    pci_write32(b,d,f,o,0xFFFFFFFF); uint32_t mask=pci_read32(b,d,f,o);
    pci_write32(b,d,f,o,orig);
    mask&=(orig&1)?0xFFFFFFFC:0xFFFFFFF0;
    return mask?(uint64_t)(~mask+1):0;
}
void pci_enable_busmaster(uint8_t b,uint8_t d,uint8_t f){
    uint16_t cmd=pci_read16(b,d,f,PCI_COMMAND);
    pci_write16(b,d,f,PCI_COMMAND,cmd|PCI_CMD_BUS_MASTER|PCI_CMD_MEM_SPACE);
}
void pci_enable_mmio(uint8_t b,uint8_t d,uint8_t f){
    uint16_t cmd=pci_read16(b,d,f,PCI_COMMAND);
    pci_write16(b,d,f,PCI_COMMAND,cmd|PCI_CMD_MEM_SPACE);
}
void pci_disable_interrupts(uint8_t b,uint8_t d,uint8_t f){
    uint16_t cmd=pci_read16(b,d,f,PCI_COMMAND);
    pci_write16(b,d,f,PCI_COMMAND,cmd|PCI_CMD_INT_DISABLE);
}
void pci_enumerate(void){
    g_pci_device_count=0;
    for(uint16_t bus=0;bus<256;bus++){
        for(uint8_t dev=0;dev<32;dev++){
            uint16_t vendor=pci_read16((uint8_t)bus,dev,0,PCI_VENDOR_ID);
            if(vendor==PCI_VENDOR_NONE) continue;
            uint8_t hdr=pci_read8((uint8_t)bus,dev,0,PCI_HEADER_TYPE);
            uint8_t max_func=(hdr&0x80)?8:1;
            for(uint8_t func=0;func<max_func;func++){
                vendor=pci_read16((uint8_t)bus,dev,func,PCI_VENDOR_ID);
                if(vendor==PCI_VENDOR_NONE) continue;
                if(g_pci_device_count>=PCI_MAX_DEVICES) return;
                pci_device_t *p=&g_pci_devices[g_pci_device_count++];
                p->bus       =(uint8_t)bus;
                p->dev       =dev; p->func=func;
                p->vendor_id =vendor;
                p->device_id =pci_read16((uint8_t)bus,dev,func,PCI_DEVICE_ID);
                p->class_code=pci_read8 ((uint8_t)bus,dev,func,PCI_CLASS);
                p->subclass  =pci_read8 ((uint8_t)bus,dev,func,PCI_SUBCLASS);
                p->prog_if   =pci_read8 ((uint8_t)bus,dev,func,PCI_PROG_IF);
                p->header_type=pci_read8((uint8_t)bus,dev,func,PCI_HEADER_TYPE);
                p->irq_line  =pci_read8 ((uint8_t)bus,dev,func,PCI_INTERRUPT_LINE);
            }
        }
    }
}
pci_device_t *pci_find_device(uint8_t class_code,uint8_t subclass){
    for(uint32_t i=0;i<g_pci_device_count;i++)
        if(g_pci_devices[i].class_code==class_code&&g_pci_devices[i].subclass==subclass)
            return &g_pci_devices[i];
    return NULL;
}
pci_device_t *pci_find_device_by_id(uint16_t vid,uint16_t did){
    for(uint32_t i=0;i<g_pci_device_count;i++)
        if(g_pci_devices[i].vendor_id==vid&&g_pci_devices[i].device_id==did)
            return &g_pci_devices[i];
    return NULL;
}
pci_device_t *pci_find_device_any_id(uint16_t vid,const uint16_t *ids,uint32_t count){
    for(uint32_t i=0;i<g_pci_device_count;i++){
        if(g_pci_devices[i].vendor_id!=vid) continue;
        for(uint32_t j=0;j<count;j++)
            if(g_pci_devices[i].device_id==ids[j])
                return &g_pci_devices[i];
    }
    return NULL;
}
