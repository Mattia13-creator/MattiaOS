#ifndef MATTIAOS_DRIVER_H
#define MATTIAOS_DRIVER_H

/*
 * kernel/drivers/driver.h — interfaccia base del sottosistema driver
 *
 * Questo file definisce le strutture e le API usate da tutti i driver kernel.
 * Ogni file .c di driver include questo header come prima dipendenza.
 *
 * Contenuto:
 *   §1  Classificazione device      (dev_type_t, device_state_t)
 *   §2  Vtable operazioni           (char_ops_t, block_ops_t, net_ops_t)
 *   §3  Strutture driver_t, device_t
 *   §4  Primitive spinlock IRQ-safe
 *   §5  Helper MMIO
 *   §6  Tabella dispatch IRQ        (g_irq_handlers[256])
 *   §7  API device tree
 *   §8  Punto di ingresso globale   (drivers_init)
 *
 * Dipendenze dirette (sempre disponibili nel kernel):
 *   kernel/include/types.h   — tipi primitivi, spinlock_t, HHDM_OFFSET
 *   kernel/include/errno.h   — codici errore EOK / E*
 *   kernel/arch/x86_64/idt.h — interrupt_frame_t
 *
 * Principi rispettati:
 *   Principio 2 — nessun refcount: device_remove() e' immediato.
 *   Principio 3 — massimo controllo hardware: MMIO helpers espongono
 *                 l'accesso diretto ai registri fisici tramite HHDM.
 */

#include "../include/types.h"
#include "../mm/vmm.h"   /* g_hhdm_offset for mmio helpers */
#include "../include/errno.h"
#include "../arch/x86_64/idt.h"

/* =========================================================================
 * §1 — Classificazione device
 *
 * dev_type_t identifica la categoria funzionale di un device.
 * I valori DEV_TYPE_CHAR / BLOCK / NET corrispondono esattamente a quelli
 * attesi da devfs.h, che include questo header.
 * ========================================================================= */

typedef enum {
    DEV_TYPE_UNKNOWN = 0,
    DEV_TYPE_CHAR,      /* fb0, tty0, ttyS0, null, zero, random, kbd0 */
    DEV_TYPE_BLOCK,     /* sda, sdb, nvme0 — accesso a settori         */
    DEV_TYPE_NET,       /* eth0, wlan0 — network interface             */
    DEV_TYPE_INPUT,     /* ps2kbd, ps2mouse — input events             */
    DEV_TYPE_BUS,       /* nodo virtuale: pci_root, ps2_ctrl           */
    DEV_TYPE_MISC,      /* tutto il resto                              */
} dev_type_t;

typedef enum {
    DEV_STATE_UNINITIALIZED = 0,
    DEV_STATE_PROBING,
    DEV_STATE_ACTIVE,
    DEV_STATE_SUSPENDED,
    DEV_STATE_ERROR,
    DEV_STATE_REMOVED,
} device_state_t;

/* Forward declarations per i tipi ricorsivi */
struct driver;
struct device;

/* =========================================================================
 * §2 — Vtable operazioni
 *
 * Ogni famiglia di device espone una propria vtable.
 * Solo la vtable corrispondente a dev_type_t e' non-NULL in device_t.
 * ========================================================================= */

/* -------------------------------------------------------------------------
 * char_ops_t — character device (fb, tty, null, zero, random)
 *
 * open/close: gestione del fd; possono essere NULL se non serve stato.
 * read/write: trasferimento dati; ritornano bytes trasferiti (>= 0)
 *             oppure codice errore negativo da errno.h.
 * ioctl:      comandi device-specific; arg e' interpretato dal driver.
 * ------------------------------------------------------------------------- */
typedef struct {
    int     (*open) (struct device *dev, uint32_t flags);
    int     (*close)(struct device *dev);
    ssize_t (*read) (struct device *dev, void *buf, size_t count,
                     off_t offset);
    ssize_t (*write)(struct device *dev, const void *buf, size_t count,
                     off_t offset);
    int     (*ioctl)(struct device *dev, uint32_t cmd, uint64_t arg);
} char_ops_t;

/* -------------------------------------------------------------------------
 * block_ops_t — block device (AHCI/SATA, NVMe)
 *
 * lba:   Logical Block Address (0-based, 48-bit per SATA, 64-bit per NVMe).
 * count: numero di settori da trasferire.
 * buf:   buffer in memoria virtuale (HHDM-mappato, allineato a 4 KB per DMA).
 * Ritornano EOK o codice errore negativo.
 *
 * sector_count e sector_size sono campi di stato impostati da init():
 *   sector_size e' 512 per SATA legacy, 4096 per Advanced Format e NVMe.
 * flush(): scarica cache write-back interna (FUA). Puo' essere NULL.
 * ------------------------------------------------------------------------- */
typedef struct {
    int (*read_sectors) (struct device *dev, uint64_t lba, uint32_t count,
                         void *buf);
    int (*write_sectors)(struct device *dev, uint64_t lba, uint32_t count,
                         const void *buf);
    int (*flush)        (struct device *dev);
    int (*ioctl)        (struct device *dev, uint32_t cmd, uint64_t arg);

    uint64_t sector_count;  /* totale settori — impostato da ahci_init/nvme_init */
    uint32_t sector_size;   /* 512 o 4096 bytes per settore                      */
} block_ops_t;

/* -------------------------------------------------------------------------
 * net_ops_t — network device (virtio-net, e1000)
 *
 * send_packet: invia un frame Ethernet grezzo; data punta al frame completo
 *              (header Ethernet incluso), len in bytes.
 * rx_callback: puntatore installato dallo stack ethernet (ethernet_init())
 *              dopo la registrazione del device; il driver lo chiama in IRQ
 *              passando il frame ricevuto.
 * get_mac/set_mac: MAC address in formato 6 byte big-endian.
 * enable_rx/disable_rx: abilitano/disabilitano la ricezione hardware.
 * mtu: Maximum Transmission Unit in bytes (default 1500).
 * ------------------------------------------------------------------------- */
typedef struct {
    int  (*send_packet) (struct device *dev, const void *data, uint16_t len);
    void (*get_mac)     (struct device *dev, uint8_t mac[6]);
    int  (*set_mac)     (struct device *dev, const uint8_t mac[6]);
    void (*enable_rx)   (struct device *dev);
    void (*disable_rx)  (struct device *dev);
    int  (*ioctl)       (struct device *dev, uint32_t cmd, uint64_t arg);

    /* installato da ethernet_init() dopo device_add() — chiamato in IRQ */
    void (*rx_callback) (struct device *dev, const void *data, uint16_t len);

    uint32_t mtu;
} net_ops_t;

/* =========================================================================
 * §3 — driver_t e device_t
 * ========================================================================= */

/* -------------------------------------------------------------------------
 * driver_t — descrittore di una classe di device
 *
 * Una istanza per ogni driver (ahci_driver, e1000_driver, ...).
 * I callback sono chiamati dal sottosistema nell'ordine:
 *
 *   probe()   — il kernel chiede se il driver gestisce questo device.
 *               Esamina dev->driver_data (es. pci_device_t*).
 *               Ritorna EOK (sì) o EINVAL (no).
 *   init()    — alloca risorse, inizializza hardware, registra IRQ e devfs.
 *               Imposta dev->state = DEV_STATE_ACTIVE se va a buon fine.
 *   remove()  — de-inizializza hardware, libera risorse, de-registra IRQ.
 *               Rimozione immediata senza attese (Principio 2).
 *   suspend() — risparmio energetico — stub che ritorna EOK inizialmente.
 *   resume()  — risveglio da suspend.
 *
 * I callback possono essere NULL se l'operazione non e' applicabile.
 * ------------------------------------------------------------------------- */
typedef struct driver {
    char     name[64];     /* "ahci", "e1000", "ps2kbd", "virtio_net", ... */
    uint32_t version;      /* 0x00010000 = v1.0 — (major << 16) | minor    */

    int (*probe)  (struct device *dev);
    int (*init)   (struct device *dev);
    int (*remove) (struct device *dev);
    int (*suspend)(struct device *dev);
    int (*resume) (struct device *dev);

    struct driver *next;   /* lista collegata globale dei driver registrati */
} driver_t;

/* -------------------------------------------------------------------------
 * device_t — nodo nel device tree
 *
 * Ogni device fisico o virtuale ha un nodo in questo albero.
 * I nodi sono collegati in struttura ad albero (parent/children/sibling)
 * e in una lista piatta globale (g_device_root -> next) per enumerazione.
 *
 * NOTA — nessun refcount (Principio 2):
 *   device_remove() rimuove il nodo immediatamente dal tree, senza
 *   attendere che qualcuno smetta di usare il device.
 *
 * lock: spinlock per proteggere state e driver_data da accessi concorrenti.
 *       NON usare per I/O: le operazioni lunghe hanno i propri lock interni.
 * ------------------------------------------------------------------------- */
typedef struct device {
    char           name[64];    /* "sda", "eth0", "fb0", "kbd0", ...        */
    dev_type_t     type;
    device_state_t state;

    driver_t      *driver;      /* driver owner — NULL se non ancora bound  */
    void          *driver_data; /* stato privato del driver (cast nel .c)   */

    /* vtable — una sola e' non-NULL in base a type */
    char_ops_t    *char_ops;
    block_ops_t   *block_ops;
    net_ops_t     *net_ops;

    /* albero dei device */
    struct device *parent;      /* NULL per i figli di g_device_root        */
    struct device *children;    /* primo figlio                             */
    struct device *sibling;     /* prossimo fratello nella lista del parent */
    struct device *next;        /* lista piatta globale                     */

    spinlock_t     lock;        /* protezione accesso concorrente a state   */
} device_t;

/* =========================================================================
 * §4 — Primitive spinlock IRQ-safe
 *
 * Tutte le primitive (spinlock_acquire, spinlock_release, irq_save,
 * irq_restore, spinlock_irqsave, spinlock_irqrestore) sono definite
 * come static inline in kernel/include/types.h, dove spinlock_t vive.
 * ========================================================================= */

/* =========================================================================
 * §5 — Helper MMIO
 *
 * Tutta la memoria fisica e' mappata linearmente nell'HHDM (Higher Half
 * Direct Map) a partire da HHDM_OFFSET (definito in types.h come
 * 0xFFFF800000000000).
 *
 * I driver ottengono l'indirizzo virtuale di un indirizzo fisico con
 * phys_to_virt() o mmio_base(), poi leggono/scrivono con mmio_readXX/mmio_writeXX.
 *
 * Il qualificatore volatile impedisce al compilatore di riordinare o
 * eliminare accessi a registri hardware.
 * mmio_barrier() aggiunge una barriera esplicita per sequenze di write
 * che devono essere completate in ordine prima di continuare.
 *
 * Uso tipico (AHCI HBA memory):
 *   uint32_t cap = mmio_read32(hba_phys + HBA_CAP);
 *   mmio_write32(hba_phys + HBA_GHC, GHC_RESET);
 *   mmio_barrier();
 * ========================================================================= */

/* virt_to_phys_hhdm — inverso di phys_to_virt (usa g_hhdm_offset) */
static inline uint64_t virt_to_phys_hhdm(void *virt) {
    return (uint64_t)virt - g_hhdm_offset;
}

/* Puntatore base su cui fare accesso a struct MMIO (zero-overhead cast) */
static inline void *mmio_base(uint64_t phys) {
    return (void *)(phys + g_hhdm_offset);
}

static inline uint8_t mmio_read8(uint64_t phys) {
    return *(volatile uint8_t  *)(phys + g_hhdm_offset);
}

static inline uint16_t mmio_read16(uint64_t phys) {
    return *(volatile uint16_t *)(phys + g_hhdm_offset);
}

static inline uint32_t mmio_read32(uint64_t phys) {
    return *(volatile uint32_t *)(phys + g_hhdm_offset);
}

static inline uint64_t mmio_read64(uint64_t phys) {
    return *(volatile uint64_t *)(phys + g_hhdm_offset);
}

static inline void mmio_write8(uint64_t phys, uint8_t val) {
    *(volatile uint8_t  *)(phys + g_hhdm_offset) = val;
}

static inline void mmio_write16(uint64_t phys, uint16_t val) {
    *(volatile uint16_t *)(phys + g_hhdm_offset) = val;
}

static inline void mmio_write32(uint64_t phys, uint32_t val) {
    *(volatile uint32_t *)(phys + g_hhdm_offset) = val;
}

static inline void mmio_write64(uint64_t phys, uint64_t val) {
    *(volatile uint64_t *)(phys + g_hhdm_offset) = val;
}

/*
 * mmio_barrier — memory barrier compilatore.
 *   Garantisce che gli accessi scritti prima non vengano riordinati
 *   dopo questa istruzione dal compilatore.
 *   Per barriera hardware completa usare MFENCE (necessaria su x86 SMP
 *   per store-load ordering, non richiesta su UP o per MMIO con UC pages).
 */
static inline void mmio_barrier(void) {
    __asm__ __volatile__("" ::: "memory");
}

/* =========================================================================
 * §6 — Tabella dispatch IRQ
 *
 * g_irq_handlers[vector] e' chiamato da isr_handler() (idt.c) ad ogni
 * interrupt hardware. Dopo la chiamata, isr_handler chiama lapic_eoi().
 *
 * Mapping vettori — LAPIC remapped, base 0x20 (vettore = IRQ + 0x20):
 *   0x20  APIC timer       (riservato — gestito internamente da apic.c)
 *   0x21  PS/2 keyboard    IRQ1
 *   0x28  RTC              IRQ8
 *   0x2A  NVMe             IRQ10 (o MSI dinamico)
 *   0x2B  AHCI             IRQ11 (o MSI dinamico)
 *   0x2C  PS/2 mouse       IRQ12
 *   0x2E  e1000/virtio-net IRQ14 (o MSI dinamico)
 *
 * Driver con MSI registrano il vettore assegnato dinamicamente dal PCI layer.
 * ========================================================================= */

typedef void (*irq_handler_t)(interrupt_frame_t *frame);

/* Tabella globale — definita e inizializzata in irq.c */
extern irq_handler_t g_irq_handlers[256];

/*
 * register_irq_handler — installa handler per il vettore vector.
 *   Sovrascrive senza avviso il precedente handler.
 *   Da chiamare in driver->init(), prima di abilitare gli IRQ sul device.
 */
void register_irq_handler(uint8_t vector, irq_handler_t handler);

/*
 * unregister_irq_handler — imposta g_irq_handlers[vector] = NULL.
 *   Da chiamare in driver->remove().
 */
void unregister_irq_handler(uint8_t vector);

/* =========================================================================
 * §7 — API device tree
 *
 * Il device tree e' una gerarchia di device_t con radice g_device_root.
 * Ogni device e' anche in una lista piatta per l'enumerazione O(n).
 *
 * NOTA sulle dipendenze:
 *   device_alloc() usa kmalloc() da slab.h.
 *   I file .c che chiamano device_alloc includono slab.h separatamente.
 *   Questo header NON include slab.h per evitare dipendenze circolari.
 * ========================================================================= */

/* Radice globale del device tree — inizializzata da drivers_init() */
extern device_t *g_device_root;

/*
 * device_alloc — alloca e azzera un nodo device_t tramite kmalloc.
 *   name: stringa identificativa (copiata, max 63 caratteri).
 *   type: classificazione funzionale.
 *   Ritorna puntatore al nuovo device_t, oppure NULL se OOM.
 */
device_t *device_alloc(const char *name, dev_type_t type);

/*
 * device_add — inserisce dev nel device tree come figlio di parent.
 *   Se parent e' NULL, dev e' figlio di g_device_root.
 *   Inserisce anche nella lista piatta globale.
 *   Se dev->driver != NULL chiama probe(); se EOK chiama init().
 */
void device_add(device_t *dev, device_t *parent);

/*
 * device_remove — rimuove dev dal device tree e dalla lista piatta.
 *   Se driver attivo chiama driver->remove(dev).
 *   Rimozione immediata, senza refcount (Principio 2).
 */
void device_remove(device_t *dev);

/*
 * device_find_by_name — ricerca lineare per nome esatto.
 *   Ritorna il primo match oppure NULL.
 */
device_t *device_find_by_name(const char *name);

/*
 * device_find_by_type — ritorna il primo device con il tipo richiesto.
 *   Utile per trovare il primo disco (DEV_TYPE_BLOCK), la prima NIC, ecc.
 */
device_t *device_find_by_type(dev_type_t type);

/* driver_register — registra un driver_t nella lista globale.
 * Chiamata da ciascun modulo driver durante drivers_init().
 */
void driver_register(driver_t *drv);

/* =========================================================================
 * §8 — Inizializzazione globale del sottosistema driver
 *
 * drivers_init() e' chiamata da kernel_main() dopo:
 *   acpi_init()       — MADT, HPET, MCFG noti
 *   pci_enumerate()   — g_pci_devices[] popolato
 *
 * Sequenza interna:
 *   1. Azzera g_irq_handlers[]
 *   2. Inizializza g_device_root (nodo virtuale "root")
 *   3. fb_init()          — framebuffer GOP    → /dev/fb0
 *   4. ps2_init()         — PS/2 controller   → /dev/kbd0, /dev/mouse0
 *   5. ahci_init()        — SATA              → /dev/sda, /dev/sdb, ...
 *   6. nvme_init()        — NVMe              → /dev/nvme0, ...
 *   7. virtio_net_init()  — virtio-net QEMU   → /dev/eth0
 *   8. e1000_init()       — Intel e1000       → /dev/eth0
 * ========================================================================= */

void drivers_init(void);

#endif /* MATTIAOS_DRIVER_H */
