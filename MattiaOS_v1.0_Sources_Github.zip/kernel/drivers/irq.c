#include "driver.h"
#include "../arch/x86_64/cpu.h"
#include "../mm/slab.h"

/*
 * irq.c — IRQ dispatch table + gestione device tree.
 *
 * Implementa le funzioni non-inline dichiarate in driver.h:
 *   register_irq_handler()    — installa un handler per un vettore
 *   unregister_irq_handler()  — rimuove un handler
 *   device_alloc()            — alloca un nodo device_t
 *   device_add()              — inserisce nel device tree
 *   device_remove()           — rimuove dal device tree (immediato, no refcount)
 *   device_find_by_name()     — ricerca per nome
 *   device_find_by_type()     — ricerca per tipo
 *   drivers_init()            — sequenza di init hardware
 */

/* =========================================================================
 * IRQ dispatch table
 * ========================================================================= */

irq_handler_t g_irq_handlers[256] = { NULL };

static spinlock_t s_irq_lock = {0};

/*
 * register_irq_handler — installa o sostituisce l'handler per il vettore.
 * Usa spinlock_irqsave: puo' essere chiamata a runtime con IRQ attivi.
 */
void register_irq_handler(uint8_t vector, irq_handler_t handler) {
    uint64_t flags = spinlock_irqsave(&s_irq_lock);
    g_irq_handlers[vector] = handler;
    spinlock_irqrestore(&s_irq_lock, flags);
}

/*
 * unregister_irq_handler — rimuove l'handler (imposta NULL).
 * Da chiamare in driver->remove() prima di liberare le risorse del driver.
 */
void unregister_irq_handler(uint8_t vector) {
    uint64_t flags = spinlock_irqsave(&s_irq_lock);
    g_irq_handlers[vector] = NULL;
    spinlock_irqrestore(&s_irq_lock, flags);
}

/* =========================================================================
 * Device tree
 * ========================================================================= */

device_t       *g_device_root = NULL;
static driver_t *s_driver_list = NULL;

static spinlock_t s_driver_lock = {0};
static spinlock_t s_device_lock = {0};

/*
 * device_alloc — alloca e azzera un device_t tramite kzalloc.
 * Imposta name (fino a 63 caratteri) e type.
 * Ritorna NULL se OOM.
 */
device_t *device_alloc(const char *name, dev_type_t type) {
    device_t *dev = (device_t *)kzalloc(sizeof(device_t));
    if (!dev) return NULL;

    /* Copia name manuale per evitare dipendenza da libc */
    uint32_t i = 0;
    while (name[i] && i < sizeof(dev->name) - 1) {
        dev->name[i] = name[i];
        i++;
    }
    dev->name[i] = '\0';

    dev->type  = type;
    dev->state = DEV_STATE_UNINITIALIZED;
    dev->lock.lock = 0;
    return dev;
}

/*
 * device_add — inserisce dev nel device tree come figlio di parent.
 * Se parent e' NULL usa g_device_root come parent.
 * Inserisce anche in coda alla lista piatta (g_device_root->next chain).
 * Se dev->driver != NULL:
 *   chiama probe(); se EOK chiama init() e imposta state = ACTIVE.
 */
void device_add(device_t *dev, device_t *parent) {
    if (!dev) return;

    uint64_t flags = spinlock_irqsave(&s_device_lock);

    device_t *p = parent ? parent : g_device_root;

    /* Inserimento nell'albero (prepend alla lista figli del parent) */
    if (p) {
        dev->sibling = p->children;
        p->children  = dev;
        dev->parent  = p;
    }

    /* Append alla lista piatta globale */
    if (g_device_root) {
        device_t *tail = g_device_root;
        while (tail->next) tail = tail->next;
        tail->next = dev;
    }
    dev->next = NULL;

    spinlock_irqrestore(&s_device_lock, flags);

    /* Probe + init fuori dal lock (possono fare I/O) */
    if (dev->driver) {
        dev->state = DEV_STATE_PROBING;
        int probe_result = EOK;
        if (dev->driver->probe)
            probe_result = dev->driver->probe(dev);

        if (probe_result == EOK) {
            int init_result = EOK;
            if (dev->driver->init)
                init_result = dev->driver->init(dev);
            dev->state = (init_result == EOK) ? DEV_STATE_ACTIVE
                                               : DEV_STATE_ERROR;
        } else {
            dev->state = DEV_STATE_ERROR;
        }
    }
}

/*
 * device_remove — rimuove dev dal device tree e dalla lista piatta.
 * Chiama driver->remove() se il device e' attivo.
 * Rimozione immediata, senza refcount (Principio 2).
 * NON libera la memoria: e' responsabilita' del driver che ha allocato dev.
 */
void device_remove(device_t *dev) {
    if (!dev) return;

    /* remove() fuori dal lock */
    if (dev->driver && dev->driver->remove && dev->state == DEV_STATE_ACTIVE)
        dev->driver->remove(dev);
    dev->state = DEV_STATE_REMOVED;

    uint64_t flags = spinlock_irqsave(&s_device_lock);

    /* Rimuovi dalla lista piatta */
    if (g_device_root) {
        device_t *cur  = g_device_root;
        device_t *prev = NULL;
        while (cur) {
            if (cur == dev) {
                if (prev) prev->next = cur->next;
                else       g_device_root   = cur->next;
                cur->next = NULL;
                break;
            }
            prev = cur;
            cur  = cur->next;
        }
    }

    /* Rimuovi dalla lista figli del parent */
    if (dev->parent) {
        device_t *cur  = dev->parent->children;
        device_t *prev = NULL;
        while (cur) {
            if (cur == dev) {
                if (prev) prev->sibling = cur->sibling;
                else dev->parent->children = cur->sibling;
                cur->sibling = NULL;
                break;
            }
            prev = cur;
            cur  = cur->sibling;
        }
    }
    dev->parent = NULL;

    spinlock_irqrestore(&s_device_lock, flags);
}

/*
 * device_find_by_name — ricerca lineare nella lista piatta per nome esatto.
 * Ritorna il primo match oppure NULL.
 */
device_t *device_find_by_name(const char *name) {
    device_t *cur = g_device_root;
    while (cur) {
        uint32_t i = 0;
        while (cur->name[i] && name[i] && cur->name[i] == name[i]) i++;
        if (cur->name[i] == '\0' && name[i] == '\0') return cur;
        cur = cur->next;
    }
    return NULL;
}

/*
 * device_find_by_type — ritorna il primo device con il tipo richiesto.
 */
device_t *device_find_by_type(dev_type_t type) {
    device_t *cur = g_device_root;
    while (cur) {
        if (cur->type == type) return cur;
        cur = cur->next;
    }
    return NULL;
}

/* =========================================================================
 * Driver registry (opzionale — usato per future operazioni di bind/unbind)
 * ========================================================================= */

void driver_register(driver_t *drv) {
    if (!drv) return;
    uint64_t flags = spinlock_irqsave(&s_driver_lock);
    drv->next     = s_driver_list;
    s_driver_list = drv;
    spinlock_irqrestore(&s_driver_lock, flags);
}

/* =========================================================================
 * drivers_init — sequenza di init hardware (chiamata da kernel_main)
 *
 * Precondizioni:
 *   slab_init() gia' completato (kmalloc disponibile)
 *   acpi_init() gia' completato (MADT/HPET noti)
 *   pci_enumerate() gia' completato (g_pci_devices[] popolato)
 * ========================================================================= */

extern void fb_init(void);
extern void ps2_init(void);
extern void keyboard_init(void);
/* Drivers storage */
#include "storage/ahci.h"
#include "storage/nvme.h"
/* Drivers rete */
#include "net/virtio_net.h"
#include "net/e1000.h"

void drivers_init(void) {
    /* Azzeramento tabella IRQ */
    for (int i = 0; i < 256; i++) g_irq_handlers[i] = NULL;

    /* Nodo radice virtuale del device tree */
    g_device_root = (device_t *)kzalloc(sizeof(device_t));
    if (!g_device_root)
        __asm__ __volatile__("cli; hlt");   /* OOM fatale */

    const char *root_name = "root";
    for (uint32_t i = 0; i < sizeof(g_device_root->name) - 1 && root_name[i]; i++)
        g_device_root->name[i] = root_name[i];
    g_device_root->type  = DEV_TYPE_BUS;
    g_device_root->state = DEV_STATE_ACTIVE;

    fb_init();          /* Framebuffer GOP → /dev/fb0               */
    ps2_init();         /* PS/2 controller: IRQ1 (kbd) + IRQ12 (mouse) */
    keyboard_init();    /* Scancode → keycode layer                 */
    ahci_init();        /* SATA block devices → /dev/sda, sdb, ...  */
    nvme_init();        /* NVMe block devices → /dev/nvme0, ...     */
    virtio_net_init();  /* virtio-net (QEMU) → /dev/eth0            */
    e1000_init();       /* Intel e1000 (hw) → /dev/eth0 o /dev/eth1 */
}
