#include "virtio_net.h"
#include "../pci.h"
#include "../../mm/pmm.h"
#include "../../mm/vmm.h"
#include "../../mm/slab.h"
#include "../../fs/devfs.h"
#include "../../include/errno.h"
#include "../../arch/x86_64/cpu.h"

/*
 * virtio_net.c — driver VirtIO-Net legacy PCI per MattiaOS
 *
 * Implementa:
 *   - Rilevamento device PCI (vendor 0x1AF4, device 0x1000)
 *   - Reset e inizializzazione VirtIO legacy
 *   - Negoziazione feature: VIRTIO_NET_F_MAC
 *   - Setup vring RX (queue 0) e TX (queue 1)
 *   - Pre-popola RX avail ring con VNET_VRING_SIZE buffer
 *   - TX: copia header+frame nel buffer DMA, pubblica descriptor,
 *         notifica host, attende completamento (polled — no IRQ per TX)
 *   - IRQ handler per RX: drain used ring, chiama rx_callback se installato
 *   - Registrazione /dev/eth0 in devfs e device tree
 *
 * I/O ports (BAR0, legacy PCI):
 *   Accesso tramite inb/outb/inw/outw dalla cpu.h del progetto.
 *
 * DMA: tutta la memoria per le vring e i buffer viene allocata con PMM
 * (pagine fisiche contigue) e acceduta tramite HHDM.
 *
 * Vring layout (per queue):
 *   Una singola allocazione PMM sufficientemente grande contiene:
 *     [0]             descriptor table (16 * VNET_VRING_SIZE byte)
 *     [desc_size]     available ring (6 + 2*VNET_VRING_SIZE byte)
 *     [PAGE_ALIGN]    used ring (6 + 8*VNET_VRING_SIZE byte)
 *   L'indirizzo fisico della pagina base / 4096 viene scritto in QUEUE_PFN.
 */

/* =========================================================================
 * Stato globale
 * ========================================================================= */

static vnet_state_t s_vnet;
static bool         s_initialized = false;

static devnode_t    s_dev_node   = {0};
static device_t     s_device     = {0};
static net_ops_t    s_net_ops    = {0};

/* =========================================================================
 * Helper I/O port (usa le funzioni di cpu.h)
 * ========================================================================= */

static inline uint8_t  vio_in8 (uint16_t reg) { return inb(s_vnet.io_base + reg); }
static inline uint16_t vio_in16(uint16_t reg)  { return inw(s_vnet.io_base + reg); }
static inline uint32_t vio_in32(uint16_t reg)  { return inl(s_vnet.io_base + reg); }
static inline void vio_out8 (uint16_t reg, uint8_t  v) { outb(s_vnet.io_base + reg, v); }
static inline void vio_out16(uint16_t reg, uint16_t v) { outw(s_vnet.io_base + reg, v); }
static inline void vio_out32(uint16_t reg, uint32_t v) { outl(s_vnet.io_base + reg, v); }

/* =========================================================================
 * Helper: memset/memcpy minimali
 * ========================================================================= */

static inline void *vn_memset(void *d, int c, size_t n) {
    uint8_t *p = (uint8_t *)d; while (n--) *p++ = (uint8_t)c; return d;
}
static inline void *vn_memcpy(void *d, const void *s, size_t n) {
    uint8_t *dd = (uint8_t *)d; const uint8_t *ss = (const uint8_t *)s;
    while (n--) *dd++ = *ss++;
    return d;
}

/* =========================================================================
 * Calcolo dimensione vring e layout in memoria
 *
 * Secondo la spec VirtIO legacy:
 *   vring_size(N) = ALIGN(sizeof(vring_desc)*N + sizeof(uint16_t)*(3+N), PAGE)
 *                 + sizeof(uint16_t)*3 + sizeof(vring_used_elem)*N
 *
 * Per semplicità allochiamo 2 pagine per queue:
 *   Pagina 0: descriptor table + available ring
 *   Pagina 1: used ring (allineata a PAGE_SIZE come richiesto dalla spec)
 * ========================================================================= */

#define VRING_DESC_TABLE_SIZE  (sizeof(vring_desc_t)  * VNET_VRING_SIZE)
#define VRING_AVAIL_SIZE       (6 + sizeof(uint16_t)  * VNET_VRING_SIZE)
#define VRING_USED_SIZE        (6 + sizeof(vring_used_elem_t) * VNET_VRING_SIZE)

/* Numero di pagine per una singola vring: desc+avail nella prima,
 * used (allineato a pagina) nella seconda. */
#define VRING_PAGES   2

static bool vring_alloc(vnet_queue_t *q) {
    uint64_t base = pmm_alloc_frames(VRING_PAGES);
    if (!base) return false;
    vn_memset(phys_to_virt(base), 0, VRING_PAGES * PAGE_SIZE);

    q->desc_phys = base;
    q->desc  = (vring_desc_t  *)phys_to_virt(base);
    q->avail = (vring_avail_t *)(phys_to_virt(base) + VRING_DESC_TABLE_SIZE);
    /* Used ring: seconda pagina (offset PAGE_SIZE dalla base) */
    q->used  = (vring_used_t  *)phys_to_virt(base + PAGE_SIZE);

    /* Costruisce catena libera dei descriptor */
    for (uint16_t i = 0; i < VNET_VRING_SIZE - 1; i++)
        q->desc[i].next = i + 1;
    q->desc[VNET_VRING_SIZE - 1].next = 0;

    q->free_head = 0;
    q->num_free  = VNET_VRING_SIZE;
    q->last_used = 0;
    return true;
}

/* =========================================================================
 * Setup singola virtqueue nel controller
 * ========================================================================= */

static bool setup_queue(uint16_t qidx, vnet_queue_t *q) {
    vio_out16(VIRTIO_PCI_QUEUE_SEL, qidx);
    uint16_t qsize = vio_in16(VIRTIO_PCI_QUEUE_SIZE);
    if (qsize == 0) return false;
    /* Usiamo VNET_VRING_SIZE, che deve essere ≤ qsize */
    if (VNET_VRING_SIZE > qsize) return false;

    if (!vring_alloc(q)) return false;

    /* Scrivi indirizzo fisico / PAGE_SIZE nel registro QUEUE_PFN */
    vio_out32(VIRTIO_PCI_QUEUE_PFN, (uint32_t)(q->desc_phys / PAGE_SIZE));
    return true;
}

/* =========================================================================
 * Alloca un descriptor libero dalla catena
 * ========================================================================= */

static int alloc_desc(vnet_queue_t *q) {
    if (q->num_free == 0) return -1;
    int idx = q->free_head;
    q->free_head = q->desc[idx].next;
    q->num_free--;
    return idx;
}

static void free_desc(vnet_queue_t *q, uint16_t idx) {
    q->desc[idx].flags = 0;
    q->desc[idx].next  = q->free_head;
    q->free_head = idx;
    q->num_free++;
}

/* =========================================================================
 * Pre-popola RX queue con buffer liberi
 *
 * Alloca VNET_VRING_SIZE buffer da VNET_BUF_SIZE byte (PMM) e pubblicali
 * tutti nella avail ring.  Il device potrà riempirli con pacchetti in arrivo.
 * ========================================================================= */

#define VNET_RX_BUF_PAGES  \
    ((VNET_BUF_SIZE * VNET_VRING_SIZE + PAGE_SIZE - 1) / PAGE_SIZE)

static bool rx_queue_populate(void) {
    /* Alloca tutti i buffer RX fisicamente contigui */
    s_vnet.rx_bufs_phys = pmm_alloc_frames(VNET_RX_BUF_PAGES);
    if (!s_vnet.rx_bufs_phys) return false;
    vn_memset(phys_to_virt(s_vnet.rx_bufs_phys), 0,
              VNET_RX_BUF_PAGES * PAGE_SIZE);

    vnet_queue_t *q = &s_vnet.rx_q;

    for (uint16_t i = 0; i < VNET_VRING_SIZE; i++) {
        int d = alloc_desc(q);
        if (d < 0) break;

        uint64_t buf_phys = s_vnet.rx_bufs_phys + (uint64_t)i * VNET_BUF_SIZE;
        q->desc[d].addr  = buf_phys;
        q->desc[d].len   = VNET_BUF_SIZE;
        q->desc[d].flags = VRING_DESC_F_WRITE;  /* device scrive */
        q->desc[d].next  = 0;

        /* Pubblica nella avail ring */
        uint16_t avail_idx = q->avail->idx % VNET_VRING_SIZE;
        q->avail->ring[avail_idx] = (uint16_t)d;
        /* Barriera prima di incrementare avail->idx */
        __asm__ __volatile__("" ::: "memory");
        q->avail->idx++;
    }

    /* Notifica host: queue 0 (RX) ha buffer disponibili */
    __asm__ __volatile__("" ::: "memory");
    vio_out16(VIRTIO_PCI_QUEUE_NOTIFY, 0);
    return true;
}

/* =========================================================================
 * IRQ handler — riceve pacchetti dalla RX used ring
 * ========================================================================= */

static void vnet_irq_handler(interrupt_frame_t *frame) {
    (void)frame;

    /* Leggi e azzera ISR (operazione obbligatoria per ACK IRQ VirtIO) */
    uint8_t isr = vio_in8(VIRTIO_PCI_ISR);
    if (!(isr & VIRTIO_ISR_QUEUE)) return;

    vnet_queue_t *q = &s_vnet.rx_q;

    /* Barriera lettura prima di ispezionare used ring */
    __asm__ __volatile__("" ::: "memory");

    while (q->last_used != q->used->idx) {
        uint16_t idx     = q->last_used % VNET_VRING_SIZE;
        uint32_t desc_id = q->used->ring[idx].id;
        uint32_t pkt_len = q->used->ring[idx].len;
        q->last_used++;

        if (pkt_len > VIRTIO_NET_HDR_SIZE) {
            uint8_t *buf = (uint8_t *)phys_to_virt(q->desc[desc_id].addr);
            /* Salta il virtio_net_hdr — passa solo il frame Ethernet */
            const uint8_t *frame_data = buf + VIRTIO_NET_HDR_SIZE;
            uint32_t       frame_len  = pkt_len - VIRTIO_NET_HDR_SIZE;

            /* Chiama il callback dello stack ethernet se installato */
            if (s_net_ops.rx_callback)
                s_net_ops.rx_callback(&s_device, frame_data,
                                      (uint16_t)frame_len);
        }

        /* Re-pubblica il descriptor nella avail ring */
        uint16_t avail_idx = q->avail->idx % VNET_VRING_SIZE;
        q->avail->ring[avail_idx] = (uint16_t)desc_id;
        __asm__ __volatile__("" ::: "memory");
        q->avail->idx++;
    }

    /* Notifica host: RX queue ha nuovi buffer disponibili */
    __asm__ __volatile__("" ::: "memory");
    vio_out16(VIRTIO_PCI_QUEUE_NOTIFY, 0);
}

/* =========================================================================
 * net_ops_t callbacks
 * ========================================================================= */

static int vnet_send(device_t *dev, const void *data, uint16_t len) {
    (void)dev;
    if (!s_initialized || !data || len == 0 || len > 1514) return -EINVAL;

    /* TX buffer: virtio_net_hdr (12 B) + frame (≤1514 B) */
    uint64_t flags = spinlock_irqsave(&s_vnet.tx_lock);

    vnet_queue_t *q = &s_vnet.tx_q;

    /* Descriptor 0: virtio_net_hdr (device legge) */
    int d0 = alloc_desc(q);
    if (d0 < 0) { spinlock_irqrestore(&s_vnet.tx_lock, flags); return -EBUSY; }

    /* Scrivi hdr nel buffer TX */
    virtio_net_hdr_t *hdr = (virtio_net_hdr_t *)phys_to_virt(s_vnet.tx_buf_phys);
    vn_memset(hdr, 0, VIRTIO_NET_HDR_SIZE);

    /* Scrivi frame subito dopo l'hdr */
    vn_memcpy((uint8_t *)hdr + VIRTIO_NET_HDR_SIZE, data, len);

    q->desc[d0].addr  = s_vnet.tx_buf_phys;
    q->desc[d0].len   = VIRTIO_NET_HDR_SIZE + len;
    q->desc[d0].flags = 0;    /* device legge */
    q->desc[d0].next  = 0;

    /* Pubblica in avail ring TX */
    uint16_t avail_idx = q->avail->idx % VNET_VRING_SIZE;
    q->avail->ring[avail_idx] = (uint16_t)d0;
    __asm__ __volatile__("" ::: "memory");
    q->avail->idx++;

    /* Notifica host: queue 1 (TX) ha un pacchetto */
    __asm__ __volatile__("" ::: "memory");
    vio_out16(VIRTIO_PCI_QUEUE_NOTIFY, 1);

    /* Attendi completamento (polled sulla TX used ring) */
    for (uint32_t i = 0; i < 500000; i++) {
        __asm__ __volatile__("" ::: "memory");
        if (q->used->idx != q->last_used) break;
        __asm__ __volatile__("pause");
    }

    /* Drena TX used ring e libera descriptor */
    __asm__ __volatile__("" ::: "memory");
    while (q->last_used != q->used->idx) {
        uint16_t uidx = q->last_used % VNET_VRING_SIZE;
        uint16_t did  = (uint16_t)q->used->ring[uidx].id;
        free_desc(q, did);
        q->last_used++;
    }

    spinlock_irqrestore(&s_vnet.tx_lock, flags);
    return EOK;
}

static void vnet_get_mac(device_t *dev, uint8_t mac[6]) {
    (void)dev;
    for (int i = 0; i < 6; i++) mac[i] = s_vnet.mac[i];
}

static int vnet_set_mac(device_t *dev, const uint8_t mac[6]) {
    (void)dev; (void)mac;
    return -EPERM;  /* MAC non modificabile su VirtIO legacy */
}

static void vnet_enable_rx(device_t *dev) {
    (void)dev;
    /* IRQ già abilitato in init — notifica host che i buffer sono pronti */
    __asm__ __volatile__("" ::: "memory");
    vio_out16(VIRTIO_PCI_QUEUE_NOTIFY, 0);
}

static void vnet_disable_rx(device_t *dev) {
    (void)dev;
    /* Non supportato su VirtIO legacy senza riconfigurare le feature */
}

/* =========================================================================
 * VFS ops per /dev/eth0 (accesso grezzo ai frame Ethernet)
 * ========================================================================= */

static ssize_t vnet_vfs_write(vnode_t *node, const void *buf,
                               size_t count, off_t offset) {
    (void)node; (void)offset;
    if (count > 1514) return -EINVAL;
    int r = vnet_send(&s_device, buf, (uint16_t)count);
    return r == EOK ? (ssize_t)count : (ssize_t)r;
}

static int vnet_vfs_ioctl(vnode_t *node, uint64_t req, void *arg) {
    (void)node;
    /* SIOCGIFHWADDR — restituisce MAC address */
    if (req == 0x8927 && arg) {
        vn_memcpy(arg, s_vnet.mac, 6);
        return EOK;
    }
    return -EINVAL;
}

static vfs_ops_t s_vnet_vfs_ops = {
    .open    = NULL, .close   = NULL,
    .read    = NULL, .write   = vnet_vfs_write,
    .ioctl   = vnet_vfs_ioctl,
    .readdir = NULL, .stat    = NULL,
    .create  = NULL, .mkdir   = NULL,
    .unlink  = NULL, .mmap    = NULL,
};

/* =========================================================================
 * virtio_net_init — punto di ingresso del driver
 * ========================================================================= */

void virtio_net_init(void) {
    /* 1 — Cerca device PCI VirtIO-Net */
    uint16_t dev_ids[] = { PCI_DEV_VIRTIO_NET_LEGACY, PCI_DEV_VIRTIO_NET_MODERN };
    pci_device_t *pci = pci_find_device_any_id(PCI_VENDOR_VIRTIO, dev_ids, 2);
    if (!pci) {
        serial_puts("[VNET] nessun device VirtIO-Net trovato\n");
        return;
    }

    pci_enable_busmaster(pci->bus, pci->dev, pci->func);

    /* 2 — Leggi BAR0 (I/O port base per legacy device) */
    uint64_t bar0 = pci_get_bar(pci->bus, pci->dev, pci->func, 0);
    if (!bar0 || (bar0 & 0x1) == 0) {
        serial_puts("[VNET] BAR0 non e' I/O port\n");
        return;
    }
    s_vnet.io_base = (uint16_t)(bar0 & 0xFFFC);  /* strip flag bits */

    /* 3 — IRQ vector */
    s_vnet.irq_vector = pci->irq_line + 0x20;

    /* 4 — Reset device */
    vio_out8(VIRTIO_PCI_STATUS, VIRTIO_STATUS_RESET);
    for (volatile int i = 0; i < 10000; i++) __asm__ __volatile__("pause");

    /* 5 — Sequenza di inizializzazione VirtIO */
    vio_out8(VIRTIO_PCI_STATUS, VIRTIO_STATUS_ACK);
    vio_out8(VIRTIO_PCI_STATUS, VIRTIO_STATUS_ACK | VIRTIO_STATUS_DRIVER);

    /* 6 — Negozia feature: richiedi solo VIRTIO_NET_F_MAC */
    uint32_t host_features = vio_in32(VIRTIO_PCI_HOST_FEATURES);
    uint32_t driver_features = host_features & VIRTIO_NET_F_MAC;
    vio_out32(VIRTIO_PCI_GUEST_FEATURES, driver_features);

    /* 7 — Leggi MAC address dalla config (offset 0x14) */
    for (int i = 0; i < 6; i++)
        s_vnet.mac[i] = vio_in8((uint16_t)(VIRTIO_PCI_NET_MAC + i));

    /* 8 — Setup queue RX (0) e TX (1) */
    if (!setup_queue(0, &s_vnet.rx_q)) {
        serial_puts("[VNET] setup RX queue fallito\n");
        vio_out8(VIRTIO_PCI_STATUS, VIRTIO_STATUS_FAILED);
        return;
    }
    if (!setup_queue(1, &s_vnet.tx_q)) {
        serial_puts("[VNET] setup TX queue fallito\n");
        vio_out8(VIRTIO_PCI_STATUS, VIRTIO_STATUS_FAILED);
        return;
    }

    /* 9 — Alloca buffer TX */
    s_vnet.tx_buf_phys = pmm_alloc_frame();
    if (!s_vnet.tx_buf_phys) {
        serial_puts("[VNET] OOM TX buffer\n");
        vio_out8(VIRTIO_PCI_STATUS, VIRTIO_STATUS_FAILED);
        return;
    }

    /* 10 — Pre-popola RX avail ring */
    if (!rx_queue_populate()) {
        serial_puts("[VNET] OOM RX buffers\n");
        vio_out8(VIRTIO_PCI_STATUS, VIRTIO_STATUS_FAILED);
        return;
    }

    /* 11 — Installa IRQ handler */
    register_irq_handler(s_vnet.irq_vector, vnet_irq_handler);

    /* 12 — Driver OK */
    vio_out8(VIRTIO_PCI_STATUS,
             VIRTIO_STATUS_ACK | VIRTIO_STATUS_DRIVER | VIRTIO_STATUS_DRIVER_OK);

    /* 13 — Registra /dev/eth0 in devfs */
    const char *name = "eth0";
    uint32_t i = 0;
    while (name[i] && i < sizeof(s_dev_node.name) - 1) {
        s_dev_node.name[i] = name[i]; i++;
    }
    s_dev_node.name[i]     = '\0';
    s_dev_node.type        = DEV_TYPE_NET;
    s_dev_node.ops         = &s_vnet_vfs_ops;
    s_dev_node.driver_data = &s_vnet;
    devfs_register(&s_dev_node);

    /* 14 — net_ops_t */
    s_net_ops.send_packet  = vnet_send;
    s_net_ops.get_mac      = vnet_get_mac;
    s_net_ops.set_mac      = vnet_set_mac;
    s_net_ops.enable_rx    = vnet_enable_rx;
    s_net_ops.disable_rx   = vnet_disable_rx;
    s_net_ops.ioctl        = NULL;
    s_net_ops.rx_callback  = NULL;
    s_net_ops.mtu          = 1514;

    /* 15 — device_t nel device tree */
    i = 0;
    while (name[i] && i < sizeof(s_device.name) - 1) {
        s_device.name[i] = name[i]; i++;
    }
    s_device.name[i]     = '\0';
    s_device.type        = DEV_TYPE_NET;
    s_device.state       = DEV_STATE_ACTIVE;
    s_device.net_ops     = &s_net_ops;
    s_device.driver_data = &s_vnet;
    device_add(&s_device, NULL);

    s_initialized = true;
    serial_puts("[VNET] init completato — /dev/eth0 (VirtIO-Net)\n");
}

/* =========================================================================
 * virtio_net_send — API diretta kernel
 * ========================================================================= */

int virtio_net_send(const void *data, uint16_t len) {
    if (!s_initialized) return -EIO;
    return vnet_send(&s_device, data, len);
}
