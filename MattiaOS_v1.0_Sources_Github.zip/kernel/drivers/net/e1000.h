#ifndef MATTIAOS_E1000_H
#define MATTIAOS_E1000_H

/*
 * kernel/drivers/net/e1000.h — driver Intel e1000 Gigabit Ethernet
 *
 * Gestisce i controller Ethernet Intel 8254x/8257x (e1000/e1000e).
 * Supportati i device ID più comuni in QEMU e hardware reale:
 *   82540EM (0x100E), 82545EM (0x100F), 82574L (0x10D3), I217LM (0x153A)
 *
 * Architettura:
 *   - BAR0: 128 KB MMIO (indirizzo fisico → accesso tramite HHDM)
 *   - TX descriptor ring: E1000_TX_DESC_COUNT entry
 *   - RX descriptor ring: E1000_RX_DESC_COUNT entry
 *   - IRQ-driven RX: vettore = pci->irq_line + 0x20
 *   - TX: polled (attende TDD bit nel TX descriptor status)
 *   - EEPROM: lettura MAC address via EERD register
 *   - PHY: auto-negotiation abilitato (reset a default hardware)
 *
 * Standard di riferimento:
 *   Intel 8254x Family Developer's Manual (rev 4.0)
 *   Intel 82574L GbE Controller Datasheet
 *
 * Dipendenze:
 *   driver.h — device_t, net_ops_t, mmio helpers, spinlock
 *   pci.h    — pci_device_t, pci_get_bar, pci_enable_busmaster
 *   pmm.h    — pmm_alloc_frames (descriptor ring + buffer DMA)
 *   vmm.h    — phys_to_virt, virt_to_phys
 *   slab.h   — kzalloc
 */

#include "../driver.h"
#include "../pci.h"

/* =========================================================================
 * Registri e1000 — offset dal BAR0 MMIO
 * ========================================================================= */

/* Controllo generale */
#define E1000_CTRL      0x00000   /* Device Control                         */
#define E1000_STATUS    0x00008   /* Device Status                          */
#define E1000_EECD      0x00010   /* EEPROM/Flash Control & Data            */
#define E1000_EERD      0x00014   /* EEPROM Read                            */
#define E1000_CTRL_EXT  0x00018   /* Extended Device Control                */
#define E1000_FLA       0x0001C   /* Flash Access                           */
#define E1000_MDIC      0x00020   /* MDI Control (PHY access)               */

/* Interrupt */
#define E1000_ICR       0x000C0   /* Interrupt Cause Read (clear on read)   */
#define E1000_ITR       0x000C4   /* Interrupt Throttling Rate              */
#define E1000_ICS       0x000C8   /* Interrupt Cause Set                    */
#define E1000_IMS       0x000D0   /* Interrupt Mask Set/Read                */
#define E1000_IMC       0x000D8   /* Interrupt Mask Clear                   */

/* Ricezione */
#define E1000_RCTL      0x00100   /* Receive Control                        */
#define E1000_RDBAL     0x02800   /* RX Descriptor Base Address Low         */
#define E1000_RDBAH     0x02804   /* RX Descriptor Base Address High        */
#define E1000_RDLEN     0x02808   /* RX Descriptor Length (byte, mult 128)  */
#define E1000_RDH       0x02810   /* RX Descriptor Head                     */
#define E1000_RDT       0x02818   /* RX Descriptor Tail                     */
#define E1000_RDTR      0x02820   /* RX Delay Timer                         */

/* Trasmissione */
#define E1000_TCTL      0x00400   /* Transmit Control                       */
#define E1000_TIPG      0x00410   /* Transmit IPG (Inter Packet Gap)        */
#define E1000_TDBAL     0x03800   /* TX Descriptor Base Address Low         */
#define E1000_TDBAH     0x03804   /* TX Descriptor Base Address High        */
#define E1000_TDLEN     0x03808   /* TX Descriptor Length                   */
#define E1000_TDH       0x03810   /* TX Descriptor Head                     */
#define E1000_TDT       0x03818   /* TX Descriptor Tail                     */

/* MAC address */
#define E1000_RAL       0x05400   /* Receive Address Low  (bytes 0-3)       */
#define E1000_RAH       0x05404   /* Receive Address High (bytes 4-5 + AV)  */

/* Multicast table */
#define E1000_MTA       0x05200   /* Multicast Table Array (128 × 32-bit)   */

/* =========================================================================
 * CTRL bits
 * ========================================================================= */

#define E1000_CTRL_FD       (1 << 0)   /* Full Duplex                       */
#define E1000_CTRL_LRST     (1 << 3)   /* Link Reset                        */
#define E1000_CTRL_ASDE     (1 << 5)   /* Auto-Speed Detection Enable       */
#define E1000_CTRL_SLU      (1 << 6)   /* Set Link Up                       */
#define E1000_CTRL_ILOS     (1 << 7)   /* Invert Loss-of-Signal             */
#define E1000_CTRL_SPEED_10  (0 << 8)
#define E1000_CTRL_SPEED_100 (1 << 8)
#define E1000_CTRL_SPEED_1G  (2 << 8)
#define E1000_CTRL_FRCSPD   (1 << 11)  /* Force Speed                       */
#define E1000_CTRL_FRCDPLX  (1 << 12)  /* Force Duplex                      */
#define E1000_CTRL_RST      (1 << 26)  /* Device Reset                      */
#define E1000_CTRL_RFCE     (1 << 27)  /* RX Flow Control Enable            */
#define E1000_CTRL_TFCE     (1 << 28)  /* TX Flow Control Enable            */
#define E1000_CTRL_VME      (1 << 30)  /* VLAN Mode Enable                  */
#define E1000_CTRL_PHY_RST  (1U << 31) /* PHY Reset                         */

/* =========================================================================
 * RCTL bits
 * ========================================================================= */

#define E1000_RCTL_EN         (1 << 1)   /* Receiver Enable                 */
#define E1000_RCTL_SBP        (1 << 2)   /* Store Bad Packets               */
#define E1000_RCTL_UPE        (1 << 3)   /* Unicast Promiscuous Enable      */
#define E1000_RCTL_MPE        (1 << 4)   /* Multicast Promiscuous Enable    */
#define E1000_RCTL_LPE        (1 << 5)   /* Long Packet Reception Enable    */
#define E1000_RCTL_LBM_NONE   (0 << 6)   /* No Loopback                     */
#define E1000_RCTL_RDMTS_HALF (0 << 8)   /* RDMT: 1/2 buffer threshold      */
#define E1000_RCTL_MO_0       (0 << 12)  /* Multicast Offset 0              */
#define E1000_RCTL_BAM        (1 << 15)  /* Broadcast Accept Mode           */
#define E1000_RCTL_BSIZE_2048 (0 << 16)  /* Receive Buffer Size: 2048 B     */
#define E1000_RCTL_BSIZE_1024 (1 << 16)
#define E1000_RCTL_BSIZE_512  (2 << 16)
#define E1000_RCTL_SECRC      (1 << 26)  /* Strip Ethernet CRC              */

/* =========================================================================
 * TCTL bits
 * ========================================================================= */

#define E1000_TCTL_EN         (1 << 1)   /* Transmit Enable                 */
#define E1000_TCTL_PSP        (1 << 3)   /* Pad Short Packets               */
#define E1000_TCTL_CT_SHIFT   4          /* Collision Threshold             */
#define E1000_TCTL_COLD_SHIFT 12         /* Collision Distance              */
#define E1000_TCTL_COLD_FD    0x040      /* Full Duplex collision distance  */

/* =========================================================================
 * Interrupt bits (ICR/IMS/IMC)
 * ========================================================================= */

#define E1000_ICR_TXDW   (1 << 0)   /* TX Descriptor Written Back          */
#define E1000_ICR_LSC    (1 << 2)   /* Link Status Change                  */
#define E1000_ICR_RXSEQ  (1 << 3)   /* RX Sequence Error                   */
#define E1000_ICR_RXDMT0 (1 << 4)   /* RX Descriptor Min Threshold         */
#define E1000_ICR_RXO    (1 << 6)   /* RX Overrun                          */
#define E1000_ICR_RXT0   (1 << 7)   /* RX Timer Interrupt                  */

/* =========================================================================
 * EERD bits (EEPROM Read)
 * ========================================================================= */

#define E1000_EERD_START  (1 << 0)  /* Start read                          */
#define E1000_EERD_DONE   (1 << 4)  /* Read done (bit 4 per 82540/82545)   */
#define E1000_EERD_ADDR_SHIFT 8
#define E1000_EERD_DATA_SHIFT 16

/* EEPROM word offsets per MAC address */
#define E1000_EEPROM_MAC_WORD0  0x00
#define E1000_EEPROM_MAC_WORD1  0x01
#define E1000_EEPROM_MAC_WORD2  0x02

/* =========================================================================
 * RAH bits
 * ========================================================================= */

#define E1000_RAH_AV  (1U << 31)   /* Address Valid                         */

/* =========================================================================
 * Strutture descriptor DMA
 * ========================================================================= */

/*
 * e1000_rx_desc_t — RX Descriptor (16 byte, legacy format).
 * Il driver prepopola buffer_addr con l'indirizzo fisico del buffer.
 * L'hardware scrive gli altri campi al completamento della ricezione.
 */
typedef struct {
    uint64_t buffer_addr;  /* Indirizzo fisico buffer dati (driver scrive)  */
    uint16_t length;       /* Byte ricevuti (hardware scrive)               */
    uint16_t checksum;     /* Checksum (ignorato)                           */
    uint8_t  status;       /* Status bits (hardware scrive)                 */
    uint8_t  errors;       /* Error bits                                    */
    uint16_t special;      /* VLAN tag (ignorato)                           */
} __attribute__((packed)) e1000_rx_desc_t;

/* RX status bits */
#define E1000_RXD_STAT_DD   (1 << 0)   /* Descriptor Done                  */
#define E1000_RXD_STAT_EOP  (1 << 1)   /* End of Packet                    */

/*
 * e1000_tx_desc_t — TX Descriptor (16 byte, legacy format).
 */
typedef struct {
    uint64_t buffer_addr;  /* Indirizzo fisico buffer dati (driver scrive)  */
    uint16_t length;       /* Byte da trasmettere                           */
    uint8_t  cso;          /* Checksum Offset (0 = no offload)             */
    uint8_t  cmd;          /* Command bits                                  */
    uint8_t  status;       /* Status (hardware scrive TDD)                  */
    uint8_t  css;          /* Checksum Start Field                         */
    uint16_t special;      /* VLAN (ignorato)                              */
} __attribute__((packed)) e1000_tx_desc_t;

/* TX cmd bits */
#define E1000_TXD_CMD_EOP   (1 << 0)   /* End of Packet                    */
#define E1000_TXD_CMD_IFCS  (1 << 1)   /* Insert FCS (CRC)                 */
#define E1000_TXD_CMD_RS    (1 << 3)   /* Report Status (write-back DD)    */

/* TX status bits */
#define E1000_TXD_STAT_DD   (1 << 0)   /* Descriptor Done                  */

/* =========================================================================
 * Dimensioni ring
 * ========================================================================= */

#define E1000_TX_DESC_COUNT  64    /* TX descriptor ring entries            */
#define E1000_RX_DESC_COUNT  64    /* RX descriptor ring entries            */
#define E1000_RX_BUF_SIZE    2048  /* byte per buffer RX (RCTL_BSIZE_2048)  */

/* =========================================================================
 * Struttura di stato del driver
 * ========================================================================= */

typedef struct {
    uint64_t bar0_phys;    /* BAR0 indirizzo fisico MMIO base               */
    uint8_t  mac[6];       /* MAC address                                   */
    uint8_t  irq_vector;   /* vettore IRQ = pci->irq_line + 0x20            */

    /* TX ring */
    e1000_tx_desc_t *tx_descs;    /* descriptor ring (HHDM virtual)         */
    uint64_t         tx_phys;     /* indirizzo fisico descriptor ring        */
    uint64_t         tx_bufs_phys;/* buffer DMA per TX (1 per slot)         */
    uint32_t         tx_tail;     /* tail corrente                          */

    /* RX ring */
    e1000_rx_desc_t *rx_descs;    /* descriptor ring (HHDM virtual)         */
    uint64_t         rx_phys;     /* indirizzo fisico descriptor ring        */
    uint64_t         rx_bufs_phys;/* buffer DMA per RX (1 per slot)         */
    uint32_t         rx_head;     /* prossimo descriptor da consumare        */

    spinlock_t tx_lock;
} e1000_state_t;

/* =========================================================================
 * Ioctl commands per /dev/eth0 (e1000)
 * ========================================================================= */

#define E1000_IOCTL_GET_MAC    0xB001   /* arg → uint8_t[6] (out) */
#define E1000_IOCTL_SET_PROMISC 0xB002  /* arg = 1 abilitato, 0 disabilitato */

/* =========================================================================
 * API pubblica
 * ========================================================================= */

/*
 * e1000_init — probe PCI, reset hardware, setup TX/RX ring,
 * legge MAC da EEPROM, registra /dev/eth0 in devfs.
 * Debole in irq.c — sovrascritta da questa implementazione.
 */
void e1000_init(void);

/*
 * e1000_send — invia un frame Ethernet grezzo (max 1514 byte).
 * Ritorna EOK o codice errore negativo.
 */
int e1000_send(const void *data, uint16_t len);

#endif /* MATTIAOS_E1000_H */
