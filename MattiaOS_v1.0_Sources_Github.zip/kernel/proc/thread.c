#include "process.h"
#include "../mm/pmm.h"
#include "../mm/vmm.h"
#include "../mm/slab.h"
#include "../include/errno.h"

#define KERNEL_STACK_PAGES 4
#define KERNEL_STACK_SIZE  (KERNEL_STACK_PAGES * PAGE_SIZE)

static tid_t s_next_tid = 1;

static inline void *tmemset(void *dst, int c, size_t n) {
    uint8_t *d = (uint8_t *)dst;
    while (n--) *d++ = (uint8_t)c;
    return dst;
}

/*
 * thread_create — allocate and initialize a thread for proc.
 * entry: RIP to start execution at.
 * stack: RSP (user stack pointer, already allocated by caller).
 * Returns NULL on allocation failure.
 * Thread is NOT yet added to the scheduler run queue — caller must
 * call scheduler_add() after thread_create().
 */
thread_t *thread_create(process_t *proc, uint64_t entry, uint64_t stack) {
    if (!proc) return NULL;

    thread_t *t = (thread_t *)kzalloc(sizeof(thread_t));
    if (!t) return NULL;

    uint64_t kstack_phys = pmm_alloc_frames(KERNEL_STACK_PAGES);
    if (!kstack_phys) {
        kfree(t);
        return NULL;
    }

    t->tid           = s_next_tid++;
    t->process       = proc;
    t->state         = PROCESS_READY;
    t->sched_level   = 0;
    t->fpu_used      = false;
    t->errno_val     = 0;
    t->kernel_stack  = (uint64_t)phys_to_virt(kstack_phys) + KERNEL_STACK_SIZE;
    t->user_stack    = stack;
    t->fs_base       = 0;
    t->gs_base       = 0;

    tmemset(&t->context, 0, sizeof(cpu_context_t));
    t->context.rip    = entry;
    t->context.rsp    = stack;
    t->context.rflags = 0x202;

    t->prev = NULL;
    t->next = proc->threads;
    if (proc->threads) proc->threads->prev = t;
    proc->threads = t;

    return t;
}

/*
 * thread_destroy — free all resources of thread and unlink from process.
 * Caller must remove thread from scheduler before calling this.
 */
void thread_destroy(thread_t *thread) {
    if (!thread) return;

    if (thread->prev) thread->prev->next = thread->next;
    else if (thread->process)
        thread->process->threads = thread->next;
    if (thread->next) thread->next->prev = thread->prev;

    if (thread->kernel_stack) {
        uint64_t base = thread->kernel_stack - KERNEL_STACK_SIZE;
        uint64_t phys = virt_to_phys((void *)base);
        for (size_t i = 0; i < KERNEL_STACK_PAGES; i++)
            pmm_free_frame(phys + i * PAGE_SIZE);
    }

    tmemset(thread->fpu_state, 0, sizeof(thread->fpu_state));
    kfree(thread);
}
