#ifndef MATTIAOS_THREAD_H
#define MATTIAOS_THREAD_H

/*
 * kernel/proc/thread.h — stub di inclusione per simmetria .h/.c
 *
 * thread.c implementa thread_create() e thread_destroy(),
 * che sono dichiarate in process.h insieme a thread_t.
 * Includere process.h per l'intera API proc/thread.
 */

#include "process.h"

#endif /* MATTIAOS_THREAD_H */
