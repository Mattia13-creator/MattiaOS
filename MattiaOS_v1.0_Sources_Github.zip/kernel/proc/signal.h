#ifndef MATTIAOS_SIGNAL_H
#define MATTIAOS_SIGNAL_H

/*
 * kernel/proc/signal.h — API segnali POSIX (subset)
 *
 * Dichiarazioni pubbliche per signal.c.
 * Le strutture process_t, thread_t e signal_handler_t
 * sono definite in process.h che va incluso prima di questo file.
 */

#include "process.h"

/* Numeri di segnale (POSIX subset) */
#define SIGHUP   1
#define SIGINT   2
#define SIGQUIT  3
#define SIGILL   4
#define SIGTRAP  5
#define SIGABRT  6
#define SIGBUS   7
#define SIGFPE   8
#define SIGKILL  9
#define SIGUSR1  10
#define SIGSEGV  11
#define SIGUSR2  12
#define SIGPIPE  13
#define SIGALRM  14
#define SIGTERM  15
#define SIGCHLD  17

/*
 * signal_send — invia il segnale sig al processo target.
 * Ritorna EOK o codice errore negativo.
 * Segnali bloccati restano in pending. SIGKILL e SIGSTOP non sono bloccabili.
 */
int signal_send(process_t *target, int sig);

/*
 * signal_handle — processa i segnali pending per proc.
 * Da chiamare al rientro da syscall o alla preemption (scheduler tick).
 * Ritorna EOK se nessun segnale terminale, -ESRCH se proc è stato terminato.
 */
int signal_handle(process_t *proc);

/*
 * signal_set_handler — installa handler per il segnale sig.
 * SIG_DFL (NULL) = azione default, SIG_IGN = ignora.
 * SIGKILL e SIGSTOP non possono essere catturati.
 */
int signal_set_handler(process_t *proc, int sig, signal_handler_t handler);

/*
 * signal_set_mask — imposta la maschera dei segnali bloccati.
 * Bit i = 1 → segnale i+1 bloccato.
 */
void signal_set_mask(process_t *proc, uint64_t mask);

#endif /* MATTIAOS_SIGNAL_H */
