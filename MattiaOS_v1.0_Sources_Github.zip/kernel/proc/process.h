#ifndef MATTIAOS_PROCESS_H
#define MATTIAOS_PROCESS_H

#include "../include/types.h"
#include "../mm/vmm.h"
#include "../fs/vfs.h"

#define PROCESS_NAME_MAX 256
#define SIGNAL_MAX       64

typedef enum {
    PROCESS_RUNNING,
    PROCESS_READY,
    PROCESS_BLOCKED,
    PROCESS_ZOMBIE,
    PROCESS_SLEEPING
} process_state_t;

typedef struct {
    uint64_t rax, rbx, rcx, rdx;
    uint64_t rsi, rdi, rbp;
    uint64_t r8,  r9,  r10, r11;
    uint64_t r12, r13, r14, r15;
    uint64_t rip;
    uint64_t rsp;
    uint64_t rflags;
} cpu_context_t;

typedef void (*signal_handler_t)(int);

typedef struct thread thread_t;

typedef struct process {
    pid_t    pid;
    pid_t    ppid;
    uid_t    uid;
    gid_t    gid;
    char     name[PROCESS_NAME_MAX];

    process_state_t state;
    int      exit_code;

    pml4_t  *pagemap;
    uint64_t heap_start;
    uint64_t heap_end;
    uint64_t stack_top;

    cpu_context_t context;

    /*
     * The PCB does NOT store the path of the executable.
     * After execve(), the kernel forgets where the binary was on disk.
     * Only the pages in RAM matter. See blueprint Principle 2.
     */

    struct file *fd_table[FD_MAX];

    thread_t *threads;

    int      priority;
    uint64_t cpu_time_used;
    uint64_t sleep_until;

    uint64_t signal_pending;
    uint64_t signal_blocked;
    signal_handler_t handlers[SIGNAL_MAX];

    struct process *next;
    struct process *prev;
} process_t;

typedef struct thread {
    tid_t     tid;
    process_t *process;

    process_state_t state;
    cpu_context_t   context;

    uint64_t kernel_stack;
    uint64_t user_stack;
    uint64_t errno_val;

    uint64_t fs_base;
    uint64_t gs_base;

    uint8_t  fpu_state[512] __attribute__((aligned(16)));
    bool     fpu_used;

    int      sched_level;

    struct thread *next;
    struct thread *prev;
} thread_t;

process_t *process_create(const char *name, uid_t uid, gid_t gid);
void       process_destroy(process_t *proc);
process_t *process_fork(process_t *parent);
int        process_execve(process_t *proc, const char *path, char **argv, char **envp);

thread_t  *thread_create(process_t *proc, uint64_t entry, uint64_t stack);
void       thread_destroy(thread_t *thread);

process_t *process_get_list(void); /* read-only list head for diagnostics */

extern process_t *g_current_process;
extern thread_t  *g_current_thread;

#endif
