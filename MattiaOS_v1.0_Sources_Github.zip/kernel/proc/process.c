#include "process.h"
#include "../mm/pmm.h"
#include "../mm/vmm.h"
#include "../mm/slab.h"
#include "../include/errno.h"

/* Global current process and thread pointers, updated on context switch */
process_t *g_current_process = NULL;
thread_t  *g_current_thread  = NULL;

/* Global process list and PID counter */
static process_t *s_process_list = NULL;
static pid_t      s_next_pid     = 1;
static spinlock_t s_proc_lock    = {0};

/* Public getter — read-only access for console/diagnostic code */
process_t *process_get_list(void) { return s_process_list; }

/* ── ELF64 structures (inline, no external libc) ───────────────────────── */

#define ELF_MAGIC      0x464C457F
#define ELF_CLASS_64   2
#define ELF_DATA_LSB   1
#define ET_EXEC        2
#define EM_X86_64      62
#define PT_LOAD        1
#define PT_INTERP      3
#define PF_X           0x1
#define PF_W           0x2
#define PF_R           0x4

typedef struct {
    uint8_t  e_ident[16];
    uint16_t e_type;
    uint16_t e_machine;
    uint32_t e_version;
    uint64_t e_entry;
    uint64_t e_phoff;
    uint64_t e_shoff;
    uint32_t e_flags;
    uint16_t e_ehsize;
    uint16_t e_phentsize;
    uint16_t e_phnum;
    uint16_t e_shentsize;
    uint16_t e_shnum;
    uint16_t e_shstrndx;
} __attribute__((packed)) elf64_ehdr_t;

typedef struct {
    uint32_t p_type;
    uint32_t p_flags;
    uint64_t p_offset;
    uint64_t p_vaddr;
    uint64_t p_paddr;
    uint64_t p_filesz;
    uint64_t p_memsz;
    uint64_t p_align;
} __attribute__((packed)) elf64_phdr_t;

/* ── Helper ─────────────────────────────────────────────────────────────── */

static inline void *kmemset(void *dst, int c, size_t n) {
    uint8_t *d = (uint8_t *)dst;
    while (n--) *d++ = (uint8_t)c;
    return dst;
}

static inline void *kmemcpy(void *dst, const void *src, size_t n) {
    uint8_t *d = (uint8_t *)dst;
    const uint8_t *s = (const uint8_t *)src;
    while (n--) *d++ = *s++;
    return dst;
}

static inline size_t kstrlen(const char *s) {
    size_t n = 0;
    while (s[n]) n++;
    return n;
}

static inline void kstrncpy(char *dst, const char *src, size_t n) {
    size_t i = 0;
    while (i < n - 1 && src[i]) { dst[i] = src[i]; i++; }
    dst[i] = '\0';
}

/* ── Process list management ─────────────────────────────────────────────── */

static void proc_list_add(process_t *proc) {
    spinlock_acquire(&s_proc_lock);
    proc->next = s_process_list;
    proc->prev = NULL;
    if (s_process_list) s_process_list->prev = proc;
    s_process_list = proc;
    spinlock_release(&s_proc_lock);
}

static void proc_list_remove(process_t *proc) {
    spinlock_acquire(&s_proc_lock);
    if (proc->prev) proc->prev->next = proc->next;
    else s_process_list = proc->next;
    if (proc->next) proc->next->prev = proc->prev;
    spinlock_release(&s_proc_lock);
}

/* ── process_create ──────────────────────────────────────────────────────
 * Allocate and initialize a new process with a fresh page map.
 * Returns NULL on allocation failure.
 */
process_t *process_create(const char *name, uid_t uid, gid_t gid) {
    process_t *proc = (process_t *)kzalloc(sizeof(process_t));
    if (!proc) return NULL;

    proc->pid   = s_next_pid++;
    proc->ppid  = g_current_process ? g_current_process->pid : 0;
    proc->uid   = uid;
    proc->gid   = gid;
    proc->state = PROCESS_READY;
    kstrncpy(proc->name, name, PROCESS_NAME_MAX);

    proc->pagemap = vmm_new_pagemap();
    if (!proc->pagemap) {
        kfree(proc);
        return NULL;
    }

    /* Default heap/stack layout in userspace */
    proc->heap_start = 0x0000000010000000ULL;
    proc->heap_end   = 0x0000000010000000ULL;
    proc->stack_top  = 0x00007FFFFFFFE000ULL;

    /* Default signal handlers: SIG_DFL = NULL */
    kmemset(proc->handlers, 0, sizeof(proc->handlers));

    /* All file descriptors start closed */
    kmemset(proc->fd_table, 0, sizeof(proc->fd_table));

    proc_list_add(proc);
    return proc;
}

/* ── process_destroy ─────────────────────────────────────────────────────
 * Free all resources belonging to proc.
 * Closes open file descriptors, destroys threads, frees page map.
 */
void process_destroy(process_t *proc) {
    if (!proc) return;

    /* Close all open file descriptors */
    for (int i = 0; i < FD_MAX; i++) {
        if (proc->fd_table[i]) {
            /* vfs_close would be called here; skip include cycle for now */
            kfree(proc->fd_table[i]);
            proc->fd_table[i] = NULL;
        }
    }

    /* Destroy threads */
    thread_t *t = proc->threads;
    while (t) {
        thread_t *next = t->next;
        thread_destroy(t);
        t = next;
    }

    /* Free page map */
    if (proc->pagemap) vmm_destroy_pagemap(proc->pagemap);

    proc_list_remove(proc);
    kfree(proc);
}

/* ── process_fork ────────────────────────────────────────────────────────
 * Create a child process that is a copy-on-write clone of parent.
 * Returns the new child process, or NULL on failure.
 *
 * COW: the child gets a new PML4 whose entries initially point to the
 * same physical frames as the parent but with WRITABLE cleared.
 * The first write fault triggers frame duplication in the #PF handler.
 *
 * NOTE: No path is stored — only RAM pages matter (Principle 2).
 */
process_t *process_fork(process_t *parent) {
    if (!parent) return NULL;

    process_t *child = (process_t *)kzalloc(sizeof(process_t));
    if (!child) return NULL;

    child->pid   = s_next_pid++;
    child->ppid  = parent->pid;
    child->uid   = parent->uid;
    child->gid   = parent->gid;
    child->state = PROCESS_READY;
    kstrncpy(child->name, parent->name, PROCESS_NAME_MAX);

    /* COW: clone page map */
    child->pagemap = vmm_clone_pagemap_cow(parent->pagemap);
    if (!child->pagemap) {
        kfree(child);
        return NULL;
    }

    child->heap_start    = parent->heap_start;
    child->heap_end      = parent->heap_end;
    child->stack_top     = parent->stack_top;
    child->context       = parent->context;
    child->cpu_time_used = 0;
    child->priority      = parent->priority;

    /* Copy signal state */
    child->signal_pending = 0;
    child->signal_blocked = parent->signal_blocked;
    kmemcpy(child->handlers, parent->handlers, sizeof(parent->handlers));

    /* Duplicate file descriptors */
    for (int i = 0; i < FD_MAX; i++) {
        if (parent->fd_table[i]) {
            struct file *f = (struct file *)kmalloc(sizeof(struct file));
            if (f) {
                kmemcpy(f, parent->fd_table[i], sizeof(struct file));
                child->fd_table[i] = f;
            }
        }
    }

    /* The child returns 0 from fork(); set rax=0 in child context */
    child->context.rax = 0;

    proc_list_add(child);
    return child;
}

/* ── process_execve ──────────────────────────────────────────────────────
 * Load an ELF64 executable from 'path' into proc's address space.
 * After loading, the kernel FORGETS the path entirely (Principle 2).
 * proc->name is updated from argv[0] but no path is stored in the PCB.
 *
 * Returns EOK on success, negative errno on failure.
 */
int process_execve(process_t *proc, const char *path,
                   char **argv, char **envp) {
    if (!proc || !path) return -EINVAL;
    (void)envp; /* argv[0] used below for proc->name; full argv passed to stack TODO */

    /* ── 1. Open the file via VFS ──────────────────────────────────────── */
    struct file *elf_file = vfs_open(path, 0 /* O_RDONLY */);
    if (!elf_file) return -ENOENT;

    /* ── 2. Read ELF header ───────────────────────────────────────────── */
    elf64_ehdr_t ehdr;
    ssize_t n = vfs_read(elf_file, &ehdr, sizeof(ehdr));
    if (n != (ssize_t)sizeof(ehdr)) {
        vfs_close(elf_file);
        return -EINVAL;
    }

    /* Validate ELF magic and architecture */
    uint32_t magic;
    kmemcpy(&magic, ehdr.e_ident, 4);
    if (magic != ELF_MAGIC
     || ehdr.e_ident[4] != ELF_CLASS_64
     || ehdr.e_ident[5] != ELF_DATA_LSB
     || ehdr.e_type      != ET_EXEC
     || ehdr.e_machine   != EM_X86_64) {
        vfs_close(elf_file);
        return -EINVAL;
    }

    /* ── 3. Create a fresh address space ─────────────────────────────── */
    pml4_t *new_pm = vmm_new_pagemap();
    if (!new_pm) {
        vfs_close(elf_file);
        return -ENOMEM;
    }

    /* ── 4. Load PT_LOAD segments ────────────────────────────────────── */
    for (uint16_t i = 0; i < ehdr.e_phnum; i++) {
        elf64_phdr_t phdr;
        off_t phdr_off = (off_t)(ehdr.e_phoff + (uint64_t)i * sizeof(elf64_phdr_t));

        /* Seek and read program header */
        elf_file->offset = phdr_off;
        n = vfs_read(elf_file, &phdr, sizeof(phdr));
        if (n != (ssize_t)sizeof(phdr)) continue;

        if (phdr.p_type != PT_LOAD) continue;
        if (phdr.p_memsz == 0) continue;

        /* Determine mapping flags */
        uint64_t vmflags = PTE_PRESENT | PTE_USER;
        if (phdr.p_flags & PF_W) vmflags |= PTE_WRITABLE;
        if (!(phdr.p_flags & PF_X)) vmflags |= PTE_NX;

        /* Allocate physical frames and map them */
        size_t num_pages = (phdr.p_memsz + PAGE_SIZE - 1) / PAGE_SIZE;
        uint64_t vaddr_base = phdr.p_vaddr & ~(uint64_t)(PAGE_SIZE - 1);

        for (size_t pg = 0; pg < num_pages; pg++) {
            uint64_t phys = pmm_alloc_frame();
            if (!phys) {
                vmm_destroy_pagemap(new_pm);
                vfs_close(elf_file);
                return -ENOMEM;
            }
            uint64_t vaddr = vaddr_base + pg * PAGE_SIZE;
            vmm_map(new_pm, vaddr, phys, vmflags);

            /* Zero the page */
            uint8_t *virt = (uint8_t *)phys_to_virt(phys);
            kmemset(virt, 0, PAGE_SIZE);
        }

        /* Copy segment data from file */
        if (phdr.p_filesz > 0) {
            elf_file->offset = (off_t)phdr.p_offset;
            /* Read in PAGE_SIZE chunks, writing to physical pages via HHDM */
            size_t remaining = phdr.p_filesz;
            uint64_t dst_virt = phdr.p_vaddr;
            uint8_t *chunk = (uint8_t *)kmalloc(PAGE_SIZE);
            if (!chunk) {
                vmm_destroy_pagemap(new_pm);
                vfs_close(elf_file);
                return -ENOMEM;
            }
            while (remaining > 0) {
                size_t to_read = remaining < PAGE_SIZE ? remaining : PAGE_SIZE;
                ssize_t got = vfs_read(elf_file, chunk, to_read);
                if (got <= 0) break;

                /* Translate destination virtual → physical via new page map */
                uint64_t phys_dst = vmm_virt_to_phys(new_pm, dst_virt);
                if (phys_dst) {
                    uint64_t page_off = dst_virt & (PAGE_SIZE - 1);
                    kmemcpy((uint8_t *)phys_to_virt(phys_dst) + page_off,
                            chunk, (size_t)got);
                }
                dst_virt  += (uint64_t)got;
                remaining -= (size_t)got;
            }
            kfree(chunk);
        }
    }

    /* ── 5. Close file — path is forgotten after this point ─────────── */
    vfs_close(elf_file);
    /* elf_file = NULL; path no longer referenced anywhere in the PCB */

    /* ── 6. Allocate user stack ──────────────────────────────────────── */
    #define USER_STACK_PAGES 8
    uint64_t stack_top = 0x00007FFFFFFFE000ULL;
    for (size_t pg = 0; pg < USER_STACK_PAGES; pg++) {
        uint64_t phys = pmm_alloc_frame();
        if (!phys) { vmm_destroy_pagemap(new_pm); return -ENOMEM; }
        uint64_t vaddr = stack_top - (pg + 1) * PAGE_SIZE;
        vmm_map(new_pm, vaddr, phys, PTE_PRESENT | PTE_WRITABLE | PTE_USER | PTE_NX);
        kmemset(phys_to_virt(phys), 0, PAGE_SIZE);
    }

    /* ── 7. Switch to new address space and set up context ───────────── */
    if (proc->pagemap) vmm_destroy_pagemap(proc->pagemap);
    proc->pagemap   = new_pm;
    proc->stack_top = stack_top - 8; /* align to 16 bytes - 8 */

    kmemset(&proc->context, 0, sizeof(cpu_context_t));
    proc->context.rip    = ehdr.e_entry;
    proc->context.rsp    = proc->stack_top;
    proc->context.rflags = 0x202; /* IF=1, reserved bit */

    /* Update process name from argv[0] if available */
    if (argv && argv[0])
        kstrncpy(proc->name, argv[0], PROCESS_NAME_MAX);

    /* Reset heap */
    proc->heap_end = proc->heap_start;

    /* Close all FDs marked close-on-exec (simplified: close all) */
    for (int i = 3; i < FD_MAX; i++) {
        if (proc->fd_table[i]) {
            kfree(proc->fd_table[i]);
            proc->fd_table[i] = NULL;
        }
    }

    /* Clear pending signals */
    proc->signal_pending = 0;
    proc->state = PROCESS_READY;

    return EOK;
}
