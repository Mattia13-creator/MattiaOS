#ifndef MATTIAOS_SLAB_H
#define MATTIAOS_SLAB_H

#include "../include/types.h"

/*
 * SLUB-inspired slab allocator.
 * Fixed-size caches: 16, 32, 64, 128, 256, 512, 1024, 2048, 4096 bytes.
 * Objects > 4096 bytes: direct vmalloc.
 */

void  slab_init(void);
void *kmalloc(size_t size);
void *kzalloc(size_t size);
void *krealloc(void *ptr, size_t new_size);
void  kfree(void *ptr);

#endif
