#include "vmm.h"
#include "pmm.h"
#include "../arch/x86_64/cpu.h"

pml4_t  *g_kernel_pml4 = NULL;
uint64_t g_hhdm_offset  = 0;

static uint64_t *get_or_create(uint64_t *table, uint16_t idx, uint64_t flags) {
    if (!(table[idx] & PTE_PRESENT)) {
        uint64_t frame = pmm_alloc_frame();
        __builtin_memset(phys_to_virt(frame), 0, PAGE_SIZE);
        table[idx] = frame | flags;
    }
    return (uint64_t *)phys_to_virt(table[idx] & PTE_ADDR_MASK);
}

void vmm_map(pml4_t *pml4, uint64_t virt, uint64_t phys, uint64_t flags) {
    uint16_t pml4_idx = (virt >> 39) & 0x1FF;
    uint16_t pdpt_idx = (virt >> 30) & 0x1FF;
    uint16_t pd_idx   = (virt >> 21) & 0x1FF;
    uint16_t pt_idx   = (virt >> 12) & 0x1FF;

    uint64_t *pdpt = get_or_create((uint64_t *)pml4, pml4_idx, PTE_PRESENT | PTE_WRITABLE | PTE_USER);
    uint64_t *pd   = get_or_create(pdpt, pdpt_idx, PTE_PRESENT | PTE_WRITABLE | PTE_USER);
    uint64_t *pt   = get_or_create(pd, pd_idx, PTE_PRESENT | PTE_WRITABLE | PTE_USER);

    pt[pt_idx] = (phys & PTE_ADDR_MASK) | flags;
    invlpg(virt);
}

void vmm_unmap(pml4_t *pml4, uint64_t virt) {
    uint16_t pml4_idx = (virt >> 39) & 0x1FF;
    uint16_t pdpt_idx = (virt >> 30) & 0x1FF;
    uint16_t pd_idx   = (virt >> 21) & 0x1FF;
    uint16_t pt_idx   = (virt >> 12) & 0x1FF;

    uint64_t *entry = (uint64_t *)pml4;
    if (!(entry[pml4_idx] & PTE_PRESENT)) return;
    entry = (uint64_t *)phys_to_virt(entry[pml4_idx] & PTE_ADDR_MASK);
    if (!(entry[pdpt_idx] & PTE_PRESENT)) return;
    entry = (uint64_t *)phys_to_virt(entry[pdpt_idx] & PTE_ADDR_MASK);
    if (!(entry[pd_idx] & PTE_PRESENT)) return;
    entry = (uint64_t *)phys_to_virt(entry[pd_idx] & PTE_ADDR_MASK);

    entry[pt_idx] = 0;
    invlpg(virt);
}

pml4_t *vmm_new_pagemap(void) {
    uint64_t frame = pmm_alloc_frame();
    pml4_t *pml4 = (pml4_t *)phys_to_virt(frame);
    __builtin_memset(pml4, 0, PAGE_SIZE);
    /* Copy higher-half kernel mappings from kernel pml4 */
    uint64_t *src = (uint64_t *)g_kernel_pml4;
    uint64_t *dst = (uint64_t *)pml4;
    for (int i = 256; i < 512; i++) dst[i] = src[i];
    return pml4;
}

void vmm_switch_pagemap(pml4_t *pml4) {
    write_cr3(virt_to_phys(pml4));
}

uint64_t vmm_virt_to_phys(pml4_t *pml4, uint64_t virt) {
    uint16_t pml4_idx = (virt >> 39) & 0x1FF;
    uint16_t pdpt_idx = (virt >> 30) & 0x1FF;
    uint16_t pd_idx   = (virt >> 21) & 0x1FF;
    uint16_t pt_idx   = (virt >> 12) & 0x1FF;

    uint64_t *e = (uint64_t *)pml4;
    if (!(e[pml4_idx] & PTE_PRESENT)) return 0;
    e = (uint64_t *)phys_to_virt(e[pml4_idx] & PTE_ADDR_MASK);
    if (!(e[pdpt_idx] & PTE_PRESENT)) return 0;
    e = (uint64_t *)phys_to_virt(e[pdpt_idx] & PTE_ADDR_MASK);
    if (!(e[pd_idx] & PTE_PRESENT)) return 0;
    e = (uint64_t *)phys_to_virt(e[pd_idx] & PTE_ADDR_MASK);
    if (!(e[pt_idx] & PTE_PRESENT)) return 0;

    return (e[pt_idx] & PTE_ADDR_MASK) | (virt & 0xFFF);
}

void vmm_init(uint64_t hhdm_offset, struct limine_kernel_address_response *kaddr) {
    g_hhdm_offset = hhdm_offset;

    /*
     * Abilita EFER.NXE (No-Execute Enable) e EFER.SCE (SYSCALL/SYSRET).
     * Deve essere fatto PRIMA di creare qualsiasi page table che usi PTE_NX
     * (bit 63): senza NXE, scrivere bit 63 in un PTE causa #GP.
     */
    uint64_t efer = rdmsr(MSR_EFER);
    efer |= EFER_NXE | EFER_SCE;
    wrmsr(MSR_EFER, efer);

    uint64_t frame = pmm_alloc_frame();
    g_kernel_pml4 = (pml4_t *)phys_to_virt(frame);
    __builtin_memset(g_kernel_pml4, 0, PAGE_SIZE);

    /*
     * Map HHDM: 4GB fisici → HHDM_OFFSET con pagine huge 2MB.
     *
     * PERCHÉ 2MB e non 4KB:
     *   4KB × 4GB = 1.048.576 iterazioni → minuti di attesa in VirtualBox.
     *   2MB × 4GB = 2048 iterazioni + 5 page table alloc → <1ms.
     *
     * PERCHÉ 4GB e non solo RAM effettiva:
     *   Oltre la RAM fisica ci sono dispositivi MMIO:
     *     LAPIC  @ 0xFEE00000  (4062MB)
     *     IOAPIC @ 0xFEC00000  (4044MB)
     *     HPET   @ ~0xFED00000 (4045MB)
     *   Tutti entro i primi 4GB → devono essere mappati nell'HHDM.
     *
     * Il bit PTE_HUGE (bit 7) nella PD entry = huge 2MB page (PS bit).
     * Con PTE_NX: HHDM è dati/MMIO, mai eseguito.
     * Con PTE_GLOBAL: non flushato sui context switch.
     */
    for (uint64_t phys = 0; phys < 0x100000000ULL; phys += 0x200000ULL) {
        uint16_t pml4_idx = ((hhdm_offset + phys) >> 39) & 0x1FF;
        uint16_t pdpt_idx = ((hhdm_offset + phys) >> 30) & 0x1FF;
        uint16_t pd_idx   = ((hhdm_offset + phys) >> 21) & 0x1FF;

        uint64_t *pdpt = get_or_create((uint64_t *)g_kernel_pml4, pml4_idx,
                                       PTE_PRESENT | PTE_WRITABLE);
        uint64_t *pd   = get_or_create(pdpt, pdpt_idx,
                                       PTE_PRESENT | PTE_WRITABLE);
        /* PTE_HUGE (bit 7) nel PD entry = 2MB huge page */
        pd[pd_idx] = (phys & ~0x1FFFFFULL)
                   | PTE_PRESENT | PTE_WRITABLE | PTE_HUGE | PTE_NX | PTE_GLOBAL;
    }

    /* Map kernel itself at higher half */
    extern char _kernel_start[], _kernel_end[];
    uint64_t kvirt = kaddr->virtual_base;
    uint64_t kphys = kaddr->physical_base;
    uint64_t ksize = (uint64_t)_kernel_end - (uint64_t)_kernel_start;
    for (uint64_t off = 0; off < ksize; off += PAGE_SIZE) {
        vmm_map(g_kernel_pml4, kvirt + off, kphys + off, PTE_PRESENT | PTE_WRITABLE | PTE_GLOBAL);
    }

    /*
     * BUG FIX v3.7: mappa i primi 1MB di memoria fisica come identity map.
     *
     * Motivo dell'estensione da 64KB a 1MB:
     *   0x00000 - 0x004FF  IVT + BDA (BIOS)
     *   0x05000 - 0x06FFF  Limine responses + E820 buffer (stage2)
     *   0x07C00            Boot stack
     *   0x08000 - 0x0DFFF  Stage2 (rimane in memoria per i response pointers)
     *   0x0B8000           VGA text mode buffer (80x25, 2KB) ← BUG se mancante!
     *
     * Senza questa riga VGA_BASE = 0xB8000 causa #PF immediatamente dopo
     * vmm_switch_pagemap(), rendendo il kernel silente su schermo.
     * HHDM mappa 0xB8000 solo all'indirizzo virtuale HHDM_OFFSET+0xB8000,
     * ma cpu.c usa l'indirizzo fisico diretto (0xB8000) come virtual.
     */
    for (uint64_t p = 0; p < 0x100000; p += PAGE_SIZE) {
        vmm_map(g_kernel_pml4, p, p, PTE_PRESENT | PTE_WRITABLE);
    }

    vmm_switch_pagemap(g_kernel_pml4);
}

/*
 * vmm_destroy_pagemap — libera tutte le page table di un pagemap utente.
 * Scorre i 256 entry inferiori del PML4 (spazio utente) e dealloca
 * ricorsivamente PDPT → PD → PT. Non tocca la metà superiore (kernel).
 * NOTA: non dealloca i frame fisici delle pagine mappate —
 *       quello spetta al gestore della memoria del processo (COW/anon).
 */
void vmm_destroy_pagemap(pml4_t *pml4) {
    if (!pml4) return;
    uint64_t *table = (uint64_t *)pml4;
    /* Solo spazio utente (entry 0-255) */
    for (int i = 0; i < 256; i++) {
        if (!(table[i] & PTE_PRESENT)) continue;
        uint64_t *pdpt = (uint64_t *)phys_to_virt(table[i] & PTE_ADDR_MASK);
        for (int j = 0; j < 512; j++) {
            if (!(pdpt[j] & PTE_PRESENT)) continue;
            uint64_t *pd = (uint64_t *)phys_to_virt(pdpt[j] & PTE_ADDR_MASK);
            for (int k = 0; k < 512; k++) {
                if (!(pd[k] & PTE_PRESENT)) continue;
                pmm_free_frame(pd[k] & PTE_ADDR_MASK);
            }
            pmm_free_frame(pdpt[j] & PTE_ADDR_MASK);
        }
        pmm_free_frame(table[i] & PTE_ADDR_MASK);
    }
    pmm_free_frame(virt_to_phys((void *)pml4));
}

/*
 * vmm_clone_pagemap_cow — crea un clone COW del pagemap sorgente.
 * Alloca un nuovo PML4, copia la metà superiore (kernel) direttamente,
 * e duplica la metà inferiore (utente) marcando le pagine writable come
 * read-only in entrambi i pagemap (trigger COW al primo write fault).
 */
pml4_t *vmm_clone_pagemap_cow(pml4_t *src) {
    if (!src) return NULL;
    uint64_t frame = pmm_alloc_frame();
    if (!frame) return NULL;
    pml4_t *dst = (pml4_t *)phys_to_virt(frame);
    __builtin_memset(dst, 0, PAGE_SIZE);

    uint64_t *src_t = (uint64_t *)src;
    uint64_t *dst_t = (uint64_t *)dst;

    /* Copia metà superiore (kernel) invariata */
    for (int i = 256; i < 512; i++)
        dst_t[i] = src_t[i];

    /* Clona metà inferiore (utente): COW — togli WRITABLE da entrambi */
    for (int i = 0; i < 256; i++) {
        if (!(src_t[i] & PTE_PRESENT)) continue;
        uint64_t pdpt_frame = pmm_alloc_frame();
        if (!pdpt_frame) { vmm_destroy_pagemap(dst); return NULL; }
        uint64_t *src_pdpt = (uint64_t *)phys_to_virt(src_t[i] & PTE_ADDR_MASK);
        uint64_t *dst_pdpt = (uint64_t *)phys_to_virt(pdpt_frame);
        __builtin_memset(dst_pdpt, 0, PAGE_SIZE);
        dst_t[i] = pdpt_frame | (src_t[i] & ~PTE_ADDR_MASK);

        for (int j = 0; j < 512; j++) {
            if (!(src_pdpt[j] & PTE_PRESENT)) continue;
            uint64_t pd_frame = pmm_alloc_frame();
            if (!pd_frame) { vmm_destroy_pagemap(dst); return NULL; }
            uint64_t *src_pd = (uint64_t *)phys_to_virt(src_pdpt[j] & PTE_ADDR_MASK);
            uint64_t *dst_pd = (uint64_t *)phys_to_virt(pd_frame);
            __builtin_memset(dst_pd, 0, PAGE_SIZE);
            dst_pdpt[j] = pd_frame | (src_pdpt[j] & ~PTE_ADDR_MASK);

            for (int k = 0; k < 512; k++) {
                if (!(src_pd[k] & PTE_PRESENT)) continue;
                uint64_t pt_frame = pmm_alloc_frame();
                if (!pt_frame) { vmm_destroy_pagemap(dst); return NULL; }
                uint64_t *src_pt = (uint64_t *)phys_to_virt(src_pd[k] & PTE_ADDR_MASK);
                uint64_t *dst_pt = (uint64_t *)phys_to_virt(pt_frame);
                __builtin_memset(dst_pt, 0, PAGE_SIZE);
                dst_pd[k] = pt_frame | (src_pd[k] & ~PTE_ADDR_MASK);

                for (int l = 0; l < 512; l++) {
                    if (!(src_pt[l] & PTE_PRESENT)) continue;
                    /* Togli WRITABLE da entrambi: COW */
                    src_pt[l] &= ~PTE_WRITABLE;
                    dst_pt[l]  = src_pt[l];
                }
            }
        }
    }
    return dst;
}
