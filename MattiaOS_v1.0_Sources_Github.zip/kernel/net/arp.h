#ifndef MATTIAOS_ARP_H
#define MATTIAOS_ARP_H

/*
 * arp.h — Address Resolution Protocol (RFC 826)
 *
 * Cache ARP kernel-side: max ARP_CACHE_SIZE entry, LRU.
 * arp_resolve(): risolve IP→MAC; se miss, invia ARP request e ritorna
 *   EAGAIN (il chiamante deve riprovare dopo il reply).
 * arp_handle(): processa i frame ARP in arrivo (request + reply).
 */

#include "../include/types.h"
#include "../include/errno.h"
#include "ethernet.h"

/* =========================================================================
 * Header ARP on-wire (IPv4 over Ethernet)
 * ========================================================================= */
typedef struct __attribute__((packed)) {
    uint16_t htype;          /* Hardware type: 1 = Ethernet */
    uint16_t ptype;          /* Protocol type: 0x0800 = IPv4 */
    uint8_t  hlen;           /* Hardware addr len: 6 */
    uint8_t  plen;           /* Protocol addr len: 4 */
    uint16_t oper;           /* Operation: 1=request, 2=reply */
    uint8_t  sha[ETH_ADDR_LEN]; /* Sender hardware address */
    uint32_t spa;            /* Sender protocol address (IPv4, big-endian) */
    uint8_t  tha[ETH_ADDR_LEN]; /* Target hardware address */
    uint32_t tpa;            /* Target protocol address (IPv4, big-endian) */
} arp_hdr_t;

#define ARP_HTYPE_ETH  1u
#define ARP_OPER_REQ   1u
#define ARP_OPER_REP   2u
#define ARP_HDR_SIZE   sizeof(arp_hdr_t)   /* 28 byte */

/* =========================================================================
 * Cache ARP
 * ========================================================================= */
#define ARP_CACHE_SIZE 64   /* Numero massimo di entry */
#define ARP_ENTRY_TTL  300  /* Secondi di validità (approssimati con tick) */

typedef struct {
    uint32_t ip;                    /* IPv4 in host byte order */
    uint8_t  mac[ETH_ADDR_LEN];
    uint64_t last_seen;             /* Tick ms dell'ultimo aggiornamento */
    bool     valid;
} arp_cache_entry_t;

/* =========================================================================
 * API pubblica
 * ========================================================================= */

/*
 * arp_init — azzera la cache e imposta l'indirizzo IP locale.
 * Chiamata da ipv4_init() con l'IP del sistema.
 */
void arp_init(uint32_t local_ip);

/*
 * arp_handle — processa un frame ARP ricevuto dalla NIC.
 * @nic:  NIC su cui è arrivato il frame.
 * @data: payload (dopo l'header ETH), dimensione @len.
 * Risponde automaticamente alle ARP request per il nostro IP.
 * Aggiorna la cache su ARP reply.
 */
void arp_handle(net_nic_t *nic, const void *data, uint16_t len);

/*
 * arp_resolve — risolve un indirizzo IPv4 nel MAC corrispondente.
 * @ip:      IPv4 destinazione in host byte order.
 * @mac_out: buffer 6 byte dove scrivere il MAC.
 * @return:  EOK se trovato in cache; EAGAIN se cache miss (ARP request
 *           inviata — riprovare dopo qualche ms); EINVAL se IP non valido.
 */
int arp_resolve(uint32_t ip, uint8_t mac_out[ETH_ADDR_LEN]);

/*
 * arp_update — inserisce o aggiorna manualmente una entry nella cache.
 * Usata da arp_handle() e da ipv4_send() per le risposte.
 */
void arp_update(uint32_t ip, const uint8_t mac[ETH_ADDR_LEN]);

#endif /* MATTIAOS_ARP_H */
