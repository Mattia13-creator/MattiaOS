#include "tcp.h"
#include "icmp.h"
#include "../mm/slab.h"
#include "../sched/mlfq.h"
#include "../proc/process.h"
#include "../arch/x86_64/cpu.h"

/* =========================================================================
 * Stato interno
 * ========================================================================= */
static tcp_conn_t  s_conns[TCP_MAX_CONN];
static spinlock_t  s_table_lock = {0};

/* Tick ms globale — incrementato da tcp_timer_tick() */
/* Definito in ipv4.c come g_net_ticks_ms; tcp_timer_tick la incrementa */
extern uint64_t g_net_ticks_ms;

/* ISN counter semplice */
static uint32_t s_isn_counter = 0x12345678u;

/* =========================================================================
 * Helper no-libc
 * ========================================================================= */
static inline void tcp_memcpy(void *d, const void *s, size_t n) {
    uint8_t *dd = (uint8_t *)d;
    const uint8_t *ss = (const uint8_t *)s;
    for (size_t i = 0; i < n; i++) dd[i] = ss[i];
}
static inline void tcp_memset(void *d, int v, size_t n) {
    uint8_t *dd = (uint8_t *)d;
    for (size_t i = 0; i < n; i++) dd[i] = (uint8_t)v;
}

/* =========================================================================
 * Wake utils
 * ========================================================================= */
static void wake_all(tcp_conn_t *conn) {
    for (uint32_t i = 0; i < conn->waiter_count; i++) {
        if (conn->waiters[i]) scheduler_unblock(conn->waiters[i]);
        conn->waiters[i] = NULL;
    }
    conn->waiter_count = 0;
}

static void add_waiter(tcp_conn_t *conn) {
    if (conn->waiter_count < 4)
        conn->waiters[conn->waiter_count++] = g_current_thread;
}

/* =========================================================================
 * ISN generation
 * ========================================================================= */
static uint32_t gen_isn(void) {
    s_isn_counter += 64000u;   /* Incremento periodico approssimato */
    return s_isn_counter;
}

/* =========================================================================
 * Porta effimera TCP
 * ========================================================================= */
static uint16_t s_tcp_ephemeral = 49152u;

static uint16_t tcp_ephemeral_port(void) {
    uint64_t f = spinlock_irqsave(&s_table_lock);
    uint16_t p = s_tcp_ephemeral++;
    if (s_tcp_ephemeral == 0) s_tcp_ephemeral = 49152u;
    spinlock_irqrestore(&s_table_lock, f);
    return p;
}

/* =========================================================================
 * Alloca / trova connessione
 * ========================================================================= */
static tcp_conn_t *conn_alloc(void) {
    for (int i = 0; i < TCP_MAX_CONN; i++) {
        if (!s_conns[i].valid) {
            tcp_memset(&s_conns[i], 0, sizeof(tcp_conn_t));
            s_conns[i].valid = true;
            return &s_conns[i];
        }
    }
    return NULL;
}

static tcp_conn_t *conn_find(uint32_t src_ip, uint16_t src_port,
                              uint32_t dst_ip, uint16_t dst_port) {
    for (int i = 0; i < TCP_MAX_CONN; i++) {
        tcp_conn_t *c = &s_conns[i];
        if (!c->valid) continue;
        if (c->remote_ip   == src_ip   && c->remote_port == src_port &&
            c->local_ip    == dst_ip   && c->local_port  == dst_port)
            return c;
    }
    return NULL;
}

static tcp_conn_t *conn_find_listener(uint16_t dst_port, uint32_t dst_ip) {
    for (int i = 0; i < TCP_MAX_CONN; i++) {
        tcp_conn_t *c = &s_conns[i];
        if (!c->valid || c->state != TCP_LISTEN) continue;
        if (c->local_port != dst_port) continue;
        if (c->local_ip != 0 && c->local_ip != dst_ip) continue;
        return c;
    }
    return NULL;
}

/* =========================================================================
 * RTO (Jacobson/Karels — RFC 6298)
 * ========================================================================= */
static void rtt_update(tcp_conn_t *c, uint32_t rtt_sample_ms) {
    if (!c->srtt_ms8) {
        /* Prima misura */
        c->srtt_ms8   = (int32_t)(rtt_sample_ms * 8u);
        c->rttvar_ms4 = (int32_t)(rtt_sample_ms * 4u / 2u);
    } else {
        int32_t r  = (int32_t)rtt_sample_ms;
        int32_t delta = r - c->srtt_ms8 / 8;
        if (delta < 0) delta = -delta;
        c->rttvar_ms4 = c->rttvar_ms4 - c->rttvar_ms4 / 4 + delta;
        c->srtt_ms8   = c->srtt_ms8   - c->srtt_ms8   / 8 + r;
    }
    uint32_t rto = (uint32_t)(c->srtt_ms8 / 8 + (uint32_t)(c->rttvar_ms4));
    if (rto < TCP_RTO_MIN_MS) rto = TCP_RTO_MIN_MS;
    if (rto > TCP_RTO_MAX_MS) rto = TCP_RTO_MAX_MS;
    c->rto_ms = rto;
}

/* =========================================================================
 * Checksum TCP
 * ========================================================================= */
static uint16_t tcp_checksum(uint32_t src_ip, uint32_t dst_ip,
                               const void *tcp_data, uint16_t tcp_len) {
    tcp_pseudo_hdr_t ph;
    ph.src_ip  = net_hton32(src_ip);
    ph.dst_ip  = net_hton32(dst_ip);
    ph.zero    = 0;
    ph.proto   = IP_PROTO_TCP;
    ph.tcp_len = net_hton16(tcp_len);

    uint32_t sum = 0;
    size_t n;

    /* Use byte pointer to avoid packed-struct alignment warning */
    const uint8_t *pb = (const uint8_t *)&ph;
    n = sizeof(ph);
    while (n > 1) { sum += (uint16_t)(pb[0] << 8 | pb[1]); pb += 2; n -= 2; }

    const uint16_t *p = (const uint16_t *)tcp_data;
    n = tcp_len;
    while (n > 1) { sum += *p++; n -= 2; }
    if (n) sum += *(const uint8_t *)p;

    while (sum >> 16) sum = (sum & 0xFFFFu) + (sum >> 16);
    return (uint16_t)~sum;
}

/* =========================================================================
 * Invia un segmento TCP
 * ========================================================================= */
static int tcp_send_segment(tcp_conn_t *c, uint8_t flags,
                             uint32_t seq, uint32_t ack,
                             const void *data, uint16_t data_len) {
    uint8_t buf[TCP_HDR_SIZE_MIN + TCP_MSS];
    if (data_len > TCP_MSS) data_len = (uint16_t)TCP_MSS;

    tcp_hdr_t *hdr = (tcp_hdr_t *)buf;
    tcp_memset(hdr, 0, TCP_HDR_SIZE_MIN);
    hdr->src_port = net_hton16(c->local_port);
    hdr->dst_port = net_hton16(c->remote_port);
    hdr->seq      = net_hton32(seq);
    hdr->ack      = net_hton32(ack);
    hdr->data_off = (uint8_t)(5u << 4);   /* 20 byte header, no options */
    hdr->flags    = flags;
    hdr->window   = net_hton16((uint16_t)(c->rcv_wnd < 65535u ? c->rcv_wnd : 65535u));
    hdr->checksum = 0;
    hdr->urgent   = 0;

    if (data && data_len)
        tcp_memcpy(buf + TCP_HDR_SIZE_MIN, data, data_len);

    uint16_t total = (uint16_t)(TCP_HDR_SIZE_MIN + data_len);
    hdr->checksum  = tcp_checksum(c->local_ip, c->remote_ip, buf, total);

    /* Avvia misura RTT se non in corso e stiamo inviando dati */
    if (data_len && !c->rtt_measuring) {
        c->rtt_measuring  = true;
        c->rtt_seq        = seq + data_len;
        c->rtt_send_tick  = g_net_ticks_ms;
    }

    return ipv4_send(c->remote_ip, IP_PROTO_TCP, buf, total);
}

/* =========================================================================
 * tcp_send_rst — invia RST senza connessione
 * ========================================================================= */
static void tcp_send_rst(uint32_t src_ip,  uint16_t src_port,
                          uint32_t dst_ip,  uint16_t dst_port,
                          uint32_t seq,     uint32_t ack) {
    uint8_t buf[TCP_HDR_SIZE_MIN];
    tcp_hdr_t *hdr = (tcp_hdr_t *)buf;
    tcp_memset(hdr, 0, TCP_HDR_SIZE_MIN);
    hdr->src_port = net_hton16(src_port);
    hdr->dst_port = net_hton16(dst_port);
    hdr->seq      = net_hton32(seq);
    hdr->ack      = net_hton32(ack);
    hdr->data_off = (uint8_t)(5u << 4);
    hdr->flags    = TCP_FLAG_RST | TCP_FLAG_ACK;
    hdr->window   = 0;
    hdr->checksum = tcp_checksum(src_ip, dst_ip, buf, TCP_HDR_SIZE_MIN);
    ipv4_send(dst_ip, IP_PROTO_TCP, buf, TCP_HDR_SIZE_MIN);
}

/* =========================================================================
 * tcp_do_send — invia dati dal send buffer finché la finestra lo permette
 * ========================================================================= */
static void tcp_do_send(tcp_conn_t *c) {
    /* Calcola quanti byte possiamo inviare ora */
    uint32_t in_flight = c->send_unacked;
    uint32_t wnd       = (c->snd_wnd < c->cwnd) ? c->snd_wnd : c->cwnd;
    if (wnd < in_flight) return;
    uint32_t sendable = wnd - in_flight;

    uint32_t unsent = c->send_count - c->send_unacked;
    if (unsent == 0 || sendable == 0) return;

    uint32_t to_send = (unsent < sendable) ? unsent : sendable;
    if (to_send > TCP_MSS) to_send = TCP_MSS;

    /* Legge dal ring buffer a partire dall'offset dei byte non ancora inviati */
    uint32_t start = (c->send_head + c->send_unacked) % TCP_SEND_BUF_SIZE;
    uint8_t seg[TCP_MSS];

    uint32_t first_part = TCP_SEND_BUF_SIZE - start;
    if (first_part >= to_send) {
        tcp_memcpy(seg, c->send_buf + start, to_send);
    } else {
        tcp_memcpy(seg, c->send_buf + start, first_part);
        tcp_memcpy(seg + first_part, c->send_buf, to_send - first_part);
    }

    uint32_t seq = c->snd_una + c->send_unacked;
    tcp_send_segment(c, TCP_FLAG_ACK | TCP_FLAG_PSH, seq, c->rcv_nxt,
                     seg, (uint16_t)to_send);

    c->send_unacked += to_send;
    c->snd_nxt       = c->snd_una + c->send_unacked;

    /* Arma il timer di ritrasmissione */
    c->retransmit_deadline = g_net_ticks_ms + c->rto_ms;
}

/* =========================================================================
 * tcp_process_ack — aggiorna snd_una, sliding window, congestion control
 * ========================================================================= */
static void tcp_process_ack(tcp_conn_t *c, uint32_t ack_val, uint16_t wnd) {
    if (TCP_SEQ_LE(ack_val, c->snd_una)) {
        /* ACK duplicato */
        c->dup_ack_count++;
        if (c->dup_ack_count == 3 && !c->fast_recovery) {
            /* Fast retransmit (Reno) */
            c->ssthresh     = (c->snd_wnd / 2 > TCP_MSS * 2) ? c->snd_wnd / 2 : TCP_MSS * 2;
            c->cwnd         = c->ssthresh + 3 * TCP_MSS;
            c->fast_recovery = true;
            c->recover_seq  = c->snd_nxt;
            /* Ritrasmetti da snd_una */
            uint32_t start = c->send_head % TCP_SEND_BUF_SIZE;
            uint32_t sz    = (c->send_unacked < TCP_MSS) ? c->send_unacked : TCP_MSS;
            uint8_t seg[TCP_MSS];
            uint32_t fp = TCP_SEND_BUF_SIZE - start;
            if (fp >= sz) tcp_memcpy(seg, c->send_buf + start, sz);
            else { tcp_memcpy(seg, c->send_buf + start, fp); tcp_memcpy(seg + fp, c->send_buf, sz - fp); }
            tcp_send_segment(c, TCP_FLAG_ACK | TCP_FLAG_PSH,
                             c->snd_una, c->rcv_nxt, seg, (uint16_t)sz);
            c->retransmit_deadline = g_net_ticks_ms + c->rto_ms;
        } else if (c->fast_recovery) {
            c->cwnd += TCP_MSS;
        }
        return;
    }

    if (TCP_SEQ_GT(ack_val, c->snd_nxt)) return;  /* ACK per qualcosa non ancora inviato */

    uint32_t acked = ack_val - c->snd_una;

    /* RTT measurement */
    if (c->rtt_measuring && TCP_SEQ_GE(ack_val, c->rtt_seq)) {
        uint32_t sample = (uint32_t)(g_net_ticks_ms - c->rtt_send_tick);
        if (sample > 0) rtt_update(c, sample);
        c->rtt_measuring = false;
    }

    /* Aggiorna congestion window */
    if (c->fast_recovery) {
        if (TCP_SEQ_GE(ack_val, c->recover_seq)) {
            c->cwnd = c->ssthresh;
            c->fast_recovery = false;
        } else {
            c->cwnd -= acked;
            if (acked > TCP_MSS) c->cwnd += TCP_MSS;
        }
    } else if (c->cwnd < c->ssthresh) {
        c->cwnd += acked;  /* Slow start */
    } else {
        c->cwnd += (TCP_MSS * TCP_MSS) / c->cwnd;  /* Congestion avoidance */
    }

    /* Avanza send_head e aggiorna contatori */
    c->send_head    = (c->send_head + acked) % TCP_SEND_BUF_SIZE;
    c->send_count  -= acked;
    c->send_unacked = (c->send_unacked > acked) ? c->send_unacked - acked : 0;
    c->snd_una      = ack_val;
    c->snd_wnd      = wnd;
    c->dup_ack_count = 0;

    /* Spegni timer se tutto confermato */
    if (c->snd_una == c->snd_nxt) {
        c->retransmit_deadline = 0;
        c->retransmit_count    = 0;
    } else {
        c->retransmit_deadline = g_net_ticks_ms + c->rto_ms;
    }

    /* Sveglia eventuali thread bloccati in tcp_send() */
    wake_all(c);

    /* Invia nuovi dati se disponibili */
    tcp_do_send(c);
}

/* =========================================================================
 * Riceve dati in-order nel receive buffer
 * ========================================================================= */
static void tcp_receive_data(tcp_conn_t *c,
                              const uint8_t *data, uint32_t data_len) {
    if (data_len == 0) return;

    uint32_t space = TCP_RECV_BUF_SIZE - c->recv_count;
    uint32_t to_store = (data_len < space) ? data_len : space;

    uint32_t tail = c->recv_tail;
    uint32_t fp   = TCP_RECV_BUF_SIZE - tail;

    if (fp >= to_store) {
        tcp_memcpy(c->recv_buf + tail, data, to_store);
    } else {
        tcp_memcpy(c->recv_buf + tail, data, fp);
        tcp_memcpy(c->recv_buf, data + fp, to_store - fp);
    }

    c->recv_tail   = (tail + to_store) % TCP_RECV_BUF_SIZE;
    c->recv_count += to_store;
    c->rcv_nxt    += to_store;

    /* Aggiorna finestra di ricezione */
    c->rcv_wnd = TCP_RECV_BUF_SIZE - c->recv_count;

    /* Sveglia reader */
    wake_all(c);
}

/* =========================================================================
 * tcp_handle — state machine in ricezione
 * ========================================================================= */
void tcp_handle(uint32_t src_ip, uint32_t dst_ip,
                const void *data, uint16_t len) {
    if (len < TCP_HDR_SIZE_MIN) return;

    const tcp_hdr_t *hdr = (const tcp_hdr_t *)data;
    uint32_t hdr_len = TCP_HDR_OFFSET(hdr);
    if (hdr_len < TCP_HDR_SIZE_MIN || hdr_len > len) return;

    /* Verifica checksum */
    if (tcp_checksum(src_ip, dst_ip, data, len) != 0) return;

    uint16_t src_port  = net_ntoh16(hdr->src_port);
    uint16_t dst_port  = net_ntoh16(hdr->dst_port);
    uint32_t seq       = net_ntoh32(hdr->seq);
    uint32_t ack_val   = net_ntoh32(hdr->ack);
    uint16_t snd_wnd   = net_ntoh16(hdr->window);
    uint8_t  flags     = hdr->flags;

    const uint8_t *payload     = (const uint8_t *)data + hdr_len;
    uint32_t       payload_len = len - hdr_len;

    uint64_t f = spinlock_irqsave(&s_table_lock);

    /* Cerca connessione esistente */
    tcp_conn_t *c = conn_find(src_ip, src_port, dst_ip, dst_port);

    if (!c) {
        /* Nessuna connessione — cerca listener se SYN */
        if (flags & TCP_FLAG_SYN) {
            tcp_conn_t *listener = conn_find_listener(dst_port, dst_ip);
            if (listener) {
                /* Alloca nuova connessione per il 3-way handshake */
                tcp_conn_t *nc = conn_alloc();
                if (!nc) {
                    spinlock_irqrestore(&s_table_lock, f);
                    tcp_send_rst(dst_ip, dst_port, src_ip, src_port,
                                 0, seq + 1);
                    return;
                }
                nc->state       = TCP_SYN_RECEIVED;
                nc->local_ip    = dst_ip ? dst_ip : ipv4_get_local_ip();
                nc->local_port  = dst_port;
                nc->remote_ip   = src_ip;
                nc->remote_port = src_port;
                nc->irs         = seq;
                nc->rcv_nxt     = seq + 1;
                nc->rcv_wnd     = TCP_RECV_BUF_SIZE;
                nc->iss         = gen_isn();
                nc->snd_una     = nc->iss;
                nc->snd_nxt     = nc->iss + 1;
                nc->snd_wnd     = snd_wnd;
                nc->cwnd        = TCP_INITIAL_CWND;
                nc->ssthresh    = TCP_INITIAL_SSTHRESH;
                nc->rto_ms      = TCP_RTO_INIT_MS;
                /* Associa al listener per l'accept */
                nc->sock = listener->sock;

                spinlock_irqrestore(&s_table_lock, f);

                /* Invia SYN-ACK */
                tcp_send_segment(nc, TCP_FLAG_SYN | TCP_FLAG_ACK,
                                 nc->iss, nc->rcv_nxt, NULL, 0);
                nc->retransmit_deadline = g_net_ticks_ms + nc->rto_ms;

                /* Notifica il listener */
                uint64_t lf = spinlock_irqsave(&listener->lock);
                wake_all(listener);
                spinlock_irqrestore(&listener->lock, lf);
                return;
            }
        }
        spinlock_irqrestore(&s_table_lock, f);
        if (!(flags & TCP_FLAG_RST))
            tcp_send_rst(dst_ip, dst_port, src_ip, src_port, 0, seq + 1);
        return;
    }

    spinlock_irqrestore(&s_table_lock, f);

    uint64_t cf = spinlock_irqsave(&c->lock);

    /* RST: chiudi immediatamente */
    if (flags & TCP_FLAG_RST) {
        c->state = TCP_CLOSED;
        wake_all(c);
        spinlock_irqrestore(&c->lock, cf);
        return;
    }

    switch (c->state) {
    case TCP_SYN_SENT:
        if ((flags & (TCP_FLAG_SYN | TCP_FLAG_ACK)) == (TCP_FLAG_SYN | TCP_FLAG_ACK)) {
            if (ack_val != c->snd_nxt) {
                tcp_send_rst(c->local_ip, c->local_port,
                             c->remote_ip, c->remote_port, ack_val, 0);
                c->state = TCP_CLOSED;
                wake_all(c);
                break;
            }
            c->irs     = seq;
            c->rcv_nxt = seq + 1;
            c->snd_una = ack_val;
            c->snd_wnd = snd_wnd;
            c->state   = TCP_ESTABLISHED;
            tcp_send_segment(c, TCP_FLAG_ACK,
                             c->snd_nxt, c->rcv_nxt, NULL, 0);
            wake_all(c);
        }
        break;

    case TCP_SYN_RECEIVED:
        if ((flags & TCP_FLAG_ACK) && ack_val == c->snd_nxt) {
            c->snd_una = ack_val;
            c->state   = TCP_ESTABLISHED;
            wake_all(c);
        }
        break;

    case TCP_ESTABLISHED:
    case TCP_FIN_WAIT_1:
    case TCP_FIN_WAIT_2:
    case TCP_CLOSE_WAIT: {
        if (flags & TCP_FLAG_ACK)
            tcp_process_ack(c, ack_val, snd_wnd);

        /* Dati in-order */
        if (payload_len > 0 && seq == c->rcv_nxt) {
            tcp_receive_data(c, payload, payload_len);
            tcp_send_segment(c, TCP_FLAG_ACK,
                             c->snd_nxt, c->rcv_nxt, NULL, 0);
        }

        /* FIN ricevuto */
        if (flags & TCP_FLAG_FIN) {
            c->rcv_nxt++;
            tcp_send_segment(c, TCP_FLAG_ACK,
                             c->snd_nxt, c->rcv_nxt, NULL, 0);
            if (c->state == TCP_ESTABLISHED) {
                c->state = TCP_CLOSE_WAIT;
                wake_all(c);
            } else if (c->state == TCP_FIN_WAIT_1) {
                c->state = TCP_CLOSING;
            } else if (c->state == TCP_FIN_WAIT_2) {
                c->state = TCP_TIME_WAIT;
                c->timewait_deadline = g_net_ticks_ms + TCP_TIMEWAIT_MS;
                wake_all(c);
            }
        }
        break;
    }

    case TCP_CLOSING:
        if (flags & TCP_FLAG_ACK) {
            c->state = TCP_TIME_WAIT;
            c->timewait_deadline = g_net_ticks_ms + TCP_TIMEWAIT_MS;
        }
        break;

    case TCP_LAST_ACK:
        if (flags & TCP_FLAG_ACK) {
            c->state = TCP_CLOSED;
            wake_all(c);
        }
        break;

    case TCP_TIME_WAIT:
        /* Ritrasmette l'ACK finale se arriva di nuovo il FIN */
        if (flags & TCP_FLAG_FIN)
            tcp_send_segment(c, TCP_FLAG_ACK,
                             c->snd_nxt, c->rcv_nxt, NULL, 0);
        break;

    default: break;
    }

    spinlock_irqrestore(&c->lock, cf);
}

/* =========================================================================
 * tcp_connect
 * ========================================================================= */
int tcp_connect(uint32_t dst_ip, uint16_t dst_port, tcp_conn_t **conn_out) {
    if (!dst_ip || !dst_port || !conn_out) return EINVAL;

    uint64_t f = spinlock_irqsave(&s_table_lock);
    tcp_conn_t *c = conn_alloc();
    if (!c) { spinlock_irqrestore(&s_table_lock, f); return ENOMEM; }

    c->state       = TCP_SYN_SENT;
    c->local_ip    = ipv4_get_local_ip();
    c->local_port  = tcp_ephemeral_port();
    c->remote_ip   = dst_ip;
    c->remote_port = dst_port;
    c->iss         = gen_isn();
    c->snd_una     = c->iss;
    c->snd_nxt     = c->iss + 1;
    c->rcv_wnd     = TCP_RECV_BUF_SIZE;
    c->cwnd        = TCP_INITIAL_CWND;
    c->ssthresh    = TCP_INITIAL_SSTHRESH;
    c->rto_ms      = TCP_RTO_INIT_MS;
    *conn_out = c;
    spinlock_irqrestore(&s_table_lock, f);

    tcp_send_segment(c, TCP_FLAG_SYN, c->iss, 0, NULL, 0);
    c->retransmit_deadline = g_net_ticks_ms + c->rto_ms;
    return EOK;
}

/* =========================================================================
 * tcp_listen
 * ========================================================================= */
int tcp_listen(uint16_t port, tcp_conn_t **conn_out) {
    if (!port || !conn_out) return EINVAL;

    uint64_t f = spinlock_irqsave(&s_table_lock);
    /* Controlla conflitti */
    for (int i = 0; i < TCP_MAX_CONN; i++) {
        if (s_conns[i].valid && s_conns[i].state == TCP_LISTEN &&
            s_conns[i].local_port == port) {
            spinlock_irqrestore(&s_table_lock, f);
            return EADDRINUSE;
        }
    }
    tcp_conn_t *c = conn_alloc();
    if (!c) { spinlock_irqrestore(&s_table_lock, f); return ENOMEM; }

    c->state      = TCP_LISTEN;
    c->local_ip   = 0;   /* INADDR_ANY */
    c->local_port = port;
    *conn_out = c;
    spinlock_irqrestore(&s_table_lock, f);
    return EOK;
}

/* =========================================================================
 * tcp_accept
 * ========================================================================= */
tcp_conn_t *tcp_accept(tcp_conn_t *listener) {
    if (!listener || listener->state != TCP_LISTEN) return NULL;

    while (1) {
        /* Cerca una connessione ESTABLISHED associata a questo listener */
        uint64_t f = spinlock_irqsave(&s_table_lock);
        for (int i = 0; i < TCP_MAX_CONN; i++) {
            tcp_conn_t *c = &s_conns[i];
            if (!c->valid || c == listener) continue;
            if (c->local_port != listener->local_port) continue;
            if (c->state == TCP_ESTABLISHED && c->sock == listener->sock) {
                c->sock = NULL;   /* dissociato — ora è del caller */
                spinlock_irqrestore(&s_table_lock, f);
                return c;
            }
        }
        /* Blocca finché non arriva un SYN */
        uint64_t lf = spinlock_irqsave(&listener->lock);
        add_waiter(listener);
        spinlock_irqrestore(&listener->lock, lf);
        spinlock_irqrestore(&s_table_lock, f);
        scheduler_block(g_current_thread);
        scheduler_yield();
    }
}

/* =========================================================================
 * tcp_send
 * ========================================================================= */
int tcp_send(tcp_conn_t *conn, const void *data, uint32_t len) {
    if (!conn || !data || len == 0) return EINVAL;
    if (conn->state != TCP_ESTABLISHED && conn->state != TCP_CLOSE_WAIT)
        return EPIPE;

    uint32_t sent = 0;
    while (sent < len) {
        uint64_t f = spinlock_irqsave(&conn->lock);

        uint32_t space = TCP_SEND_BUF_SIZE - conn->send_count;
        if (space == 0) {
            add_waiter(conn);
            spinlock_irqrestore(&conn->lock, f);
            scheduler_block(g_current_thread);
            scheduler_yield();
            continue;
        }

        uint32_t to_copy = len - sent;
        if (to_copy > space) to_copy = space;

        /* Scrivi nel ring buffer */
        uint32_t tail = conn->send_tail;
        uint32_t fp   = TCP_SEND_BUF_SIZE - tail;
        if (fp >= to_copy) {
            tcp_memcpy(conn->send_buf + tail, (const uint8_t *)data + sent, to_copy);
        } else {
            tcp_memcpy(conn->send_buf + tail, (const uint8_t *)data + sent, fp);
            tcp_memcpy(conn->send_buf, (const uint8_t *)data + sent + fp, to_copy - fp);
        }
        conn->send_tail   = (tail + to_copy) % TCP_SEND_BUF_SIZE;
        conn->send_count += to_copy;
        sent += to_copy;

        tcp_do_send(conn);
        spinlock_irqrestore(&conn->lock, f);
    }
    return (int)sent;
}

/* =========================================================================
 * tcp_recv
 * ========================================================================= */
int tcp_recv(tcp_conn_t *conn, void *buf, uint32_t len) {
    if (!conn || !buf || len == 0) return EINVAL;

    while (1) {
        uint64_t f = spinlock_irqsave(&conn->lock);

        if (conn->recv_count > 0) {
            uint32_t to_read = conn->recv_count < len ? conn->recv_count : len;
            uint32_t head = conn->recv_head;
            uint32_t fp   = TCP_RECV_BUF_SIZE - head;
            if (fp >= to_read) {
                tcp_memcpy(buf, conn->recv_buf + head, to_read);
            } else {
                tcp_memcpy(buf, conn->recv_buf + head, fp);
                tcp_memcpy((uint8_t *)buf + fp, conn->recv_buf, to_read - fp);
            }
            conn->recv_head   = (head + to_read) % TCP_RECV_BUF_SIZE;
            conn->recv_count -= to_read;
            conn->rcv_wnd     = TCP_RECV_BUF_SIZE - conn->recv_count;
            spinlock_irqrestore(&conn->lock, f);
            return (int)to_read;
        }

        if (conn->state == TCP_CLOSE_WAIT || conn->state == TCP_CLOSED) {
            spinlock_irqrestore(&conn->lock, f);
            return 0;   /* EOF */
        }

        add_waiter(conn);
        spinlock_irqrestore(&conn->lock, f);
        scheduler_block(g_current_thread);
        scheduler_yield();
    }
}

/* =========================================================================
 * tcp_close
 * ========================================================================= */
void tcp_close(tcp_conn_t *conn) {
    if (!conn) return;

    uint64_t f = spinlock_irqsave(&conn->lock);
    switch (conn->state) {
    case TCP_ESTABLISHED:
    case TCP_SYN_RECEIVED:
        conn->state = TCP_FIN_WAIT_1;
        tcp_send_segment(conn, TCP_FLAG_FIN | TCP_FLAG_ACK,
                         conn->snd_nxt, conn->rcv_nxt, NULL, 0);
        conn->snd_nxt++;
        break;
    case TCP_CLOSE_WAIT:
        conn->state = TCP_LAST_ACK;
        tcp_send_segment(conn, TCP_FLAG_FIN | TCP_FLAG_ACK,
                         conn->snd_nxt, conn->rcv_nxt, NULL, 0);
        conn->snd_nxt++;
        break;
    default:
        break;
    }
    spinlock_irqrestore(&conn->lock, f);
}

/* =========================================================================
 * tcp_free
 * ========================================================================= */
void tcp_free(tcp_conn_t *conn) {
    if (!conn) return;
    uint64_t f = spinlock_irqsave(&conn->lock);
    conn->valid = false;
    spinlock_irqrestore(&conn->lock, f);
}

/* =========================================================================
 * tcp_timer_tick — chiamato ogni ms dall'APIC timer (connessione pendente)
 * ========================================================================= */
void tcp_timer_tick(void) {
    g_net_ticks_ms++;

    for (int i = 0; i < TCP_MAX_CONN; i++) {
        tcp_conn_t *c = &s_conns[i];
        if (!c->valid) continue;

        /* Ritrasmissione */
        if (c->retransmit_deadline &&
            g_net_ticks_ms >= c->retransmit_deadline) {

            if (c->retransmit_count >= TCP_MAX_RETRANSMIT) {
                c->state = TCP_CLOSED;
                c->retransmit_deadline = 0;
                wake_all(c);
                continue;
            }

            /* Backoff esponenziale RTO */
            c->rto_ms *= 2;
            if (c->rto_ms > TCP_RTO_MAX_MS) c->rto_ms = TCP_RTO_MAX_MS;
            c->retransmit_deadline = g_net_ticks_ms + c->rto_ms;
            c->retransmit_count++;
            c->rtt_measuring = false;

            /* Reno: dimezza cwnd e ssthresh */
            c->ssthresh = (c->cwnd / 2 > TCP_MSS * 2) ? c->cwnd / 2 : TCP_MSS * 2;
            c->cwnd     = TCP_MSS;
            c->fast_recovery = false;
            c->dup_ack_count = 0;

            /* Ritrasmetti dal punto snd_una */
            if (c->state == TCP_SYN_SENT) {
                tcp_send_segment(c, TCP_FLAG_SYN, c->iss, 0, NULL, 0);
            } else if (c->send_unacked > 0) {
                uint32_t start = c->send_head % TCP_SEND_BUF_SIZE;
                uint32_t sz = (c->send_unacked < TCP_MSS) ? c->send_unacked : TCP_MSS;
                uint8_t seg[TCP_MSS];
                uint32_t fp = TCP_SEND_BUF_SIZE - start;
                if (fp >= sz) tcp_memcpy(seg, c->send_buf + start, sz);
                else { tcp_memcpy(seg, c->send_buf + start, fp); tcp_memcpy(seg + fp, c->send_buf, sz - fp); }
                tcp_send_segment(c, TCP_FLAG_ACK | TCP_FLAG_PSH,
                                 c->snd_una, c->rcv_nxt, seg, (uint16_t)sz);
            }
        }

        /* TIME_WAIT expiry */
        if (c->state == TCP_TIME_WAIT && c->timewait_deadline &&
            g_net_ticks_ms >= c->timewait_deadline) {
            c->state = TCP_CLOSED;
            c->valid = false;
        }
    }
}
