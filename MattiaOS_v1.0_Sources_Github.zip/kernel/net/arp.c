#include "arp.h"
#include "../arch/x86_64/cpu.h"

/* =========================================================================
 * Stato interno
 * ========================================================================= */
static arp_cache_entry_t s_cache[ARP_CACHE_SIZE];
static spinlock_t        s_cache_lock = {0};
static uint32_t          s_local_ip   = 0;

/* Tick counter ms — incrementato dall'APIC timer; extern definita in tcp.c */
extern uint64_t g_net_ticks_ms;

/* =========================================================================
 * Helper no-libc
 * ========================================================================= */
static inline void arp_memcpy(void *d, const void *s, size_t n) {
    uint8_t *dd = (uint8_t *)d;
    const uint8_t *ss = (const uint8_t *)s;
    for (size_t i = 0; i < n; i++) dd[i] = ss[i];
}
static inline void arp_memset(void *d, int v, size_t n) {
    uint8_t *dd = (uint8_t *)d;
    for (size_t i = 0; i < n; i++) dd[i] = (uint8_t)v;
}
static inline int arp_maceq(const uint8_t *a, const uint8_t *b) {
    for (int i = 0; i < ETH_ADDR_LEN; i++) if (a[i] != b[i]) return 0;
    return 1;
}

static const uint8_t s_bcast_mac[ETH_ADDR_LEN] = {0xFF,0xFF,0xFF,0xFF,0xFF,0xFF};

/* =========================================================================
 * arp_init
 * ========================================================================= */
void arp_init(uint32_t local_ip) {
    arp_memset(s_cache, 0, sizeof(s_cache));
    s_local_ip = local_ip;
}

/* =========================================================================
 * arp_update — inserisce/aggiorna entry nella cache (LRU semplice)
 * ========================================================================= */
void arp_update(uint32_t ip, const uint8_t mac[ETH_ADDR_LEN]) {
    uint64_t f = spinlock_irqsave(&s_cache_lock);

    /* Cerca entry esistente */
    for (int i = 0; i < ARP_CACHE_SIZE; i++) {
        if (s_cache[i].valid && s_cache[i].ip == ip) {
            arp_memcpy(s_cache[i].mac, mac, ETH_ADDR_LEN);
            s_cache[i].last_seen = g_net_ticks_ms;
            spinlock_irqrestore(&s_cache_lock, f);
            return;
        }
    }

    /* Cerca slot libero o il più vecchio (LRU) */
    int victim = 0;
    for (int i = 0; i < ARP_CACHE_SIZE; i++) {
        if (!s_cache[i].valid) { victim = i; break; }
        if (s_cache[i].last_seen < s_cache[victim].last_seen) victim = i;
    }

    s_cache[victim].ip        = ip;
    s_cache[victim].last_seen = g_net_ticks_ms;
    s_cache[victim].valid     = true;
    arp_memcpy(s_cache[victim].mac, mac, ETH_ADDR_LEN);

    spinlock_irqrestore(&s_cache_lock, f);
}

/* =========================================================================
 * arp_send_request — invia ARP request broadcast per un IP
 * ========================================================================= */
static void arp_send_request(net_nic_t *nic, uint32_t target_ip) {
    if (!nic) return;

    arp_hdr_t req;
    arp_memset(&req, 0, sizeof(req));
    req.htype = net_hton16(ARP_HTYPE_ETH);
    req.ptype = net_hton16(ETH_TYPE_IPV4);
    req.hlen  = ETH_ADDR_LEN;
    req.plen  = 4;
    req.oper  = net_hton16(ARP_OPER_REQ);
    arp_memcpy(req.sha, nic->mac, ETH_ADDR_LEN);
    req.spa   = net_hton32(s_local_ip);
    arp_memset(req.tha, 0, ETH_ADDR_LEN);
    req.tpa   = net_hton32(target_ip);

    ethernet_send(nic, s_bcast_mac, ETH_TYPE_ARP, &req, (uint16_t)sizeof(req));
}

/* =========================================================================
 * arp_resolve
 * ========================================================================= */
int arp_resolve(uint32_t ip, uint8_t mac_out[ETH_ADDR_LEN]) {
    if (!ip) return EINVAL;

    /* Loopback */
    if ((ip & 0xFF000000u) == 0x7F000000u) {
        arp_memset(mac_out, 0, ETH_ADDR_LEN);
        return EOK;
    }

    uint64_t f = spinlock_irqsave(&s_cache_lock);
    for (int i = 0; i < ARP_CACHE_SIZE; i++) {
        if (s_cache[i].valid && s_cache[i].ip == ip) {
            arp_memcpy(mac_out, s_cache[i].mac, ETH_ADDR_LEN);
            spinlock_irqrestore(&s_cache_lock, f);
            return EOK;
        }
    }
    spinlock_irqrestore(&s_cache_lock, f);

    /* Cache miss: invia ARP request sulla NIC primaria */
    net_nic_t *nic = ethernet_get_nic(0);
    arp_send_request(nic, ip);
    return EAGAIN;
}

/* =========================================================================
 * arp_handle — processa frame ARP ricevuto
 * ========================================================================= */
void arp_handle(net_nic_t *nic, const void *data, uint16_t len) {
    if (len < (uint16_t)sizeof(arp_hdr_t)) return;

    const arp_hdr_t *arp = (const arp_hdr_t *)data;

    /* Verifica che sia ARP IPv4/Ethernet */
    if (net_ntoh16(arp->htype) != ARP_HTYPE_ETH) return;
    if (net_ntoh16(arp->ptype) != ETH_TYPE_IPV4)  return;
    if (arp->hlen != ETH_ADDR_LEN || arp->plen != 4) return;

    uint16_t oper   = net_ntoh16(arp->oper);
    uint32_t spa    = net_ntoh32(arp->spa);  /* Sender IP */
    uint32_t tpa    = net_ntoh32(arp->tpa);  /* Target IP */

    /* Aggiorna sempre la cache per il mittente */
    if (spa && !arp_maceq(arp->sha, s_bcast_mac)) {
        arp_update(spa, arp->sha);
    }

    if (oper == ARP_OPER_REQ && tpa == s_local_ip && nic) {
        /* ARP request per il nostro IP: invia reply */
        arp_hdr_t rep;
        arp_memcpy(&rep, arp, sizeof(rep));
        rep.oper = net_hton16(ARP_OPER_REP);
        /* Scambia mittente/destinatario */
        arp_memcpy(rep.tha, arp->sha, ETH_ADDR_LEN);
        rep.tpa = arp->spa;
        arp_memcpy(rep.sha, nic->mac, ETH_ADDR_LEN);
        rep.spa = net_hton32(s_local_ip);

        ethernet_send(nic, arp->sha, ETH_TYPE_ARP, &rep, (uint16_t)sizeof(rep));
    }
    /* ARP reply: già aggiornata la cache sopra */
}
