#ifndef MATTIAOS_SOCKET_H
#define MATTIAOS_SOCKET_H

/*
 * socket.h — BSD socket API (POSIX subset)
 *
 * Ogni socket è un file descriptor nel fd_table del processo, backed
 * da un vnode devfs con vfs_ops_t.  read/write/close sul fd delegano
 * a sock_vfs_read/write/close qui definiti.
 *
 * Famiglie:   AF_INET (IPv4)
 * Tipi:       SOCK_STREAM (TCP), SOCK_DGRAM (UDP)
 * Protocolli: IPPROTO_TCP, IPPROTO_UDP (0 = default per tipo)
 */

#include "../include/types.h"
#include "../include/errno.h"
#include "tcp.h"
#include "udp.h"
#include "../fs/vfs.h"
#include "../proc/process.h"

/* =========================================================================
 * Costanti AF / tipo / protocollo
 * ========================================================================= */
#define AF_INET        2
#define SOCK_STREAM    1    /* TCP */
#define SOCK_DGRAM     2    /* UDP */

#define IPPROTO_TCP    6
#define IPPROTO_UDP    17
#define IPPROTO_IP     0    /* Default: TCP per STREAM, UDP per DGRAM */

/* =========================================================================
 * sockaddr_in — indirizzo IPv4 (POSIX)
 * ========================================================================= */
typedef struct __attribute__((packed)) {
    uint16_t sin_family;   /* AF_INET */
    uint16_t sin_port;     /* Porta in network byte order (big-endian) */
    uint32_t sin_addr;     /* IPv4 in network byte order */
    uint8_t  sin_zero[8];
} sockaddr_in_t;

/* Alias POSIX generico */
typedef sockaddr_in_t sockaddr_t;

/* INADDR_ANY e INADDR_BROADCAST */
#define INADDR_ANY        0x00000000u
#define INADDR_BROADCAST  0xFFFFFFFFu

/* =========================================================================
 * setsockopt — livello e opzioni
 * ========================================================================= */
#define SOL_SOCKET       1
#define SO_REUSEADDR     2
#define SO_KEEPALIVE     9
#define SO_RCVBUF        8
#define SO_SNDBUF        7

#define IPPROTO_TCP_OPT  6
#define TCP_NODELAY      1    /* Disabilita Nagle (non implementato, accettato) */

/* =========================================================================
 * socket_t — descrittore interno
 * ========================================================================= */
typedef enum {
    SOCK_PROTO_TCP,
    SOCK_PROTO_UDP,
} sock_proto_t;

typedef struct socket {
    bool        valid;
    int         domain;      /* AF_INET */
    int         type;        /* SOCK_STREAM / SOCK_DGRAM */
    sock_proto_t proto;

    /* Stato connessione */
    bool        bound;
    bool        listening;
    bool        connected;
    bool        nonblock;

    /* Indirizzi locali e remoti (host byte order) */
    uint32_t    local_ip;
    uint16_t    local_port;
    uint32_t    remote_ip;
    uint16_t    remote_port;

    /* Puntatori al sottosistema di trasporto */
    tcp_conn_t *tcp_conn;    /* Non NULL per SOCK_STREAM */
    udp_socket_t *udp_sock;  /* Non NULL per SOCK_DGRAM */

    /* vnode associato per l'integrazione VFS */
    vnode_t     vnode;
    vfs_ops_t   vops;        /* Vtable — inizializzata da socket_create */

    spinlock_t  lock;
} socket_t;

/* Numero massimo di socket aperti contemporaneamente */
#define SOCK_MAX  32  /* Ridotto per boot iniziale */

/* =========================================================================
 * API pubblica — syscall-level (operano su fd del processo corrente)
 * ========================================================================= */

/*
 * sys_socket — crea un nuovo socket.
 * @domain:   AF_INET.
 * @type:     SOCK_STREAM o SOCK_DGRAM.
 * @protocol: IPPROTO_TCP, IPPROTO_UDP o 0 (auto).
 * @return:   file descriptor >= 0, o errore negativo.
 */
int sys_socket(int domain, int type, int protocol);

/*
 * sys_bind — associa il socket a un indirizzo locale.
 * @sockfd: fd del socket.
 * @addr:   puntatore a sockaddr_in_t con sin_family=AF_INET,
 *          sin_port e sin_addr in network byte order.
 * @addrlen: sizeof(sockaddr_in_t).
 * @return:  EOK, EBADF, EINVAL, EADDRINUSE.
 */
int sys_bind(int sockfd, const sockaddr_t *addr, uint32_t addrlen);

/*
 * sys_listen — pone il socket TCP in stato di ascolto.
 * @sockfd:  fd del socket.
 * @backlog: dimensione coda connessioni in attesa (ignorato — sempre 8).
 * @return:  EOK, EBADF, EINVAL, EOPNOTSUPP (su UDP).
 */
int sys_listen(int sockfd, int backlog);

/*
 * sys_accept — estrae la prima connessione completata dalla coda.
 * Blocca se nessuna connessione è disponibile.
 * @sockfd:    fd del socket LISTEN.
 * @addr_out:  se non NULL, riceve l'indirizzo del client.
 * @addrlen:   puntatore alla dimensione del buffer addr_out.
 * @return:    nuovo fd per la connessione accettata, o errore.
 */
int sys_accept(int sockfd, sockaddr_t *addr_out, uint32_t *addrlen);

/*
 * sys_connect — avvia connessione attiva TCP o imposta destinazione UDP.
 * @sockfd: fd del socket.
 * @addr:   indirizzo destinazione.
 * @addrlen: sizeof(sockaddr_in_t).
 * @return:  EOK (connessione avviata/stabilita), o errore.
 *
 * Per TCP: blocca finché la connessione non è ESTABLISHED o fallisce.
 * Per UDP: registra solo l'indirizzo remoto (sendto semplificato).
 */
int sys_connect(int sockfd, const sockaddr_t *addr, uint32_t addrlen);

/*
 * sys_send — invia dati su socket connesso.
 * @sockfd: fd.
 * @buf:    dati da inviare.
 * @len:    dimensione.
 * @flags:  ignorati (0).
 * @return: byte inviati, o errore.
 */
int sys_send(int sockfd, const void *buf, size_t len, int flags);

/*
 * sys_recv — riceve dati da socket connesso.
 * @sockfd: fd.
 * @buf:    buffer di output.
 * @len:    dimensione massima.
 * @flags:  ignorati (0).
 * @return: byte ricevuti (0 = EOF/connessione chiusa), o errore.
 */
int sys_recv(int sockfd, void *buf, size_t len, int flags);

/*
 * sys_sendto — invia un datagramma UDP a indirizzo specificato.
 * @sockfd:  fd UDP.
 * @buf:     dati.
 * @len:     dimensione.
 * @flags:   ignorati.
 * @dst:     indirizzo destinazione.
 * @addrlen: sizeof(sockaddr_in_t).
 * @return:  byte inviati, o errore.
 */
int sys_sendto(int sockfd, const void *buf, size_t len, int flags,
               const sockaddr_t *dst, uint32_t addrlen);

/*
 * sys_recvfrom — riceve un datagramma UDP con indirizzo mittente.
 * @sockfd:     fd UDP.
 * @buf:        buffer di output.
 * @len:        dimensione massima.
 * @flags:      ignorati.
 * @src_out:    riceve l'indirizzo mittente (può essere NULL).
 * @addrlen:    puntatore alla dimensione (in/out).
 * @return:     byte ricevuti, o errore.
 */
int sys_recvfrom(int sockfd, void *buf, size_t len, int flags,
                 sockaddr_t *src_out, uint32_t *addrlen);

/*
 * sys_setsockopt — imposta opzione sul socket.
 * @sockfd:   fd.
 * @level:    SOL_SOCKET o IPPROTO_TCP_OPT.
 * @optname:  SO_REUSEADDR, SO_KEEPALIVE, TCP_NODELAY, ecc.
 * @optval:   puntatore al valore (int).
 * @optlen:   sizeof(int).
 * @return:   EOK, EBADF, EINVAL (opzione non riconosciuta — tollerata).
 */
int sys_setsockopt(int sockfd, int level, int optname,
                   const void *optval, uint32_t optlen);

/*
 * sys_close_socket — chiude il socket e libera le risorse.
 * Chiamata automaticamente da vfs_close quando il fd viene chiuso.
 */
int sys_close_socket(int sockfd);

/* =========================================================================
 * API interna — usata dal layer socket per collegare tcp_conn a socket_t
 * ========================================================================= */

/*
 * socket_from_tcp — restituisce il socket_t associato a una tcp_conn_t.
 * Usato da tcp.c per notificare eventi (ESTABLISHED, CLOSE_WAIT, ecc.)
 * tramite il campo conn->sock.
 */
socket_t *socket_from_tcp(tcp_conn_t *conn);

#endif /* MATTIAOS_SOCKET_H */
