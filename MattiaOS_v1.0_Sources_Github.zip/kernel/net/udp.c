#include "udp.h"
#include "icmp.h"
#include "../mm/slab.h"
#include "../sched/mlfq.h"
#include "../proc/process.h"
#include "../arch/x86_64/cpu.h"

/* =========================================================================
 * Tabella globale socket UDP
 * ========================================================================= */
static udp_socket_t  s_sockets[UDP_MAX_SOCKETS];
static spinlock_t    s_table_lock = {0};
static uint16_t      s_ephemeral  = 49152u;  /* Porta effimera corrente */

/* =========================================================================
 * Helper no-libc
 * ========================================================================= */
static inline void udp_memcpy(void *d, const void *s, size_t n) {
    uint8_t *dd = (uint8_t *)d;
    const uint8_t *ss = (const uint8_t *)s;
    for (size_t i = 0; i < n; i++) dd[i] = ss[i];
}
static inline void udp_memset(void *d, int v, size_t n) {
    uint8_t *dd = (uint8_t *)d;
    for (size_t i = 0; i < n; i++) dd[i] = (uint8_t)v;
}

/* =========================================================================
 * udp_socket_alloc / free
 * ========================================================================= */
udp_socket_t *udp_socket_alloc(void) {
    uint64_t f = spinlock_irqsave(&s_table_lock);
    for (int i = 0; i < UDP_MAX_SOCKETS; i++) {
        if (!s_sockets[i].valid) {
            udp_memset(&s_sockets[i], 0, sizeof(udp_socket_t));
            s_sockets[i].valid = true;
            spinlock_irqrestore(&s_table_lock, f);
            return &s_sockets[i];
        }
    }
    spinlock_irqrestore(&s_table_lock, f);
    return NULL;
}

void udp_socket_free(udp_socket_t *sock) {
    if (!sock) return;
    uint64_t f = spinlock_irqsave(&sock->lock);
    udp_memset(sock, 0, sizeof(udp_socket_t));
    spinlock_irqrestore(&sock->lock, f);
}

/* =========================================================================
 * udp_ephemeral_port
 * ========================================================================= */
uint16_t udp_ephemeral_port(void) {
    uint64_t f = spinlock_irqsave(&s_table_lock);
    uint16_t p = s_ephemeral++;
    if (s_ephemeral == 0) s_ephemeral = 49152u;
    spinlock_irqrestore(&s_table_lock, f);
    return p;
}

/* =========================================================================
 * udp_bind
 * ========================================================================= */
int udp_bind(udp_socket_t *sock, uint32_t ip, uint16_t port) {
    if (!sock) return EINVAL;

    if (port == 0) port = udp_ephemeral_port();

    /* Controlla collisioni */
    uint64_t f = spinlock_irqsave(&s_table_lock);
    for (int i = 0; i < UDP_MAX_SOCKETS; i++) {
        if (&s_sockets[i] == sock) continue;
        if (!s_sockets[i].valid) continue;
        if (s_sockets[i].local_port == port &&
            (s_sockets[i].local_ip == ip || ip == 0 || s_sockets[i].local_ip == 0)) {
            spinlock_irqrestore(&s_table_lock, f);
            return EADDRINUSE;
        }
    }
    sock->local_port = port;
    sock->local_ip   = ip;
    spinlock_irqrestore(&s_table_lock, f);
    return EOK;
}

/* =========================================================================
 * Calcola checksum UDP
 * ========================================================================= */
static uint16_t udp_checksum(uint32_t src_ip, uint32_t dst_ip,
                               const void *udp_data, uint16_t udp_len) {
    udp_pseudo_hdr_t ph;
    ph.src_ip  = net_hton32(src_ip);
    ph.dst_ip  = net_hton32(dst_ip);
    ph.zero    = 0;
    ph.proto   = IP_PROTO_UDP;
    ph.udp_len = net_hton16(udp_len);

    /* Checksum su pseudo-header + segmento UDP */
    uint32_t sum = 0;
    size_t n;

    /* Use byte pointer to avoid packed-struct alignment warning */
    const uint8_t *pb = (const uint8_t *)&ph;
    n = sizeof(ph);
    while (n > 1) { sum += (uint16_t)(pb[0] << 8 | pb[1]); pb += 2; n -= 2; }

    const uint16_t *p = (const uint16_t *)udp_data;
    n = udp_len;
    while (n > 1) { sum += *p++; n -= 2; }
    if (n) sum += *(const uint8_t *)p;

    while (sum >> 16) sum = (sum & 0xFFFFu) + (sum >> 16);
    return (uint16_t)~sum;
}

/* =========================================================================
 * udp_send
 * ========================================================================= */
int udp_send(udp_socket_t *sock, uint32_t dst_ip, uint16_t dst_port,
             const void *data, uint16_t len) {
    if (!sock || !data || len > UDP_MAX_PAYLOAD) return EINVAL;

    uint16_t src_port = sock->local_port;
    if (!src_port) src_port = udp_ephemeral_port();

    uint16_t udp_len = (uint16_t)(UDP_HDR_SIZE + len);

    uint8_t buf[UDP_HDR_SIZE + UDP_MAX_PAYLOAD];
    udp_hdr_t *hdr = (udp_hdr_t *)buf;
    hdr->src_port = net_hton16(src_port);
    hdr->dst_port = net_hton16(dst_port);
    hdr->length   = net_hton16(udp_len);
    hdr->checksum = 0;

    udp_memcpy(buf + UDP_HDR_SIZE, data, len);

    uint32_t src_ip = sock->local_ip ? sock->local_ip : ipv4_get_local_ip();
    hdr->checksum = udp_checksum(src_ip, dst_ip, buf, udp_len);

    return ipv4_send(dst_ip, IP_PROTO_UDP, buf, udp_len);
}

/* =========================================================================
 * udp_recv
 * ========================================================================= */
int udp_recv(udp_socket_t *sock, void *buf, uint16_t buf_size,
             uint32_t *src_ip_out, uint16_t *src_port_out) {
    if (!sock || !buf || buf_size == 0) return EINVAL;

    while (1) {
        uint64_t f = spinlock_irqsave(&sock->lock);

        if (sock->q_count > 0) {
            udp_dgram_t *dg = &sock->queue[sock->q_head];
            uint16_t to_copy = dg->len < buf_size ? dg->len : buf_size;
            udp_memcpy(buf, dg->data, to_copy);
            if (src_ip_out)   *src_ip_out   = dg->src_ip;
            if (src_port_out) *src_port_out = dg->src_port;
            sock->q_head = (sock->q_head + 1) % UDP_RECV_QUEUE_LEN;
            sock->q_count--;
            spinlock_irqrestore(&sock->lock, f);
            return (int)to_copy;
        }

        /* Coda vuota: blocca thread */
        if (sock->waiter_count < 8) {
            sock->waiters[sock->waiter_count++] = g_current_thread;
        }
        spinlock_irqrestore(&sock->lock, f);
        scheduler_block(g_current_thread);
        scheduler_yield();
    }
}

/* =========================================================================
 * udp_handle — ricezione dal layer IPv4
 * ========================================================================= */
void udp_handle(uint32_t src_ip, uint32_t dst_ip,
                const void *data, uint16_t len) {
    if (len < UDP_HDR_SIZE) return;

    const udp_hdr_t *hdr = (const udp_hdr_t *)data;
    uint16_t src_port = net_ntoh16(hdr->src_port);
    uint16_t dst_port = net_ntoh16(hdr->dst_port);
    uint16_t udp_len  = net_ntoh16(hdr->length);

    if (udp_len < UDP_HDR_SIZE || udp_len > len) return;

    /* Verifica checksum se non zero */
    if (hdr->checksum != 0) {
        if (udp_checksum(src_ip, dst_ip, data, udp_len) != 0) return;
    }

    const uint8_t *payload = (const uint8_t *)data + UDP_HDR_SIZE;
    uint16_t       plen    = (uint16_t)(udp_len - UDP_HDR_SIZE);
    if (plen > UDP_MAX_PAYLOAD) plen = UDP_MAX_PAYLOAD;

    /* Cerca socket con porta corrispondente */
    uint64_t f = spinlock_irqsave(&s_table_lock);
    udp_socket_t *target = NULL;
    for (int i = 0; i < UDP_MAX_SOCKETS; i++) {
        if (!s_sockets[i].valid) continue;
        if (s_sockets[i].local_port != dst_port) continue;
        if (s_sockets[i].local_ip != 0 &&
            s_sockets[i].local_ip != dst_ip) continue;
        target = &s_sockets[i];
        break;
    }
    spinlock_irqrestore(&s_table_lock, f);

    if (!target) {
        /* Porta non in ascolto: invia ICMP Port Unreachable */
        /* orig = IP header + 8 byte UDP — costruito dal caller (ipv4_handle) */
        /* Per ora limitato: segnala solo se non è broadcast */
        if (dst_ip != 0xFFFFFFFFu)
            icmp_send_unreachable(src_ip, ICMP_CODE_PORT_UNREACH, data, 8);
        return;
    }

    /* Inserisci nella coda del socket */
    uint64_t sf = spinlock_irqsave(&target->lock);
    if (target->q_count < UDP_RECV_QUEUE_LEN) {
        udp_dgram_t *dg = &target->queue[target->q_tail];
        udp_memcpy(dg->data, payload, plen);
        dg->src_ip   = src_ip;
        dg->src_port = src_port;
        dg->len      = plen;
        target->q_tail  = (target->q_tail + 1) % UDP_RECV_QUEUE_LEN;
        target->q_count++;
    }
    /* Sveglia il primo waiter */
    if (target->waiter_count > 0) {
        thread_t *t = target->waiters[0];
        uint32_t last = target->waiter_count - 1;
        target->waiters[0] = target->waiters[last];
        target->waiters[last] = NULL;
        target->waiter_count--;
        spinlock_irqrestore(&target->lock, sf);
        scheduler_unblock(t);
    } else {
        spinlock_irqrestore(&target->lock, sf);
    }
}
