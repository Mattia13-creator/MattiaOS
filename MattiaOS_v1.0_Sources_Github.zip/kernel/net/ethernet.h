#ifndef MATTIAOS_ETHERNET_H
#define MATTIAOS_ETHERNET_H

/*
 * ethernet.h — Layer 2: parsing e dispatch frame Ethernet
 *
 * ethernet_init() scorre il device tree e installa ethernet_rx come
 * rx_callback su ogni device DEV_TYPE_NET attivo.  Va chiamata in
 * drivers_init() dopo virtio_net_init() / e1000_init().
 *
 * Dipendenze obbligatorie: driver.h (device_t, net_ops_t), types.h.
 */

#include "../include/types.h"
#include "../drivers/driver.h"

/* =========================================================================
 * Byte-order helpers (little-endian host ↔ big-endian network)
 * Definiti qui perché usati da tutti i livelli dello stack.
 * ========================================================================= */
static inline uint16_t net_hton16(uint16_t x) {
    return (uint16_t)((x >> 8) | (x << 8));
}
static inline uint32_t net_hton32(uint32_t x) {
    return ((x >> 24)) | ((x >> 8) & 0xFF00u) |
           ((x << 8) & 0xFF0000u) | ((x << 24));
}
#define net_ntoh16 net_hton16
#define net_ntoh32 net_hton32

/* =========================================================================
 * Costanti Ethernet
 * ========================================================================= */
#define ETH_ADDR_LEN       6
#define ETH_HDR_SIZE       14
#define ETH_MAX_PAYLOAD    1500
#define ETH_MAX_FRAME      (ETH_HDR_SIZE + ETH_MAX_PAYLOAD)  /* 1514 byte */

#define ETH_TYPE_IPV4      0x0800u
#define ETH_TYPE_ARP       0x0806u
#define ETH_TYPE_IPV6      0x86DDu

#define NET_MAX_NICS       4   /* NIC contemporanee tracciate */

/* =========================================================================
 * Strutture
 * ========================================================================= */
typedef struct __attribute__((packed)) {
    uint8_t  dst[ETH_ADDR_LEN];
    uint8_t  src[ETH_ADDR_LEN];
    uint16_t ethertype;         /* big-endian */
} eth_hdr_t;

/* Descrittore NIC: puntatore al device + cache MAC */
typedef struct {
    device_t *dev;
    uint8_t   mac[ETH_ADDR_LEN];
    bool      active;
} net_nic_t;

/* =========================================================================
 * API pubblica
 * ========================================================================= */

/*
 * ethernet_init — scansiona il device tree, installa rx_callback su ogni
 * NIC attiva, carica i MAC address nella tabella interna.
 * Da chiamare dopo tutti i driver NIC (fine di drivers_init).
 */
void ethernet_init(void);

/*
 * ethernet_send — costruisce l'header ETH e chiama net_ops->send_packet.
 * @nic:         NIC di uscita (NULL = NIC primaria, indice 0).
 * @dst_mac:     MAC destinazione 6 byte.
 * @ethertype:   tipo protocollo in host byte order (ETH_TYPE_IPV4 ecc.).
 * @payload:     dati del livello superiore.
 * @payload_len: dimensione payload in byte (max ETH_MAX_PAYLOAD).
 * @return:      EOK oppure EIO/EINVAL.
 */
int ethernet_send(net_nic_t *nic, const uint8_t *dst_mac, uint16_t ethertype,
                  const void *payload, uint16_t payload_len);

/*
 * ethernet_rx — entry point per frame in arrivo; chiamata dalla NIC via
 * net_ops_t.rx_callback.  Verifica lunghezza, toglie header ETH, dispatch
 * verso arp_handle() o ipv4_handle() in base all'ethertype.
 */
void ethernet_rx(device_t *dev, const void *data, uint16_t len);

/* Restituisce il puntatore alla NIC all'indice richiesto (0 = primaria). */
net_nic_t *ethernet_get_nic(int index);

/* Numero di NIC attualmente registrate. */
int ethernet_nic_count(void);

#endif /* MATTIAOS_ETHERNET_H */
