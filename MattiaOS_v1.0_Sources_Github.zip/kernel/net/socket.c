#include "socket.h"
#include "../arch/x86_64/cpu.h"
#include "../mm/slab.h"      /* kzalloc, kfree */
#include "../sched/mlfq.h"   /* scheduler_block, scheduler_yield */

/* =========================================================================
 * Tabella globale socket
 * ========================================================================= */
static socket_t   s_sockets[SOCK_MAX];
static spinlock_t s_table_lock = {0};

/* =========================================================================
 * Helper no-libc
 * ========================================================================= */
static inline void sock_memset(void *d, int v, size_t n) {
    uint8_t *dd = (uint8_t *)d;
    for (size_t i = 0; i < n; i++) dd[i] = (uint8_t)v;
}

/* =========================================================================
 * Lookup socket da fd del processo corrente
 * ========================================================================= */
static socket_t *sock_from_fd(int fd) {
    if (!g_current_process) return NULL;
    if (fd < 0 || fd >= FD_MAX) return NULL;
    file_t *f = g_current_process->fd_table[fd];
    if (!f || !f->vnode) return NULL;
    /* Il vnode fs_data punta alla socket_t */
    return (socket_t *)f->vnode->fs_data;
}

/* =========================================================================
 * Alloca slot socket interno
 * ========================================================================= */
static socket_t *sock_alloc(void) {
    uint64_t f = spinlock_irqsave(&s_table_lock);
    for (int i = 0; i < SOCK_MAX; i++) {
        if (!s_sockets[i].valid) {
            sock_memset(&s_sockets[i], 0, sizeof(socket_t));
            s_sockets[i].valid = true;
            spinlock_irqrestore(&s_table_lock, f);
            return &s_sockets[i];
        }
    }
    spinlock_irqrestore(&s_table_lock, f);
    return NULL;
}

/* =========================================================================
 * VFS ops — delegano ai layer TCP/UDP
 * ========================================================================= */
static ssize_t sock_vfs_read(vnode_t *node, void *buf, size_t count, off_t offset) {
    (void)offset;
    socket_t *sock = (socket_t *)node->fs_data;
    if (!sock) return EBADF;

    if (sock->proto == SOCK_PROTO_TCP && sock->tcp_conn) {
        return (ssize_t)tcp_recv(sock->tcp_conn, buf, (uint32_t)count);
    } else if (sock->proto == SOCK_PROTO_UDP && sock->udp_sock) {
        return (ssize_t)udp_recv(sock->udp_sock, buf, (uint16_t)count,
                                  NULL, NULL);
    }
    return EINVAL;
}

static ssize_t sock_vfs_write(vnode_t *node, const void *buf, size_t count, off_t offset) {
    (void)offset;
    socket_t *sock = (socket_t *)node->fs_data;
    if (!sock) return EBADF;

    if (sock->proto == SOCK_PROTO_TCP && sock->tcp_conn) {
        return (ssize_t)tcp_send(sock->tcp_conn, buf, (uint32_t)count);
    } else if (sock->proto == SOCK_PROTO_UDP && sock->udp_sock) {
        return (ssize_t)udp_send(sock->udp_sock, sock->remote_ip,
                                  sock->remote_port, buf, (uint16_t)count);
    }
    return EINVAL;
}

static int sock_vfs_close(vnode_t *node) {
    socket_t *sock = (socket_t *)node->fs_data;
    if (!sock || !sock->valid) return EBADF;

    if (sock->proto == SOCK_PROTO_TCP && sock->tcp_conn) {
        tcp_close(sock->tcp_conn);
        tcp_free(sock->tcp_conn);
        sock->tcp_conn = NULL;
    } else if (sock->proto == SOCK_PROTO_UDP && sock->udp_sock) {
        udp_socket_free(sock->udp_sock);
        sock->udp_sock = NULL;
    }

    uint64_t f = spinlock_irqsave(&s_table_lock);
    sock_memset(sock, 0, sizeof(socket_t));
    spinlock_irqrestore(&s_table_lock, f);
    return EOK;
}

static vfs_ops_t s_sock_vops = {
    .open    = NULL,
    .close   = sock_vfs_close,
    .read    = sock_vfs_read,
    .write   = sock_vfs_write,
    .readdir = NULL,
    .stat    = NULL,
    .create  = NULL,
    .mkdir   = NULL,
    .unlink  = NULL,
    .mmap    = NULL,
    .ioctl   = NULL,
};

/* =========================================================================
 * Installa socket come fd nel processo corrente
 * ========================================================================= */
static int install_fd(socket_t *sock) {
    process_t *proc = g_current_process;
    if (!proc) return EINVAL;

    /* Trova il primo fd libero */
    for (int i = 0; i < FD_MAX; i++) {
        if (!proc->fd_table[i]) {
            file_t *f = (file_t *)kzalloc(sizeof(file_t));
            if (!f) return ENOMEM;

            /* Inizializza il vnode embedded */
            sock->vnode.fs_data  = sock;
            sock->vnode.ops      = &s_sock_vops;
            sock->vnode.size     = 0;
            sock->vnode.mode     = 0600;

            f->vnode  = &sock->vnode;
            f->offset = 0;
            f->flags  = 0;

            proc->fd_table[i] = f;
            return i;
        }
    }
    return EMFILE;
}

/* =========================================================================
 * sys_socket
 * ========================================================================= */
int sys_socket(int domain, int type, int protocol) {
    if (domain != AF_INET) return EAFNOSUPPORT;
    if (type != SOCK_STREAM && type != SOCK_DGRAM) return EINVAL;

    sock_proto_t proto;
    if (type == SOCK_STREAM) {
        if (protocol != IPPROTO_TCP && protocol != IPPROTO_IP) return EPROTONOSUPPORT;
        proto = SOCK_PROTO_TCP;
    } else {
        if (protocol != IPPROTO_UDP && protocol != IPPROTO_IP) return EPROTONOSUPPORT;
        proto = SOCK_PROTO_UDP;
    }

    socket_t *sock = sock_alloc();
    if (!sock) return ENOMEM;

    sock->domain = domain;
    sock->type   = type;
    sock->proto  = proto;

    if (proto == SOCK_PROTO_UDP) {
        sock->udp_sock = udp_socket_alloc();
        if (!sock->udp_sock) {
            sock->valid = false;
            return ENOMEM;
        }
    }
    /* TCP: tcp_conn allocata solo a connect/accept */

    int fd = install_fd(sock);
    if (fd < 0) {
        if (sock->udp_sock) udp_socket_free(sock->udp_sock);
        sock->valid = false;
        return fd;
    }
    return fd;
}

/* =========================================================================
 * sys_bind
 * ========================================================================= */
int sys_bind(int sockfd, const sockaddr_t *addr, uint32_t addrlen) {
    if (!addr || addrlen < sizeof(sockaddr_in_t)) return EINVAL;
    socket_t *sock = sock_from_fd(sockfd);
    if (!sock) return EBADF;
    if (sock->bound) return EINVAL;

    const sockaddr_in_t *sin = (const sockaddr_in_t *)addr;
    if (sin->sin_family != AF_INET) return EAFNOSUPPORT;

    uint32_t ip   = net_ntoh32(sin->sin_addr);
    uint16_t port = net_ntoh16(sin->sin_port);

    if (sock->proto == SOCK_PROTO_UDP) {
        int r = udp_bind(sock->udp_sock, ip, port);
        if (r != EOK) return r;
        sock->local_ip   = ip;
        sock->local_port = sock->udp_sock->local_port;
    } else {
        /* TCP bind: solo registrazione locale; listen/connect completa */
        sock->local_ip   = ip;
        sock->local_port = port;
    }
    sock->bound = true;
    return EOK;
}

/* =========================================================================
 * sys_listen
 * ========================================================================= */
int sys_listen(int sockfd, int backlog) {
    (void)backlog;
    socket_t *sock = sock_from_fd(sockfd);
    if (!sock) return EBADF;
    if (sock->proto != SOCK_PROTO_TCP) return EOPNOTSUPP;
    if (sock->listening) return EOK;  /* Idempotente */

    tcp_conn_t *listener = NULL;
    int r = tcp_listen(sock->local_port, &listener);
    if (r != EOK) return r;

    listener->sock  = sock;
    sock->tcp_conn  = listener;
    sock->listening = true;
    return EOK;
}

/* =========================================================================
 * sys_accept
 * ========================================================================= */
int sys_accept(int sockfd, sockaddr_t *addr_out, uint32_t *addrlen) {
    socket_t *sock = sock_from_fd(sockfd);
    if (!sock) return EBADF;
    if (!sock->listening || sock->proto != SOCK_PROTO_TCP) return EINVAL;

    tcp_conn_t *new_conn = tcp_accept(sock->tcp_conn);
    if (!new_conn) return EIO;

    /* Crea nuovo socket per la connessione accettata */
    socket_t *new_sock = sock_alloc();
    if (!new_sock) {
        tcp_close(new_conn);
        tcp_free(new_conn);
        return ENOMEM;
    }
    new_sock->domain     = AF_INET;
    new_sock->type       = SOCK_STREAM;
    new_sock->proto      = SOCK_PROTO_TCP;
    new_sock->tcp_conn   = new_conn;
    new_sock->connected  = true;
    new_sock->bound      = true;
    new_sock->local_ip   = new_conn->local_ip;
    new_sock->local_port = new_conn->local_port;
    new_sock->remote_ip  = new_conn->remote_ip;
    new_sock->remote_port = new_conn->remote_port;
    new_conn->sock = new_sock;

    if (addr_out && addrlen && *addrlen >= sizeof(sockaddr_in_t)) {
        sockaddr_in_t *sin  = (sockaddr_in_t *)addr_out;
        sin->sin_family     = AF_INET;
        sin->sin_addr       = net_hton32(new_conn->remote_ip);
        sin->sin_port       = net_hton16(new_conn->remote_port);
        sock_memset(sin->sin_zero, 0, sizeof(sin->sin_zero));
        *addrlen = sizeof(sockaddr_in_t);
    }

    int fd = install_fd(new_sock);
    if (fd < 0) {
        tcp_close(new_conn);
        tcp_free(new_conn);
        new_sock->valid = false;
        return fd;
    }
    return fd;
}

/* =========================================================================
 * sys_connect
 * ========================================================================= */
int sys_connect(int sockfd, const sockaddr_t *addr, uint32_t addrlen) {
    if (!addr || addrlen < sizeof(sockaddr_in_t)) return EINVAL;
    socket_t *sock = sock_from_fd(sockfd);
    if (!sock) return EBADF;

    const sockaddr_in_t *sin = (const sockaddr_in_t *)addr;
    if (sin->sin_family != AF_INET) return EAFNOSUPPORT;

    uint32_t dst_ip   = net_ntoh32(sin->sin_addr);
    uint16_t dst_port = net_ntoh16(sin->sin_port);

    if (sock->proto == SOCK_PROTO_UDP) {
        /* UDP connect: solo registra l'indirizzo remoto */
        sock->remote_ip   = dst_ip;
        sock->remote_port = dst_port;
        sock->connected   = true;
        return EOK;
    }

    /* TCP connect */
    if (sock->connected) return EISCONN;

    tcp_conn_t *conn = NULL;
    int r = tcp_connect(dst_ip, dst_port, &conn);
    if (r != EOK) return r;

    sock->tcp_conn   = conn;
    conn->sock       = sock;
    sock->remote_ip  = dst_ip;
    sock->remote_port = dst_port;

    /* Blocca finché la connessione non è ESTABLISHED o fallisce */
    while (conn->state == TCP_SYN_SENT) {
        if (conn->waiter_count < 4) {
            conn->waiters[conn->waiter_count++] = g_current_thread;
        }
        scheduler_block(g_current_thread);
        scheduler_yield();
    }

    if (conn->state != TCP_ESTABLISHED) {
        tcp_free(conn);
        sock->tcp_conn = NULL;
        return ECONNREFUSED;
    }

    sock->connected  = true;
    sock->local_ip   = conn->local_ip;
    sock->local_port = conn->local_port;
    return EOK;
}

/* =========================================================================
 * sys_send
 * ========================================================================= */
int sys_send(int sockfd, const void *buf, size_t len, int flags) {
    (void)flags;
    socket_t *sock = sock_from_fd(sockfd);
    if (!sock) return EBADF;
    if (!sock->connected) return ENOTCONN;

    if (sock->proto == SOCK_PROTO_TCP && sock->tcp_conn)
        return tcp_send(sock->tcp_conn, buf, (uint32_t)len);

    if (sock->proto == SOCK_PROTO_UDP && sock->udp_sock)
        return udp_send(sock->udp_sock, sock->remote_ip, sock->remote_port,
                        buf, (uint16_t)len);
    return EINVAL;
}

/* =========================================================================
 * sys_recv
 * ========================================================================= */
int sys_recv(int sockfd, void *buf, size_t len, int flags) {
    (void)flags;
    socket_t *sock = sock_from_fd(sockfd);
    if (!sock) return EBADF;

    if (sock->proto == SOCK_PROTO_TCP && sock->tcp_conn)
        return tcp_recv(sock->tcp_conn, buf, (uint32_t)len);

    if (sock->proto == SOCK_PROTO_UDP && sock->udp_sock)
        return udp_recv(sock->udp_sock, buf, (uint16_t)len, NULL, NULL);

    return EINVAL;
}

/* =========================================================================
 * sys_sendto
 * ========================================================================= */
int sys_sendto(int sockfd, const void *buf, size_t len, int flags,
               const sockaddr_t *dst, uint32_t addrlen) {
    (void)flags;
    socket_t *sock = sock_from_fd(sockfd);
    if (!sock) return EBADF;
    if (sock->proto != SOCK_PROTO_UDP) return EOPNOTSUPP;

    uint32_t dst_ip   = 0;
    uint16_t dst_port = 0;
    if (dst && addrlen >= sizeof(sockaddr_in_t)) {
        const sockaddr_in_t *sin = (const sockaddr_in_t *)dst;
        dst_ip   = net_ntoh32(sin->sin_addr);
        dst_port = net_ntoh16(sin->sin_port);
    } else if (sock->connected) {
        dst_ip   = sock->remote_ip;
        dst_port = sock->remote_port;
    } else {
        return EDESTADDRREQ;
    }

    return udp_send(sock->udp_sock, dst_ip, dst_port, buf, (uint16_t)len);
}

/* =========================================================================
 * sys_recvfrom
 * ========================================================================= */
int sys_recvfrom(int sockfd, void *buf, size_t len, int flags,
                 sockaddr_t *src_out, uint32_t *addrlen) {
    (void)flags;
    socket_t *sock = sock_from_fd(sockfd);
    if (!sock) return EBADF;
    if (sock->proto != SOCK_PROTO_UDP) return EOPNOTSUPP;

    uint32_t src_ip   = 0;
    uint16_t src_port = 0;
    int r = udp_recv(sock->udp_sock, buf, (uint16_t)len, &src_ip, &src_port);
    if (r < 0) return r;

    if (src_out && addrlen && *addrlen >= sizeof(sockaddr_in_t)) {
        sockaddr_in_t *sin = (sockaddr_in_t *)src_out;
        sin->sin_family    = AF_INET;
        sin->sin_addr      = net_hton32(src_ip);
        sin->sin_port      = net_hton16(src_port);
        sock_memset(sin->sin_zero, 0, sizeof(sin->sin_zero));
        *addrlen = sizeof(sockaddr_in_t);
    }
    return r;
}

/* =========================================================================
 * sys_setsockopt
 * ========================================================================= */
int sys_setsockopt(int sockfd, int level, int optname,
                   const void *optval, uint32_t optlen) {
    (void)optval; (void)optlen;
    socket_t *sock = sock_from_fd(sockfd);
    if (!sock) return EBADF;

    /*
     * SO_REUSEADDR, SO_KEEPALIVE, TCP_NODELAY: accettati silenziosamente.
     * SO_RCVBUF / SO_SNDBUF: ignorati — buffer fissi a 64 KB.
     */
    if (level == SOL_SOCKET) {
        switch (optname) {
        case SO_REUSEADDR:
        case SO_KEEPALIVE:
        case SO_RCVBUF:
        case SO_SNDBUF:
            return EOK;
        default:
            return ENOPROTOOPT;
        }
    }
    if (level == IPPROTO_TCP_OPT && optname == TCP_NODELAY)
        return EOK;

    return ENOPROTOOPT;
}

/* =========================================================================
 * sys_close_socket
 * ========================================================================= */
int sys_close_socket(int sockfd) {
    socket_t *sock = sock_from_fd(sockfd);
    if (!sock) return EBADF;
    return sock_vfs_close(&sock->vnode);
}

/* =========================================================================
 * socket_from_tcp
 * ========================================================================= */
socket_t *socket_from_tcp(tcp_conn_t *conn) {
    if (!conn) return NULL;
    return (socket_t *)conn->sock;
}
