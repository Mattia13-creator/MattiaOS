#ifndef MATTIAOS_UDP_H
#define MATTIAOS_UDP_H

/*
 * udp.h — User Datagram Protocol (RFC 768)
 *
 * Ogni socket UDP è un udp_socket_t con binding opzionale su porta locale.
 * I datagrammi ricevuti vengono inseriti in un ring buffer per socket;
 * il consumer legge con udp_recv().
 * Demultiplexing: porta destinazione → socket corrispondente.
 */

#include "../include/types.h"
#include "../include/errno.h"
#include "ipv4.h"

/* =========================================================================
 * Costanti
 * ========================================================================= */
#define UDP_HDR_SIZE        8u
#define UDP_MAX_SOCKETS     16  /* Ridotto */
#define UDP_RECV_QUEUE_LEN  8       /* Ridotto per boot iniziale */
#define UDP_MAX_PAYLOAD     (ETH_MAX_PAYLOAD - IP_HDR_SIZE_MIN - UDP_HDR_SIZE)

/* =========================================================================
 * Header UDP on-wire
 * ========================================================================= */
typedef struct __attribute__((packed)) {
    uint16_t src_port;   /* big-endian */
    uint16_t dst_port;   /* big-endian */
    uint16_t length;     /* big-endian: header + data */
    uint16_t checksum;   /* big-endian: 0 = checksum disabilitato */
} udp_hdr_t;

/* Pseudo-header IPv4 per checksum UDP */
typedef struct __attribute__((packed)) {
    uint32_t src_ip;
    uint32_t dst_ip;
    uint8_t  zero;
    uint8_t  proto;      /* IP_PROTO_UDP = 17 */
    uint16_t udp_len;
} udp_pseudo_hdr_t;

/* =========================================================================
 * UDP socket
 * ========================================================================= */
typedef struct {
    uint8_t  data[UDP_MAX_PAYLOAD];
    uint16_t src_port;   /* host byte order */
    uint32_t src_ip;     /* host byte order */
    uint16_t len;
} udp_dgram_t;

typedef struct {
    bool     valid;
    uint16_t local_port;      /* host byte order; 0 = non bound */
    uint32_t local_ip;        /* host byte order; 0 = INADDR_ANY */
    uint32_t remote_ip;       /* host byte order; 0 = non connesso */
    uint16_t remote_port;     /* host byte order */

    /* Ring buffer di datagrammi ricevuti */
    udp_dgram_t  queue[UDP_RECV_QUEUE_LEN];
    uint32_t     q_head;
    uint32_t     q_tail;
    uint32_t     q_count;

    spinlock_t lock;

    /* Thread bloccati in attesa di dati */
    struct thread *waiters[8];
    uint32_t       waiter_count;
} udp_socket_t;

/* =========================================================================
 * API pubblica
 * ========================================================================= */

/*
 * udp_handle — entry point per datagrammi IPv4/UDP ricevuti.
 * Chiamata da ipv4_handle() con il payload UDP (header incluso).
 */
void udp_handle(uint32_t src_ip, uint32_t dst_ip,
                const void *data, uint16_t len);

/*
 * udp_socket_alloc — alloca un nuovo socket UDP.
 * @return: puntatore al socket, NULL se esauriti.
 */
udp_socket_t *udp_socket_alloc(void);

/*
 * udp_socket_free — libera un socket UDP.
 */
void udp_socket_free(udp_socket_t *sock);

/*
 * udp_bind — associa socket a porta locale.
 * @sock:  socket da legare.
 * @ip:    indirizzo locale (0 = INADDR_ANY).
 * @port:  porta locale in host byte order (0 = assegna automaticamente).
 * @return: EOK, EADDRINUSE, EINVAL.
 */
int udp_bind(udp_socket_t *sock, uint32_t ip, uint16_t port);

/*
 * udp_send — invia un datagramma UDP.
 * @sock:      socket mittente (può essere non bound).
 * @dst_ip:    destinazione (host byte order).
 * @dst_port:  porta destinazione (host byte order).
 * @data:      payload applicativo.
 * @len:       lunghezza payload.
 * @return:    EOK, EINVAL, EIO, EAGAIN (ARP miss).
 */
int udp_send(udp_socket_t *sock, uint32_t dst_ip, uint16_t dst_port,
             const void *data, uint16_t len);

/*
 * udp_recv — legge il prossimo datagramma dalla coda di ricezione.
 * Blocca il thread se la coda è vuota (tramite scheduler_block).
 * @sock:      socket.
 * @buf:       buffer di output.
 * @buf_size:  dimensione buffer.
 * @src_ip_out: indirizzo mittente (host byte order), può essere NULL.
 * @src_port_out: porta mittente (host byte order), può essere NULL.
 * @return:    byte ricevuti, EINVAL, EAGAIN (solo con flag non-blocking).
 */
int udp_recv(udp_socket_t *sock, void *buf, uint16_t buf_size,
             uint32_t *src_ip_out, uint16_t *src_port_out);

/* Assegna una porta effimera libera (49152–65535). */
uint16_t udp_ephemeral_port(void);

#endif /* MATTIAOS_UDP_H */
