#ifndef MATTIAOS_TYPES_H
#define MATTIAOS_TYPES_H

typedef unsigned char      uint8_t;
typedef unsigned short     uint16_t;
typedef unsigned int       uint32_t;
typedef unsigned long long uint64_t;
typedef signed char        int8_t;
typedef signed short       int16_t;
typedef signed int         int32_t;
typedef signed long long   int64_t;

typedef uint64_t size_t;
typedef int64_t  ssize_t;
typedef int64_t  off_t;
typedef uint32_t mode_t;
typedef int32_t  pid_t;
typedef int32_t  tid_t;
typedef uint32_t uid_t;
typedef uint32_t gid_t;
typedef int64_t  time_t;
typedef uint64_t uintptr_t;
typedef int64_t  intptr_t;

typedef _Bool bool;
#define true  1
#define false 0

#define NULL ((void *)0)

#define UINT8_MAX  0xFF
#define UINT16_MAX 0xFFFF
#define UINT32_MAX 0xFFFFFFFF
#define UINT64_MAX 0xFFFFFFFFFFFFFFFFULL

#define PAGE_SIZE   4096ULL
#define KERNEL_BASE 0xFFFFFFFF80000000ULL
#define HHDM_OFFSET 0xFFFF800000000000ULL

#define FD_MAX 1024

typedef struct { volatile int lock; } spinlock_t;
typedef struct { volatile int lock; } mutex_t;

/* =========================================================================
 * Primitive spinlock — inline per uso in qualsiasi file kernel.
 * Usano GCC __atomic builtins; richiedono -std=gnu11 o -std=c11.
 * ========================================================================= */

static inline void spinlock_acquire(spinlock_t *lock) {
    while (__atomic_test_and_set(&lock->lock, __ATOMIC_ACQUIRE))
        __asm__ __volatile__("pause");
}

static inline void spinlock_release(spinlock_t *lock) {
    __atomic_clear(&lock->lock, __ATOMIC_RELEASE);
}

static inline uint64_t irq_save(void) {
    uint64_t flags;
    __asm__ __volatile__("pushfq; popq %0; cli" : "=r"(flags) :: "memory");
    return flags;
}

static inline void irq_restore(uint64_t flags) {
    __asm__ __volatile__("pushq %0; popfq" :: "r"(flags) : "memory", "cc");
}

static inline void irq_disable(void) {
    __asm__ __volatile__("cli" ::: "memory");
}

static inline void irq_enable(void) {
    __asm__ __volatile__("sti" ::: "memory");
}

static inline uint64_t spinlock_irqsave(spinlock_t *lock) {
    uint64_t flags = irq_save();
    spinlock_acquire(lock);
    return flags;
}

static inline void spinlock_irqrestore(spinlock_t *lock, uint64_t flags) {
    spinlock_release(lock);
    irq_restore(flags);
}

#endif
