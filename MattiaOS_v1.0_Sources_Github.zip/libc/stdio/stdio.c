#include "../include/stdio.h"
#include "../include/stdlib.h"
#include "../include/string.h"
#include "../include/errno.h"
#include "../include/fcntl.h"
#include "../include/unistd.h"
#include "../include/syscall.h"
#include "../include/stdint.h"
#include "../include/math.h"

/* =========================================================================
 * Syscall numbers usati da stdio
 * ========================================================================= */
#define SYS_READ    0
#define SYS_WRITE   1
#define SYS_OPEN    2
#define SYS_CLOSE   3
#define SYS_LSEEK   8

/* =========================================================================
 * Stream standard
 * ========================================================================= */
static FILE s_stdin_file  = { .fd = 0, .mode = 0, .flags = O_RDONLY };
static FILE s_stdout_file = { .fd = 1, .mode = 1, .flags = O_WRONLY };
static FILE s_stderr_file = { .fd = 2, .mode = 0, .flags = O_WRONLY };

FILE *stdin  = &s_stdin_file;
FILE *stdout = &s_stdout_file;
FILE *stderr = &s_stderr_file;

/* =========================================================================
 * fopen / fclose / fflush
 * ========================================================================= */
FILE *fopen(const char *path, const char *mode) {
    int flags;
    if (mode[0] == 'r' && mode[1] != '+')      flags = O_RDONLY;
    else if (mode[0] == 'r' && mode[1] == '+')  flags = O_RDWR;
    else if (mode[0] == 'w' && mode[1] != '+')  flags = O_WRONLY | O_CREAT | O_TRUNC;
    else if (mode[0] == 'w' && mode[1] == '+')  flags = O_RDWR   | O_CREAT | O_TRUNC;
    else if (mode[0] == 'a' && mode[1] != '+')  flags = O_WRONLY | O_CREAT | O_APPEND;
    else if (mode[0] == 'a' && mode[1] == '+')  flags = O_RDWR   | O_CREAT | O_APPEND;
    else { errno = EINVAL; return (FILE *)0; }

    int fd = (int)__sc_errno(__syscall3(SYS_OPEN,
                                         (long)path, (long)flags,
                                         (long)0644));
    if (fd < 0) return (FILE *)0;

    FILE *f = (FILE *)calloc(1, sizeof(FILE));
    if (!f) { __syscall1(SYS_CLOSE, fd); errno = ENOMEM; return (FILE *)0; }
    f->fd    = fd;
    f->flags = flags;
    f->mode  = 2;  /* block-buffered per file regolari */
    return f;
}

int fflush(FILE *stream) {
    if (!stream) return 0;
    if (stream->wbuf_len > 0) {
        long written = __syscall3(SYS_WRITE, (long)stream->fd,
                                   (long)stream->wbuf,
                                   (long)stream->wbuf_len);
        if (written < 0) { errno = (int)-written; stream->error = 1; return EOF; }
        stream->wbuf_len = 0;
    }
    return 0;
}

int fclose(FILE *stream) {
    if (!stream) return EOF;
    fflush(stream);
    __syscall1(SYS_CLOSE, (long)stream->fd);
    if (stream != stdin && stream != stdout && stream != stderr)
        free(stream);
    return 0;
}

/* =========================================================================
 * fputc / fgetc con buffer
 * ========================================================================= */
int fputc(int c, FILE *stream) {
    stream->wbuf[stream->wbuf_len++] = (char)c;
    if (stream->wbuf_len >= _LIBC_FILE_BUFSIZE ||
        stream->mode == 0 ||
        (stream->mode == 1 && c == '\n')) {
        if (fflush(stream) == EOF) return EOF;
    }
    return (unsigned char)c;
}

int fgetc(FILE *stream) {
    if (stream->eof) return EOF;
    if (stream->rbuf_pos >= stream->rbuf_len) {
        long r = __syscall3(SYS_READ, (long)stream->fd,
                             (long)stream->rbuf, (long)_LIBC_FILE_BUFSIZE);
        if (r < 0) { errno = (int)-r; stream->error = 1; return EOF; }
        if (r == 0) { stream->eof = 1; return EOF; }
        stream->rbuf_len = (int)r;
        stream->rbuf_pos = 0;
    }
    return (unsigned char)stream->rbuf[stream->rbuf_pos++];
}

int putchar(int c)      { return fputc(c, stdout); }
int getchar(void)       { return fgetc(stdin); }

/* =========================================================================
 * fread / fwrite
 * ========================================================================= */
size_t fwrite(const void *ptr, size_t size, size_t nmemb, FILE *stream) {
    size_t total = size * nmemb;
    const char *p = (const char *)ptr;
    size_t done = 0;
    while (done < total) {
        if (fputc((unsigned char)p[done], stream) == EOF) break;
        done++;
    }
    return done / (size ? size : 1);
}

size_t fread(void *ptr, size_t size, size_t nmemb, FILE *stream) {
    size_t total = size * nmemb;
    char  *p = (char *)ptr;
    size_t done = 0;
    while (done < total) {
        int c = fgetc(stream);
        if (c == EOF) break;
        p[done++] = (char)c;
    }
    return done / (size ? size : 1);
}

/* =========================================================================
 * fgets / fputs / puts
 * ========================================================================= */
char *fgets(char *s, int n, FILE *stream) {
    if (n <= 0) return (char *)0;
    int i = 0;
    while (i < n - 1) {
        int c = fgetc(stream);
        if (c == EOF) { if (i == 0) return (char *)0; break; }
        s[i++] = (char)c;
        if (c == '\n') break;
    }
    s[i] = '\0';
    return s;
}

int fputs(const char *s, FILE *stream) {
    while (*s) if (fputc((unsigned char)*s++, stream) == EOF) return EOF;
    return 0;
}

int puts(const char *s) {
    if (fputs(s, stdout) == EOF) return EOF;
    return fputc('\n', stdout);
}

/* =========================================================================
 * fseek / ftell / rewind / feof / ferror
 * ========================================================================= */
int fseek(FILE *stream, long offset, int whence) {
    stream->rbuf_pos = stream->rbuf_len = 0;  /* Invalida read buffer */
    fflush(stream);
    long ret = __sc_errno(__syscall3(SYS_LSEEK,
                                      (long)stream->fd,
                                      (long)offset,
                                      (long)whence));
    if (ret < 0) return -1;
    stream->pos  = ret;
    stream->eof  = 0;
    return 0;
}

long ftell(FILE *stream) {
    return (long)__sc_errno(__syscall3(SYS_LSEEK,
                                        (long)stream->fd, 0L, (long)SEEK_CUR));
}

void   rewind  (FILE *s) { fseek(s, 0, SEEK_SET); s->error = 0; }
int    feof    (FILE *s) { return s->eof; }
int    ferror  (FILE *s) { return s->error; }
void   clearerr(FILE *s) { s->eof = 0; s->error = 0; }

/* =========================================================================
 * open (syscall wrapper — dichiarata in fcntl.h)
 * ========================================================================= */
int open(const char *path, int flags, ...) {
    unsigned int mode = 0644;
    return (int)__sc_errno(__syscall3(SYS_OPEN, (long)path, (long)flags, (long)mode));
}

/* =========================================================================
 * ssize_t read/write/close/lseek (unistd.h)
 * ========================================================================= */
ssize_t read (int fd, void *buf, size_t n) {
    return (ssize_t)__sc_errno(__syscall3(SYS_READ,  (long)fd, (long)buf, (long)n));
}
ssize_t write(int fd, const void *buf, size_t n) {
    return (ssize_t)__sc_errno(__syscall3(SYS_WRITE, (long)fd, (long)buf, (long)n));
}
int close(int fd) {
    return (int)__sc_errno(__syscall1(SYS_CLOSE, (long)fd));
}
long lseek(int fd, long offset, int whence) {
    return (long)__sc_errno(__syscall3(SYS_LSEEK, (long)fd, (long)offset, (long)whence));
}

/* =========================================================================
 * Altre syscall userspace (getpid, fork, execve, ecc.)
 * ========================================================================= */
#define SYS_GETPID  39
#define SYS_FORK    57
#define SYS_EXECVE  59
#define SYS_GETUID  102
#define SYS_GETGID  104
#define SYS_MKDIR   83
#define SYS_RMDIR   84
#define SYS_UNLINK  87
#define SYS_GETCWD  79
#define SYS_CHDIR   80

int   getpid(void) { return (int)__syscall0(SYS_GETPID); }
unsigned int getuid(void) { return (unsigned int)__syscall0(SYS_GETUID); }
unsigned int getgid(void) { return (unsigned int)__syscall0(SYS_GETGID); }
int   fork  (void) { return (int)__sc_errno(__syscall0(SYS_FORK)); }
int   execve(const char *p, char *const a[], char *const e[]) {
    return (int)__sc_errno(__syscall3(SYS_EXECVE, (long)p, (long)a, (long)e));
}
int   unlink(const char *p) { return (int)__sc_errno(__syscall1(SYS_UNLINK,(long)p)); }
int   rmdir (const char *p) { return (int)__sc_errno(__syscall1(SYS_RMDIR, (long)p)); }
int   mkdir (const char *p, unsigned int m) {
    return (int)__sc_errno(__syscall2(SYS_MKDIR, (long)p, (long)m));
}
int   chdir (const char *p) { return (int)__sc_errno(__syscall1(SYS_CHDIR, (long)p)); }
char *getcwd(char *buf, size_t size) {
    long r = __sc_errno(__syscall2(SYS_GETCWD, (long)buf, (long)size));
    return r < 0 ? (char *)0 : buf;
}

/* =========================================================================
 * vsnprintf — cuore del sistema printf
 * ========================================================================= */

/* Buffer di scrittura controllato */
typedef struct {
    char  *buf;
    size_t cap;     /* 0 = illimitato (sprintf) */
    size_t len;
    FILE  *stream;  /* Non NULL → scrittura su stream */
    int    fd;      /* >= 0 → scrittura su fd */
} pf_ctx_t;

static void pf_putc(pf_ctx_t *ctx, char c) {
    if (ctx->stream) {
        fputc((unsigned char)c, ctx->stream);
        ctx->len++;
        return;
    }
    if (ctx->fd >= 0) {
        write(ctx->fd, &c, 1);
        ctx->len++;
        return;
    }
    if (!ctx->buf) return;
    if (ctx->cap == 0 || ctx->len < ctx->cap - 1) {
        ctx->buf[ctx->len] = c;
    }
    ctx->len++;
}

static void pf_puts(pf_ctx_t *ctx, const char *s, int len) {
    for (int i = 0; i < len; i++) pf_putc(ctx, s[i]);
}

/* Formatta intero in buffer temporaneo */
/* Converte intero in stringa, ritorna numero di cifre */
static int uint_to_str(unsigned long long v, int base, int upper, char *out) {
    const char *digs = upper ? "0123456789ABCDEF" : "0123456789abcdef";
    if (v == 0) { out[0] = '0'; return 1; }
    char tmp[64]; int n = 0;
    while (v) { tmp[n++] = digs[v % (unsigned)base]; v /= (unsigned)base; }
    for (int i = 0; i < n; i++) out[i] = tmp[n - 1 - i];
    return n;
}

static int vsnprintf_ctx(pf_ctx_t *ctx, const char *fmt, va_list ap) {
    while (*fmt) {
        if (*fmt != '%') { pf_putc(ctx, *fmt++); continue; }
        fmt++;  /* skip '%' */
        if (*fmt == '\0') break;
        if (*fmt == '%') { pf_putc(ctx, '%'); fmt++; continue; }

        /* Flags */
        int flag_left = 0, flag_zero = 0, flag_plus = 0, flag_space = 0, flag_hash = 0;
        for (;;) {
            if      (*fmt == '-') flag_left  = 1;
            else if (*fmt == '0') flag_zero  = 1;
            else if (*fmt == '+') flag_plus  = 1;
            else if (*fmt == ' ') flag_space = 1;
            else if (*fmt == '#') flag_hash  = 1;
            else break;
            fmt++;
        }

        /* Width */
        int width = 0;
        if (*fmt == '*') { width = va_arg(ap, int); fmt++; }
        else while (*fmt >= '0' && *fmt <= '9') width = width * 10 + (*fmt++ - '0');

        /* Precision */
        int prec = -1;
        if (*fmt == '.') {
            fmt++; prec = 0;
            if (*fmt == '*') { prec = va_arg(ap, int); fmt++; }
            else while (*fmt >= '0' && *fmt <= '9') prec = prec * 10 + (*fmt++ - '0');
        }

        /* Length modifier */
        int mod_l = 0, mod_ll = 0;
        if      (*fmt == 'z') { mod_l  = 1; fmt++; }  /* %zu → size_t = unsigned long */
        else if (*fmt == 'l') {
            fmt++;
            if (*fmt == 'l') { mod_ll = 1; fmt++; }
            else               mod_l  = 1;
        }

        char spec = *fmt++;
        char tmp[80];
        int  tlen = 0;
        int  is_neg = 0;
        char prefix[4] = {0};
        int  plen = 0;

        switch (spec) {
        case 'd': case 'i': {
            long long v;
            if (mod_ll)     v = va_arg(ap, long long);
            else if (mod_l) v = va_arg(ap, long);
            else            v = va_arg(ap, int);
            if (v < 0) { is_neg = 1; v = -v; }
            tlen = uint_to_str((unsigned long long)v, 10, 0, tmp);
            break;
        }
        case 'u': {
            unsigned long long v;
            if (mod_ll)     v = va_arg(ap, unsigned long long);
            else if (mod_l) v = va_arg(ap, unsigned long);
            else            v = va_arg(ap, unsigned int);
            tlen = uint_to_str(v, 10, 0, tmp);
            break;
        }
        case 'o': {
            unsigned long long v;
            if (mod_ll)     v = va_arg(ap, unsigned long long);
            else if (mod_l) v = va_arg(ap, unsigned long);
            else            v = va_arg(ap, unsigned int);
            tlen = uint_to_str(v, 8, 0, tmp);
            if (flag_hash && tmp[0] != '0') { prefix[plen++] = '0'; }
            break;
        }
        case 'x': case 'X': {
            unsigned long long v;
            if (mod_ll)     v = va_arg(ap, unsigned long long);
            else if (mod_l) v = va_arg(ap, unsigned long);
            else            v = va_arg(ap, unsigned int);
            tlen = uint_to_str(v, 16, spec == 'X', tmp);
            if (flag_hash && v != 0) {
                prefix[plen++] = '0'; prefix[plen++] = (spec == 'X') ? 'X' : 'x';
            }
            break;
        }
        case 'c':
            tmp[0] = (char)va_arg(ap, int); tlen = 1;
            break;
        case 's': {
            const char *s = va_arg(ap, const char *);
            if (!s) s = "(null)";
            int slen = (int)strlen(s);
            if (prec >= 0 && slen > prec) slen = prec;
            int pad = (width > slen) ? width - slen : 0;
            if (!flag_left) for (int i = 0; i < pad; i++) pf_putc(ctx, ' ');
            pf_puts(ctx, s, slen);
            if (flag_left)  for (int i = 0; i < pad; i++) pf_putc(ctx, ' ');
            continue;
        }
        case 'p': {
            unsigned long long v = (unsigned long long)(uintptr_t)va_arg(ap, void *);
            tlen = uint_to_str(v, 16, 0, tmp);
            prefix[plen++] = '0'; prefix[plen++] = 'x';
            break;
        }
        case 'f': case 'e': case 'E': case 'g': case 'G': {
            /* Floating point — formattazione semplice %f senza esponenziale completo */
            double v = va_arg(ap, double);
            if (prec < 0) prec = 6;
            if (v < 0) { is_neg = 1; v = -v; }
            /* Parte intera */
            unsigned long long ipart = (unsigned long long)v;
            double fpart = v - (double)ipart;
            int ilen = uint_to_str(ipart, 10, 0, tmp);
            tmp[ilen++] = '.';
            /* Parte frazionaria */
            for (int i = 0; i < prec; i++) {
                fpart *= 10.0;
                int d = (int)fpart;
                tmp[ilen++] = (char)('0' + d);
                fpart -= d;
            }
            tlen = ilen;
            break;
        }
        default:
            pf_putc(ctx, '%'); pf_putc(ctx, spec); continue;
        }

        /* Segno e prefisso */
        char sign_char = 0;
        if (spec == 'd' || spec == 'i' || spec == 'f' ||
            spec == 'e' || spec == 'E' || spec == 'g' || spec == 'G') {
            if (is_neg)        sign_char = '-';
            else if (flag_plus) sign_char = '+';
            else if (flag_space) sign_char = ' ';
        }

        /* Padding */
        int content_len = tlen + plen + (sign_char ? 1 : 0);
        int pad = (width > content_len) ? width - content_len : 0;
        char pad_char = (flag_zero && !flag_left) ? '0' : ' ';

        if (!flag_left) for (int i = 0; i < pad; i++) pf_putc(ctx, pad_char);
        if (sign_char) pf_putc(ctx, sign_char);
        for (int i = 0; i < plen; i++) pf_putc(ctx, prefix[i]);
        pf_puts(ctx, tmp, tlen);
        if (flag_left) for (int i = 0; i < pad; i++) pf_putc(ctx, ' ');
    }

    if (ctx->buf && (ctx->cap == 0 || ctx->len < ctx->cap))
        ctx->buf[ctx->len] = '\0';

    return (int)ctx->len;
}

/* =========================================================================
 * printf family — implementazioni pubbliche
 * ========================================================================= */
int vsnprintf(char *buf, size_t n, const char *fmt, va_list ap) {
    pf_ctx_t ctx = { .buf = buf, .cap = n, .len = 0, .stream = 0, .fd = -1 };
    return vsnprintf_ctx(&ctx, fmt, ap);
}

int vsprintf(char *buf, const char *fmt, va_list ap) {
    pf_ctx_t ctx = { .buf = buf, .cap = 0, .len = 0, .stream = 0, .fd = -1 };
    return vsnprintf_ctx(&ctx, fmt, ap);
}

int vfprintf(FILE *stream, const char *fmt, va_list ap) {
    pf_ctx_t ctx = { .buf = 0, .cap = 0, .len = 0, .stream = stream, .fd = -1 };
    return vsnprintf_ctx(&ctx, fmt, ap);
}

int vprintf(const char *fmt, va_list ap) { return vfprintf(stdout, fmt, ap); }

int snprintf(char *buf, size_t n, const char *fmt, ...) {
    va_list ap; va_start(ap, fmt);
    int r = vsnprintf(buf, n, fmt, ap);
    va_end(ap); return r;
}
int sprintf(char *buf, const char *fmt, ...) {
    va_list ap; va_start(ap, fmt);
    int r = vsprintf(buf, fmt, ap);
    va_end(ap); return r;
}
int fprintf(FILE *stream, const char *fmt, ...) {
    va_list ap; va_start(ap, fmt);
    int r = vfprintf(stream, fmt, ap);
    va_end(ap); return r;
}
int printf(const char *fmt, ...) {
    va_list ap; va_start(ap, fmt);
    int r = vfprintf(stdout, fmt, ap);
    va_end(ap); return r;
}
int dprintf(int fd, const char *fmt, ...) {
    va_list ap; va_start(ap, fmt);
    pf_ctx_t ctx = { .buf = 0, .cap = 0, .len = 0, .stream = 0, .fd = fd };
    int r = vsnprintf_ctx(&ctx, fmt, ap);
    va_end(ap); return r;
}
int dprintf_fd(int fd, const char *fmt, ...) {
    va_list ap; va_start(ap, fmt);
    pf_ctx_t ctx = { .buf = 0, .cap = 0, .len = 0, .stream = 0, .fd = fd };
    int r = vsnprintf_ctx(&ctx, fmt, ap);
    va_end(ap); return r;
}

/* =========================================================================
 * perror — print errno description to stderr
 * ========================================================================= */
void perror(const char *s) {
    /* Minimal perror: print "s: <errno number>\n" to stderr.
     * A full strerror() table is omitted for size — the shell uses this
     * only for fatal errors where the errno number is informative enough.
     */
    static const char * const errtab[] = {
        "Success",            /*  0 */
        "Operation not permitted", /* 1 EPERM */
        "No such file or directory", /* 2 ENOENT */
        "No such process",    /*  3 ESRCH */
        "Interrupted call",   /*  4 EINTR */
        "I/O error",          /*  5 EIO */
        "No such device/address", /* 6 ENXIO */
        "Arg list too long",  /*  7 E2BIG */
        "Exec format error",  /*  8 ENOEXEC */
        "Bad file descriptor", /* 9 EBADF */
        "No child processes", /* 10 ECHILD */
        "Try again",          /* 11 EAGAIN */
        "Out of memory",      /* 12 ENOMEM */
        "Permission denied",  /* 13 EACCES */
        "Bad address",        /* 14 EFAULT */
        "Block device required", /* 15 ENOTBLK */
        "Device busy",        /* 16 EBUSY */
        "File exists",        /* 17 EEXIST */
        "Cross-device link",  /* 18 EXDEV */
        "No such device",     /* 19 ENODEV */
        "Not a directory",    /* 20 ENOTDIR */
        "Is a directory",     /* 21 EISDIR */
        "Invalid argument",   /* 22 EINVAL */
        "File table overflow",/* 23 ENFILE */
        "Too many open files",/* 24 EMFILE */
        "Not a typewriter",   /* 25 ENOTTY */
        "Text file busy",     /* 26 ETXTBSY */
        "File too large",     /* 27 EFBIG */
        "No space left",      /* 28 ENOSPC */
        "Illegal seek",       /* 29 ESPIPE */
        "Read-only filesystem", /* 30 EROFS */
        "Too many links",     /* 31 EMLINK */
        "Broken pipe",        /* 32 EPIPE */
    };
    const char *msg = "Unknown error";
    int e = errno;
    if (e >= 0 && (size_t)e < sizeof(errtab)/sizeof(errtab[0]))
        msg = errtab[e];
    if (s && *s)
        fprintf(stderr, "%s: %s\n", s, msg);
    else
        fprintf(stderr, "%s\n", msg);
}

/* =========================================================================
 * sscanf / vsscanf — minimal implementation for integer/string parsing
 * ========================================================================= */
static int vsscanf_impl(const char *str, const char *fmt, va_list ap) {
    int matched = 0;
    const char *s = str;
    const char *f = fmt;

    while (*f) {
        if (*f == '%') {
            f++;
            int suppress = 0;
            if (*f == '*') { suppress = 1; f++; }

            if (*f == 'd' || *f == 'i') {
                /* skip whitespace */
                while (*s == ' ' || *s == '\t' || *s == '\n') s++;
                if (!*s) break;
                int neg = 0;
                if (*s == '-') { neg = 1; s++; }
                else if (*s == '+') { s++; }
                long long val = 0; int got = 0;
                while (*s >= '0' && *s <= '9') { val = val*10 + (*s-'0'); s++; got=1; }
                if (!got) break;
                if (neg) val = -val;
                if (!suppress) { *va_arg(ap, int*) = (int)val; matched++; }
                f++;
            } else if (*f == 'u') {
                while (*s == ' ' || *s == '\t' || *s == '\n') s++;
                if (!*s) break;
                unsigned long long val = 0; int got = 0;
                while (*s >= '0' && *s <= '9') { val = val*10 + (*s-'0'); s++; got=1; }
                if (!got) break;
                if (!suppress) { *va_arg(ap, unsigned int*) = (unsigned int)val; matched++; }
                f++;
            } else if (*f == 's') {
                while (*s == ' ' || *s == '\t' || *s == '\n') s++;
                if (!*s) break;
                if (!suppress) {
                    char *out = va_arg(ap, char *);
                    while (*s && *s != ' ' && *s != '\t' && *s != '\n') *out++ = *s++;
                    *out = 0;
                    matched++;
                } else {
                    while (*s && *s != ' ' && *s != '\t' && *s != '\n') s++;
                }
                f++;
            } else if (*f == 'c') {
                if (!*s) break;
                if (!suppress) { *va_arg(ap, char*) = *s; matched++; }
                s++; f++;
            } else if (*f == '%') {
                if (*s != '%') break;
                s++; f++;
            } else {
                f++; /* skip unknown specifier */
            }
        } else if (*f == ' ' || *f == '\t' || *f == '\n') {
            while (*s == ' ' || *s == '\t' || *s == '\n') s++;
            f++;
        } else {
            if (*s != *f) break;
            s++; f++;
        }
    }
    return matched;
}

int vsscanf(const char *str, const char *fmt, va_list ap) {
    return vsscanf_impl(str, fmt, ap);
}

int sscanf(const char *str, const char *fmt, ...) {
    va_list ap;
    va_start(ap, fmt);
    int r = vsscanf_impl(str, fmt, ap);
    va_end(ap);
    return r;
}
