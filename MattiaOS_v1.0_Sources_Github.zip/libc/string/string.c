#include "../include/string.h"
#include "../include/stdlib.h"   /* malloc, free per strdup */
#include "../include/stdint.h"

/* =========================================================================
 * Operazioni su blocchi di memoria
 * ========================================================================= */

void *memcpy(void *dst, const void *src, size_t n) {
    uint8_t       *d = (uint8_t *)dst;
    const uint8_t *s = (const uint8_t *)src;
    /* Copia word-by-word quando possibile (8 byte a volta su x86-64) */
    while (n >= 8) {
        *(uint64_t *)d = *(const uint64_t *)s;
        d += 8; s += 8; n -= 8;
    }
    while (n--) *d++ = *s++;
    return dst;
}

void *memmove(void *dst, const void *src, size_t n) {
    uint8_t       *d = (uint8_t *)dst;
    const uint8_t *s = (const uint8_t *)src;
    if (d == s || n == 0) return dst;
    if (d < s || d >= s + n) {
        return memcpy(dst, src, n);
    }
    /* Regioni sovrapposte: copia dalla fine */
    d += n; s += n;
    while (n--) *--d = *--s;
    return dst;
}

void *memset(void *dst, int c, size_t n) {
    uint8_t *d = (uint8_t *)dst;
    uint8_t  v = (uint8_t)c;
    /* Riempi word-by-word */
    uint64_t vv = (uint64_t)v;
    vv |= vv << 8; vv |= vv << 16; vv |= vv << 32;
    while (n >= 8) { *(uint64_t *)d = vv; d += 8; n -= 8; }
    while (n--) *d++ = v;
    return dst;
}

int memcmp(const void *a, const void *b, size_t n) {
    const uint8_t *pa = (const uint8_t *)a;
    const uint8_t *pb = (const uint8_t *)b;
    while (n--) {
        int diff = (int)*pa++ - (int)*pb++;
        if (diff) return diff;
    }
    return 0;
}

void *memchr(const void *s, int c, size_t n) {
    const uint8_t *p = (const uint8_t *)s;
    while (n--) {
        if (*p == (uint8_t)c) return (void *)p;
        p++;
    }
    return (void *)0;
}

/* =========================================================================
 * strlen / strnlen
 * ========================================================================= */

size_t strlen(const char *s) {
    const char *p = s;
    while (*p) p++;
    return (size_t)(p - s);
}

size_t strnlen(const char *s, size_t maxlen) {
    size_t n = 0;
    while (n < maxlen && s[n]) n++;
    return n;
}

/* =========================================================================
 * strcmp / strncmp
 * ========================================================================= */

int strcmp(const char *a, const char *b) {
    while (*a && *a == *b) { a++; b++; }
    return (unsigned char)*a - (unsigned char)*b;
}

int strncmp(const char *a, const char *b, size_t n) {
    while (n-- && *a && *a == *b) { a++; b++; }
    if (n == (size_t)-1) return 0;   /* n era 0 */
    return (unsigned char)*a - (unsigned char)*b;
}

static inline int tolower_c(int c) {
    if (c >= 'A' && c <= 'Z') return c + 32;
    return c;
}

int strcasecmp(const char *a, const char *b) {
    while (*a && tolower_c(*a) == tolower_c(*b)) { a++; b++; }
    return tolower_c((unsigned char)*a) - tolower_c((unsigned char)*b);
}

int strncasecmp(const char *a, const char *b, size_t n) {
    while (n-- && *a && tolower_c(*a) == tolower_c(*b)) { a++; b++; }
    if (n == (size_t)-1) return 0;
    return tolower_c((unsigned char)*a) - tolower_c((unsigned char)*b);
}

/* =========================================================================
 * strcpy / strncpy / strcat / strncat
 * ========================================================================= */

char *strcpy(char *dst, const char *src) {
    char *d = dst;
    while ((*d++ = *src++));
    return dst;
}

char *strncpy(char *dst, const char *src, size_t n) {
    char *d = dst;
    while (n && (*d++ = *src++)) n--;
    while (n--) *d++ = '\0';
    return dst;
}

char *strcat(char *dst, const char *src) {
    char *d = dst + strlen(dst);
    while ((*d++ = *src++));
    return dst;
}

char *strncat(char *dst, const char *src, size_t n) {
    char *d = dst + strlen(dst);
    while (n-- && *src) *d++ = *src++;
    *d = '\0';
    return dst;
}

/* =========================================================================
 * strchr / strrchr / strstr
 * ========================================================================= */

char *strchr(const char *s, int c) {
    for (; *s; s++) if (*s == (char)c) return (char *)s;
    if (c == '\0') return (char *)s;
    return (char *)0;
}

char *strrchr(const char *s, int c) {
    const char *last = (char *)0;
    for (; *s; s++) if (*s == (char)c) last = s;
    if (c == '\0') return (char *)s;
    return (char *)last;
}

char *strstr(const char *haystack, const char *needle) {
    if (!*needle) return (char *)haystack;
    size_t nlen = strlen(needle);
    for (; *haystack; haystack++) {
        if (*haystack == *needle && memcmp(haystack, needle, nlen) == 0)
            return (char *)haystack;
    }
    return (char *)0;
}

/* =========================================================================
 * strtok / strtok_r
 * ========================================================================= */

static char *s_strtok_save = (char *)0;

char *strtok(char *str, const char *delim) {
    return strtok_r(str, delim, &s_strtok_save);
}

char *strtok_r(char *str, const char *delim, char **saveptr) {
    if (str) *saveptr = str;
    if (!*saveptr) return (char *)0;

    /* Salta delimitatori iniziali */
    char *start = *saveptr;
    while (*start && strchr(delim, *start)) start++;
    if (!*start) { *saveptr = start; return (char *)0; }

    /* Trova la fine del token */
    char *end = start;
    while (*end && !strchr(delim, *end)) end++;
    if (*end) {
        *end   = '\0';
        *saveptr = end + 1;
    } else {
        *saveptr = end;
    }
    return start;
}

/* =========================================================================
 * strdup / strndup
 * ========================================================================= */

char *strdup(const char *s) {
    size_t n = strlen(s) + 1;
    char *buf = (char *)malloc(n);
    if (!buf) return (char *)0;
    memcpy(buf, s, n);
    return buf;
}

char *strndup(const char *s, size_t n) {
    size_t len = strnlen(s, n);
    char *buf = (char *)malloc(len + 1);
    if (!buf) return (char *)0;
    memcpy(buf, s, len);
    buf[len] = '\0';
    return buf;
}

/* =========================================================================
 * strspn / strcspn / strpbrk
 * ========================================================================= */

size_t strspn(const char *s, const char *accept) {
    size_t n = 0;
    while (s[n] && strchr(accept, s[n])) n++;
    return n;
}

size_t strcspn(const char *s, const char *reject) {
    size_t n = 0;
    while (s[n] && !strchr(reject, s[n])) n++;
    return n;
}

char *strpbrk(const char *s, const char *accept) {
    for (; *s; s++) if (strchr(accept, *s)) return (char *)s;
    return (char *)0;
}

/* =========================================================================
 * strerror
 * ========================================================================= */

char *strerror(int errnum) {
    switch (errnum) {
    case 0:   return "Success";
    case 1:   return "Operation not permitted";
    case 2:   return "No such file or directory";
    case 4:   return "Interrupted system call";
    case 5:   return "Input/output error";
    case 9:   return "Bad file descriptor";
    case 11:  return "Resource temporarily unavailable";
    case 12:  return "Out of memory";
    case 13:  return "Permission denied";
    case 14:  return "Bad address";
    case 17:  return "File exists";
    case 20:  return "Not a directory";
    case 21:  return "Is a directory";
    case 22:  return "Invalid argument";
    case 24:  return "Too many open files";
    case 28:  return "No space left on device";
    case 32:  return "Broken pipe";
    case 34:  return "Numerical result out of range";
    case 38:  return "Function not implemented";
    case 98:  return "Address already in use";
    case 111: return "Connection refused";
    default:  return "Unknown error";
    }
}
