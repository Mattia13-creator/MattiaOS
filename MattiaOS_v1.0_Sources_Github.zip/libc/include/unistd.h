#ifndef _UNISTD_H
#define _UNISTD_H

#include "stddef.h"
#include "stdint.h"

/* lseek whence */
#define SEEK_SET 0
#define SEEK_CUR 1
#define SEEK_END 2

/* Standard fd */
#define STDIN_FILENO  0
#define STDOUT_FILENO 1
#define STDERR_FILENO 2

typedef int pid_t;
typedef unsigned int uid_t;
typedef unsigned int gid_t;

ssize_t read  (int fd, void *buf, size_t count);
ssize_t write (int fd, const void *buf, size_t count);
int     close (int fd);
long    lseek (int fd, long offset, int whence);

pid_t   getpid(void);
uid_t   getuid(void);
gid_t   getgid(void);

pid_t   fork  (void);
int     execve(const char *path, char *const argv[], char *const envp[]);

int     unlink(const char *path);
int     rmdir (const char *path);
int     mkdir (const char *path, unsigned int mode);
char   *getcwd(char *buf, size_t size);
int     chdir (const char *path);

/* Primitiva sbrk per allocatore malloc */
void   *sbrk(long increment);

#endif /* _UNISTD_H */
