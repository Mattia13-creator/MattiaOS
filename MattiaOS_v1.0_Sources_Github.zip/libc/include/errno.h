#ifndef _ERRNO_H
#define _ERRNO_H

/*
 * errno.h — codici di errore POSIX (userspace MattiaOS libc)
 *
 * errno è una variabile globale semplice (single-thread per ora).
 * In un sistema multi-thread diventerebbe thread-local (__thread int errno).
 */

extern int errno;

/* Codici standard POSIX */
#define EPERM            1
#define ENOENT           2
#define ESRCH            3
#define EINTR            4
#define EIO              5
#define ENXIO            6
#define E2BIG            7
#define ENOEXEC          8
#define EBADF            9
#define ECHILD          10
#define EAGAIN          11
#define ENOMEM          12
#define EACCES          13
#define EFAULT          14
#define EBUSY           16
#define EEXIST          17
#define EXDEV           18
#define ENODEV          19
#define ENOTDIR         20
#define EISDIR          21
#define EINVAL          22
#define ENFILE          23
#define EMFILE          24
#define ENOTTY          25
#define EFBIG           27
#define ENOSPC          28
#define ESPIPE          29
#define EROFS           30
#define EPIPE           32
#define EDOM            33
#define ERANGE          34
#define EDEADLK         35
#define ENAMETOOLONG    36
#define ENOLCK          37
#define ENOSYS          38
#define ENOTEMPTY       39
#define EADDRINUSE      98
#define ECONNREFUSED   111
#define ENOTCONN       107
#define EISCONN        106
#define EOPNOTSUPP      95
#define EAFNOSUPPORT    97
#define ETIMEDOUT      110
#define EWOULDBLOCK    EAGAIN
#define ENOBUFS         55
#define EDESTADDRREQ    89

#endif /* _ERRNO_H */
