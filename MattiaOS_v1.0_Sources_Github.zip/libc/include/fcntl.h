#ifndef _FCNTL_H
#define _FCNTL_H

#include "stdint.h"

/* Flags per open() */
#define O_RDONLY    0x000
#define O_WRONLY    0x001
#define O_RDWR      0x002
#define O_CREAT     0x040
#define O_EXCL      0x080
#define O_TRUNC     0x200
#define O_APPEND    0x400
#define O_NONBLOCK  0x800

/* Permessi di default per creat */
#ifndef S_IRUSR
#define S_IRUSR 0400
#endif
#ifndef S_IWUSR
#define S_IWUSR 0200
#endif
#ifndef S_IXUSR
#define S_IXUSR 0100
#endif
#ifndef S_IRGRP
#define S_IRGRP 0040
#endif
#ifndef S_IWGRP
#define S_IWGRP 0020
#endif
#ifndef S_IROTH
#define S_IROTH 0004
#endif

int open (const char *path, int flags, ...);
int creat(const char *path, unsigned int mode);

#endif /* _FCNTL_H */
