#ifndef _SYSCALL_H
#define _SYSCALL_H

/*
 * syscall.h — wrapper inline per l'istruzione SYSCALL x86-64
 *
 * Convenzione ABI Linux/SysV x86-64 (usata da MattiaOS):
 *   rax = numero syscall
 *   rdi, rsi, rdx, r10, r8, r9 = argomenti
 *   rax = valore di ritorno (negativo = errore, -errno)
 *   rcx e r11 vengono distrutti dall'istruzione syscall.
 *
 * errno viene impostato automaticamente se il kernel ritorna negativo.
 */

#include "stdint.h"
#include "errno.h"

static inline long __syscall0(long n) {
    long ret;
    __asm__ __volatile__("syscall"
        : "=a"(ret) : "a"(n)
        : "rcx", "r11", "memory");
    return ret;
}

static inline long __syscall1(long n, long a1) {
    long ret;
    __asm__ __volatile__("syscall"
        : "=a"(ret) : "a"(n), "D"(a1)
        : "rcx", "r11", "memory");
    return ret;
}

static inline long __syscall2(long n, long a1, long a2) {
    long ret;
    __asm__ __volatile__("syscall"
        : "=a"(ret) : "a"(n), "D"(a1), "S"(a2)
        : "rcx", "r11", "memory");
    return ret;
}

static inline long __syscall3(long n, long a1, long a2, long a3) {
    long ret;
    __asm__ __volatile__("syscall"
        : "=a"(ret) : "a"(n), "D"(a1), "S"(a2), "d"(a3)
        : "rcx", "r11", "memory");
    return ret;
}

static inline long __syscall4(long n, long a1, long a2, long a3, long a4) {
    long ret;
    register long r10 __asm__("r10") = a4;
    __asm__ __volatile__("syscall"
        : "=a"(ret) : "a"(n), "D"(a1), "S"(a2), "d"(a3), "r"(r10)
        : "rcx", "r11", "memory");
    return ret;
}

static inline long __syscall5(long n, long a1, long a2, long a3,
                               long a4, long a5) {
    long ret;
    register long r10 __asm__("r10") = a4;
    register long r8  __asm__("r8")  = a5;
    __asm__ __volatile__("syscall"
        : "=a"(ret) : "a"(n), "D"(a1), "S"(a2), "d"(a3), "r"(r10), "r"(r8)
        : "rcx", "r11", "memory");
    return ret;
}

static inline long __syscall6(long n, long a1, long a2, long a3,
                               long a4, long a5, long a6) {
    long ret;
    register long r10 __asm__("r10") = a4;
    register long r8  __asm__("r8")  = a5;
    register long r9  __asm__("r9")  = a6;
    __asm__ __volatile__("syscall"
        : "=a"(ret) : "a"(n), "D"(a1), "S"(a2), "d"(a3),
          "r"(r10), "r"(r8), "r"(r9)
        : "rcx", "r11", "memory");
    return ret;
}

/* Macro convenienza: imposta errno se ret < 0 e ritorna -1 */
static inline long __sc_errno(long ret) {
    if (ret < 0) { errno = (int)-ret; return -1; }
    return ret;
}

#endif /* _SYSCALL_H */
