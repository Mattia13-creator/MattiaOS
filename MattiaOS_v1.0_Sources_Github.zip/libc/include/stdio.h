#ifndef _STDIO_H
#define _STDIO_H

#include "stddef.h"
#include "stdarg.h"

/* =========================================================================
 * FILE — descrittore di stream
 *
 * Internamente è un buffer attorno a un file descriptor (syscall).
 * I/O bufferizato con flush automatico su '\n' (line-buffered) per stdout,
 * block-buffered per file, unbuffered per stderr.
 * ========================================================================= */
#define _LIBC_FILE_BUFSIZE  4096
#define FOPEN_MAX           64

typedef struct _FILE {
    int     fd;                         /* File descriptor kernel */
    int     flags;                      /* O_RDONLY / O_WRONLY / O_RDWR */
    int     mode;                       /* 0=unbuf, 1=linebuf, 2=fullbuf */
    int     error;                      /* Flag errore */
    int     eof;                        /* Flag EOF */
    long    pos;                        /* Posizione logica (per ftell) */

    /* Write buffer */
    char    wbuf[_LIBC_FILE_BUFSIZE];
    int     wbuf_len;                   /* Byte presenti nel write buffer */

    /* Read buffer */
    char    rbuf[_LIBC_FILE_BUFSIZE];
    int     rbuf_len;                   /* Byte validi nel read buffer */
    int     rbuf_pos;                   /* Prossimo byte da leggere */
} FILE;

/* Stream standard — definiti in stdio.c */
extern FILE *stdin;
extern FILE *stdout;
extern FILE *stderr;

#define EOF (-1)

/* =========================================================================
 * Apertura / chiusura file
 * ========================================================================= */
FILE  *fopen (const char *path, const char *mode);
int    fclose(FILE *stream);
int    fflush(FILE *stream);

/* =========================================================================
 * I/O binario / testo
 * ========================================================================= */
size_t fread (void *ptr, size_t size, size_t nmemb, FILE *stream);
size_t fwrite(const void *ptr, size_t size, size_t nmemb, FILE *stream);

int    fgetc (FILE *stream);
int    fputc (int c, FILE *stream);
char  *fgets (char *s, int n, FILE *stream);
int    fputs (const char *s, FILE *stream);

int    getchar(void);
int    putchar(int c);
int    puts   (const char *s);

/* =========================================================================
 * Seek / tell
 * ========================================================================= */
int    fseek  (FILE *stream, long offset, int whence);
long   ftell  (FILE *stream);
void   rewind (FILE *stream);
int    feof   (FILE *stream);
int    ferror (FILE *stream);
void   clearerr(FILE *stream);

/* =========================================================================
 * Printf / scanf family
 *
 * Specificatori supportati in printf:
 *   %d %i %u %o %x %X   — interi (con %l %ll %z qualificatori)
 *   %f %e %E %g %G       — floating point (double)
 *   %s %c %p             — stringa, carattere, puntatore
 *   %%                   — percentuale letterale
 *   Width, precision, flag '-' '+' ' ' '0' '#'
 * ========================================================================= */
int printf  (const char *fmt, ...) __attribute__((format(printf, 1, 2)));
int fprintf (FILE *stream, const char *fmt, ...)
             __attribute__((format(printf, 2, 3)));
int sprintf (char *buf, const char *fmt, ...)
             __attribute__((format(printf, 2, 3)));
int snprintf(char *buf, size_t n, const char *fmt, ...)
             __attribute__((format(printf, 3, 4)));
int dprintf (int fd, const char *fmt, ...)
             __attribute__((format(printf, 2, 3)));

int vprintf  (const char *fmt, va_list ap);
int vfprintf (FILE *stream, const char *fmt, va_list ap);
int vsprintf (char *buf, const char *fmt, va_list ap);
int vsnprintf(char *buf, size_t n, const char *fmt, va_list ap);

/* =========================================================================
 * Scanf family
 * Specificatori supportati: %d %i %u %o %x %X %f %s %c %% %n
 *   con qualificatori l ll h z e lunghezza/larghezza campo
 * ========================================================================= */
int scanf  (const char *fmt, ...) __attribute__((format(scanf, 1, 2)));
int fscanf (FILE *stream, const char *fmt, ...) __attribute__((format(scanf, 2, 3)));
int sscanf (const char *str, const char *fmt, ...) __attribute__((format(scanf, 2, 3)));
int vscanf (const char *fmt, va_list ap);
int vsscanf(const char *str, const char *fmt, va_list ap);

/* =========================================================================
 * Error reporting
 * ========================================================================= */
void perror(const char *s);

/* Variante interna al kernel: scrive su fd direttamente senza FILE */
int dprintf_fd(int fd, const char *fmt, ...);

#endif /* _STDIO_H */
