# MattiaOS — PROJECT BLUEPRINT
## Sistema Operativo con GUI costruito da zero — x86-64

---

# SEZIONE 1 — ISTRUZIONI PER L'AI

Sei lo sviluppatore AI principale di MattiaOS. Questo file è la tua fonte di verità assoluta. Leggilo per intero prima di fare qualsiasi cosa.

Con un prompt semplice come "continua", "riprendi", "inizia la prossima fase", sai già cosa fare:
1. Leggi questo file per intero
2. Vai alla sezione "Stato del Progetto" e identifica dove si è arrivati
3. Leggi il file sorgente della fase corrente (vedi Sezione 3 — Albero del Progetto)
4. Scrivi codice reale e completo
5. A fine sessione aggiorna questo file, crea lo zip versionato e allega tutto

---

## Regole Assolute

**Regola 1 — Questo file è la fonte di verità.**
In caso di contraddizione tra questo blueprint e qualsiasi altra cosa (codice, suggerimenti, richieste vaghe), il blueprint vince sempre.

**Regola 2 — Il codice sbagliato si corregge. Il blueprint no.**
Se il codice non funziona, si corregge il codice. Il design del blueprint non si modifica per aggirare un problema implementativo.

**Regola 3 — Non rimettere in discussione le scelte consolidate.**
Architettura, bootloader, linguaggio, scheduler, filosofia di eliminazione file: già decisi. Non proporre alternative salvo richiesta esplicita.

**Regola 4 — Aggiorna questo file ad ogni decisione significativa.**
Ogni nuova scelta architetturale va documentata qui, nella sezione del modulo corrispondente, prima o subito dopo aver scritto il codice.

**Regola 5 — Rispetta la matrice delle dipendenze.**
Non implementare un modulo che dipende da uno non ancora completato. Vedi Sezione 7.

**Regola 6 — CLI prima. GUI mai nelle prime 5 milestone.**
Il kernel non sa nulla di GUI. La grafica vive esclusivamente in userspace e si sviluppa solo dopo che il sistema CLI è stabile e testato.

**Regola 7 — Rispetta la filosofia di eliminazione immediata.**
Nessun modulo implementa meccanismi che trattengono file aperti o bloccano operazioni richieste dall'utente. Vedi Sezione 2, Principio 2.

**Regola 8 — Riscrittura obbligatoria di questo file.**
Ogni modifica a questo file, anche minima, richiede di riscriverlo per intero dall'inizio alla fine. Non aggiornare solo una sezione. Non riassumere. Non omettere. L'unica operazione lecita è aggiungere o modificare.

**Regola 9 — Verifica obbligatoria della dimensione.**
Dopo ogni riscrittura, verificare con `wc -c docs/OS_PROJECT_BLUEPRINT.md` che la dimensione sia >= alla versione precedente. Un file più piccolo indica perdita di contenuto — ripetere da capo.

**Regola 10 — Separazione blueprint / codice.**
Questo file contiene solo: istruzioni, filosofia, albero del progetto, stato, roadmap, decisioni. Il codice vive nei file sorgente. Non inserire blocchi di codice in questo file.

**Regola 11 — File sorgente puliti.**
I file `.c`, `.h`, `.asm`, `.ld`, `.cfg`, `.sh` contengono solo codice compilabile. Zero istruzioni meta. Zero commenti sul blueprint. Solo codice.

**Regola 12 — Zip versionato obbligatorio a fine sessione.**
Alla fine di ogni sessione, dopo aver aggiornato tutti i file, creare uno zip con TUTTI i file del progetto (blueprint incluso). Il nome dello zip deve contenere la versione del blueprint: `MattiaOS_vX.Y.zip`. La versione aumenta ad ogni sessione (1.0 → 1.1 → 1.2 … 1.9 → 2.0 → 2.1 …). Lo zip deve essere allegato in chat insieme al blueprint aggiornato. Senza zip, la sessione non è considerata completata.

---

## Protocollo Inizio Sessione

1. Leggi questo file per intero
2. Nota la dimensione attuale con `wc -c docs/OS_PROJECT_BLUEPRINT.md`
3. Nota la versione attuale in Sezione 4 per calcolare quella nuova
4. Identifica fase corrente e prossimo passo in Sezione 4
5. Leggi i file sorgente della fase corrente (Sezione 3)
6. Conferma in una riga cosa stai per fare
7. Scrivi codice reale e completo

## Protocollo Fine Sessione

1. Aggiorna Sezione 4 (Stato del Progetto): fase, ultimo completato, prossimo passo, file creati, versione blueprint
2. Aggiorna Sezione 3: segna i nuovi file come "creato" o sposta stato
3. Riscrivi questo file per intero con le modifiche integrate
4. Verifica `wc -c` >= versione precedente
5. Crea zip: `zip MattiaOS_vX.Y.zip docs/OS_PROJECT_BLUEPRINT.md [tutti i file sorgente]`
6. Allega in chat: lo zip + questo file blueprint separatamente
7. Scrivi: "Sessione completata. File modificati: [...]. Blueprint: [X] → [Y] bytes. Zip: MattiaOS_vX.Y.zip"

---

# SEZIONE 2 — FILOSOFIA DEL PROGETTO (VINCOLANTE PER OGNI MODULO)

Questi principi non sono preferenze stilistiche. Sono vincoli architetturali che influenzano ogni singolo modulo. Non proporre mai soluzioni che li contraddicano.

## Principio 1 — L'utente è il padrone assoluto del sistema

L'utente è esperto e pienamente consapevole delle proprie azioni. Il sistema non lo protegge da sé stesso.

Se l'utente vuole eliminare un file di sistema mentre il kernel gira, cancellare la home, terminare un processo critico, sovrascrivere dati in uso: il sistema **esegue senza bloccare, senza chiedere conferma, senza avvisare**. La responsabilità è interamente dell'utente.

Implicazione tecnica: nessun modulo rifiuta un'operazione con privilegi sufficienti, salvo protezioni hardware obbligatorie (ring protection, NX bit). Le politiche di sicurezza separano i processi tra loro, non l'utente dalle proprie scelte.

## Principio 2 — Nessun collegamento permanente tra RAM e disco

Una volta che un file o programma è caricato in memoria, il collegamento con il disco è **reciso completamente**. RAM e disco sono domini separati.

L'unica eccezione: il caricamento iniziale. Dopo quel momento, il file su disco può essere eliminato senza effetti sul processo in esecuzione.

| Sistema | Comportamento su `rm file_aperto` | Accettabile |
|---|---|---|
| Windows | Blocca l'operazione | NO |
| Linux | Reference counting inode, blocchi liberati alla chiusura fd | NO |
| MattiaOS | Eliminazione immediata e completa — il file sparisce dal disco in quel momento | SÌ |

Implicazioni tecniche dirette — rispettare in ogni modulo:
- VFS e MattiaFS: nessun refcount degli inode. `unlink()` libera immediatamente blocchi e inode.
- PCB: dopo `execve()`, il kernel dimentica il path dell'eseguibile. Sa solo dove sono le pagine in RAM.
- VMM: le VMA non mantengono riferimento al file di origine dopo il mapping iniziale.
- File descriptor: apertura di un fd non trattiene il file su disco. Se eliminato, il file è sparito. Il processo può continuare a leggere dalla posizione corrente in memoria.
- Nessun `O_LOCK`, nessun mandatory locking, nessun advisory locking forzato dal kernel.

## Principio 3 — Massimo controllo hardware diretto

Il sistema non astrae l'hardware più del necessario. I driver espongono le capacità reali del dispositivo. Le applicazioni con privilegi sufficienti accedono direttamente a registri hardware e memoria fisica mappata.

## Principio 4 — CLI prima, GUI poi

Il kernel non sa nulla di GUI. Non esiste alcun concetto di finestra, pixel o evento grafico nel kernel. Tutto il grafico vive in userspace.

Milestone 1–5: interamente CLI, nessun codice grafico.
Milestone 6+: GUI costruita sopra un sistema CLI già solido e testato.

## Principio 5 — Principi tecnici generali

- POSIX-compatible dove possibile, non vincolante
- Separation of concerns rigorosa tra kernel e userspace
- No global locks — lock granulari per ogni sottosistema
- Everything is a file (VFS)
- Codice commentato e leggibile prima di essere ottimizzato

---

# SEZIONE 3 — ALBERO DEL PROGETTO E LISTA FILE

```
mattiaos/
├── docs/
│   └── OS_PROJECT_BLUEPRINT.md
│
├── boot/
│   └── limine.cfg
│
├── kernel/
│   ├── arch/
│   │   └── x86_64/
│   │       ├── asm/
│   │       │   └── context_switch.asm
│   │       ├── entry.h / entry.c
│   │       ├── gdt.h / gdt.c
│   │       ├── idt.h / idt.c
│   │       ├── apic.h / apic.c
│   │       ├── cpu.h / cpu.c
│   │       └── linker.ld
│   │
│   ├── mm/
│   │   ├── pmm.h / pmm.c
│   │   ├── vmm.h / vmm.c
│   │   └── slab.h / slab.c
│   │
│   ├── proc/
│   │   ├── process.h / process.c
│   │   ├── thread.h / thread.c
│   │   └── signal.h / signal.c
│   │
│   ├── sched/
│   │   ├── mlfq.h
│   │   └── mlfq.c
│   │
│   ├── fs/
│   │   ├── vfs.h / vfs.c
│   │   ├── tmpfs.h / tmpfs.c
│   │   ├── devfs.h / devfs.c
│   │   ├── fat32.h / fat32.c
│   │   └── mattiafs/
│   │       ├── mattiafs.h
│   │       └── mattiafs.c
│   │
│   ├── drivers/
│   │   ├── driver.h
│   │   ├── irq.h / irq.c
│   │   ├── pci.h / pci.c
│   │   ├── video/
│   │   │   ├── fb.h / fb.c
│   │   ├── input/
│   │   │   ├── ps2.h / ps2.c
│   │   │   └── keyboard.h / keyboard.c
│   │   ├── storage/
│   │   │   ├── ahci.h / ahci.c
│   │   │   └── nvme.h / nvme.c
│   │   └── net/
│   │       ├── virtio_net.h / virtio_net.c
│   │       └── e1000.h / e1000.c
│   │
│   ├── ipc/
│   │   ├── shm.h / shm.c          [✅ Fase 9 — creato]
│   │   └── msgq.h / msgq.c        [✅ Fase 9 — creato]
│   │
│   ├── net/
│   │   ├── ethernet.h / ethernet.c [✅ Fase 9 — creato]
│   │   ├── arp.h / arp.c           [✅ Fase 9 — creato]
│   │   ├── ipv4.h / ipv4.c         [✅ Fase 9 — creato]
│   │   ├── icmp.h / icmp.c         [✅ Fase 9 — creato]
│   │   ├── udp.h / udp.c           [✅ Fase 9 — creato]
│   │   ├── tcp.h / tcp.c           [✅ Fase 9 — creato]
│   │   └── socket.h / socket.c     [✅ Fase 9 — creato]
│   │
│   ├── acpi/
│   │   └── acpi.h / acpi.c         [✅ Fase 9 — creato]
│   │
│   └── include/
│       ├── types.h
│       ├── errno.h
│       └── syscall_numbers.h
│
├── libc/
│   ├── string/string.c        [✅ Fase 11 — creato]
│   ├── stdlib/stdlib.c        [✅ Fase 11 — creato]
│   ├── stdio/stdio.c          [✅ Fase 11 — creato]
│   ├── math/math.c            [✅ Fase 11 — creato]
│   └── include/               [✅ Fase 11 — 13 header creati]
│
├── userspace/
│   ├── include/userspace.h [✅ Fase 12 — creato]
│   ├── crt0.c              [✅ Fase 12 — creato]
│   ├── Makefile            [✅ Fase 12 — creato]
│   ├── init/init.c         [✅ Fase 12 — creato]
│   ├── shell/shell.c       [✅ Fase 12 — creato]
│   └── coreutils/          [✅ Fase 12 — 33 file creati]
│       ls rm cp mv mkdir cat touch find stat ln chmod chown
│       ps kill top mount umount uname free df du dmesg
│       ping ifconfig grep sed wc head tail sort cut echo edit
│
├── gui/                    [🔲 Fase 13-16]
│
├── scripts/
│   ├── build_toolchain.sh
│   └── run_qemu.sh
│
├── Makefile
└── .gitignore
```

---

## Descrizione dettagliata di ogni file

### Progetto / configurazione

| File | Scopo |
|---|---|
| `docs/OS_PROJECT_BLUEPRINT.md` | Documento master. Istruzioni AI, filosofia, stato progetto, albero file, roadmap, convenzioni, dipendenze. L'AI lo legge per intero ad ogni sessione. |
| `Makefile` | Build system principale. Compila tutti i `.c` e `.asm`, linka il kernel ELF64, crea l'immagine ISO bootabile con Limine. |
| `.gitignore` | Esclude da Git: `*.o`, `*.elf`, `*.iso`, `build/`, file temporanei editor. |
| `boot/limine.cfg` | Configurazione del bootloader Limine v8. Definisce il kernel da caricare, risoluzione framebuffer (1280×720×32bpp). |
| `scripts/build_toolchain.sh` | Scarica e compila da sorgente binutils 2.41 + GCC 13.2.0 per il target `x86_64-elf`. Va eseguito una volta sull'host prima di tutto il resto. |
| `scripts/run_qemu.sh` | Avvia QEMU con i flag corretti: q35, 256MB RAM, OVMF UEFI, output seriale su stdout, no-reboot. |

### kernel/include/ — tipi base condivisi da tutto il kernel

| File | Scopo |
|---|---|
| `types.h` | Definisce `uint8_t`…`uint64_t`, `size_t`, `pid_t`, `tid_t`, `uid_t`, `bool`, `NULL`, `PAGE_SIZE`, `KERNEL_BASE`, `HHDM_OFFSET`, `FD_MAX`, `spinlock_t`, `mutex_t`. Include anche tutte le primitive spinlock inline (`spinlock_acquire/release`, `spinlock_irqsave/irqrestore`, `irq_save/restore`). Incluso da ogni file kernel. |
| `errno.h` | Codici di errore kernel: `EOK`, `ENOMEM`, `EINVAL`, `ENOENT`, `EACCES`, `EBUSY`, `EIO`, `EPERM`, `EROFS`, `ENOSYS`, `EFBIG` e altri. Le funzioni kernel ritornano questi valori negativi in caso di errore. |
| `syscall_numbers.h` | Numeri delle system call, compatibili con Linux x86-64 ABI dove possibile. `SYS_UNLINK = 87` — eliminazione immediata senza blocchi. Include syscall custom: SYS_THREAD_CREATE=300, SYS_THREAD_EXIT=301. |

### kernel/arch/x86_64/ — codice specifico CPU

| File | Scopo |
|---|---|
| `linker.ld` | Script linker per il kernel ELF64. Posiziona il kernel a `0xFFFFFFFF80000000` (higher half). Definisce le sezioni `.text`, `.rodata`, `.data`, `.bss`, `.limine_requests`. Esporta i simboli `_kernel_start` e `_kernel_end`. |
| `entry.h / entry.c` | Entry point `kernel_main()` chiamato da Limine. Dichiara tutte le Limine requests (framebuffer, memmap, HHDM, kernel address, RSDP, SMP). Chiama in sequenza: `gdt_init`, `idt_init`, `serial_init`, `pmm_init`, `vmm_init`, `slab_init`, `lapic_init`, `apic_timer_init`, `pci_enumerate`, `vfs_init`, `vfs_mount("/dev")`, `sti`, `drivers_init`. entry.h espone solo la dichiarazione di `kernel_main()`. |
| `cpu.h / cpu.c` | Funzioni inline per I/O hardware: `inb/outb/inw/outw/inl/outl`, `rdmsr/wrmsr`, `read_cr2/read_cr3/write_cr3`, `invlpg`. Struct `tss_t`. Costanti MSR (MSR_EFER, EFER_NXE, EFER_SCE) e MSR_IA32_APIC_BASE. Implementazione `serial_init/putchar/puts` su COM1 (0x3F8) per debug. |
| `gdt.h / gdt.c` | Global Descriptor Table. 6 entry: null, kernel code 64-bit, kernel data, user code 32-bit (per SYSRET), user data, user code 64-bit. Entry TSS a 128-bit (due slot GDT). Selettori: `KERNEL_CS=0x08`, `KERNEL_DS=0x10`, `USER_DS=0x23`, `USER_CS_64=0x2B`, `TSS_SEL=0x30`. Funzioni `gdt_init()` e `tss_set_rsp0()`. |
| `idt.h / idt.c` | Interrupt Descriptor Table. 256 entry. Struct `idt_entry_t` (16 bytes packed) e `interrupt_frame_t` (tutti i registri + vector + error_code). Gate types: `0x8E` interrupt, `0x8F` trap, `0xEE` user. Double Fault su IST1, NMI su IST2, Machine Check su IST3. Handler C `isr_handler()` chiamato dagli stub assembly. Dispatch vettori ≥ 0x20 tramite `g_irq_handlers[]` in irq.c. Page fault (#14) ha handler speciale (COW da implementare). |
| `apic.h / apic.c` | Local APIC (xAPIC). Inizializzazione via MSR `IA32_APIC_BASE`. LAPIC MMIO mappato tramite HHDM (`lapic_phys + g_hhdm_offset`). Funzioni: `lapic_init()`, `lapic_eoi()`, `lapic_id()`, `lapic_send_ipi()`. Timer APIC: `apic_timer_calibrate()` (TODO: calibrazione con HPET), `apic_timer_init()` — periodic mode, vettore 0x20, count hardcoded 1000000 (da calibrare con ACPI/HPET). |
| `asm/context_switch.asm` | Assembly NASM a 64-bit. Contiene: `context_switch(old, new, cr3)` — salva/ripristina tutti i registri GPR, cambia CR3 se necessario; `gdt_flush(gdtr)` — carica GDT e ricarica i segment registers tramite far return; `tss_flush(sel)` — esegue `ltr`; 256 ISR stub generati con macro `%macro` — ogni stub pusha dummy error code (se eccezione senza errore) + numero vettore, poi salta al common handler che pusha tutti i registri e chiama `isr_handler()` in C; tabella `isr_stubs[]` con i 256 indirizzi. Entry 20-255 generate con `%rep 236`. |

### kernel/mm/ — gestione memoria

| File | Scopo |
|---|---|
| `pmm.h / pmm.c` | Physical Memory Manager. Algoritmo: bitmap (1 bit per frame da 4KB) + contatore frame liberi. Inizializzato dalla Limine memmap: segna tutto occupato, libera le regioni `LIMINE_MEMMAP_USABLE`, ri-occupa la bitmap stessa. API: `pmm_alloc_frame()`, `pmm_free_frame()`, `pmm_alloc_frames(n)` per frame contigui (usato da DMA driver), `pmm_total/free_memory()`. Struct globale `g_pmm`. |
| `vmm.h / vmm.c` | Virtual Memory Manager. 4-level paging (PML4→PDPT→PD→PT). Flag PTE: `PRESENT`, `WRITABLE`, `USER`, `NO_CACHE`, `HUGE`, `GLOBAL`, `NX`. EFER.NXE e EFER.SCE abilitati in `vmm_init()`. Layout: userspace `0x0–0x00007FFF…`, HHDM `0xFFFF800000000000`, kernel `0xFFFFFFFF80000000`. API: `vmm_map/unmap/new_pagemap/switch_pagemap/virt_to_phys/destroy_pagemap/clone_pagemap_cow`. Helper inline: `phys_to_virt`, `virt_to_phys`, `vmm_get_cr3`. Init: crea kernel PML4, mappa HHDM (primi 4GB), mappa il kernel stesso, installa CR3. Globali: `g_kernel_pml4`, `g_hhdm_offset`. |
| `slab.h / slab.c` | SLUB-inspired slab allocator. 9 cache di dimensione fissa: 16, 32, 64, 128, 256, 512, 1024, 2048, 4096 bytes. Oggetti > 4096: allocazione diretta via PMM. Header nascosto di 8 byte prima di ogni allocazione: contiene indice cache (0-8) o UINT64_MAX per grandi allocazioni. Questo elimina euristiche di allineamento — kfree è O(1) esatto. API pubblica: `kmalloc(size)`, `kzalloc(size)` (zero-init), `krealloc(ptr, size)`, `kfree(ptr)`. `kfree(NULL)` è no-op. `kmalloc(0)` ritorna NULL. |

### kernel/proc/ — gestione processi e thread

| File | Scopo |
|---|---|
| `process.h / process.c` | Definisce `process_t` (PCB): pid, ppid, uid, gid, name, state, exit_code, pagemap, heap_start/end, stack_top, cpu_context_t, fd_table[FD_MAX], thread list, priority, cpu_time_used, sleep_until, signal_pending/blocked, handlers[SIGNAL_MAX]. NOTA: nessun campo path — dopo execve() il kernel dimentica il percorso del binario. Definisce `thread_t` (TCB): tid, process*, state, context, kernel/user stack, errno_val, fs/gs base (TLS), fpu_state[512] aligned 16 (FXSAVE), fpu_used (lazy FPU), sched_level. Implementa: `process_create` (alloca PCB + pagemap vuoto), `process_destroy` (chiude fd, distrugge thread, libera pagemap), `process_fork` (COW via vmm_clone_pagemap_cow, rax=0 in figlio), `process_execve` (ELF loader, crea pagemap fresco, carica PT_LOAD, alloca stack utente, imposta RIP=e_entry, dimentica path). Include inline ELF64 parser senza libc. |
| `thread.h / thread.c` | thread.h è redirect a process.h (thread_t e le sue API sono dichiarate in process.h). thread.c implementa: `thread_create` (alloca TCB via kzalloc + kernel stack 4 pagine via pmm_alloc_frames, inizializza context con entry/stack/rflags=0x202, collega alla lista thread del processo) e `thread_destroy` (libera kernel stack frame per frame via pmm_free_frame, azzera fpu_state, kfree TCB). Thread non aggiunto allo scheduler da thread_create — responsabilità del chiamante. |
| `signal.h / signal.c` | Gestione segnali POSIX subset. signal.h dichiara: signal_send, signal_handle, signal_set_handler, signal_set_mask. Segnali: SIGHUP=1 … SIGTERM=15, SIGCHLD=17, SIGCONT=18, SIGSTOP=19, SIGTSTP=20. SIGKILL e SIGSTOP non mascherabili (SIGNAL_UNBLOCKABLE). signal_send: imposta bit in signal_pending, sveglia processi sleeping/blocked. signal_handle: trova segnale più prioritario consegnabile, esegue handler utente (imposta RIP=handler, RDI=sig) o azione default (terminate/ignore/continue/stop). SIGKILL → PROCESS_ZOMBIE immediato. |

### kernel/sched/ — scheduler

| File | Scopo |
|---|---|
| `mlfq.h / mlfq.c` | Multilevel Feedback Queue. 8 livelli, quantum raddoppiato per livello: 5, 10, 20, 40, 80, 160, 320, 640 ms. Struct `run_queue_t` (head, tail, quantum_ms, thread_count). Doubly-linked list per O(1) insert/remove. Priority boost ogni PRIORITY_BOOST_MS=1000 ms (anti-starvation): tutti i thread salgono al livello 0. API: `scheduler_init/add/remove/next/tick/yield/block/unblock/priority_boost`. Thread nuovo nasce al livello 0. Esaurisce quantum → scende di un livello. Blocco volontario → mantiene livello. Risveglio da I/O → sale di un livello. `scheduler_next()` mai NULL: ritorna g_idle_thread se code vuote. `MLFQ_QUANTUM_MS` definita come `const` in mlfq.c (non static in header). |

### kernel/fs/ — filesystem

| File | Scopo |
|---|---|
| `vfs.h / vfs.c` | Virtual Filesystem Switch. Struct `vnode_t`: inode, size, mode, uid, gid, timestamps, ops (vtable vfs_ops_t), fs_data, name[256]. NOTA CRITICA: nessun campo refcount — il VFS non ritarda mai unlink() per file aperti. Struct `file_t`: vnode + offset + flags. Struct `filesystem_t` e `mount_t`. Max 32 mount points. API: vfs_init/mount/unmount/lookup/open/close/read/write/unlink/mkdir/stat. Lookup risolve path componente per componente via readdir. Lock: spinlock_t s_vfs_lock={0}. |
| `tmpfs.h / tmpfs.c` | RAM filesystem. Struct interna tmpfs_node_t (vnode + type + data buffer + children/next/parent). Supporta file e directory. write() usa krealloc dinamico con 4KB di overhead. unlink() immediato: libera data buffer e il nodo senza refcount. Helper inline (tm_memset/memcpy/strlen/strcmp/strncpy). Esporta tmpfs_get_fs() → filesystem_t con mount/unmount. |
| `devfs.h / devfs.c` | Device filesystem montato su /dev. Lista linkata di devnode_t registrati dai driver. Protetta da spinlock_irqsave. Built-in: /dev/null (read→EOF, write→discard) e /dev/zero (read→0x00). API: devfs_register(devnode_t*), devfs_unregister(name), devfs_get_fs(). readdir enumerates lista dinamica. Driver registrano i propri devnode dopo init. |
| `fat32.h / fat32.c` | FAT32 read-only. Struct fat32_bpb_t, fat32_dir_entry_t, fat32_fs_t. Lettura cluster chain tramite FAT in-memory (fat_cache). Calcola next_cluster via FAT entries. write/create/mkdir/unlink ritornano -EROFS. mount() ritorna stub root vnode (collegamento a AHCI da completare). Esporta fat32_get_fs(). |
| `mattiafs/mattiafs.h` | Strutture on-disk MattiaFS: `mattiafs_superblock_t` (magic 0x4D415446='MATF', block_size=4096, free_blocks/inodes, journal_inode), `mattiafs_bgd_t` (block group descriptor: block_bitmap_block, inode_bitmap_block, inode_table_block, free_blocks, free_inodes), `mattiafs_inode_t` (mode, uid, gid, size, atime/mtime/ctime, 12 direct_blocks + indirect_block + double_indirect + triple_indirect, xattr), `mattiafs_dirent_t` (inode + rec_len + name_len + name[]). Costanti: MATTIAFS_BLOCK_SIZE=4096, MATTIAFS_INODE_SIZE=256, MATTIAFS_DIRECT_BLOCKS=12, MATTIAFS_BLOCKS_PER_GRP. |
| `mattiafs/mattiafs.c` | Implementazione MattiaFS. mf_read_inode/write_inode: calcola group/index/block/offset. mf_free_block/mf_free_inode_entry: azzera bit in bitmap, aggiorna contatori. mf_free_inode_blocks: libera tutti i blocchi diretti + indiretti. mattiafs_unlink(): rimuove dirent, legge inode, libera TUTTI i blocchi e l'inode — immediatamente, senza refcount, senza check se aperto (Principio 2). mattiafs_read(): legge blocchi diretti via direct_blocks[]. write(): ritorna -ENOSYS (block allocator da implementare). mount() ritorna stub root vnode (inode #2). |

### kernel/drivers/ — driver hardware

| File | Scopo |
|---|---|
| `driver.h` | Interfaccia base driver. Struct: `driver_t` (name, version, probe/init/remove), `device_t` (name, type, state, net_ops, block_ops, char_ops, driver_data, parent, children, sibling, next, lock), `devnode_t` (name, type, ops/char_ops/block_ops, driver_data, next), `net_ops_t` (send_packet, get_mac, set_mac, enable_rx, disable_rx, ioctl, rx_callback, mtu), `block_ops_t` (read_sectors, write_sectors, flush, get_sector_count, get_sector_size), `char_ops_t` (read, write, ioctl). MMIO helpers inline: mmio_read32/64, mmio_write32/64, mmio_barrier. typedef irq_handler_t. Enum dev_type_t, dev_state_t. |
| `irq.h / irq.c` | irq.h redirect a driver.h. irq.c implementa: tabella `g_irq_handlers[256]`, register_irq_handler/unregister_irq_handler con spinlock_irqsave. device tree: g_device_root, device_alloc/add/remove/find_by_name/find_by_type. driver_register. `drivers_init()`: azzera g_irq_handlers, alloca g_device_root ("root"), chiama in ordine: fb_init, ps2_init, keyboard_init, ahci_init, nvme_init, virtio_net_init, e1000_init. Include reali header storage e net (nessun stub weak). |
| `pci.h / pci.c` | PCI config space via I/O port 0xCF8/0xCFC (mechanism 1). Struct `pci_device_t` (bus, dev, func, vendor_id, device_id, class_code, subclass, prog_if, header_type, irq_line). Array globale g_pci_devices[PCI_MAX_DEVICES=256]. API completa: pci_read8/16/32, pci_write16/32, pci_get_bar (32/64-bit), pci_bar_is_mmio/64bit, pci_bar_size, pci_enable_busmaster, pci_enable_mmio, pci_disable_interrupts, pci_enumerate (scansiona tutti i bus/device/function), pci_find_device (class+subclass), pci_find_device_by_id (vendor+device), pci_find_device_any_id (vendor + array di device_id). |
| `video/fb.h / fb.c` | Framebuffer GOP da Limine. Struct fb_info_t (addr, width, height, pitch, bpp). API: fb_write_pixel, fb_fill_rect, fb_blit (copia rettangolo), fb_clear. ioctl: FB_IOCTL_GET_INFO, FB_IOCTL_FILL_RECT, FB_IOCTL_BLIT, FB_IOCTL_CLEAR. Registra /dev/fb0 in devfs. device_add in device tree. |
| `input/ps2.h / ps2.c` | PS/2 controller Intel 8042. Self-test controller (0xAA). Configura porta 1 (tastiera): IRQ1 → vettore 0x21. Configura porta 2 (mouse): IRQ12 → vettore 0x2C. Scan code set 2 attivato. Ring buffer circolare per scan code grezzi. Registra ps2_ctrl_dev e ps2_kbd_dev nel device tree. |
| `input/keyboard.h / keyboard.c` | Conversione scan code PS/2 set 2 → keycode virtuale vk_t. State machine per sequenze multi-byte: E0 prefix, F0 break, E0+F0 release. Tabelle SC2→VK con designated initializers {[N]=VK_X}. Modificatori: Shift (L/R), Ctrl (L/R), Alt (L/R), CapsLock, NumLock, ScrollLock. LED sync via PS/2 command 0xED. `ascii_from_vk(vk, mods)` → char ASCII. Ring buffer key_event_t (vk + mods + ascii + pressed). `keyboard_process()` da chiamare ogni tick APIC (connessione mancante — nota aperta). `keyboard_get_event()` per consumare eventi. |
| `storage/ahci.h / ahci.c` | AHCI 1.3.1 / SATA driver. PCI class=0x01 subclass=0x06, BAR5=HBA MMIO (mapped via HHDM). Supporta fino a AHCI_MAX_PORTS=8 porte. Per ogni porta: 1 command slot, command list (1KB), FIS buffer (256B), command table (256B), data buffer (128KB). LBA48 READ/WRITE DMA EXT (0x25/0x35). Batch max 128 settori. I/O polled su PxCI bit, timeout 1M cicli. spinlock_irqsave per porta. Registra /dev/sda, /dev/sdb, … in devfs con block_ops. ioctl: AHCI_IOCTL_GET_SECTORS (0xA001), GET_SECT_SIZE (0xA002), FLUSH (0xA003). API: ahci_init, ahci_read, ahci_write. |
| `storage/nvme.h / nvme.c` | NVMe 1.4 driver. PCI class=0x01 subclass=0x08, BAR0=Controller MMIO 64-bit. Supporta fino a 4 namespace. Admin Queue (64 entry CQ+SQ) per identify/create_ioq. I/O Queue (256 entry, qid=1) per read/write. PRP: singola/doppia/lista (per trasferimenti >8KB). I/O polled su CQ phase tag, timeout 2M cicli. spinlock_irqsave per admin e io queue. Registra /dev/nvme0, /dev/nvme1, … con block_ops. ioctl: NVME_IOCTL_GET_SECTORS (0xE001), GET_SECT_SIZE (0xE002), FLUSH (0xE003). API: nvme_init, nvme_read, nvme_write. |
| `net/virtio_net.h / virtio_net.c` | VirtIO-Net legacy PCI (spec 0.9.5). PCI vendor=0x1AF4 device=0x1000/0x1041. BAR0=I/O port space (inb/outb/inw/outw). 2 virtqueue: RX (vq0, 256 entry) + TX (vq1, 256 entry). Vring: desc table 16B×256 + avail ring (pagina 0) + used ring (pagina 1, page-aligned). RX pre-popolato con 256 DMA buffer da VNET_BUF_SIZE=1526B (12B virtio_net_hdr + 1514B frame). TX: polled su used ring, prepende virtio_net_hdr automaticamente. RX: IRQ-driven (vettore=irq_line+0x20), drain used ring → chiama net_ops.rx_callback. Feature negotiation: VIRTIO_NET_F_MAC only. MTU=1514. spinlock_irqsave per TX. Registra /dev/eth0, ioctl SIOCGIFHWADDR (0x8927). API: virtio_net_init, virtio_net_send. |
| `net/e1000.h / e1000.c` | Intel e1000 Gigabit Ethernet. Supporta: 82540EM (0x100E), 82545EM (0x100F), 82574L (0x10D3), I217LM (0x153A). PCI vendor=0x8086. BAR0=128KB MMIO (accesso via HHDM + mmio_read32/write32). TX ring: 64 entry (e1000_tx_desc_t 16B), polled su DD bit in status. RX ring: 64 entry (e1000_rx_desc_t 16B), 2048B/buffer, IRQ-driven (ICR_RXT0+ICR_LSC, vettore=irq_line+0x20). MAC: letto da EEPROM (EERD busy-wait, 3 word: mac[1:0]/mac[3:2]/mac[5:4]) con fallback RAL/RAH se AV=1. Reset hardware via CTRL.RST. Configura TCTL/RCTL/TIPG=0x0060200A. Azzera MTA (128 entry). Registra /dev/eth0 (o /dev/eth1 se già occupata). ioctl: E1000_IOCTL_GET_MAC (0xB001), E1000_IOCTL_SET_PROMISC (0xB002). API: e1000_init, e1000_send. |

### kernel/ipc/ — inter-process communication (Fase 9)

| File | Scopo |
|---|---|
| `shm.h / shm.c` | Shared memory. Regioni identificate da chiave numerica. Implementate mappando la stessa pagina fisica in più spazi virtuali diversi. Usate dal compositor GUI per condividere buffer di rendering. API: shm_create, shm_attach, shm_detach, shm_destroy. |
| `msgq.h / msgq.c` | Message queues. Ring buffer kernel-side con lock. Blocco su coda piena/vuota tramite scheduler_block/unblock. API POSIX-like: mq_open, mq_close, mq_send, mq_receive, mq_unlink. |

### kernel/net/ — stack di rete (Fase 9)

| File | Scopo |
|---|---|
| `ethernet.h / ethernet.c` | Parsing frame Ethernet (dst MAC 6B + src MAC 6B + ethertype 2B). Dispatch: ARP (0x0806) → arp.c, IPv4 (0x0800) → ipv4.c. rx_callback installato in net_ops_t dei driver NIC. |
| `arp.h / arp.c` | ARP request/reply per risoluzione IP→MAC. Cache ARP in hash table (max 64 entry, LRU). arp_resolve: risolve IP→MAC, invia ARP request se miss. arp_handle: processa ARP reply in arrivo. |
| `ipv4.h / ipv4.c` | IPv4: header parsing, checksum ones complement, frammentazione/riassemblaggio (max 64 frammenti). Routing table minimale (default gateway + loopback). Dispatch a TCP/UDP/ICMP per campo protocol. |
| `icmp.h / icmp.c` | ICMP echo request (type 8) → echo reply (type 0). Checksum. type 3 (destination unreachable) per errori UDP/TCP. |
| `udp.h / udp.c` | UDP connectionless. Struct udp_socket_t. Binding porta, demultiplexing. Ring buffer receive per socket. |
| `tcp.h / tcp.c` | TCP state machine completa (CLOSED→SYN_SENT→ESTABLISHED→FIN_WAIT1→FIN_WAIT2→TIME_WAIT→CLOSED). Sliding window (rwnd + cwnd). Congestion control Reno. Retransmission timer (RTO Jacobson/Karels). |
| `socket.h / socket.c` | BSD socket API: socket/bind/listen/accept/connect/send/recv/close/setsockopt. AF_INET + SOCK_STREAM (TCP) + SOCK_DGRAM (UDP). Integrato con VFS: ogni socket è un fd su vnode devfs. |

### kernel/acpi/ (Fase 9)

| File | Scopo |
|---|---|
| `acpi.h / acpi.c` | Parsing tabelle ACPI dal RSDP fornito da Limine. RSDT/XSDT (preferisce XSDT se revision >= 2). MADT: trova Local APIC e I/O APIC per ogni core (necessario per SMP), popola s_cpus[] e s_ioapics[]. HPET: timer alta precisione, abilita main counter a boot, espone base MMIO virtuale e periodo in femtosecondi per calibrazione APIC timer (risolve il TODO in apic_timer_calibrate). MCFG e FADT: strutture dichiarate, ricercabili tramite acpi_find_table(). API: acpi_init(uint64_t rsdp_phys), acpi_find_table(sig), acpi_get_madt, acpi_get_hpet, acpi_hpet_period_fs. Chiamata da entry.c PRIMA di lapic_init. Helper no-libc interni (ac_memcmp, ac_memcpy, phys_to_virt via g_hhdm_offset). Validazione checksum su RSDP, XSDT/RSDT e ogni tabella individuale. apic.c aggiornato: apic_timer_calibrate() implementa ora la calibrazione reale via HPET (busy-wait 10ms, misura tick LAPIC, calcola g_apic_ticks_per_ms). entry.c aggiornato: acpi_init() chiamata dopo slab_init() e prima di lapic_init(). |

### userspace/ (Fase 12)

| File | Scopo |
|---|---|
| `init/init.c` | PID 1. Prima cosa che gira in userspace. Monta: devfs su /dev, tmpfs su /tmp e /proc, MattiaFS sulla partizione root. Configura device nodes. Lancia shell su TTY. Adotta processi orfani. Gestisce SIGCHLD per cleanup zombie. |
| `shell/shell.c` | mattiaos-sh. Tokenizer con gestione quote. Variabili d'ambiente. Ridirezione I/O (> < >> 2> 2>&1). Pipe (|). Background (&). Job control (fg, bg, Ctrl+C, Ctrl+Z). Glob (* ?). Builtins: cd, echo, export, unset, exit, pwd, history, source, alias. History su ~/.mattiaos_history. |
| `coreutils/rm.c` | Eliminazione immediata e completa. Flag -r ricorsivo, -f forza. NESSUN controllo "file in uso". Se aperto da un processo, viene eliminato comunque dal disco. |
| `coreutils/ls,cp,mv,mkdir,cat,touch` | Operazioni filesystem di base. |
| `coreutils/find,stat,ln,chmod,chown` | Ricerca e metadati. stat non indica mai "file in uso". |
| `coreutils/ps,kill,top` | Gestione processi. |
| `coreutils/mount,umount,uname,free,df,du,dmesg` | Amministrazione sistema. |
| `coreutils/ping,ifconfig` | Rete. |
| `coreutils/grep,sed,wc,head,tail,sort,cut,echo` | Strumenti testo. |
| `coreutils/edit.c` | Editor TUI tipo nano. Obbligatorio prima della GUI. |

### gui/ (Fase 13-16 — solo dopo Milestone 5)

| File | Scopo |
|---|---|
| `compositor/compositor.c` | Display server userspace. Accede a /dev/fb0 direttamente. Compositing superfici in ordine Z. IPC con client via socket. Smista eventi input. |
| `wm/wm.c` | Window Manager. Floating e tiling. Title bar 32px, border 4px per resize. |
| `toolkit/libgui.h / libgui.c` | Widget toolkit: Label, Button, Input, List, Menu, Progressbar. Signal/slot. Layout: HBOX/VBOX/GRID/FLOW. |
| `toolkit/render2d.h / render2d.c` | Software 2D renderer. fill_rect, draw_line, fill_circle. Testo con font PSF2/TrueType. blit con alpha compositing ARGB. |
| `apps/terminal/` | VT100/ANSI + PTY + font monospace. |
| `apps/filemanager/` | Browse MattiaFS, operazioni CRUD, preview. |
| `apps/texteditor/` | Syntax highlighting base. |
| `apps/sysmonitor/` | CPU%, RAM, processi, grafici real-time. |
| `apps/settings/` | Tema, risoluzione, rete, sistema. |

### libc/ (Fase 11)

| File | Scopo |
|---|---|
| `string/` | memcpy, memmove, memset, memcmp, strlen, strcmp, strcpy, strcat, strdup, strtok, strstr. |
| `stdlib/` | malloc, free, realloc, atoi, atol, strtol, strtoul, qsort, bsearch, exit, abort, rand. |
| `stdio/` | printf, fprintf, sprintf, snprintf, vprintf (%d %s %x %f %ld %lld %zu %p, width, precision). fopen, fclose, fread, fwrite, fgets, fputs, fseek, ftell. |
| `math/` | sin, cos, tan, sqrt, pow, floor, ceil, fabs, log, exp — wrapper SSE/x87. |

---

### Stato file per fase

| File | Fase | Stato |
|---|---|---|
| `kernel/include/types.h` | 0 | ✅ creato e verificato |
| `kernel/include/errno.h` | 0 | ✅ creato e verificato |
| `kernel/include/syscall_numbers.h` | 10 | ✅ creato e verificato |
| `kernel/arch/x86_64/linker.ld` | 1 | ✅ creato e verificato |
| `kernel/arch/x86_64/entry.h / entry.c` | 1 | ✅ creato e verificato |
| `kernel/arch/x86_64/cpu.h / cpu.c` | 2 | ✅ creato e verificato |
| `kernel/arch/x86_64/gdt.h / gdt.c` | 2 | ✅ creato e verificato |
| `kernel/arch/x86_64/idt.h / idt.c` | 4 | ✅ creato e verificato |
| `kernel/arch/x86_64/apic.h / apic.c` | 4 | ✅ creato e verificato |
| `kernel/arch/x86_64/asm/context_switch.asm` | 5 | ✅ creato e verificato |
| `kernel/mm/pmm.h / pmm.c` | 3 | ✅ creato e verificato |
| `kernel/mm/vmm.h / vmm.c` | 3 | ✅ creato e verificato (fix v3.6.2: low memory identity map in vmm_init) |
| `kernel/mm/slab.h / slab.c` | 3 | ✅ creato e verificato |
| `kernel/proc/process.h / process.c` | 5 | ✅ creato e verificato |
| `kernel/proc/thread.h / thread.c` | 5 | ✅ creato e verificato |
| `kernel/proc/signal.h / signal.c` | 5 | ✅ creato e verificato |
| `kernel/sched/mlfq.h / mlfq.c` | 6 | ✅ creato e verificato |
| `kernel/fs/vfs.h / vfs.c` | 7 | ✅ creato e verificato |
| `kernel/fs/tmpfs.h / tmpfs.c` | 7 | ✅ creato e verificato |
| `kernel/fs/devfs.h / devfs.c` | 7 | ✅ creato e verificato |
| `kernel/fs/fat32.h / fat32.c` | 7 | ✅ creato e verificato |
| `kernel/fs/mattiafs/mattiafs.h / mattiafs.c` | 7 | ✅ creato e verificato |
| `kernel/drivers/driver.h` | 8 | ✅ creato e verificato |
| `kernel/drivers/irq.h / irq.c` | 8 | ✅ creato e verificato |
| `kernel/drivers/pci.h / pci.c` | 8 | ✅ creato e verificato (era troncato — ricostruito) |
| `kernel/drivers/video/fb.h / fb.c` | 8 | ✅ creato e verificato |
| `kernel/drivers/input/ps2.h / ps2.c` | 8 | ✅ creato e verificato |
| `kernel/drivers/input/keyboard.h / keyboard.c` | 8 | ✅ creato e verificato |
| `kernel/drivers/storage/ahci.h / ahci.c` | 8 | ✅ creato e verificato |
| `kernel/drivers/storage/nvme.h / nvme.c` | 8 | ✅ creato e verificato |
| `kernel/drivers/net/virtio_net.h / virtio_net.c` | 8 | ✅ creato e verificato |
| `kernel/drivers/net/e1000.h / e1000.c` | 8 | ✅ creato e verificato |
| `boot/limine.cfg` | 1 | ✅ creato e verificato |
| `Makefile` | 0 | ✅ creato e verificato |
| `scripts/build_toolchain.sh` | 0 | ✅ creato e verificato |
| `scripts/run_qemu.sh` | 0 | ✅ creato e verificato |
| `.gitignore` | 0 | ✅ creato e verificato |
| `kernel/limine.h` | 1 | ✅ creato v3.0 (ricostruito da spec — rete non disponibile in build env) |
| `kernel/lib/string.c` | 0 | ✅ creato v3.0 (memset/memcpy/strlen per kernel freestanding) |
| `kernel/arch/x86_64/asm/context_switch_gas.S` | 5 | ✅ creato v3.0 (conversione GAS/Intel del .asm originale per compilazione senza nasm) |
| `libc/Makefile` | 11 | ✅ creato v3.0 |
| `userspace/Makefile` | 12 | ✅ creato v3.0 |
| `userspace/crt0.c` | 12 | ✅ creato e verificato (Fase 12 — v2.9/v3.0) |
| `userspace/include/userspace.h` | 12 | ✅ creato e verificato (Fase 12 — v2.9/v3.0) |
| `kernel/acpi/acpi.h / acpi.c` | 9 | ✅ creato e verificato |
| `kernel/ipc/shm.h / shm.c` | 9 | ✅ creato |
| `kernel/ipc/msgq.h / msgq.c` | 9 | ✅ creato |
| `kernel/net/ethernet.h / ethernet.c` | 9 | ✅ creato |
| `kernel/net/arp.h / arp.c` | 9 | ✅ creato |
| `kernel/net/ipv4.h / ipv4.c` | 9 | ✅ creato |
| `kernel/net/icmp.h / icmp.c` | 9 | ✅ creato |
| `kernel/net/udp.h / udp.c` | 9 | ✅ creato |
| `kernel/net/tcp.h / tcp.c` | 9 | ✅ creato |
| `kernel/net/socket.h / socket.c` | 9 | ✅ creato |
| `libc/` (tutti) | 11 | ✅ creato e verificato (Fase 11 — v2.8) |
| `userspace/init/init.c` | 12 | ✅ creato e verificato (Fase 12 — v2.9/v3.0) |
| `userspace/shell/shell.c` | 12 | ✅ creato e verificato (Fase 12 — v2.9/v3.0) |
| `userspace/coreutils/` (tutti i 33) | 12 | ✅ creato e verificato (Fase 12 — v2.9/v3.0) |
| `gui/` (tutti) | 13-16 | 🔲 da creare (Fase 13-16) |

Legenda: ✅ creato e verificato | 🔄 in sviluppo | 🔲 da creare | ⚠️ da revisionare

---

# SEZIONE 4 — STATO DEL PROGETTO

| Campo | Valore |
|---|---|
| **Versione blueprint** | v5.7 |
| **Versione zip corrente** | MattiaOS_v5.7.zip |
| **ISO bootabile corrente** | mattiaos.iso (El Torito BIOS, 6/6 check strutturali OK) |
| **DRIVER HARDWARE — STATO** | ✅ TUTTI I DRIVER DI FASE 8 COMPLETI E VERIFICATI. Audit doppio (v2.3+v2.4): 26/26 file .c compilano -Wall -Wextra -Werror. |
| **Fase corrente** | Fase 12 COMPLETATA. VFS funzionante: ls/cd/clear/help/ver/mem/pci/halt/reboot operativi nella console kernel. Tastiera PS/2 funzionante (PIC rimappato v3.7). |
| **Ultimo completato** | Sessione v5.7: corretti 3 bug critici VFS (vfs_lookup liberava il nodo radice, tmpfs ops=NULL su nuovi nodi, tmpfs_stat mancante). Aggiunte directory /Binari_Eseguibili e /Dipendenze con /Dipendenze/dipendenze.cfg. Versione bumped a v5.7. |
| **Prossimo passo** | Fase 13 — ELF loader completo in process_execve() + syscall dispatcher (MSR_LSTAR, handler asm, tabella 300+ entry). Priorità: SYS_EXECVE con load_elf(), SYS_RT_SIGACTION, SYS_SETSID, SYS_GETDENTS64, SYS_NANOSLEEP, SYS_SYSINFO, SYS_STATFS. |
| **File sorgente** | 62 file kernel (29 .c + 30 .h + 1 .S + 1 .asm + 1 .ld) + 2 bootloader .asm + 4 libc .c + 36 userspace .c |
| **Compilazione kernel** | ✅ VERIFICATA v5.7: 0 errori, 0 warning. kernel.elf: 196032B (con padding 576B → 192 settori CD), entry 0xffffffff800081ad. .limine_requests paddr=0x366000. Flags: -std=gnu11 -ffreestanding -fno-pic -fno-pie -mno-red-zone -mcmodel=kernel -Wall -Wextra -Werror |
| **Compilazione bootloader** | ✅ stage1.bin e stage2.bin compilati con NASM 3.01. Stage2 legge entry point dinamicamente dall'ELF header (mov rax,[rbx+0x18]) — nessun hardcode da aggiornare dopo ricompilazione kernel. |
| **Limine offsets v5.7** | .limine_requests paddr=0x366000. HHDM response*: section+0x128 (abs 0x366128). MEMMAP response*: section+0x0A8 (abs 0x3660A8). KADDR response*: section+0x0E8 (abs 0x3660E8). Verificati con ELF parser Python. |
| **Note aperte** | (1) COW #PF handler: vmm_clone_pagemap_cow pronto ma idt.c fa panic su #PF — da implementare Fase 13. (2) keyboard_process() non collegata al tick APIC. (3) tcp_timer_tick() non collegata al timer APIC. (4) fat32.c: read_sectors non collegata ad AHCI. (5) mattiafs write(): -ENOSYS. (6) **CRITICO PERMANENTE**: offset .limine_requests cambiano ad ogni ricompilazione kernel. Dopo ogni `make kernel` rieseguire ELF parser Python (Appendice C). Stage2 legge l'entry point dal header ELF dinamicamente (non hardcoded). |
| **Dimensione blueprint** | ~125 KB (v5.7) |

---

# SEZIONE 5 — STACK TECNOLOGICO

| Componente | Scelta | Alternativa Scartata | Motivo |
|---|---|---|---|
| Architettura CPU | x86-64 | ARM64 | Documentazione, VM, disponibilità |
| Bootloader | Limine v8 | GRUB2 / custom | UEFI nativo, framebuffer, mappa memoria, HPET |
| Linguaggio Kernel | C11 + NASM | C++, Rust | Controllo totale, ABI stabile, nessun runtime |
| Linguaggio Userspace | C11, poi C++ | Rust | Semplicità iniziale, libc propria |
| Compilatore | GCC cross (x86_64-elf) binutils 2.41 + GCC 13.2.0 — versioni fisse, non aggiornare senza testare | Clang | Maturità |
| Assembler | NASM | GNU as | Sintassi Intel, controllo esplicito |
| Linker | GNU ld (binutils) | lld | Standard, ben documentato |
| Build System | GNU Make + Bash | CMake, Meson | Semplicità, no dipendenze |
| Formato eseguibile | ELF64 | PE32+, Mach-O | Standard Unix, supporto nativo GCC |
| Boot Protocol | Limine Boot Protocol | Multiboot2 | Framebuffer nativo, mappa memoria, HPET |
| Memoria virtuale | 4-level paging (PML4) | 5-level | Standard x86-64, sufficiente per 128 TB |
| Filesystem nativo | MattiaFS (ext4-inspired, magic 0x4D415446='MATF') | ext2, FAT32 | Design proprio; FAT32 read-only per EFI |
| File locking | Nessuno — eliminazione immediata | Reference counting | Principio 2 |
| Display protocol | Custom compositor (Wayland-inspired) | X11 | X11 legacy; Wayland troppo complesso da portare |
| IPC principale | Shared memory + message queues | Unix sockets | Performance GUI; sockets secondari |
| Allocatore kernel | SLUB-like slab (cache 16–4096 bytes, header 8B nascosto) | buddy puro | Frammentazione ridotta, cache-friendly, kfree O(1) esatto |
| Allocatore user | dlmalloc / ptmalloc variant | jemalloc | Semplicità iniziale |
| Version control | Git + GitHub | — | Backup, storico |
| PCI access | I/O port mechanism 1 (0xCF8/0xCFC) | MMIO/MCFG | Universale; PCIe MMIO aggiunto con ACPI |
| Driver NIC sviluppo | VirtIO-Net legacy (0x1AF4/0x1000) | e1000 come primario | QEMU default, nessun hardware richiesto |
| Driver NIC hardware | Intel e1000 (82540/82545/82574/I217) | RTL8139, RTL8169 | Documentazione eccellente, QEMU+hardware reale |
| Driver storage SATA | AHCI 1.3.1 (PCI 01/06) | PATA/IDE | Standard moderno, DMA nativo |
| Driver storage NVMe | NVMe 1.4 (PCI 01/08) | virtio-blk | Hardware reale, spec pubblica |
| Calibrazione timer | HPET da ACPI (da implementare) | PIT 8253 | HPET più preciso, già supportato da Limine |

---

# SEZIONE 6 — ROADMAP

## Milestone 0 — "Hello Screen" (Settimane 1–3)
- [x] Setup toolchain cross-compiler GCC x86_64-elf (script pronto)
- [x] Struttura repository completa
- [ ] Kernel bootabile con Limine — output seriale funzionante
- [ ] Testo su framebuffer (font bitmap 8x16 embedded nel kernel)

## Milestone 1 — "Memory" (Settimane 4–7)
- [x] GDT + TSS + IDT completa (codice scritto)
- [x] PMM con bitmap (codice scritto)
- [x] VMM 4-level paging + EFER.NXE/SCE (codice scritto)
- [x] Slab allocator kmalloc/kfree con header hidden (codice scritto)
- [ ] Test: PMM+VMM funzionano in QEMU senza crash
- [ ] #PF handler con demand paging e COW (vmm_clone_pagemap_cow pronto, manca handler)

## Milestone 2 — "Process" (Settimane 8–12)
- [x] process.c: process_create, process_fork (COW), process_execve (ELF loader)
- [x] thread.c: thread_create, thread_destroy
- [x] context_switch.asm: salva/ripristina registri, cambia CR3
- [x] APIC timer + scheduler MLFQ 8 livelli
- [ ] Collegamento scheduler → context_switch in produzione
- [ ] Idle thread per ogni CPU

## Milestone 3 — "Storage & Filesystem" (Settimane 13–18)
- [x] vfs.c — VFS layer (senza refcount)
- [x] tmpfs.c — RAM filesystem
- [x] devfs.c — device filesystem
- [x] AHCI driver completo
- [x] NVMe driver completo
- [x] FAT32 read-only
- [x] MattiaFS base (read + unlink immediata; write richiede block allocator)
- [ ] Block allocator MattiaFS
- [ ] Collegamento fat32 ↔ AHCI block_ops

## Milestone 4 — "Userspace" (Settimane 19–24)
- [x] ACPI (MADT/HPET) — prerequisito per calibrazione timer e SMP — **completato v2.5**
- [ ] Syscall via syscall/sysret (wrmsr MSR_LSTAR, handler assembly, tabella)
- [ ] libc minimale custom
- [ ] init (PID 1)
- [ ] Shell testuale (mattiaos-sh)

## Milestone 5 — "CLI Completa" (Settimane 25–32)
- [ ] Tutti i comandi CLI base (coreutils)
- [ ] Editor di testo TUI
- [x] Driver NIC (virtio_net + e1000 completi)
- [ ] Stack rete kernel (ethernet/arp/ipv4/icmp/udp/tcp/socket — Fase 9)
- **Fine Milestone 5 = sistema CLI stabile. Da qui si sviluppa la GUI.**

## Milestone 6 — "GUI Base" (Settimane 33–42)
- [ ] Compositor (display server userspace, /dev/fb0)
- [ ] Software 2D renderer
- [ ] Window Manager
- [ ] Widget Toolkit (libgui)
- [ ] Terminal Emulator grafico

## Milestone 7 — "GUI Completa" (Settimane 43+)
- [ ] Font TrueType (stb_truetype), PNG/JPEG (stb_image)
- [ ] File Manager, Text Editor, System Monitor, Settings
- [ ] USB HID
- [ ] SMP multi-core

---

# SEZIONE 7 — MATRICE DIPENDENZE

```
Limine
  └─► kernel_main (entry.c)
        ├─► gdt_init() ──► idt_init()
        │                      └─► lapic_init() ──► apic_timer_init() ──► scheduler (MLFQ)
        ├─► serial_init() [debug immediato]
        ├─► pmm_init() ──► vmm_init() (EFER.NXE+SCE) ──► slab_init() ──► [tutti i kmalloc]
        ├─► [FASE 9] acpi_init() ──► MADT → APIC/IOAPIC; HPET → calibra timer
        ├─► pci_enumerate() ──► g_pci_devices[] → probe AHCI/NVMe/NIC
        ├─► vfs_init() + vfs_mount("/dev") ──► devfs pronto prima dei driver
        ├─► sti
        └─► drivers_init():
              fb_init()          → /dev/fb0
              ps2_init()         → IRQ1 (kbd 0x21) + IRQ12 (mouse 0x2C)
              keyboard_init()    → sc2 → vk → ascii [TODO: collegare a timer tick]
              ahci_init()        → /dev/sda, sdb, ... + block_ops
              nvme_init()        → /dev/nvme0, nvme1, ... + block_ops
              virtio_net_init()  → /dev/eth0 + net_ops [rx_callback NULL finché ethernet.c non esiste]
              e1000_init()       → /dev/eth0|eth1 + net_ops [stessa nota]

[FASE 9 — dipendenze interne]:
  acpi.c ──► MADT → lapic: abilitazione multi-core
          └─► HPET → apic_timer_calibrate() (risolve TODO in apic.c)
  ethernet.c ──► net_ops_t.rx_callback (installato su device_t via e1000/virtio)
    └─► arp.c ──► cache IP→MAC, integrato con ipv4.c
    └─► ipv4.c ──► icmp.c, udp.c, tcp.c
                         └─► socket.c ──► VFS fd ──► userspace
  shm.c ──► VMM (stessa pagina fisica in spazi virtuali multipli)
  msgq.c ──► scheduler_block/unblock

[FASE 10 — syscall]:
  MSR_LSTAR wrmsr ──► handler assembly ──► tabella syscall C
    └─► libc ──► init (PID 1) ──► shell ──► coreutils

[FASE 13+ — GUI]:
  /dev/fb0 ──► compositor ──► WM ──► libgui ──► app GUI
              └─► shm (buffer condivisi tra compositor e app)

[Dipendenze critiche non ancora collegate]:
  fat32.c → AHCI block_ops:  read_sectors non ancora implementata in fat32
  keyboard_process() → APIC timer tick: manca la chiamata
  #PF handler → vmm_clone_pagemap_cow: COW non completato
  acpi_init() → entry.c: COLLEGATO in v2.5 (dopo slab_init, prima di lapic_init)
```

---

# SEZIONE 8 — CONVENZIONI DI CODICE

## Naming
- Tipi: `snake_case_t` (es. `process_t`, `phys_addr_t`)
- Funzioni: `modulo_azione` (es. `pmm_alloc_frame`, `vmm_map`, `mattiafs_unlink`)
- Macro / costanti: `UPPER_SNAKE_CASE` (es. `PAGE_SIZE`, `KERNEL_BASE`)
- Variabili globali kernel: prefisso `g_` (es. `g_current_process`, `g_hhdm_offset`)
- Variabili static file-scope: prefisso `s_` (es. `s_pmm_lock`, `s_lapic_virt`)

## Error handling
Funzioni ritornano `int` con valori da `errno.h` (`EOK`, `ENOMEM`, ecc.). Mai valori positivi per errori. Controllare sempre il valore di ritorno prima di procedere.

## Locking
- `spinlock_t`: busy-wait con `pause`, solo per sezioni brevissime (< µs)
- `mutex_t`: sleep-lock, per sezioni lunghe
- In interrupt handler: solo `spinlock_irqsave/irqrestore`
- Inizializzazione: `spinlock_t lock = {0}` — mai `= 0` diretto

## No libc in kernel
I file .c del kernel non includono mai `<string.h>`, `<stdlib.h>` o altri header libc standard. Usano helper inline statici (es. `vn_memset`, `e_memcpy`) o le funzioni di slab.h/vmm.h. Unica eccezione: `<limine.h>` per il protocollo bootloader.

## Documentazione
Ogni funzione pubblica ha un commento che spiega scopo, parametri, return value. Commenti critici di architettura (es. "no refcount per Principio 2") nel file `.h`.

## Compilazione target
`-std=gnu11 -ffreestanding -fno-pic -fno-pie -fno-stack-protector -mcmodel=kernel -mno-red-zone -mno-mmx -mno-sse -mno-sse2 -Wall -Wextra -Werror`
Nota: `-std=gnu11` (non `-std=c11`) necessario per la keyword `asm volatile`.
Nota: `-fno-pic -fno-pie` obbligatori con `-mcmodel=kernel` (PIC + kernel model sono incompatibili).

---

# SEZIONE 9 — TESTING E DEBUGGING

## QEMU + GDB
```
qemu-system-x86_64 -s -S [altri flag]
gdb kernel.elf
(gdb) target remote :1234
(gdb) hbreak kernel_main
(gdb) continue
```

## Comando QEMU di riferimento (Fase 8)
```bash
qemu-system-x86_64                          \
  -M q35 -m 256M                            \
  -bios /usr/share/ovmf/OVMF.fd             \
  -cdrom mattiaos.iso                        \
  -serial stdio                              \
  -no-reboot                                 \
  -drive file=disk.img,format=raw            \
  -netdev user,id=net0                       \
  -device virtio-net-pci,netdev=net0
```

## Serial logging
Livelli: TRACE(0), DEBUG(1), INFO(2), WARN(3), ERROR(4), PANIC(5).
Funzione: `klog(int level, const char *module, const char *fmt, ...)`

## PANIC
`PANIC(fmt, ...)` → stampa su seriale, dump registri e stack trace, `cli; hlt`

## Checklist pre-commit
- Compila senza warning: `-std=gnu11 -ffreestanding -Wall -Wextra -Werror`
- Output seriale mostra init corretto di tutti i moduli
- Nessun kernel panic nei test base QEMU
- Blueprint aggiornato e riscritto per intero
- `wc -c docs/OS_PROJECT_BLUEPRINT.md` >= versione precedente
- Zip `MattiaOS_vX.Y.zip` creato e allegato

---

# SEZIONE 10 — MAPPA FILE RUNTIME (sistema avviato)

| Percorso | Filesystem | Tipo | Scopo |
|---|---|---|---|
| `/` | MattiaFS | directory | Root filesystem |
| `/boot` | FAT32 | directory | Partizione EFI/boot (read-only) |
| `/boot/limine.cfg` | FAT32 | testo | Config bootloader |
| `/boot/kernel.elf` | FAT32 | ELF64 | Kernel compilato |
| `/dev` | devfs | directory | Device files |
| `/dev/fb0` | devfs | char | Framebuffer lineare GOP (1280×720×32bpp) |
| `/dev/tty0` | devfs | char | Console di sistema |
| `/dev/ttyS0` | devfs | char | Porta seriale COM1 |
| `/dev/sda` | devfs | block | Primo disco SATA (AHCI) |
| `/dev/nvme0` | devfs | block | Primo namespace NVMe |
| `/dev/eth0` | devfs | char | Prima NIC (VirtIO-Net in VM) |
| `/dev/eth1` | devfs | char | Seconda NIC (e1000 se presente) |
| `/dev/null` | devfs | char | Scarta tutto, ritorna EOF |
| `/dev/zero` | devfs | char | Ritorna infiniti byte 0x00 |
| `/dev/random` | devfs | char | Dati casuali |
| `/tmp` | tmpfs | directory | File temporanei in RAM |
| `/Binari_Eseguibili` | tmpfs | directory | Binari eseguibili MattiaOS (equivalente /bin + /usr/bin) — creato al boot |
| `/Dipendenze` | tmpfs | directory | Librerie condivise (equivalente /lib) — creato al boot |
| `/Dipendenze/dipendenze.cfg` | tmpfs | testo | Registro librerie→programmi; le librerie senza utenti vengono eliminate automaticamente |
| `/proc` | procfs | directory | Info processi e sistema |
| `/bin/init` | MattiaFS | ELF64 | Init system, PID 1 |
| `/bin/sh` | MattiaFS | ELF64 | Shell (mattiaos-sh) |
| `/bin/rm` | MattiaFS | ELF64 | Eliminazione immediata — nessun blocco |
| `/bin/ls /bin/cp /bin/mv /bin/mkdir /bin/cat` | MattiaFS | ELF64 | Coreutils base |
| `/bin/ps /bin/kill /bin/top` | MattiaFS | ELF64 | Gestione processi |
| `/bin/mount /bin/umount /bin/uname /bin/dmesg` | MattiaFS | ELF64 | Amministrazione |
| `/bin/grep /bin/sed /bin/wc /bin/sort` | MattiaFS | ELF64 | Strumenti testo |
| `/bin/ping /bin/ifconfig` | MattiaFS | ELF64 | Rete |
| `/bin/edit` | MattiaFS | ELF64 | Editor TUI (obbligatorio pre-GUI) |
| `/lib/libc.so` | MattiaFS | ELF64 shared | C standard library custom |
| `/lib/ld.so` | MattiaFS | ELF64 | Dynamic linker |
| `/etc/fstab` | MattiaFS | testo | Filesystem da montare all'avvio |
| `/etc/hostname` | MattiaFS | testo | Nome host |
| `/etc/passwd` | MattiaFS | testo | Utenti del sistema |
| `/etc/profile` | MattiaFS | script | Variabili d'ambiente globali |
| `/usr/bin/compositor` | MattiaFS | ELF64 | Display server (Fase 13+) |
| `/usr/bin/wm` | MattiaFS | ELF64 | Window Manager (Fase 14+) |
| `/usr/bin/terminal` | MattiaFS | ELF64 | Terminal emulator grafico (Fase 16+) |
| `/usr/share/fonts/` | MattiaFS | directory | Font PSF2 e TrueType |
| `/usr/share/themes/` | MattiaFS | directory | Temi GUI |

---

# APPENDICE A — RISORSE DI RIFERIMENTO

- Intel/AMD manuals Vol.3A: paging, GDT, IDT, APIC
- OSDev Wiki: https://wiki.osdev.org
- Limine Boot Protocol: https://github.com/limine-bootloader/limine
- ELF Specification: https://refspecs.linuxfoundation.org/elf/elf.pdf
- POSIX.1-2017: compatibilità API
- AHCI 1.3.1 Spec: Intel Serial ATA Advanced Host Controller Interface
- NVMe 1.4 Spec: https://nvmexpress.org/specifications/
- VirtIO Spec 0.9.5 (legacy): https://ozlabs.org/~rusty/virtio-spec/
- Intel 8254x Family Developer's Manual (e1000 / 82540/82545/82574)
- ACPI Specification 6.4: https://uefi.org/specifications
- SerenityOS: OS completo con GUI, codice C++ leggibile
- Lyre OS: usa Limine, struttura moderna
- xv6 (MIT): kernel Unix minimale, C pulito
- ToaruOS: OS con GUI, single developer
- Librerie single-header (Fase 13+): stb_image.h, stb_truetype.h, stb_ds.h

---

# APPENDICE B — DECISIONI NON ANCORA PRESE

| Decisione | Impatto | Da prendere entro |
|---|---|---|
| Formato font early output (PSF2 vs TTF embedded) | Rendering testo kernel prima della GUI | Fase 0 finale |
| Struttura /proc (Linux-like vs custom) | procfs design | Fase 7 |
| Formato /etc/mattiaos.conf (INI vs JSON-like) | Settings app, init system | Fase 12 |
| GPU acceleration (futuro) | Performance compositor | Fase 13 |
| Package manager: formato e struttura | Distribuzione software | Milestone 7 |
| Schermata boot / splash screen | UX | Milestone 6 |
| Supporto multi-utente completo (passwd, login, sudo) | Sicurezza e privilegi | Milestone 5 |
| MSI/MSI-X per AHCI e NVMe | Performance I/O, eliminazione polling | Fase 10 |
| Numero massimo di CPU per SMP | Strutture dati per core | Fase ACPI |
| Allocatore blocchi MattiaFS (buddy vs extent) | Performance scrittura | Fase 9 |
| Dynamic linker: formato e ABI | Compatibilità binaria | Fase 11 |

---

# APPENDICE C — BUG CRITICI CORRETTI (storico completo)

Questa appendice documenta tutti i bug critici scoperti durante gli audit e corretti nel codice.

## Audit Fase 8 — sessione 1 (v1.9 → v2.0)
- `idt.c` isr_handler non dispatchava vettori ≥ 0x20 — tutti gli IRQ hardware ignorati silenziosamente
- `apic.c` LAPIC MMIO con indirizzo fisico raw — crash immediato dopo vmm_init (prima di driver)
- `driver.h` phys_to_virt duplicata rispetto a vmm.h — errore di link su ogni TU che includeva entrambi
- `types.h` spinlock API mancante — usata in 8+ file ma non definita
- `vfs.c / process.c / mlfq.c` spinlock_t = 0 invece di = {0} — UB su compilatori strict
- `vmm.h / vmm.c` mancavano vmm_destroy_pagemap, vmm_clone_pagemap_cow, vmm_get_cr3

## Audit Fase 8 — sessione 2 (v2.0 → v2.1)
- `slab.c` kfree: identificazione cache per allineamento → OOB, tutto liberato in cache[0]
- `slab.c` krealloc: copiava new_size byte da buffer old_size → OOB read/write su shrink
- `vmm.c` EFER.NXE mai abilitato → PTE_NX in qualsiasi mapping causava #GP
- `irq.c` ahci_init/nvme_init/virtio_net_init/e1000_init definiti come weak stubs → linker usava stubs vuoti invece dei driver reali
- `process.c / thread.c` HHDM_OFFSET costante hardcoded 0xFFFF800000000000 invece di g_hhdm_offset dinamico → crash se HHDM diverso
- `keyboard.c` VK_SCROLLLOCK senza case in update_modifiers → ScrollLock non aggiornava LED
- `keyboard.c` typo s_scrollock → s_scrolllock in 2 punti
- `mlfq.h` static const per MLFQ_QUANTUM_MS → copia separata per ogni TU → symbol duplicato al link
- `Makefile` -std=c11 → -std=gnu11 necessario per asm volatile inline

## Audit Fase 8 — sessione 3 (v2.1 → v2.2)
- `process.c` ELF loader: (void)argv su argomento usato 130 righe dopo → warning Werror
- `irq.c` weak stubs rimossi per virtio_net_init/e1000_init — ora include i veri header driver
- Header aggiunti per simmetria .h/.c: signal.h, thread.h (redirect process.h), entry.h, irq.h (redirect driver.h)

## Fix Fase 8 — sessione 4 (v2.2 → v2.3)
- `pci.c` TRONCATO: mancavano tutte le funzioni non-triviali (7 su 7): pci_enumerate, pci_find_device, pci_find_device_by_id, pci_find_device_any_id, pci_enable_busmaster, pci_enable_mmio, pci_disable_interrupts. Il file conteneva solo le primitive di accesso al config space. Senza pci_enumerate, il sistema non avrebbe mai trovato nessun device PCI (AHCI, NVMe, e1000, VirtIO sarebbero tutti invisibili). Ricostruito completo.

## Verifica finale (v2.4 — doppia verifica)
Audit sistematico doppio (v2.3 + v2.4) di TUTTI i 57 file (26 .c + 30 .h + 1 .asm):
- Ogni .c compilato singolarmente con -Wall -Wextra -Werror: 26/26 OK
- Ogni funzione dichiarata in .h presente in .c corrispondente: 26/26 OK verificato per tutte le coppie (idt, gdt, apic, cpu, pmm, vmm, slab, process, thread, signal, mlfq, vfs, tmpfs, devfs, fat32, mattiafs, driver/irq, pci, fb, ps2, keyboard, ahci, nvme, virtio_net, e1000)
- context_switch.asm: 256 ISR stub presenti, gdt_flush, tss_flush, context_switch tutti implementati
- Simmetria .h/.c verificata: 26/26 coppie OK
- File mancanti: nessuno
- File troncati residui: nessuno

---

## Sessione v2.8 — libc completa (Fase 11)

### libc/include/ — 13 header pubblici
- `stddef.h`: size_t, ptrdiff_t, NULL, offsetof
- `stdint.h`: uint8/16/32/64_t, int8/16/32/64_t, uintptr_t, INT*_MAX/MIN
- `stdbool.h`: bool, true, false via _Bool
- `stdarg.h`: va_list, va_start/arg/end/copy — builtin GCC
- `errno.h`: int errno (globale), ~30 codici POSIX (EPERM … EDESTADDRREQ)
- `syscall.h`: __syscall0..6 inline asm x86-64 SYSCALL; __sc_errno()
- `string.h`: 25 prototipi (mem*, str*)
- `stdlib.h`: malloc/free/calloc/realloc, strtol/ul/ll/ull/d, atoi/l/ll/f, itoa, rand/srand, qsort, bsearch, exit/abort, abs/labs/llabs, div/ldiv
- `stdio.h`: FILE con buffer 4KB, stdin/stdout/stderr, fopen/close/flush, fread/write, fgetc/putc, fgets/puts, fseek/tell/rewind, printf family (7 varianti + 2 v-form)
- `math.h`: tutte le funzioni trig, exp/log, pow/sqrt, floor/ceil/round/trunc, fabs, iperboliche, frexp/ldexp/modf
- `fcntl.h`: O_RDONLY…O_NONBLOCK, S_IRUSR…
- `unistd.h`: read/write/close/lseek, getpid, fork, execve, mkdir, chdir, getcwd, sbrk

### libc/string/string.c
- memcpy (word-by-word 8B), memmove (overlap-safe), memset (word-fill), memcmp, memchr
- strlen (ottimizzato), strnlen, strcmp/strncmp, strcasecmp/strncasecmp
- strcpy/strncpy/strcat/strncat, strchr/strrchr, strstr (naive)
- strtok/strtok_r (thread-safe), strdup/strndup (usa malloc)
- strspn/strcspn/strpbrk, strerror (tabella statica)

### libc/stdlib/stdlib.c
- Heap allocator first-fit con boundary tags (block_hdr_t, 16B overhead).
  Split al malloc, coalescenza bidirezionale al free. Espansione via sbrk(SYS_BRK).
  Sanity check magic=0xBEEFDEAD contro corruzioni/double-free.
- calloc con overflow check, realloc con expand-in-place
- sbrk: wrapper SYS_BRK (numero 12), tracking s_brk statico
- strtol/strtoul/ll/ull: parsing base 2-36 con prefisso auto (0x/0/decimale)
- strtod/atof: parsing decimale con esponente 'e'/'E'
- itoa: conversione int→stringa in qualsiasi base
- rand/srand: LCG 64-bit (Knuth), RAND_MAX=0x7FFFFFFF
- qsort: insertion sort per n≤16, quicksort con mediana-di-3 per n>16
- bsearch: ricerca binaria O(log n)
- exit: SYS_EXIT(60); abort: SYS_KILL(62) con SIGABRT=6

### libc/stdio/stdio.c
- FILE con write buffer line/block/unbuffered (mode 0/1/2), read buffer 4KB
- stdin/stdout/stderr come istanze statiche FILE
- fopen: flags stringa→O_flags, allocazione FILE con calloc
- fflush: svuota wbuf via SYS_WRITE; fclose: flush + SYS_CLOSE + free
- fputc/fgetc con buffer; fread/fwrite tramite fputc/fgetc
- vsnprintf_ctx: engine printf interno. Supporta %d/%i/%u/%o/%x/%X/%c/%s/%p/%f + width/precision/flags -+0 #
  %zu gestito come %lu (size_t=uint64_t=unsigned long)
- 10 varianti printf: printf, fprintf, sprintf, snprintf, dprintf, vprintf, vfprintf, vsprintf, vsnprintf, dprintf_fd
- open/read/write/close/lseek/fork/execve/unlink/mkdir/chdir/getcwd: wrapper syscall per unistd.h

### libc/math/math.c
- sin/cos/tan: FSIN, FCOS, FPTAN inline asm x87
- atan2/atan: FPATAN; asin/acos via atan2+sqrt
- sqrt: FSQRT; exp: F2XM1+FSCALE (2^(x*log2(e))); log/log2/log10: FYL2X
- pow: exp(e*ln(b)) con casi speciali negativo/zero; cbrt; hypot
- floor/ceil/trunc: FRNDINT con modifica CW x87; round: floor(x+0.5)
- fabs: FABS; copysign: manipolazione bit IEEE 754
- fmod: FPREM in loop fino a C2=0
- sinh/cosh/tanh: formule con exp; ldexp/frexp/modf: manipolazione bit IEEE 754
- isinf/isnan/isfinite: test bitmask su uint64

### Verifica GCC (sanity check)
Tutti e 4 i .c compilano con zero errori e zero warning con:
  gcc -std=gnu11 -ffreestanding -nostdlib -Wall -Wextra -m64 -mno-red-zone


### Stato libc/ (Fase 11 — completata in v2.8)

| File | Stato |
|---|---|
| `libc/include/stddef.h` | ✅ creato |
| `libc/include/stdint.h` | ✅ creato |
| `libc/include/stdbool.h` | ✅ creato |
| `libc/include/stdarg.h` | ✅ creato |
| `libc/include/errno.h` | ✅ creato |
| `libc/include/syscall.h` | ✅ creato |
| `libc/include/string.h` | ✅ creato |
| `libc/include/stdlib.h` | ✅ creato |
| `libc/include/stdio.h` | ✅ creato |
| `libc/include/math.h` | ✅ creato |
| `libc/include/fcntl.h` | ✅ creato |
| `libc/include/unistd.h` | ✅ creato |
| `libc/string/string.c` | ✅ creato |
| `libc/stdlib/stdlib.c` | ✅ creato |
| `libc/stdio/stdio.c` | ✅ creato |
| `libc/math/math.c` | ✅ creato |

## Sessione v2.7 — Stack di rete completo (kernel/net/)

- `ethernet.h/c` — Frame Ethernet: parsing, dispatch ARP/IPv4, tx via net_ops->send_packet. NET_MAX_NICS=4. ethernet_init() scansiona device tree, installa rx_callback su ogni NIC. Helper net_hton16/32, net_ntoh16/32 inline in ethernet.h (usati da tutti i layer).
- `arp.h/c` — ARP su IPv4/Ethernet. Cache LRU 64 entry (arp_cache_entry_t). arp_resolve(): hit→MAC immediato, miss→ARP request broadcast + EAGAIN. arp_handle(): aggiorna cache sul mittente; risponde automaticamente alle ARP request per s_local_ip. arp_update() con spinlock_irqsave.
- `ipv4.h/c` — IPv4: header parsing con validazione checksum ones-complement, routing table 8 entry (longest prefix match), fragmentazione/riassemblaggio (64 gruppi × 64 KB buffer). ipv4_send(): lookup rotta → ARP resolve → build header → ethernet_send. ipv4_handle(): verifica checksum, dispatch ICMP/TCP/UDP, gestione frammenti con frag_group_t. g_net_ticks_ms definita qui (extern in arp.c e tcp.c).
- `icmp.h/c` — Echo Request (type 8) → Echo Reply (type 0) con checksum. icmp_send_unreachable(): type 3 con pseudo-header RFC 792 (IP header + 8 byte originali).
- `udp.h/c` — UDP_MAX_SOCKETS=64, ring buffer ricezione 32 datagrammi/socket. udp_send(): checksum su pseudo-header. udp_recv(): blocco con scheduler_block+yield, sblocco in udp_handle(). Demultiplexing per dst_port, fallback ICMP Port Unreachable.
- `tcp.h/c` — State machine completa (11 stati). Sliding window: snd_una/snd_nxt/snd_wnd/rcv_nxt/rcv_wnd. Congestion control Reno: slow start, congestion avoidance, fast retransmit (3 dup ACK), fast recovery. RTO Jacobson/Karels con backoff esponenziale. tcp_timer_tick(): ritrasmissione, TIME_WAIT expiry (chiamata ogni ms — connessione pendente in apic.c). TCP_MAX_CONN=64, send/recv buffer ring 64 KB ciascuno.
- `socket.h/c` — sys_socket/bind/listen/accept/connect/send/recv/sendto/recvfrom/setsockopt/close. AF_INET + SOCK_STREAM + SOCK_DGRAM. Ogni socket è un vnode (sock->vnode con fs_data=socket_t) inserito nel fd_table del processo via install_fd(). VFS ops sock_vfs_read/write/close delegano a tcp_recv/send e udp_recv/send. SOCK_MAX=128.
- `kernel/include/errno.h` — aggiunti 9 codici rete: EADDRINUSE, EAFNOSUPPORT, ECONNREFUSED, EDESTADDRREQ, EISCONN, ENOTCONN, ENOPROTOOPT, EOPNOTSUPP, EPROTONOSUPPORT (-25..-33).

Bug fix durante check:
- tcp.c: rimosso case TCP_FIN_WAIT_1 duplicato nello switch di tcp_handle (era già coperto dal blocco combinato ESTABLISHED|FIN_WAIT_1|FIN_WAIT_2|CLOSE_WAIT).
- socket.c: rimossa label C non-standard in sys_connect, sostituita con while loop pulito.

Connessione pendente annotata nel blueprint:
- tcp_timer_tick() va aggiunta al handler APIC timer (IRQ 0x20) in kernel/arch/x86_64/apic.c nella prossima sessione.

## Sessione v2.6 — Implementazione IPC

- `kernel/ipc/shm.h` — Creato: struttura shm_region_t (chiave, pagine fisiche, array attach proc+vaddr, attach_count, spinlock). Costanti SHM_MAX_REGIONS=64, SHM_MAX_PAGES_PER_REGION=256, SHM_MAX_ATTACHMENTS=32. Flag SHM_FLAG_*, SHM_PROT_*. API: shm_create, shm_attach, shm_detach, shm_destroy, shm_find.
- `kernel/ipc/shm.c` — Creato: tabella statica s_regions[64] protetta da s_table_lock. shm_create: alloca pagine fisiche via PMM, azzera via HHDM. shm_attach: trova vaddr libero nello spazio utente del processo (da SHM_VADDR_BASE=256MB a passi da 2MB), mappa con vmm_map usando PTE_USER+PTE_NX±PTE_WRITABLE. shm_detach: vmm_unmap, compact dell'array attach, free pagine se pending_destroy e count==0. shm_destroy: free immediata se nessun attach, altrimenti flag pending. Nessun libc, helper interni shm_memset/shm_memcpy.
- `kernel/ipc/msgq.h` — Creato: struttura msgq_t (ring buffer mq_msg_t*, capacity, head/tail/count, open_count, unlinked, lock, waiters_send[], waiters_recv[]). mq_msg_t: prio+size+data[4096]. Costanti MQ_MAX_QUEUES=32, MQ_MSG_DATA_MAX=4096, MQ_DEFAULT_DEPTH=64, MQ_MAX_DEPTH=256, MQ_MAX_WAITERS=32. Flag MQ_OFLAG_*. API POSIX-like: mq_open, mq_close, mq_send, mq_receive, mq_unlink.
- `kernel/ipc/msgq.c` — Creato: tabella statica s_queues[32]. ring_insert: inserimento con bubble-up per priorità max-first. ring_pop: estrazione testa. mq_send: loop con spinlock_irqsave, se piena → registra thread in waiters_send[], scheduler_block()+scheduler_yield(), retry. mq_receive: simmetrico, chiama wake_one_sender() dopo pop. mq_unlink: marca unlinked, distrugge se open_count<=0. kmalloc/kfree per ring buffer. Nessun libc.

---


## Sessione v2.9 — Userspace completo (Fase 12)

### userspace/include/userspace.h (605 righe)
Header condiviso per tutti i programmi userspace. Include tutti i libc headers. Definisce:
- Syscall aggiuntive non nella libc: SYS_RT_SIGACTION=13, SYS_RT_SIGPROCMASK=14, SYS_NANOSLEEP=35, SYS_ALARM=37, SYS_FSYNC=74, SYS_TRUNCATE=76, SYS_FTRUNCATE=77, SYS_LINK=86, SYS_SYMLINK=88, SYS_READLINK=89, SYS_SYSINFO=99, SYS_SETUID=105, SYS_SETGID=106, SYS_SETPGID=109, SYS_GETPPID=110, SYS_SETSID=112, SYS_GETPGID=121, SYS_GETSID=124, SYS_STATFS=137, SYS_FSTATFS=138, SYS_CHROOT=161, SYS_GETDENTS64=217, SYS_UTIMENSAT=280
- Costanti segnali: SIGHUP=1 … SIGWINCH=28
- struct stat (120 byte, layout Linux x86-64), struct dirent64 (ino/off/reclen/type/name[256]), struct utsname, struct sysinfo, struct statfs, struct timespec, struct winsize, struct sigaction, struct sockaddr, struct ifreq
- Wrapper syscall: sys_stat, sys_getdents, sys_rename, sys_link, sys_symlink, sys_chmod, sys_chown, sys_kill, sys_wait4, sys_pipe, sys_dup2, sys_mount, sys_umount, sys_uname, sys_sysinfo, sys_statfs, sys_nanosleep, sys_sigaction, sys_socket, sys_sendto, sys_recvfrom
- Helper: format_mode, format_size_human, read_line, sleep/usleep, WIFEXITED/WIFSIGNALED macro, ANSI color, die/warn/xmalloc macro

### userspace/crt0.c (44 righe)
Entry point C runtime. _start: estrae argc/argv/envp dallo stack (rsp), allinea rsp a 16 byte, chiama main(), passa return value a exit().

### userspace/init/init.c (276 righe)
PID 1. Monta: devfs su /dev, tmpfs su /tmp, procfs su /proc. Crea gerarchia /bin /sbin /usr /etc /var /root /home /lib /mnt /sys. Scrive /etc/hostname, /etc/os-release, /etc/fstab, /etc/environment. Installa SIGCHLD handler. Fork/exec shell su /dev/tty0. Loop infinito con wait4(-1) per reap zombie + respawn shell.

### userspace/shell/shell.c (1257 righe)
Shell completa mattiaos-sh. Tokenizer (quote singole/doppie, escape), espansione variabili ($VAR ${VAR} $$ $? $! ~), glob expansion (* ?), alias, env vars, history (~/.mattiaos_history, frecce), line editing raw (termios ICANON|ECHO|ISIG off, frecce/Home/End/Backspace/Delete/Ctrl+C/D), builtins (cd echo export unset pwd history alias unalias jobs fg bg source . help type), pipeline (sys_pipe + dup2), redirections (< > >> 2> 2>&1), background (&), job tracking, PATH search, prompt colorato.

### userspace/coreutils/ (33 programmi)
ls rm cp mv mkdir cat touch find stat ln chmod chown ps kill top mount umount uname free df du dmesg ping ifconfig grep sed wc head tail sort cut echo edit — tutti completamente implementati, 0 errori GCC -fsyntax-only, parentesi bilanciate, ogni file ha main() e return.

### Fix applicati in v2.9 (storico)
- libc/include/fcntl.h: aggiunto #ifndef guard su S_IRUSR/IWUSR/IXUSR per evitare ridefinizioni
- libc/include/userspace.h: aggiunto #ifndef su tutte le 30 macro S_I*
- libc/include/stdio.h: aggiunte dichiarazioni sscanf/vsscanf/scanf/fscanf/vscanf/perror (mancanti, usate da df/ifconfig/ping/shell)
- kernel/include/syscall_numbers.h: aggiunte 23 syscall mancanti (rt_sigaction, nanosleep, setsid, statfs, sysinfo, getdents64, utimensat, ecc.)
- libc/Makefile: creato (build libc → libmattiac.a)
- userspace/Makefile: creato (build init.elf, sh.elf, tutti i coreutil.elf)
- Makefile: aggiornato per orchestrare kernel + libc + userspace

### Stato Fase 12 (v3.0 — COMPLETATA)
- 36 file sorgente userspace: 0 errori, 0 warning reali GCC
- Graffe bilanciate in tutti i file (verificato con parser Python che ignora stringhe/commenti)
- Byte NUL: nessuno; righe troncate: nessuna
- Tutti i coreutil: main() + #include + return presenti
- shell.c: 14/14 simboli critici presenti
- init.c: 12/12 simboli critici presenti
- Numeri syscall kernel == userspace: zero conflitti

### Cosa manca per il primo avvio (note aperte v3.0)
1. **ELF loader in kernel** (process_execve): load_elf() che mappa PT_LOAD, costruisce stack iniziale con argc/argv/envp/auxv, salta a _start — CRITICO per avviare init
2. **Syscall dispatcher** (entry.c/asm): MSR_LSTAR + handler syscall + tabella 300+ entry — necessario per qualsiasi syscall da userspace
3. **SYS_GETDENTS64 (217)** nel kernel: ls/find/ps/du non funzionano senza
4. **SYS_RT_SIGACTION/SETSID** nel kernel: shell crasha senza
5. **libc sscanf/perror implementation** in libc/stdio/stdio.c: dichiarate ma non implementate
6. **Filesystem radice** popolato su disco: /sbin/init, /bin/sh, /bin/ls, ..., /etc/passwd, /etc/group



## Sessione v3.3 — ISO Bootabile Compilata

### Novità
- **Compilazione da sorgente**: xorriso 1.5.6.pl02 compilato e installato
- **Bootloader custom**: stage1.asm + stage2.asm scritti in NASM 3.01
  - stage1: El Torito BIOS boot (2048B), E820 memory map, carica stage2
  - stage2: real mode kernel loader (INT 15h AX=87h), protected mode 32-bit,
    page tables (0-4GB identity + HHDM 0xFFFF800000000000 + kernel 0xFFFFFFFF80000000),
    long mode 64-bit, ELF parser, Limine protocol v2 responses, jump to kernel_main
- **ISO El Torito**: MattiaOS_v3.3.iso (2.6MB) — bootabile su QEMU/VirtualBox BIOS
- **BSS ridotto**: 15MB → 1MB (TCP buffer 64KB→4KB, UDP queue 32→8, socket 128→32)
- **Layout fisico**: kernel @ 0x200000..0x310000, responses @ 0x5000, E820 @ 0x5FFC/0x6000
- **Verifiche**: boot image LBA 39, stage2 LBA 40 (CLI CLD ✓), kernel LBA 68 (ELF ✓)

### Struttura ISO
```
boot.img = stage1.bin (2KB) + stage2.bin (56KB) + kernel.elf (112KB)
LBA 39: stage1 (El Torito boot entry)
LBA 40: stage2 (28 settori)
LBA 68: kernel.elf
/usr/bin/: 35 ELF userspace (coreutils + init + sh)
```

### Avvio su QEMU
```
qemu-system-x86_64 -cdrom MattiaOS_v3.3.iso -m 256M -serial stdio
```

## Sessione v3.0-fix — Bug critici pre-boot corretti

### Bug trovati e corretti (revisione manuale del boot path)

| # | File | Bug | Fix |
|---|------|-----|-----|
| 1 | `kernel/arch/x86_64/gdt.c` | TSS senza IST stacks → double fault diventa triple fault e reboot | Allocati 3 stack statici (8KB) per IST1/2/3 e RSP0 |
| 2 | `kernel/arch/x86_64/entry.c` | `rsdp_request.response->address` senza null check → crash su VM senza ACPI | Aggiunto null check su tutte le Limine response; ACPI marcato opzionale |
| 3 | `kernel/arch/x86_64/entry.c` | BSS non azzerato → variabili globali hanno valori garbage | Aggiunto loop di zero-BSS come prima istruzione di kernel_main |
| 4 | `kernel/arch/x86_64/linker.ld` | .bss non allineato, nessun /DISCARD/, senza _bss_start/_bss_end | Aggiunto ALIGN(4096), simboli _bss_start/_bss_end, /DISCARD/ per .eh_frame/.comment |
| 5 | `kernel/arch/x86_64/idt.c` | page_fault_handler non stampava RIP/RSP/CR2 → debug impossibile | Sostituito con dump_exception: stampa vettore, nome, RIP, RSP, CR2, error_code |

### Verificato corretto (nessun fix necessario)
- `interrupt_frame_t` in idt.h: layout già corretto, corrisponde esattamente all'ordine push di isr_common nel .S
- `apic_timer_calibrate()`: già ha fallback quando HPET non disponibile
- `drivers_init()`: già implementata in kernel/drivers/irq.c
- `isr_stubs[]`: correttamente in .data, IDT li installa tutti e 256

### Stato dopo fix
- Ricompilazione completa: 77 file → 0 errori, 0 warning
- kernel.elf: 112KB (entry 0xffffffff80001530)
- 35 ELF userspace: tutti linkati correttamente

## Sessione v3.0 — Compilazione reale verificata

### Fix applicati durante compilazione

**kernel/limine.h** (creato ex-novo, 184 righe)
Limine Boot Protocol v8 header ricostruito dalla specifica ufficiale. Self-contained: usa `__UINT*_TYPE__` GCC builtins invece di includere `<stdint.h>` (evita conflitti con `kernel/include/types.h`). Definisce: `LIMINE_BASE_REVISION`, request markers, struct per framebuffer/memmap/hhdm/kernel-address/rsdp/smp.

**kernel/lib/string.c** (creato, 100 righe)
GCC lowera `__builtin_memset/__builtin_memcpy` in chiamate a `memset/memcpy` quando le dimensioni non sono costanti. Il kernel freestanding non può linkare libc. Aggiunto: `memset, memcpy, memmove, memcmp, strlen, strcmp, strncmp, strcpy, strncpy, strcat, strchr, strrchr, strstr`.

**kernel/arch/x86_64/asm/context_switch_gas.S** (creato, 224 righe)
nasm non disponibile nell'ambiente di build (rete ristretta). Conversione del `context_switch.asm` originale in GAS (GNU Assembler) con `.intel_syntax noprefix`. Usa `.macro`/`.irp` per i 256 stub ISR. Aggiunto `.section .note.GNU-stack,"",@progbits` per stack non-eseguibile.

**kernel/acpi/acpi.c** — rinominato `phys_to_virt` → `ac_phys_to_virt`
`vmm.h` (incluso via `#include`) definisce già `phys_to_virt` come `static inline`. Ridenominata la copia locale per eliminare la ridefinizione.

**kernel/net/socket.c** — aggiunti include `slab.h` + `mlfq.h`
`kzalloc()`, `scheduler_block()`, `scheduler_yield()` usate ma non dichiarate.

**kernel/net/tcp.c + udp.c** — fix allineamento struct packed
`tcp_pseudo_hdr_t` / `udp_pseudo_hdr_t` sono `__attribute__((packed))`. Cast diretto a `uint16_t *` → warning unaligned. Riscritta la funzione checksum per leggere prima byte-per-byte con `uint8_t *`.

**kernel/net/ethernet.c** — `s_nic_lock` unused
Marcata `__attribute__((unused))`.

**libc/stdio/stdio.c** — aggiunte implementazioni mancanti
`perror()`: stampa messaggio errno su stderr con tabella 0-32.
`sscanf()` / `vsscanf()`: parser minimo per `%d %u %s %c %%`.

**userspace/coreutils/grep.c, sort.c, top.c** — misleading indentation
Aggiunte graffe dove GCC 13 segnalava `-Wmisleading-indentation`.

**userspace/coreutils/grep.c** — `s_total_matches` unused
Marcata `__attribute__((unused))`.

**userspace/coreutils/edit.c** — `draw_help_bar` unused
Marcata `__attribute__((unused))` con forward declaration.

**userspace/coreutils/ps.c** — `opt_long` set but not used
Marcata `__attribute__((unused))`.

### Risultati compilazione
| Categoria | File | .o | Errori | Warnings |
|---|---|---|---|---|
| Kernel | 36 .c + 1 .S | 37 | 0 | 0 |
| libc | 4 .c | 4 | 0 | 0 |
| Userspace | 36 .c | 36 | 0 | 0 |
| **TOTALE** | **77 file** | **77** | **0** | **0** |

### Binari ELF prodotti
| Binario | Dimensione | Entry point |
|---|---|---|
| `kernel.elf` | 124 KB | `0xffffffff80001530` (kernel_main) |
| `userspace/init/init.elf` | 54 KB | `0x401310` (_start) |
| `userspace/shell/sh.elf` | 71 KB | `0x401310` (_start) |
| `userspace/coreutils/ls.elf` | ~45 KB | `0x401310` |
| … (33 coreutils totali) | ~35-60 KB | `0x401310` |

## Sessione v3.6 — Bootloader fix: 2 bug critici risolti

### Contesto
Il kernel era già verificato funzionante (GDT/IDT/SERIAL OK su schermo nella sessione v3.4).
La sessione v3.6 ha trovato e risolto 2 bug critici nel bootloader che causavano rispettivamente
schermo nero (crash silenzioso) e kernel panic "Limine memmap response NULL".

### Bug #1 — Dati prima del codice in stage2 (→ schermo nero)

**Problema:** stage2.asm aveva variabili globali (`vga_row`, `vga_col`, `drv16`, `dap16`, `kentry`, stringhe, GDT) come **primissimi byte** del binario, prima di qualsiasi istruzione JMP. Quando stage1 saltava a 0x8000, la CPU eseguiva i dati come istruzioni (es. `00 00` = `ADD [BX+SI], AL`) causando un crash immediato e silenzioso. Output: schermo nero con cursore lampeggiante.

**Fix applicato in stage2.asm v3.6:**
- Aggiunta come **primissima istruzione** (byte 0): `jmp near stage2_entry`
- Tutti i dati e le funzioni helper rimangono subito dopo il JMP
- `stage2_entry:` è l'effettivo ingresso del codice di boot
- Verificato: primo byte del .bin = `0xE9` (JMP near), NON `0x00`

**Nota storica (v3.4_debug):** Un precedente tentativo aveva messo le stringhe di debug prima del JMP, causando lo stesso crash. Il JMP deve essere il byte assoluto 0 del binario.

### Bug #2 — Offset Limine sbagliati di +0x10 (→ kernel panic "memmap NULL")

**Problema:** stage2 scriveva i Limine response pointers con offset errati nella sezione `.limine_requests` del kernel. Gli offset erano calcolati assumendo che ogni request struct avesse `id[2]` (2×uint64=16B), ma la struct reale ha `id[4]` (4×uint64=32B):

```
Struct layout reale:  id[0..3]=32B, revision=8B, response*=8B  → response @ +0x28
Struct layout errato: id[0..1]=16B, revision=8B, response*=8B  → response @ +0x18 (sbagliato)
```

Tutti e 3 gli offset erano sbagliati di esattamente +0x10:

| Request | Offset v3.4 (SBAGLIATO) | Offset v3.6 (CORRETTO) | Fonte |
|---|---|---|---|
| memmap.response | +0x098 → paddr 0x319098 | +0x0A8 → paddr 0x31b0A8 | objdump kernel |
| kaddr.response  | +0x0D8 → paddr 0x3190D8 | +0x0E8 → paddr 0x31b0E8 | objdump kernel |
| hhdm.response   | +0x118 → paddr 0x319118 | +0x128 → paddr 0x31b128 | objdump kernel |

**Come trovato:** `x86_64-linux-gnu-objdump -d kernel.elf` mostrava:
```
mov 0x116f66(%rip),%rax  # ffffffff801190a8 <memmap_request+0x28>
```
Paddr reale = `0x31b0A8`, non `0x319098`.

**Fix applicato in stage2.asm v3.6:**
- Patch HHDM:   `mov [rbx + 0x128], rax`  (era 0x118)
- Patch memmap: `mov [rbx + 0x0A8], rax`  (era 0x098)
- Patch kaddr:  `mov [rbx + 0x0E8], rax`  (era 0x0D8)

### Verifica finale stage2 v3.6

13/13 check binari passati:
- ✅ Primo byte = JMP (0xE9) — codice, NON dati
- ✅ NON inizia con 0x00 0x00
- ✅ size=57344 (28 settori CD)
- ✅ REP MOVSD presente (copia kernel)
- ✅ kentry = 0xFFFFFFFF80002086
- ✅ HHDM   patch +0x128: `48 89 83 28 01 00 00`
- ✅ memmap patch +0x0A8: `48 89 83 A8 00 00 00`
- ✅ kaddr  patch +0x0E8: `48 89 83 E8 00 00 00`
- ✅ Vecchio +0x118 ASSENTE
- ✅ Vecchio +0x098 ASSENTE
- ✅ Vecchio +0x0D8 ASSENTE
- ✅ INT15h AH=87h ASSENTE (non usato, eliminato in v3.3)
- ✅ VGA 0xB8000 presente

### Layout memoria bootloader v3.6 (definitivo)

```
Fisica    | Contenuto
----------+------------------------------------------
0x0000    | IVT (interrupt vector table, BIOS)
0x5000    | Limine HHDM response {rev=0, offset=0xFFFF800000000000}
0x5020    | Limine memmap response {rev=0, count=N, entries=0x5100+HHDM}
0x5100    | Array puntatori HHDM → Limine memmap entries (N×8B)
0x5200    | Limine memmap entries convertiti da E820 (N×24B)
0x5400    | Limine kaddr response {rev=0, phys=0x200000, virt=0xFFFF...80000000}
0x5FFC    | E820 count (scritto da stage1, LETTO da stage2 — NON azzerare)
0x6000    | E820 buffer raw (scritto da stage1, LETTO da stage2 — NON azzerare)
0x7C00    | Stack (condiviso 16/32/64-bit)
0x7DF0    | kernel_start_LBA (scritto da stage1, letto da stage2)
0x8000    | stage2 (57344B = 28 settori CD) — BYTE 0 = JMP NEAR stage2_entry
0x10000   | ELF staging temporanea (dopo copia viene sovrascritto dai page tables)
0x10000   | PML4 (dopo che ELF è stato copiato a 0x600000)
0x11000   | PDPT_ID (identity 0-4GB)
0x12000   | PD0 (0-1GB, huge pages 2MB)
0x13000   | PD1 (1-2GB)
0x14000   | PD2 (2-3GB)
0x15000   | PD3 (3-4GB)
0x16000   | PDPT_HHDM (HHDM 0xFFFF800000000000)
0x17000   | PDPT_KERN (kernel higher half)
0x18000   | PD_KERN (3 huge pages: 0x200000, 0x400000, 0x600000)
0x200000  | Kernel ELF segmenti copiati (PT_LOAD)
0x31b000  | .limine_requests paddr — patched da stage2
0x600000  | Kernel ELF staging (copiato da 0x10000 in PM32 PRIMA di setup PT)
```

### Impostazioni VirtualBox corrette per MattiaOS

⚠️ **CRITICO**: configurazioni errate causano schermo nero o boot fallito.

**Generale → Base:**
- Nome: MattiaOS (qualsiasi)
- Tipo: **Other**
- Versione: **Other/Unknown (64-bit)**

**Sistema → Scheda madre:**
- Memoria base: **256 MB** (minimo)
- Ordine di avvio: ✅ **Ottico SOLO** (disabilita Floppy e Hard Disk)
- Chipset: **PIIX3**
- Dispositivo di puntamento: PS/2 Mouse
- ✅ **Abilita I/O APIC** — OBBLIGATORIO
- ❌ **EFI: DISABILITATO** — CRITICO: MattiaOS usa BIOS, non UEFI
- ✅ **Abilita PAE/NX**

**Sistema → Processore:**
- CPU: 1 (per ora, SMP non implementato)
- Limite esecuzione: 100%
- ✅ PAE/NX abilitato

**Sistema → Accelerazione:**
- Paravirtualizzazione: **Legacy** o **None**
- ✅ **Abilita VT-x/AMD-V** (per Long Mode)
- ✅ **Abilita Nested Paging**

**Schermo:**
- Memoria video: **16 MB**
- Controller grafico: **VBoxVGA** (non VMSVGA o VBoxSVGA — questi cambiano il framebuffer!)
- ❌ Accelerazione 2D/3D: disabilitate

**Archiviazione:**
- Controller: **IDE**
- Dispositivo: **Unità ottica** (CD/DVD)
- Inserisci: `MattiaOS_v3.6.iso`
- ❌ NON usare SATA controller per l'ottico (compatibilità BIOS)

**Audio:** Disabilitato (non implementato nel kernel)

**Rete:** Disabilitato o NAT (e1000 presente ma network stack non ancora connesso a userspace)

**Avvio:** Avvia la VM → deve apparire testo colorato su schermo nero.

### Sequenza di boot attesa v3.6

```
[bianco]  MattiaOS v3.6 - Stage2 avviato
[bianco]  A20 fast gate OK
[bianco]  Kernel ELF caricato (120 sett CD)
[verde]   PM32: copia kernel 0x10000->0x600000
[verde]   PM32: page tables pronte
[giallo]  LM64 attivo
[giallo]  LM64: ELF loader OK
[giallo]  LM64: Limine responses patched
[giallo]  LM64: Salto a kernel_main!
─────────────────────────────────────────────
         MattiaOS — Kernel Boot        v3.6
─────────────────────────────────────────────
[verde]   [OK]   [GDT]    Descriptor tables OK
[verde]   [OK]   [IDT]    Interrupt table OK
[verde]   [OK]   [SERIAL] COM1 @ 38400 baud + VGA attivi
[ciano]   [INFO] [LIMINE] Verifica boot protocol responses...
[verde]   [OK]   [LIMINE] Tutte le risposte valide
[verde]   [OK]   [PMM]    Physical memory manager OK
... continua fino a drivers_init → HLT
```

Se compare **schermo nero con cursore** = stage2 crasha (dati prima del codice).
Se compare **KERNEL PANIC memmap NULL** = offset Limine sbagliati.
Se compare **[OK] GDT/IDT/SERIAL poi si blocca** = crash in PMM/VMM (da debuggare).

### Stato prodotti v3.6

| File | Dimensione | Contenuto |
|---|---|---|
| `MattiaOS_v3.6.iso` | 10MB | ISO bootabile BIOS El Torito |
| `MattiaOS_v3.6_sources.zip` | 317KB | Tutti i sorgenti (.asm, .c, .h, .ld, .cfg, Makefile) |
| `MattiaOS_v3.6_compiled.zip` | 990KB | Sorgenti + binari (.bin, .elf, .img) |

---

## Sessione v3.6.1 — Fix CR4.PSE (triple fault in PMM)

### Contesto
Dopo il fix v3.6, il kernel raggiungeva kernel_main e stampava GDT/IDT/SERIAL OK su VGA, poi si bloccava con Guru Meditation in VirtualBox (VINF_EM_TRIPLE_FAULT) durante pmm_init.
Crash: RIP=0xffffffff8000fe31, CR2=0xffffffff80026740, errcd=0x9 (#PF reserved bit).

### Causa radice
CR4 = 0x000000A0 → PAE (bit5) + PGE (bit7), ma **PSE (bit4) mancante**.
Le page table di stage2 usano 2MB huge pages (PS bit set nei PD entry).
In Long Mode con PAE attivo, il PS bit in un PD entry è **reserved** se CR4.PSE=0.
Accedere a una pagina mappata con PS=1 e CR4.PSE=0 → #PF con errcd=0x9 (reserved bit violation) → nessun handler IDT → #DF double fault → triple fault → reboot.
Il crash avveniva durante `__builtin_memset(g_pmm.bitmap, 0xFF, g_pmm.bitmap_size)` in pmm_init, che accedeva a una regione grande via HHDM (che usa le huge pages).

### Fix applicato in stage2.asm
Prima (bug): `or eax, (1<<5)|(1<<7)` → CR4 = 0xA0 (PAE + PGE)
Dopo (fix):  `or eax, (1<<4)|(1<<5)|(1<<7)` → CR4 = 0xB0 (PSE + PAE + PGE)

Verificato nel binario: byte a stage2+1051 = `0f 20 e0 0d b0 00 00 00 0f 22`
- `0f 20 e0` = `mov eax, cr4`
- `0d b0 00 00 00` = `or eax, 0x000000B0`
- bit4=PSE ✅, bit5=PAE ✅, bit7=PGE ✅

### Problema residuo scoperto in questa sessione
Il metodo di patching usato per produrre v3.6.1 (xorriso in modalità --overwrite) ha corrotto il Boot Record Descriptor dell'ISO:
- BRD type = 255 (deve essere 0 = El Torito Boot Record)
- Boot catalog LBA = 0
- Boot indicator = 0x00 (deve essere 0x88)

Risultato: VirtualBox non riconosceva il disco come bootabile e non avviava nemmeno stage1. Questo bug è stato corretto in v3.6.2 ricostruendo l'ISO da zero.

---

## Sessione v3.6.2 — 4 bug corretti, ISO ricostruita e kernel ricompilato

### Bug #1 — El Torito Boot Record Descriptor corrotto (→ VirtualBox non boota affatto)
**Causa:** xorriso usato in modalità patch aveva scritto nel settore 17 dell'ISO sovrascrivendo il Boot Record Descriptor con valori non validi. BRD type=255, Boot catalog LBA=0, Boot indicator=0x00.
**Effetto:** VirtualBox non vedeva il disco come bootabile → nessun output su schermo.
**Fix:** ISO ricostruita completamente da zero:
```
xorriso -as mkisofs -iso-level 3 -full-iso9660-filenames
  -volid "MattiaOS_v3.6.2" -no-emul-boot -boot-load-size 4
  -boot-info-table -b boot/boot.img -output ISO /tmp/iso_build/
```
Verificato: BRD type=0 ✅, Boot indicator=0x88 ✅, Load RBA valido ✅.

### Bug #2 — E820 count azzerato prima della lettura (→ memmap con 4 entries fisse)
**Causa:** In stage2.asm (sezione LM64), il codice azzerava 0x5000-0x5FFF con `rep stosq` **prima** di leggere il count E820 da 0x5FFC. Poiché 0x5FFC è dentro il range azzerato, il count diventava 0 → fallback a 4 entries fittizie (`mov rax, 4`). La memoria reale della macchina non veniva mai passata correttamente al kernel.
**Fix:** Salvataggio del count in `r13` **prima** del clear:
```asm
movzx r13, dword [0x5FFC]   ; salva E820 count PRIMA di azzerare
mov rdi, 0x5000
mov rcx, 0x1000/8
xor rax, rax
rep stosq                    ; ora azzera tutto, incluso 0x5FFC (non più necessario)
; ... poi usa r13 invece di [0x5FFC]
mov rax, r13                 ; count salvato
test rax, rax
jnz .cnt_ok
mov rax, 4                   ; fallback solo se davvero 0
```

### Bug #3 — vmm_switch_pagemap senza identity map low memory (→ #PF su stack)
**Causa:** vmm_init() costruiva un nuovo PML4 (g_kernel_pml4) mappando HHDM (4GB) + kernel higher half, poi chiamava `vmm_switch_pagemap(g_kernel_pml4)` che eseguiva `write_cr3`. Il nuovo PML4 non aveva alcuna entry per virtual 0x0-0x10000. Quindi lo stack di boot (RSP=0x7C00) diventava inaccessibile immediatamente dopo il cambio di CR3. Il primo `ret` dopo vmm_switch_pagemap avrebbe generato #PF su 0x7C00 → triple fault.
**Fix:** Aggiunto in vmm_init(), prima di vmm_switch_pagemap():
```c
/* BUG FIX v3.6.2: mappa low memory (0-64KB) identity per mantenere
 * lo stack di boot a 0x7C00 accessibile dopo vmm_switch_pagemap. */
for (uint64_t p = 0; p < 0x10000; p += PAGE_SIZE) {
    vmm_map(g_kernel_pml4, p, p, PTE_PRESENT | PTE_WRITABLE);
}
```

### Bug #4 — Offset Limine e kentry non aggiornati dopo ricompilazione kernel
**Causa:** Ricompilando il kernel con il fix vmm.c, il linker ha cambiato il layout ELF:
- La sezione `.limine_requests` si è spostata da paddr 0x31b000 a **0x312000**
- L'entry point è cambiato da 0xFFFFFFFF80002086 a **0xFFFFFFFF80001AD0**
- Gli offset interni delle response* sono cambiati (dipendono dall'ordine di dichiarazione in entry.c)

Nuovi offset `.limine_requests` (paddr 0x312000), verificati dal dump ELF:

| Request | Offset nella sezione | Paddr assoluto |
|---|---|---|
| smp.response* | section+0x048 | 0x312048 (non patched) |
| rsdp.response* | section+0x088 | 0x312088 (non patched) |
| hhdm.response* | section+0x0C8 | 0x3120C8 |
| kaddr.response* | section+0x108 | 0x312108 |
| memmap.response* | section+0x148 | 0x312148 |

**Fix:** stage2.asm aggiornato:
- `kentry dq 0xFFFFFFFF80001AD0`
- `mov rbx, 0x312000` (era 0x31b000)
- `mov [rbx + 0x0C8], rax` per HHDM (era 0x128)
- `mov [rbx + 0x148], rax` per memmap (era 0x0A8)
- `mov [rbx + 0x108], rax` per kaddr (era 0x0E8)

**AVVERTIMENTO PERMANENTE:** Gli offset `.limine_requests` cambiano ad ogni ricompilazione del kernel perché dipendono dall'ordine di dichiarazione delle request struct in entry.c e dalla dimensione di ogni sezione ELF. Prima di ogni aggiornamento di stage2.asm verificare con:
```python
python3 -c "
import struct
with open('kernel.elf', 'rb') as f: elf = f.read()
e_phoff = struct.unpack_from('<Q', elf, 0x20)[0]
e_phnum = struct.unpack_from('<H', elf, 0x38)[0]
e_phentsz = struct.unpack_from('<H', elf, 0x36)[0]
for i in range(e_phnum):
    b = e_phoff + i * e_phentsz
    vaddr = struct.unpack_from('<Q', elf, b+0x10)[0]
    off = struct.unpack_from('<Q', elf, b+0x08)[0]
    fsz = struct.unpack_from('<Q', elf, b+0x20)[0]
    if vaddr >= 0xFFFFFFFF80000000:
        paddr = vaddr - 0xFFFFFFFF80000000 + 0x200000
        print(f'paddr=0x{paddr:08x} offset=0x{off:x} size=0x{fsz:x}')
        # dump the section to find response* at +0x28 offsets
"
```

### Verifica finale v3.6.2 (9/9 check)
| Check | Risultato |
|---|---|
| El Torito BRD type=0 | ✅ |
| Boot indicator=0x88 | ✅ |
| stage1[0:4] = EB 58 90 00 (JMP SHORT) | ✅ |
| stage2[2048:2052] = E9 13 02 00 (JMP NEAR stage2_entry) | ✅ |
| CR4 OR value = 0x000000B0 (PSE+PAE+PGE) | ✅ |
| Kernel ELF magic = 7F 45 4C 46 | ✅ |
| Kernel entry = 0xFFFFFFFF80001AD0 | ✅ |
| kentry in stage2 = 0xFFFFFFFF80001AD0 | ✅ |
| Limine paddr 0x312000 in stage2 | ✅ |

### Impostazioni VirtualBox corrette per MattiaOS v3.6.2

⚠️ **CRITICO**: configurazioni errate causano schermo nero o boot fallito.

**Generale → Base:**
- Nome: MattiaOS (qualsiasi)
- Tipo: **Other**
- Versione: **Other/Unknown (64-bit)**

**Sistema → Scheda madre:**
- Memoria base: **256 MB** (minimo)
- Ordine di avvio: ✅ **Ottico SOLO** (disabilita Floppy e Hard Disk)
- Chipset: **PIIX3**
- ✅ **Abilita I/O APIC** — OBBLIGATORIO
- ❌ **EFI: DISABILITATO** — CRITICO: MattiaOS usa BIOS, non UEFI
- ✅ **Abilita PAE/NX**

**Sistema → Processore:**
- CPU: 1 (SMP non implementato)
- ✅ PAE/NX abilitato

**Sistema → Accelerazione:**
- Paravirtualizzazione: **Legacy** o **None**
- ✅ VT-x/AMD-V + Nested Paging

**Schermo:**
- Memoria video: **16 MB**
- Controller grafico: **VBoxVGA** (non VMSVGA o VBoxSVGA)
- ❌ Accelerazione 2D/3D: disabilitate

**Archiviazione:**
- Controller: **IDE**
- Dispositivo: **Unità ottica** con `MattiaOS_v3.6.2.iso`
- ❌ NON usare SATA controller per l'ottico

### Sequenza di boot attesa v3.6.2
```
[bianco]  MattiaOS v3.6 - Stage2 avviato
[bianco]  A20 fast gate OK
[bianco]  Kernel ELF caricato (120 sett CD)
[verde]   PM32: copia kernel 0x10000->0x600000
[verde]   PM32: page tables pronte
[giallo]  LM64: Long Mode attivo
[giallo]  LM64: ELF loader OK
[giallo]  LM64: Limine responses patched
[giallo]  LM64: Salto a kernel_main!
─────────────────────────────────────────────
         MattiaOS — Kernel Boot        v3.6
─────────────────────────────────────────────
[verde]  [OK]   [GDT]    Descriptor tables OK
[verde]  [OK]   [IDT]    Interrupt table OK
[verde]  [OK]   [SERIAL] COM1 @ 38400 baud + VGA attivi
[ciano]  [INFO] [LIMINE] Verifica boot protocol responses...
[verde]  [OK]   [LIMINE] Responses valide
[verde]  [OK]   [PMM]    Physical Memory Manager pronto
[verde]  [OK]   [VMM]    Virtual Memory Manager pronto
[verde]  [OK]   [SLAB]   Allocatore slab pronto
[giallo] [WARN] [ACPI]   RSDP non disponibile — saltato
[verde]  [OK]   [APIC]   LAPIC + timer APIC attivi
[verde]  [OK]   [PCI]    Bus PCI enumerato
[verde]  [OK]   [VFS]    / e /dev montati
[verde]  [OK]   [CPU]    Interrupt abilitati
[verde]  [OK]   [DRV]    Driver hardware pronti
         *** MattiaOS v3.6 — Boot completato! ***
```

Se compare **schermo nero con cursore** = stage1 non boota (El Torito corrotto o EFI abilitato).
Se compare **KERNEL PANIC memmap NULL** = offset Limine sbagliati nel stage2.
Se compare **Guru Meditation triple fault in PMM** = CR4.PSE mancante (bit4).
Se compare **crash dopo VMM init** = vmm_init non ha mappato low memory.

---

---

## Sessione v3.6 — Audit bug completo, 6 bug corretti, ISO ricostruita

### Bug #1 — stage2.asm: paddr .limine_requests SBAGLIATO (→ KERNEL PANIC memmap NULL)
**Causa:** stage2.asm aveva `mov rbx, 0x312000` (valore della sessione v3.6.2). Dopo la ricompilazione del kernel nella nuova sessione, la sezione `.limine_requests` si trova a paddr **0x31b000** (come da v3.6 originale). Il kernel compilato in questa sessione aveva PT[3] vaddr=0xffffffff80119000 → paddr=0x31b000.
**Effetto:** Le tre response* patchate da stage2 finivano in indirizzi sbagliati. Il kernel leggeva response=0 (NULL) → KERNEL PANIC "Limine memmap response NULL" o "Limine HHDM response NULL".
**Fix:** `mov rbx, 0x31b000` e aggiornati tutti e tre gli offset.

### Bug #2 — stage2.asm: offset HHDM response sbagliato (→ KERNEL PANIC HHDM NULL)
**Causa:** stage2 usava `mov [rbx + 0x0C8], rax` per HHDM. Verificato con ELF parser Python: HHDM.response è a section+0x128. Offset sbagliato di 0x60 bytes.
**Fix:** `mov [rbx + 0x128], rax`

### Bug #3 — stage2.asm: offset MEMMAP response sbagliato (→ KERNEL PANIC memmap NULL)
**Causa:** stage2 usava `mov [rbx + 0x148], rax` per MEMMAP. Verificato: MEMMAP.response è a section+0x0A8.
**Fix:** `mov [rbx + 0x0A8], rax`

### Bug #4 — stage2.asm: offset KADDR response sbagliato (→ crash in vmm_init)
**Causa:** stage2 usava `mov [rbx + 0x108], rax` per KADDR. Verificato: KADDR.response è a section+0x0E8.
**Fix:** `mov [rbx + 0x0E8], rax`

### Bug #5 — Makefile: usa Limine binary (non presenti) e manca -fno-pie
**Causa:** Makefile aveva `iso` target che copiava `limine/limine-bios.sys` ecc. — file mai presenti nel progetto. Il sistema usa un bootloader custom (stage1/stage2), non il vero Limine binary. Inoltre mancava `-fno-pie` (documentato in blueprint Sezione 8 come obbligatorio con `-mcmodel=kernel`).
**Effetto:** `make iso` falliva con "cp: cannot stat 'limine/limine-bios.sys': No such file or directory".
**Fix:** Makefile completamente riscritto:
- Target `$(STAGE1)` e `$(STAGE2)`: `nasm -f bin` per i flat binary del bootloader
- Target `$(BOOTIMG)`: concatena stage1+stage2+kernel_padded → boot.img (layout settori CD 2048B)
- Target `iso`: usa solo `xorriso -as mkisofs` con `-b boot/boot.img -boot-info-table`
- Aggiunto `-fno-pie` alle CFLAGS

### Bug #6 — stage2.asm: logica E820 count=0 bypass fallback (→ PMM con 0 entries)
**Causa:** Il codice usava `cmp rax, 32 / jle .cnt_ok` che, se count=0, saltava al `.cnt_ok` bypassando il `mov rax, 4` di fallback. La `.cnt_max_ok` era raggiunta solo da rax>32 (dopo cap a 32), non da rax=0.
**Effetto:** In caso di E820 completamente assente, PMM inizializzato con 0 entries → pmm_alloc_frame() restituisce subito ~0 → crash.
**Fix:** Logica riscritta: `test rax, rax / jnz .cnt_nonzero / mov rax, 4 / jmp .cnt_ok / .cnt_nonzero: / cmp rax, 32 / ...`

### Bug #7 — limine.cfg: kernel_path sbagliato (→ solo se usato Limine vero, non applicabile al boot custom)
**Causa:** limine.cfg puntava a `mattiaos_kernel.elf` ma Makefile copia `kernel.elf`.
**Fix:** Corretto in `kernel_path: boot():/boot/kernel.elf` (documentazione coerente).

### Verifica finale v3.6 (9/9 check)
| Check | Risultato |
|---|---|
| El Torito BRD type=0x00 | ✅ |
| Boot indicator=0x88 | ✅ |
| Media type=0 (no-emulation) | ✅ |
| Sector count=4 (boot-load-size) | ✅ |
| bi_boot_LBA == boot image LBA | ✅ |
| stage1[0]=0xEB (JMP SHORT) | ✅ |
| stage1[2]=0x90 (NOP) | ✅ |
| Kernel ELF magic 7F454C46 a LBA bi+29 | ✅ |
| Kernel entry in higher half (0xFFFFFFFF8...) | ✅ |

### Kernel ELF v3.6 — layout segmenti
| Segmento | vaddr | paddr | filesz |
|---|---|---|---|
| .text | 0xffffffff80000000 | 0x00200000 | 0x1a270 |
| .rodata | 0xffffffff8001b000 | 0x0021b000 | 0x1e00 |
| .data/.bss | 0xffffffff8001d000 | 0x0021d000 | 0xf68 |
| .limine_requests | 0xffffffff80119000 | 0x00319000 | 0x1d0 |

Entry point: `0xffffffff8000394d`
HHDM response: section+0x128 | MEMMAP: section+0x0A8 | KADDR: section+0x0E8

**AVVERTIMENTO PERMANENTE (ripetuto):** Questi offset cambiano ad ogni ricompilazione. Dopo ogni modifica al kernel, eseguire:
```python
python3 -c "
import struct
with open('kernel.elf', 'rb') as f: elf = f.read()
e_phoff = struct.unpack_from('<Q', elf, 0x20)[0]
e_phentsz = struct.unpack_from('<H', elf, 0x36)[0]
b = e_phoff + 3 * e_phentsz  # PT[3] = .limine_requests
p_off = struct.unpack_from('<Q', elf, b+0x08)[0]
p_filesz = struct.unpack_from('<Q', elf, b+0x20)[0]
p_vaddr = struct.unpack_from('<Q', elf, b+0x10)[0]
BASE_PADDR = p_vaddr - 0xFFFFFFFF80000000 + 0x200000
print(f'.limine_requests paddr = 0x{BASE_PADDR:x}')
data = elf[p_off:p_off+p_filesz]
magics = {'HHDM':(0x48dcf1cb8ad2b852,0x63984e959a98244b),'MEMMAP':(0x67cf3d9d378a806f,0xe304acdfc50c3c62),'KADDR':(0x71ba76863cc55f63,0xb2644a48c516a487)}
for name,(m0,m1) in magics.items():
    for i in range(0,len(data)-40,8):
        if struct.unpack_from('<Q',data,i)[0]==m0 and struct.unpack_from('<Q',data,i+8)[0]==m1:
            print(f'{name}: response* @ section+0x{i+0x28:03x}  (paddr 0x{BASE_PADDR+i+0x28:07x})')
            break
"
```
Aggiornare le tre righe `mov [rbx + 0xXXX], rax` in stage2.asm se gli offset differiscono.

### Impostazioni VirtualBox corrette per MattiaOS v3.6
(Identiche alla v3.6.2 — nessun cambio hardware richiesto)

**Generale → Base:**
- Tipo: **Other** / Versione: **Other/Unknown (64-bit)**

**Sistema → Scheda madre:**
- Memoria: **256 MB** (minimo)
- Ordine avvio: ✅ **Ottico SOLO**
- Chipset: **PIIX3**
- ✅ **I/O APIC** — OBBLIGATORIO
- ❌ **EFI: DISABILITATO** — CRITICO (MattiaOS usa BIOS)
- ✅ **PAE/NX**

**Sistema → Accelerazione:**
- Paravirtualizzazione: **Legacy** o **None**

**Schermo:**
- Memoria video: **16 MB**
- Controller: **VBoxVGA** (non VMSVGA)

**Archiviazione:**
- Controller: **IDE** → Unità ottica → `mattiaos.iso`
- ❌ NON usare SATA per l'ottico

*MattiaOS Blueprint v3.6 — In caso di contraddizione tra questo file e qualsiasi altra cosa, questo file ha la precedenza. Il codice sbagliato si corregge. Il blueprint no.*

---

## Sessione v3.7 — 3 bug critici corretti, tastiera funzionante

### Contesto
Dopo la sessione v3.6 il kernel bootava correttamente (GDT/IDT/SERIAL/PMM/VMM OK su VGA),
ma era impossibile inserire comandi nella console interattiva.
Sono stati identificati e corretti 3 bug critici che rendevano la tastiera completamente non funzionante.

### Bug #1 — PIC 8259 mai rimappato (→ ogni keypress = KERNEL PANIC)

**Root cause:** Il BIOS lascia il PIC 8259 con la configurazione legacy:
- IRQ0-7 → vettori CPU 0x08-0x0F (coincidono esattamente con le eccezioni CPU)
- In particolare IRQ1 (tastiera PS/2) → vettore 0x09 = "Coprocessor Segment Overrun"

Ogni pressione di un tasto generava un'eccezione CPU invece di chiamare il nostro
handler PS/2. `isr_handler()` vedeva vec=0x09 < 0x20 e chiamava `dump_exception()` → `cli; hlt`.
Il sistema si bloccava silenziosamente al primo tasto.

**Diagnostica:** Senza debug seriale questo bug è invisibile: lo schermo smette semplicemente
di rispondere. Con seriale si vedrebbe "[KERNEL PANIC] Exception 09: Coprocessor Seg Overrun".

**Fix:** Aggiunta funzione `pic_init()` in `cpu.c` e `cpu.h`:
- ICW1-ICW4: rimappa PIC master a 0x20-0x27, slave a 0x28-0x2F
- IMR master: 0xF9 → IRQ1 (kbd) e IRQ2 (cascata slave) attivi, tutti gli altri mascherati
- IMR slave: 0xEF → IRQ12 (mouse PS/2) attivo, tutti gli altri mascherati
- IRQ0 (PIT timer) mascherato perché usiamo LAPIC timer (vettore 0x20)

**Chiamata in `entry.c`:** Dopo `idt_init()`, PRIMA di `sti()` e `lapic_init()`.

### Bug #2 — VGA buffer (0xB8000) non mappato dopo vmm_switch_pagemap (→ crash VGA silenzioso)

**Root cause:** `vmm_init()` mappava come identity solo i primi 64KB (0x0-0xFFFF).
Il VGA text buffer è a 0xB8000 (≈753KB), fuori dal range mappato.
Dopo `vmm_switch_pagemap()`, qualsiasi `vga_putchar_attr()` generava #PF su 0xB8000.
Il nuovo PML4 non aveva quella mappatura: l'HHDM mappa 0xB8000 solo all'indirizzo
`HHDM_OFFSET + 0xB8000`, ma cpu.c usa l'indirizzo fisico diretto 0xB8000 come virtuale.

**Effetto:** Il kernel continuava a girare (output seriale intatto), ma lo schermo si
congelava all'ultima riga stampata prima di vmm_switch_pagemap. Qualsiasi tentativo
di scrivere su VGA causava un #PF silenzioso (handler IDT non ancora attivo al momento
dell'init) → triple fault → reboot.

**Fix:** In `vmm_init()`, l'identity map è estesa a tutto il primo MB (0x0-0xFFFFF):
```c
for (uint64_t p = 0; p < 0x100000; p += PAGE_SIZE) {
    vmm_map(g_kernel_pml4, p, p, PTE_PRESENT | PTE_WRITABLE);
}
```
Questo copre:
- 0x00000-0x004FF  IVT + BDA (BIOS)
- 0x07C00          Stack di boot
- 0x08000-0x0DFFF  Stage2
- 0x0B8000         VGA text buffer ← il bug

### Bug #3 — Nessun EOI al PIC 8259 dopo IRQ hardware (→ una sola keypress poi silenzio)

**Root cause:** `isr_handler()` inviava EOI solo al LAPIC (`lapic_eoi()`).
Il PIC 8259 fisico è separato dal LAPIC: riceve l'IRQ dalla periferica (tastiera)
e deve ricevere il proprio EOI indipendentemente. Senza EOI al PIC, il master
mantiene la linea IRQ1 asserted e non genera mai più interrupt per la tastiera.
Il risultato: il primo tasto funziona, poi silenzio totale.

**Fix:** In `idt.c`, `isr_handler()`, dopo il dispatch del handler:
```c
if (vec >= 0x21 && vec <= 0x2F) {
    if (vec >= 0x28) outb(0xA0, 0x20);  // EOI al PIC slave (IRQ8-15)
    outb(0x20, 0x20);                    // EOI al PIC master
}
lapic_eoi();  // sempre, per il LAPIC
```
Nota: vettore 0x20 = LAPIC timer (non passa dal PIC → solo lapic_eoi).
Vettori 0x21-0x27 = IRQ PIC master → EOI solo al master.
Vettori 0x28-0x2F = IRQ PIC slave → EOI a slave + master.

### File modificati in v3.7

| File | Modifica |
|---|---|
| `kernel/arch/x86_64/cpu.h` | Aggiunta dichiarazione `pic_init()` con documentazione |
| `kernel/arch/x86_64/cpu.c` | Aggiunta implementazione `pic_init()` (rimappaggio PIC + mascheratura IRQ) |
| `kernel/arch/x86_64/idt.c` | Fix `isr_handler()`: aggiunto EOI al PIC 8259 per vettori 0x21-0x2F |
| `kernel/mm/vmm.c` | Fix `vmm_init()`: identity map estesa a 1MB (era 64KB) per coprire VGA 0xB8000 |
| `kernel/arch/x86_64/entry.c` | Aggiunta chiamata `pic_init()` dopo `idt_init()` con log [OK] |
| `boot/stage2.asm` | Aggiornato `kentry` a 0xFFFFFFFF8000E9FD (entry point spostato dopo ricompilazione) |

### Verifica post-fix v3.7

| Metrica | Valore |
|---|---|
| kernel.elf | 174032 bytes |
| Entry point | 0xFFFFFFFF8000E9FD |
| .limine_requests paddr | 0x31b000 (invariato) |
| HHDM response* | section+0x128 (invariato) |
| MEMMAP response* | section+0x0A8 (invariato) |
| KADDR response* | section+0x0E8 (invariato) |
| stage1.bin | 2048 bytes |
| stage2.bin | 57344 bytes |
| ISO El Torito | 9/9 check OK |

### Sequenza di boot attesa v3.7

```
[bianco]  MattiaOS v3.5 - Stage2 avviato
[bianco]  A20 fast gate OK
[bianco]  Kernel ELF caricato (120 sett CD)
[verde]   PM32: copia kernel ...
          ...
[giallo]  LM64: Salto a kernel_main!
─────────────────────────────────────────
[verde]  [OK]   [GDT]    Descriptor tables OK
[verde]  [OK]   [IDT]    256 interrupt vectors
[verde]  [OK]   [SERIAL] COM1 + VGA attivi
[verde]  [OK]   [PIC]    8259 rimappato: IRQ1/IRQ12 attivi
[verde]  [OK]   [LIMINE] Responses valide
[verde]  [OK]   [PMM]    PMM pronto
[verde]  [OK]   [VMM]    PML4 attivo (1MB identity + HHDM + kernel)
[verde]  [OK]   [SLAB]   Allocatore slab pronto
[giallo] [WARN] [ACPI]   RSDP opzionale
[verde]  [OK]   [APIC]   LAPIC + timer 1ms
[verde]  [OK]   [PCI]    Bus enumerato
[verde]  [OK]   [VFS]    / e /dev montati
[verde]  [OK]   [CPU]    Interrupt abilitati
[verde]  [OK]   [DRV]    Driver pronti

  ──────────────────────────────────────
  MattiaOS v3.6 — Boot OK. Digita 'help'
  ──────────────────────────────────────

MattiaOS> _       ← CURSORE LAMPEGGIANTE, TASTIERA FUNZIONANTE
```

### Spiegazione contenuto ISO (risposta alla domanda utente)

La ISO contiene solo la cartella `/boot/boot.img`. Questo è corretto e intenzionale.
boot.img = stage1(2KB) + stage2(56KB) + kernel.elf(174KB) concatenati.
Non ci sono cartelle sorgente, userspace o filesystem separati nell'ISO perché:
1. MattiaOS non ha ancora un filesystem su disco (Fase 13+ non implementata)
2. Il kernel è self-contained: tutto il codice è nel kernel.elf
3. Lo stage2 carica direttamente il kernel ELF dai settori CD
4. init, shell e coreutils saranno popolati su un disco MattiaFS separato (Fase 13+)

### Impostazioni VirtualBox v3.7 (verificate e corrette)

**Sistema → Scheda madre:**
- Memoria: 256 MB
- Ordine avvio: ✅ Ottico SOLO (disabilita tutto il resto)
- Chipset: PIIX3
- ✅ I/O APIC — OBBLIGATORIO
- ❌ EFI: DISABILITATO — CRITICO (MattiaOS usa BIOS)
- ✅ PAE/NX

**Sistema → Accelerazione:**
- Paravirtualizzazione: Legacy o None
- ✅ VT-x/AMD-V + Nested Paging

**Schermo:**
- Controller: **VBoxVGA** (NON VMSVGA, NON VBoxSVGA — questi cambiano il framebuffer)
- Memoria video: 16 MB
- ❌ Accelerazione 2D/3D disabilitate

**Archiviazione:**
- Controller: **IDE** (non SATA)
- Unità ottica → MattiaOS_v3.7.iso

**Rete:** Disabilitata o NAT (network stack non ancora connesso a userspace)

### Stato Fase corrente (v3.7)
- Fase 12 COMPLETATA + bug tastiera corretti
- Kernel console interattiva funzionante
- Prossimo: Fase 13 — syscall dispatcher (MSR_LSTAR) + ELF loader


---

## Sessione v3.8 — Analisi sistematica tastiera: 4 bug aggiuntivi corretti

### Premessa
Dopo v3.7 la tastiera non rispondeva ancora. Analisi sistematica di tutte le possibili cause,
dal livello hardware (APIC routing) al livello software (polling fallback).

### Lista cause analizzate

| # | Causa | Probabilità | Esito analisi |
|---|---|---|---|
| A | LAPIC LINT0 non configurato come ExtINT | 🔴 ALTA | **BUG CONFERMATO** — valore di reset è 0x10000 (masked/fixed), PIC→LINT0 non funzionava |
| B | I/O APIC mai inizializzato | 🔴 ALTA | **BUG CONFERMATO** — VirtualBox con I/O APIC abilitato: IRQ passano per I/O APIC, mai configurato |
| C | ps2_init() fallisce silenziosamente | 🟡 MEDIA | **BUG CONFERMATO** — 5 `return` prematuri senza log, nessuna diagnostica; riscritto con debug completo |
| D | Mancano io_wait() tra write PIC | 🟡 MEDIA | **FIX APPLICATA** — aggiunta io_wait() dopo ogni ICW/OCW write |
| E | Scan code translation ancora attiva | 🟡 MEDIA | **DIAGNOSTICA AGGIUNTA** — ora logghiamo se sc_active=0x43 (translation ON forzata) |
| F | Nessun polling fallback senza IRQ | 🟡 MEDIA | **FIX APPLICATA** — ps2_kbd_poll_hardware() nel loop console come fallback |
| G | Race tra keyboard_getchar() e hlt | 🟢 BASSA | Non critico con LAPIC timer 1ms che sveglia la CPU comunque |
| H | LAPIC Timer vec 0x20 conflitto PIC | 🟢 BASSA | Non reale: IRQ0 PIT mascherato (IMR=0xF9) |

### Bug A — LAPIC LINT0 non configurato come ExtINT (`apic.c`, `apic.h`)

**Root cause:** Il LAPIC all'accensione ha LVT LINT0 = `0x00010000` (masked, delivery mode Fixed).
In "Virtual Wire Mode" (PIC 8259 → LINT0 → CPU), il pin LINT0 deve essere programmato con
delivery mode **ExtINT** (0x700): questo dice al LAPIC di accettare il vettore dal PIC esterno
tramite il ciclo INTA, invece di usare il campo vector interno.
Senza questa riga, gli IRQ del PIC grida nel vuoto anche se il PIC è perfettamente configurato.

**Fix:** In `lapic_init()`:
```c
lapic_write(LAPIC_LVT_LINT0, LAPIC_LVT_DELIVERY_EXTINT);  // 0x700
lapic_write(LAPIC_LVT_LINT1, LAPIC_LVT_DELIVERY_NMI);      // 0x400 (NMI)
```
Aggiunti define `LAPIC_LVT_LINT0=0x350`, `LAPIC_LVT_LINT1=0x360`,
`LAPIC_LVT_DELIVERY_EXTINT=(7<<8)`, `LAPIC_LVT_DELIVERY_NMI=(4<<8)` in `apic.h`.

### Bug B — I/O APIC mai inizializzato (`apic.c`, `apic.h`)

**Root cause:** VirtualBox ha I/O APIC abilitato (necessario per MattiaOS: flag "I/O APIC" nelle
impostazioni). Con I/O APIC attivo, gli interrupt hardware (IRQ1=kbd, IRQ12=mouse, ecc.) transitano
per l'I/O APIC (porta 0xFEC00000) prima di raggiungere il LAPIC. Il firmware SeaBIOS può
programmare la redirect table al boot, ma noi sovrascriviamo tutto con `pml4_switch` e potremmo
invalidare quella configurazione. La nostra `ioapic_init()` non esisteva.

**Fix:** Nuova funzione `ioapic_init()` in `apic.c`:
- Legge indirizzo I/O APIC da MADT ACPI (fallback: 0xFEC00000)
- Maschera TUTTE le redirect entries (pulizia stato firmware)
- Programma: INTIN#1 → vector 0x21 (kbd), INTIN#12 → vector 0x2C (mouse), dest=BSP LAPIC ID
- Chiamata da `entry.c` dopo `apic_timer_init()`

**Accesso I/O APIC:** Registro indiretto IOREGSEL (offset 0x00) + IOWIN (offset 0x10 = indice 4).

**Redirect Entry format (64-bit):**
```
[7:0]   Vector  = 0x21 per IRQ1
[10:8]  Delivery Mode = 000 (Fixed)
[11]    Dest Mode = 0 (Physical)
[13]    Polarity = 0 (Active High)
[15]    Trigger = 0 (Edge)
[16]    Mask = 0 (attivo)
[63:56] Destination = LAPIC ID (Physical mode)
```

### Fix C — ps2_init() riscritto con diagnostica completa (`ps2.c`)

La versione precedente aveva 5 `return` silenziosi (self-test fail, port test fail, reset fail,
ecc.) senza alcun log seriale. In v3.8:
- Ogni step logga il risultato su COM1 con `serial_printf`
- Nessun ritorno silenzioso: tutti i "fail" vengono loggati ma l'init continua
- Verifica scan code set attivo con comando 0xF0 0x00 (query)
- Logga warning se sc_active=0x43 (translation ON forzata → set 1 invece di set 2)
- CFG byte loggato prima e dopo ogni modifica

### Fix D — io_wait() tra write PIC (`cpu.c`, `cpu.h`)

Aggiunta inline `io_wait()` che scrive su porta 0x80 (POST code port, ~1µs di delay).
Inserita dopo ogni `outb()` verso il PIC 8259 (ICW1-4, OCW1). Non strettamente necessaria
in VirtualBox, ma rispetta i timing dell'8259 su hardware reale.

### Fix F — Polling fallback ps2_kbd_poll_hardware() (`ps2.c`, `ps2.h`, `entry.c`)

Nuova funzione `ps2_kbd_poll_hardware()`: controlla OBF bit (porta 0x64 bit0), legge
il byte da porta 0x60 se disponibile, deposita nel ring buffer g_ps2_kbd_buf, chiama
`keyboard_process()`. Non bloccante (ritorna false se nessun dato).

Nel loop `kernel_console()`, dopo `hlt` (svegliato dal LAPIC timer ~1ms), viene
chiamato `ps2_kbd_poll_hardware()` come fallback. Questo garantisce funzionamento
anche se gli IRQ non vengono consegnati correttamente.

### File modificati in v3.8

| File | Modifica |
|---|---|
| `kernel/arch/x86_64/apic.h` | +LAPIC_LVT_LINT0, LINT1, LVT_DELIVERY_* defines; +dichiarazione ioapic_init() |
| `kernel/arch/x86_64/apic.c` | lapic_init(): LINT0=ExtINT, LINT1=NMI; nuova ioapic_init() |
| `kernel/arch/x86_64/cpu.h` | Aggiunta inline io_wait() |
| `kernel/arch/x86_64/cpu.c` | pic_init(): io_wait() dopo ogni write, log seriale |
| `kernel/arch/x86_64/entry.c` | +include ps2.h; +chiamata ioapic_init(); loop console con polling fallback |
| `kernel/drivers/input/ps2.h` | +dichiarazione ps2_kbd_poll_hardware() |
| `kernel/drivers/input/ps2.c` | IRQ handler con serial_printf debug; ps2_init() riscritto con diagnostica completa; nuova ps2_kbd_poll_hardware() |

### Verifica post-build v3.8

| Metrica | Valore |
|---|---|
| kernel.elf | 174296 bytes |
| Entry point | 0xFFFFFFFF8000AF24 |
| .limine_requests paddr | 0x31b000 (invariato) |
| ISO El Torito | 9/9 check OK |

### Sequenza di boot attesa v3.8 (output seriale COM1)

Con una porta seriale (COM1, 38400 baud) vedrai:
```
[PIC] 8259 rimappato: master=0x20, slave=0x28. IMR: master=0xF9 slave=0xEF
[LAPIC] Abilitato. LINT0=ExtINT(0x700) LINT1=NMI(0x400)
[IOAPIC] Trovato in MADT: phys=0xfec00000 gsi_base=0
[IOAPIC] ver=0x... max_redir=23
[IOAPIC] IRQ1 → INTIN#1 → vec 0x21, LAPIC 0
[IOAPIC] IRQ12 → INTIN#12 → vec 0x2C, LAPIC 0
[PS2] Init controller 8042...
[PS2] CFG originale: 0x45  (XLAT=1 IRQ1=1 IRQ12=0)
[PS2] CFG dopo clear XLAT: 0x40  (XLAT=0 IRQ1=0)
[PS2] Self-test: 0x55  (atteso 0x55=OK)
[PS2] Test porta 1: 0x00  (atteso 0x00=OK)
[PS2] Reset kbd: ack=0xfa self=0xaa  (OK)
[PS2] Set scan code 2: ack1=0xfa ack2=0xfa  (OK)
[PS2] Query scan code: ack=0xfa ack2=0xfa set=0x02
[PS2] Enable scanning: ack=0xfa  (OK)
[PS2] CFG finale: 0x41  (IRQ1=1 XLAT=0)
--- tastiera funzionante ---
[PS2] IRQ1 byte=0x1c   ← premuto 'a' (make code set 2)
[PS2] IRQ1 byte=0xf0   ← prefix release
[PS2] IRQ1 byte=0x1c   ← rilasciato 'a' (break)
```

### Note diagnostiche

**Se il seriale mostra [PS2] Query scan code: set=0x43:**
La scan code translation è forzata ON dal firmware. Il controller invia scan code set 1
(0x1E per 'a' invece di 0x1C). keyboard.c decodifica set 2 → i tasti saranno sbagliati.
Soluzione futura: aggiungere tabella set 1 in keyboard.c come fallback.

**Se non compaiono righe [PS2] IRQ1 byte=...:**
Gli IRQ non arrivano. Verificare:
1. VirtualBox: I/O APIC abilitato (Sistema → Scheda madre → I/O APIC ✅)
2. VirtualBox: Controller grafico = VBoxVGA (non VMSVGA)
3. VirtualBox: Dispositivo di puntamento = PS/2 Mouse
4. La riga [IOAPIC] appare? Se no, acpi_init() non ha trovato la MADT.

**Se compaiono [PS2] IRQ1 byte=... ma niente su schermo:**
Il decoder keyboard.c non converte correttamente. Verificare il campo 'ascii' nell'evento.

---

## Sessione v3.8 — Analisi sistematica tastiera: 4 bug aggiuntivi corretti

### Bug A — LAPIC LINT0 non configurato come ExtINT
Il LAPIC al reset ha LVT LINT0 = 0x10000 (masked/fixed). In Virtual Wire Mode il PIC
deve consegnare IRQ tramite LINT0 programmato come ExtINT (0x700). Senza questa riga
il PIC non riesce a consegnare IRQ1 alla CPU indipendentemente da qualsiasi altra config.
Fix: lapic_write(LAPIC_LVT_LINT0, 0x700) e LAPIC_LVT_LINT1=NMI(0x400) in lapic_init().

### Bug B — I/O APIC mai inizializzato
VirtualBox ha I/O APIC abilitato (obbligatorio per MattiaOS). Con I/O APIC attivo, IRQ
hardware passano per I/O APIC prima del LAPIC. Nuova funzione ioapic_init(): legge
indirizzo da MADT ACPI, maschera tutte le entries, programma INTIN#1→vec0x21(kbd) e
INTIN#12→vec0x2C(mouse) con dest=BSP LAPIC ID. Chiamata dopo apic_timer_init().

### Fix C — ps2_init() riscritto con diagnostica
5 ritorni silenziosi rimossi, ogni step logga su COM1. Aggiunta verifica scan code set
con query 0xF0 0x00. Warning se sc_active=0x43 (translation forzata → set 1).

### Fix D — io_wait() tra write PIC 8259
Aggiunta inline io_wait() (outb 0x80) dopo ogni ICW/OCW write in pic_init().

### Fix F — Polling fallback ps2_kbd_poll_hardware()
Nuova funzione che legge porta 0x60 direttamente se OBF=1, senza aspettare IRQ.
Chiamata nel loop console dopo hlt per garantire funzionamento anche senza IRQ.

### File modificati v3.8
apic.h, apic.c (LINT0/LINT1/ioapic_init), cpu.h (io_wait), cpu.c (pic_init con delays),
entry.c (ioapic_init + polling fallback), ps2.h (ps2_kbd_poll_hardware decl),
ps2.c (IRQ debug + ps2_init diagnostica + ps2_kbd_poll_hardware).

### Build v3.8
kernel.elf: 174296 bytes | entry: 0xFFFFFFFF8000AF24 | .limine_requests paddr: 0x31b000 | ISO: 9/9 OK

---

## Sessione v5.7 — 3 bug critici VFS corretti, nuove directory sistema

### Contesto
Sessione di debug sistematico del VFS: il comando `ls` nella console kernel mostrava
"(directory vuota)" anche dopo che kernel_main aveva creato /tmp, /etc, /home, /var.
Identificati 3 bug critici interconnessi nella catena vfs_lookup → tmpfs.

### Bug #1 — vfs_lookup restituisce il nodo radice direttamente (NON heap-allocated)
**Root cause:** `vfs_lookup("/")` restituiva `&m->root` ovvero il puntatore diretto al
nodo radice del mount, NON una copia heap-allocated. Tutte le funzioni chiamanti
(`vfs_mkdir`, `vfs_unlink`, `vfs_stat`) terminano con `kfree(parent)`. Dopo 4 chiamate
a `vfs_mkdir` (/tmp, /etc, /home, /var), il nodo radice veniva liberato e poi
sovrascritto dallo slab allocator con la chiamata successiva a `kzalloc`. L'azzeramento
dello slab sovrascriveva `root->vnode.ops = NULL`. Qualsiasi successiva `vfs_readdir`
trovava `ops == NULL` → ritornava ENOTDIR → `cmd_ls` vedeva 0 entry → "(directory vuota)".

**Fix:** `vfs_lookup` ora alloca sempre una copia heap con `kzalloc` anche per i mount
root, copiandone il contenuto. Il nodo originale non viene mai passato ai caller.

### Bug #2 — tmpfs_create e tmpfs_mkdir_op non impostano ops pointer
**Root cause:** `kzalloc` azzera tutto. Nuovi nodi (file e directory) avevano
`vnode.ops = NULL`. Qualsiasi operazione su di essi (ls di sottodirectory, open di file)
falliva con ENOTDIR o EINVAL.

**Fix:** Aggiunto `node->vnode.ops = &s_tmpfs_ops;` in entrambe le funzioni
`tmpfs_create` e `tmpfs_mkdir_op`.

### Bug #3 — tmpfs non aveva implementazione di stat
**Root cause:** `s_tmpfs_ops.stat = NULL`. Qualsiasi chiamata `vfs_stat` su file/dir
tmpfs ritornava sempre EINVAL.

**Fix:** Implementato `tmpfs_stat_op()`: popola una struct stat kernel-compatible con
st_ino, st_mode, st_size, st_blksize, st_blocks. Aggiunto `static vfs_ops_t s_tmpfs_ops;`
forward declaration per risolvere il riferimento circolare (create/mkdir usano `&s_tmpfs_ops`
prima della sua definizione).

### Nuove funzionalità aggiunte

**vfs_create_file() — nuova API kernel:**
Crea un file (non directory) via percorso assoluto. Usa vfs_lookup del parent + ops->create.
Dichiarata in vfs.h, implementata in vfs.c.

**Directory /Binari_Eseguibili:**
Creata in `kernel_main` all'avvio. Equivalente di /bin + /usr/bin in Linux.
Conterrà tutti i binari eseguibili di MattiaOS quando il syscall layer sarà attivo.

**Directory /Dipendenze:**
Creata in `kernel_main` all'avvio. Equivalente di /lib in Linux.
Contiene le librerie condivise usate dai programmi.

**File /Dipendenze/dipendenze.cfg:**
Creato e popolato al boot con contenuto statico. Traccia per ogni libreria quali
programmi la usano. Formato: `LIBRERIA: prog1 prog2 ...`. Le librerie senza utenti
vengono rimosse automaticamente (logica da implementare nel syscall layer).

**Versione bumped v3.19 → v5.7.**

### File modificati in v5.7

| File | Modifica |
|---|---|
| `kernel/fs/vfs.c` | Fix `vfs_lookup`: sempre heap-allocated copy; aggiunta `vfs_create_file()` |
| `kernel/fs/vfs.h` | Aggiunta dichiarazione `vfs_create_file()` |
| `kernel/fs/tmpfs.c` | Fix `tmpfs_create`/`tmpfs_mkdir_op`: ops pointer; aggiunta `tmpfs_stat_op()`; forward decl `s_tmpfs_ops`; set `root->vnode.ops` in mount |
| `kernel/arch/x86_64/entry.c` | Versione v5.7; aggiunte `/Binari_Eseguibili`, `/Dipendenze`, `/Dipendenze/dipendenze.cfg` |
| `Makefile` | volid aggiornato a `MattiaOS_v5.7` |

### Verifica build v5.7

| Metrica | Valore |
|---|---|
| kernel.elf | 196032 bytes (+ 576B padding = 192 settori CD) |
| Entry point | 0xffffffff800081ad |
| .limine_requests paddr | 0x366000 |
| HHDM response* | section+0x128 (abs 0x366128) |
| MEMMAP response* | section+0x0A8 (abs 0x3660A8) |
| KADDR response* | section+0x0E8 (abs 0x3660E8) |
| Stage2 entry point read | Dinamico da ELF header [rbx+0x18] — NON hardcoded |
| ISO El Torito | ind=0x88 ✅ media=0 ✅ stage1[0]=0xeb ✅ |
| Errori compilazione | 0 errori, 0 warning |

*MattiaOS Blueprint v5.7 — In caso di contraddizione tra questo file e qualsiasi altra cosa, questo file ha la precedenza. Il codice sbagliato si corregge. Il blueprint no.*

---

## Sessione v5.7 — Comandi cat e tree; chiarimento architettura binari

### Chiarimento architettura: /Binari_Eseguibili e /Dipendenze

**Stato attuale (v5.7):**
- Tutti i comandi della console (`ls`, `cd`, `cat`, `tree`, `mem`, `pci`, ecc.) sono
  **integrati nel kernel** come funzioni C statiche in `entry.c`. Non sono ELF separati.
- `/Binari_Eseguibili` è **correttamente vuota**: non ci sono ancora binari ELF eseguibili
  da userspace perché il syscall dispatcher (Fase 13) non è ancora implementato.
- `/Dipendenze/dipendenze.cfg` contiene il registro delle dipendenze per quando
  i programmi userspace saranno avviabili.
- Quando la Fase 13 sarà completata (ELF loader + syscall layer), i 33 coreutils
  e la shell compilati da `userspace/` andranno in `/Binari_Eseguibili`, e
  `libmattiac.a` (→ .so) andrà in `/Dipendenze`.

### Nuovi comandi aggiunti alla console kernel

**`cat <percorso>` — visualizzatore file multi-tipo:**

Rilevamento automatico del tipo:
- **ELF** (magic `7F 45 4C 46`): hex dump colorato in ciano con header `[ELF64]`
- **Binario generico** (byte non-printable fuori da `\t\n\r`): hex dump
- **Testo puro**: output diretto come caratteri

Formato hex dump (4 byte per riga, adattato a 80 colonne VGA):
```
0x00000000: 01111111 01000101 01001100 01000110  |  7f 45 4c 46  |  .ELF
└─ offset ─┘ └────────── bit per byte ────────┘     └── hex ──┘     └ASCII┘
```
Supporta file di qualsiasi dimensione tramite read() a chunk da 4KB.
Interrompibile con Ctrl+C.

**`tree [percorso]` — albero ricorsivo filesystem:**

Stampa l'albero completo del filesystem con rami box-drawing stile unix tree:
```
  /
  ├── etc/
  ├── home/
  ├── tmp/
  ├── var/
  ├── Binari_Eseguibili/
  └── Dipendenze/
      └── dipendenze.cfg
```
Profondità massima: 16 livelli. Mostra sommario finale `N dir, M file`.
Interrompibile con Ctrl+C. Implementato con stack iterativo (no ricorsione).
Colori: directory=verde, file=bianco, rami=grigio.

### File modificati in v5.7

| File | Modifica |
|---|---|
| `kernel/arch/x86_64/entry.c` | Versione v5.7; aggiunto `cmd_cat()`, `cmd_tree()`, helper `con_hex32/con_bits8/con_hex8`; aggiornato `cmd_help()`; aggiunto dispatch per `cat` e `tree` |
| `boot/stage2.asm` | paddr `.limine_requests` aggiornato a 0x366000 (kernel cresciuto per buffer statici) |

### Verifica build v5.7

| Metrica | Valore |
|---|---|
| kernel.elf | ~270 KB (aumentato per buffer statici tree/cat 32KB+32KB) |
| Entry point | 0xffffffff8000f4ec |
| .limine_requests paddr | 0x366000 |
| HHDM response* | section+0x128 (abs 0x366128) |
| MEMMAP response* | section+0x0A8 (abs 0x3660A8) |
| KADDR response* | section+0x0E8 (abs 0x3660E8) |
| Stage2 0x366000 | ✅ presente |
| Errori compilazione | 0 errori, 0 warning |

*MattiaOS Blueprint v5.7 — In caso di contraddizione tra questo file e qualsiasi altra cosa, questo file ha la precedenza.*

---

## ⚠️ REGOLA VERSIONE — OBBLIGATORIA PER OGNI SESSIONE

**La versione DEVE essere incrementata ad ogni singolo cambiamento al codice, alla configurazione, o alla documentazione del kernel.**

Questo vale per:
- qualsiasi modifica a un file `.c`, `.h`, `.asm`, `.ld`, `Makefile`
- qualsiasi aggiornamento al Blueprint stesso
- qualsiasi fix, anche di una sola riga

**Procedura obbligatoria:**
1. Bump versione in `entry.c` (`#define MATTIAOS_VERSION`)
2. Ricompila (`make iso`)
3. Ricalcola paddr `.limine_requests` con ELF parser Python
4. Aggiorna `stage2.asm` (`mov rbx, 0xXXXXXX`)
5. Ricompila ISO (`make iso`)
6. Verifica stage2.bin con script di verifica
7. Aggiorna Blueprint con nuova versione e paddr

**Non esistono "piccoli fix" che non richiedono bump di versione.** Ogni ISO deve avere un numero univoco per tracciare correttamente i bug.

---

## Sessione v5.7 — Fix bug critico PMM: bitmap sovrascrive BSS kernel

### Bug diagnosticato: GURU_MEDITATION triple fault al boot (VirtualBox 4.8GB / 6 CPU)

**Sintomo:** Triple fault (VINF_EM_TRIPLE_FAULT) immediatamente dopo il boot. Il kernel stampava tutto fino a `[OK] [VFS] / (tmpfs) + /dev (devfs) montati`, poi si bloccava. L'`asm volatile("sti")` successivo causava l'interrupt timer che accedeva a stato corrotto → triple fault.

**Root cause:** Due problemi concatenati.

**Problema 1 — BSS enorme (v4.12):**
Le variabili statiche introdotte in v4.12 per `cmd_tree` e `cmd_cat` gonfiavano il BSS a 2.2MB:
- `s_stack[TREE_MAX_DEPTH * TREE_MAX_ITEMS]` = `[16][256]` × 268 bytes = **1.1MB**
- `c_name[TREE_MAX_ITEMS][64]` = 256 × 64 = **16KB**
- `e_name[TREE_MAX_ITEMS][64]` = variabile **locale** sullo stack = 16KB (potenziale stack overflow)
- `s_cat_buf[4096]` = 4KB

Questo portava il kernel fisico da `0x200000` a `~0x453000`, superando `PMM_RESERVED_BELOW = 0x400000`.

**Problema 2 — PMM bitmap sovrascrive BSS (root cause del crash):**
Con 4.8GB RAM, il bitmap PMM era 128KB. `pmm_init` cercava il primo indirizzo usable ≥ `PMM_RESERVED_BELOW = 0x400000` e lo trovava esattamente a `0x400000` — dentro il BSS del kernel (che arrivava fino a `0x451500`). La `memset(bitmap, 0xFF, 128KB)` sovrascriveva il BSS del kernel corrompendo variabili statiche critiche. Con 256MB RAM il bitmap era solo 8KB e il problema era meno visibile (il danno era contenuto), ma con 4.8GB RAM diventa fatale.

**Analisi VBox log:**
```
CR3 = 0x453000 (PML4 correttamente allocato dopo kernel)
RIP = 0xffffffff8000fa8e (crash nell'ISR timer dopo STI)
RBX = 0x452000 (paddr .limine_requests v4.12 — confermato)
guest paging VCPU0: AMD64+NX (kernel in esecuzione)
guest paging VCPU1-5: Real (AP non inizializzati — normale senza SMP)
```

### Fix v5.7

**Fix 1 — PMM robusto (kernel/mm/pmm.c + pmm.h):**
Modifica firma `pmm_init` → `pmm_init(memmap, kernel_phys_end)`.
`bitmap_min = max(PMM_RESERVED_BELOW, kernel_phys_end)` garantisce che il bitmap venga sempre posizionato DOPO il kernel, indipendentemente dalla dimensione del BSS o dalla RAM del sistema.

**Fix 2 — entry.c kernel_main:**
`ke_phys` calcolato PRIMA di chiamare `pmm_init` e passato come argomento. I `pmm_mark_used` espliciti rimangono come difesa ulteriore.

**Fix 3 — Riduzione costanti cmd_tree (entry.c):**
- `TREE_MAX_DEPTH`: 16 → 8
- `TREE_MAX_ITEMS`: 256 → 32
- `e_name[][]`: variabile locale → `static` (evita 2KB sullo stack kernel)
- BSS totale scende da 2.2MB a 1.2MB; kernel_phys_end ≈ 0x355000 < PMM_RESERVED_BELOW ✅

### Verifica build v5.7

| Metrica | Valore |
|---|---|
| kernel.elf | ~195 KB |
| Entry point | 0xffffffff80014b8d |
| .limine_requests paddr | 0x366000 |
| HHDM response* | section+0x128 (abs 0x366128) |
| MEMMAP response* | section+0x0A8 (abs 0x3660A8) |
| KADDR response* | section+0x0E8 (abs 0x3660E8) |
| kernel_phys_end | ~0x355000 < 0x400000 ✅ |
| Stage2 0x366000 | ✅ presente a offset 0x680 |
| Errori compilazione | 0 errori, 0 warning |

### File modificati in v5.7

| File | Modifica |
|---|---|
| `kernel/mm/pmm.c` | `pmm_init(memmap, kernel_phys_end)` — bitmap posizionato DOPO kernel |
| `kernel/mm/pmm.h` | Firma `pmm_init` aggiornata |
| `kernel/arch/x86_64/entry.c` | Versione v5.7; calcola `ke_phys` prima di `pmm_init`; TREE_MAX ridotti; `e_name` static |
| `boot/stage2.asm` | paddr `.limine_requests` → 0x366000 |

*MattiaOS Blueprint v5.7 — In caso di contraddizione tra questo file e qualsiasi altra cosa, questo file ha la precedenza.*

---

## Sessione v5.7 — Ctrl+C funzionante, comando `open`, /home/ciao.txt

### Modifiche

**1. Ctrl+C — Fix definitivo**

Root cause v4.13: `con_handle_key()` settava `g_ctrlc=1` solo quando il loop
di `kernel_console` girava. Ma durante un comando (es. `tree`), l'esecuzione
era bloccata dentro `con_exec()` → il loop `for(;;)` in `kernel_console` non
girava → `keyboard_process()` non veniva chiamato → la porta PS/2 non veniva
mai letta → Ctrl+C non veniva visto.

Fix: funzione `con_check_ctrlc()` che chiama esplicitamente
`keyboard_process()` + `keyboard_poll_event()` cercando `ascii==3` (ETX).
Va inserita come condizione nei loop lunghi. Sostituisce i passivi `!g_ctrlc`
in `cmd_tree` (2 for + 1 while) e `cmd_ls` (1 if).

```c
static bool con_check_ctrlc(void) {
    keyboard_process();          // drena porta PS/2 → ring buffer
    key_event_t ev;
    while (keyboard_poll_event(&ev)) {
        if (ev.pressed && ev.ascii == 3) {
            g_ctrlc = 1;
            vga_puts_attr("^C\n", 0x0C00);
        }
    }
    return g_ctrlc != 0;
}
```

**2. Comando `open` — visualizzatore file full-screen**

Sostituisce `cat`. Entra in modalità schermo intero (salva VGA buffer 80×25
in `s_ol_vga[]`), ripristina allo scorrimento con q/ESC/Ctrl+C.

Caratteristiche:
- Header blu (riga 0): percorso, tipo, posizione, hint tasti
- Contenuto (righe 1–23): righe numerate a sinistra (5 cifre + ":")
- Footer grigio (riga 24): range righe + percentuale
- Scorrimento: ↑↓ per riga, PgUp/PgDn per pagina, Home/End
- Tipi: TESTO (righe numerate) | BINARIO (hex dump) | ELF64 (hex dump ciano)
- Lazy loading testo: `s_ol_off[OPEN_MAX_LINES=2000]` indicizza offset inizio
  di ogni riga on-demand. Mai più di OPEN_ROWS+2 righe indicizzate per schermata.
- Budget BSS: 80×25×2=4KB (VGA save) + 2000×8=16KB (index) + 4KB (read buf) = ~24KB

**3. /home/ciao.txt**

File creato in `kernel_main` con contenuto `"ciao\n"`. La directory `/home`
preesisteva già (creata da v4.10).

### Parametri ELF v5.7

| Campo | Valore |
|---|---|
| Entry point | `0xffffffff8001bc7c` |
| .limine_requests paddr | `0x366000` |
| HHDM response* | `section+0x128` → `0x366128` |
| MEMMAP response* | `section+0x0A8` → `0x3660A8` |
| KADDR response* | `section+0x0E8` → `0x3660E8` |
| kernel_phys_end | ~`0x359000` < `0x400000` ✅ |
| BSS | ~1227 KB |

### File modificati

| File | Modifica |
|---|---|
| `kernel/arch/x86_64/entry.c` | v5.7; `con_check_ctrlc()`; `cmd_open()`; `/home/ciao.txt`; dispatch cat→open |
| `boot/stage2.asm` | paddr `.limine_requests` → `0x366000` |

---

## Sessione v5.7 — 9 bug fix + /sys/PATH + /Binari_Eseguibili stubs

### Priorità e interventi

#### CRITICO 1: Ctrl+C (keyboard.c)
**Root cause:** In `ascii_from_vk()`, il check `if (vk >= 'a' && 'z')` veniva PRIMA del check Ctrl.
Quando Ctrl+C premuto: vk=VK_C='c', mods=MOD_CTRL → colpiva il ramo lettera → restituiva 'c' non 3.
**Fix:** Check `if (mods & MOD_CTRL) && vk in [a..z]` spostato IN CIMA, prima del check lettera.

#### CRITICO 2: Enter spurio dopo comandi (entry.c)
**Root cause A (loop principale):** L'AR veniva armato con `s_ar_key=VK_ENTER, s_ar_ms=ora` PRIMA
di chiamare `con_handle_key`. Il comando (es. tree) durava N secondi. Al ritorno, `elapsed >> AR_DELAY_MS`
(250ms) → la macchina AR sparava subito Enter di nuovo → loop infinito di enter vuoti.
**Fix A:** All'inizio del ramo Enter in `con_handle_key`, reset immediato: `s_ar_state=AR_IDLE`.

**Root cause B (cmd_open):** `open_wait_key()` consumava tasti con `keyboard_poll_event()` direttamente,
lasciando eventi residui nel ring (es. 'q' → poteva diventare un Enter spieghiamolo meglio: il
problema era che s_ar_state non veniva resettato dopo l'uscita da open).
**Fix B:** Dopo il loop in `cmd_open`, flush completo: `g_kbd_events.head=tail=0; s_ar_state=AR_IDLE`.

#### CRITICO 3: vfs_is_dir ritornava true per tutti i file (vfs.c)
**Root cause:** Fallback `ops->readdir != NULL` → in tmpfs tutti i nodi (file E dir) condividono
lo stesso ops table → `readdir` sempre non-NULL → ogni file risultava "directory" → `ciao.txt/`.
**Fix:** Rimosso fallback. `vfs_is_dir` usa SOLO `node->mode & 0x4000` (S_IFDIR bit).

#### BUG 4: Caratteri UTF-8 mostrati come garbage in VGA CP437 (entry.c)
**Root cause:** VGA text mode usa codepage CP437. Le sequenze UTF-8 multi-byte (├ = E2 94 9C,
└ = E2 94 94, │ = E2 94 82, ─ = E2 94 80) vengono output come 3 byte separati → garbage.
**Fix:** Sostituiti con CP437: `\xC3\xC4\xC4`=├──, `\xC0\xC4\xC4`=└──, `\xB3`=│, `\xC4`=─.
Banner lines: `\xe2\x94\x80` × 36 → `\xC4` × 36.

#### BUG 5: `tree` sempre da "/" invece che da cwd (entry.c)
**Fix:** `con_build_path((arg&&*arg)?arg:NULL, ...)` — NULL → usa s_cwd.

#### FEATURE 6-8: Infrastruttura /sys/PATH + /Binari_Eseguibili + dipendenze.cfg
- `/Binari_Eseguibili/`: 12 stub file (uno per comando built-in), contenuto testo con USAGE
- `/sys/PATH`: file testo, formato `nome=/Binari_Eseguibili/nome`, 12 voci
- `/Dipendenze/dipendenze.cfg`: formato corretto `nome_comando: `, deps vuote per built-in
- `con_exec()`: per comandi sconosciuti, cerca in /sys/PATH e mostra percorso + nota Phase 13

### Parametri ELF v5.7
| Campo | Valore |
|---|---|
| Entry point | `0xffffffff80010fbf` |
| .limine_requests paddr | `0x366000` |
| HHDM response* | `section+0x128` → `0x366128` |
| MEMMAP response* | `section+0x0A8` → `0x3660A8` |
| KADDR response* | `section+0x0E8` → `0x3660E8` |
| kernel_phys_end | ~`0x35b000` < `0x400000` ✅ |

### File modificati
| File | Modifica |
|---|---|
| `kernel/drivers/input/keyboard.c` | Fix Ctrl+lettera check ordering |
| `kernel/fs/vfs.c` | Fix vfs_is_dir: mode-only, no ops fallback |
| `kernel/arch/x86_64/entry.c` | v5.7; AR flush su Enter e post-open; CP437; tree cwd; /sys/PATH; stubs |
| `boot/stage2.asm` | paddr `.limine_requests` → `0x366000` |

---

## Sessione v5.7 — diagnosi ls vuoto

### Problema
`ls /` mostrava "(directory vuota)" anche con directory popolate.

### Causa sospetta (da confermare con diag)
In v4.14, `con_check_ctrlc()` veniva chiamato per primo nel loop di `cmd_ls`.
Il fix Ctrl+C (spostare MOD_CTRL prima del check lettera) in v4.15 ha già risolto
il caso in cui byte PS/2 residui venivano interpretati come ETX, settando `g_ctrlc=1`
prima ancora che `vfs_readdir_entry` potesse restituire la prima entry.

### Fix aggiunto in v5.7
- `cmd_ls`: output diagnostico su seriale quando `vfs_readdir_entry` ritorna <0 a idx=0
- nuovo comando `diag`: chiama `vfs_debug_dump()` che stampa su VGA+seriale:
  - mount table completa (mountpoint, puntatore root, fs_data)
  - loop `tmpfs_readdir` diretto su root[0..7]
  - loop `vfs_readdir_entry("/", 0..7)`
- helper `int_to_dec()` per stampare codici errno negativi
- `vfs_debug_dump()` aggiunta a vfs.c

### Parametri ELF v5.7 (invariati da v4.15)
| Campo | Valore |
|---|---|
| .limine_requests paddr | `0x366000` |
| HHDM response* | `0x366128` |
| MEMMAP response* | `0x3660A8` |
| KADDR response* | `0x3660E8` |

### File modificati
| File | Modifica |
|---|---|
| `kernel/arch/x86_64/entry.c` | v5.7; diag cmd; ls serial diag; int_to_dec |
| `kernel/fs/vfs.c` | vfs_debug_dump() |
| `kernel/fs/vfs.h` | dichiarazione vfs_debug_dump() |

---

## Sessione v5.7 — 5 nuove feature

### 1. KP_SLASH fix (`keyboard.c`)
Operatori tastierino (+,-,*,/) e KP_ENTER spostati fuori da `if(s_numlock)` → sempre attivi.

### 2. Scrollback terminale (`cpu.c` + `entry.c`)
- Ring buffer `s_sb_buf[128][80]` in BSS (16KB). Hook in `vga_scroll()` salva la riga che scivola via.
- API pubblica: `vga_sb_lines()`, `vga_scrollback_render(offset)`.
- Attivazione: **Shift+UP** entra in scrollback; Shift+UP/DOWN naviga; qualsiasi altro tasto esce.

### 3. History comandi (`entry.c`)
- Ring buffer `s_hist[32][256]`. `hist_push()` aggiunge a ogni Enter (salta duplicati).
- **UP** = comando precedente, **DOWN** = successivo, torna alla riga salvata.
- `s_hist_idx = -1` resettato a ogni Enter/Ctrl+C.

### 4. Editor testo `edit` (`entry.c`)
- Buffer BSS `s_ed_buf[8192]`. Carica file in RAM, editing full-screen.
- Header riga 0 (blu): path + stato. Footer riga 24: r:c + salvato/modificato*.
- Frecce/PgUp/PgDn/Home/End navigazione. Backspace/Delete eliminazione. Invio=newline.
- **Ctrl+S** = salva (unlink+create+write). **ESC/Ctrl+C** = esci senza salvare.
- Solo file testo ≤8KB; file binari rifiutati.

### 5. PATH v5.7 + `/home/mattia_hello` + `/Dipendenze/libmattiac.so`
- Formato: `nome=percorso_exe:dep1:dep2:...`
- `con_exec` mostra eseguibile + lista dipendenze per comandi non built-in.
- `/home/mattia_hello` = primo "programma" demo (testo, Phase 13 lo eseguirà).
- `/Dipendenze/libmattiac.so` = stub libreria standard.
- 14 voci nel PATH (13 built-in + mattia_hello).

### Parametri ELF v5.7
| Campo | Valore |
|---|---|
| .limine_requests paddr | `0x366000` |
| HHDM response* | `0x366128` |
| MEMMAP response* | `0x3660A8` |
| KADDR response* | `0x3660E8` |

### File modificati
| File | Modifica |
|---|---|
| `kernel/drivers/input/keyboard.c` | KP_SLASH/operatori fuori da NumLock guard |
| `kernel/arch/x86_64/cpu.c` | scrollback buffer + vga_scroll hook + API |
| `kernel/arch/x86_64/cpu.h` | vga_sb_lines(), vga_scrollback_render() |
| `kernel/arch/x86_64/entry.c` | v5.7; history; scrollback; cmd_edit; PATH v5.7 |
| `boot/stage2.asm` | paddr → `0x366000` |

---

## Sessione v5.7 patch — BUG CRITICO tmpfs: write non persisteva tra open/close

### Root cause (architetturale)

`vfs_lookup` ritorna sempre una **copia heap-allocata** del vnode (per evitare
che kfree() dei chiamanti distrugga la root del mount — fix introdotto in v4.10).

Il problema: la copia contiene `size=0` copiato da `child->vnode.size` al momento
del lookup. `tmpfs_write` aggiornava solo `node->size` (la copia), NON
`n->vnode.size` (il campo canonico dentro `tmpfs_node_t`).

Alla `vfs_close`, la copia viene `kfree()`-ata. `child->vnode.size` resta 0.
Alla prossima `vfs_open`, `tmpfs_readdir` copia di nuovo `child->vnode` con
`size=0`. `tmpfs_read` ritorna 0 (`offset >= size`). File apparentemente vuoto.

### Tre fix applicati in `tmpfs.c`

1. **`tmpfs_write`**: ora aggiorna sia `n->vnode.size` (canonico, persiste) sia
   `node->size` (copia corrente, coerenza di sessione).

2. **`tmpfs_read`**: usa `n->vnode.size` come sorgente autorevole, non `node->size`.

3. **`tmpfs_stat_op`**: usa `n->vnode.size` come sorgente autorevole.

### Effetti collaterali risolti

- `open <file>` mostrava "file vuoto" per qualsiasi file scritto a runtime
  perché `vfs_read` ritornava 0 → `probe <= 0` → early return.
- `edit <file>` + Ctrl+S sembrava salvare ma alla prossima apertura il file
  era vuoto per lo stesso motivo.
- `ls` e `tree` mostravano i file ma `open` non li leggeva.

### File modificati
| File | Modifica |
|---|---|
| `kernel/fs/tmpfs.c` | tmpfs_write/read/stat usano n->vnode.size canonico |

---

## Sessione v5.7 — Fix scrollback e history

### Bug scrollback
`vga_scrollback_render` sovrascriveva il framebuffer reale senza salvarlo.
`sb_exit` non ripristinava nulla → schermo corrotto in modo permanente.
**Fix**: aggiunto buffer BSS `s_sb_live[80*25]`. All'ingresso in scrollback
lo schermo viene salvato qui; `sb_exit` lo ripristina prima di rimettere
il cursore hardware.

### Bug history (visivo)
`con_redraw_line` puliva solo 4 caratteri dopo la riga corrente.
Caricando una voce history più corta della precedente, i caratteri extra
restavano visibili — sembrava non funzionare mentre funzionava.
**Fix**: `con_redraw_line` ora pulisce fino a col=79 sulla riga corrente.

### Parametri ELF v5.7 (aggiornati)
.limine_requests paddr = 0x366000 | HHDM=0x366128 | MEMMAP=0x3660A8 | KADDR=0x3660E8

### File modificati
| File | Modifica |
|---|---|
| `kernel/arch/x86_64/entry.c` | sb_exit ripristina schermo; s_sb_live buffer; con_redraw_line pulisce riga intera |
| `boot/stage2.asm` | paddr → 0x366000 |

---

## Sessione v5.7 — Diagnostica ls + analisi bug directory vuota

### Problema
`ls /` continuava a mostrare "(directory vuota)" nonostante la root tmpfs
contenesse directory create da `kernel_main`. Bug mai risolto per analisi statica.

### Approccio diagnostico
Impossibile trovare la causa per sola analisi del codice: la logica di
`vfs_readdir_entry` (Phase 1 + Phase 2 sintetica) sembra corretta su carta.

### Soluzione adottata
Aggiunta diagnostica VGA diretta in `cmd_ls`: quando count==0 e la directory
esiste, stampa su schermo `mounts=X root_children=Y synth=Z` usando tre
funzioni di ispezione interna aggiunte a `vfs.c`:
- `vfs_diag_mount_count()` — quanti mount sono registrati
- `vfs_diag_root_children()` — quanti figli ha la root tmpfs
- `vfs_diag_synth_count(path)` — quante entry sintetiche produce enumerate_child_mount

Queste funzioni rimangono nel codice — sono utili per debug futuro.

### File modificati
| File | Modifica |
|---|---|
| `kernel/fs/vfs.c` | vfs_diag_mount_count/root_children/synth_count |
| `kernel/fs/vfs.h` | dichiarazioni diagnostica |
| `kernel/arch/x86_64/entry.c` | cmd_ls con output diagnostico VGA |

### Parametri ELF (invariati da fix precedente)
.limine_requests paddr = 0x366000

---

## README GitHub — Sessione finale

### Analisi repo GitHub più seguiti
Descrizioni più efficaci sono quelle che:
1. Colpiscono su un fatto specifico e verificabile, non aggettivi generici
2. Rispondono allo scetticismo immediato ("funziona davvero?")
3. Comunicano la profondità tecnica senza elenchi

### Descrizione repository (campo About su GitHub)
```
A completely working OS - from bootloader to shell - written entirely by AI. Zero human code. Author is 14 years old.
```

### README.md aggiornato (v finale)
Il README include:
- Architettura tecnica completa (PMM, VMM, slab, APIC, driver, rete)
- Layout filesystem con albero visivo
- Tabella comandi aggiornata (14 comandi inclusi edit, reboot, easteregg)
- Istruzioni build
- Tabella impostazioni VirtualBox
- 4 bug critici risolti con spiegazione tecnica
- Roadmap Phase 13
- Correzione "Gemini 3.2" → "Claude Sonnet 4.6 Extended"
- Versione bilingue IT + EN sincronizzate

---

## Stato corrente del progetto — v5.7 (ultimo aggiornamento)

### Versione: v5.7
### Build: kernel compilato, ISO verificata, stage2 paddr = 0x366000

### Comandi kernel console funzionanti
| Comando | Stato |
|---|---|
| help | OK |
| ver | OK |
| mem | OK |
| pci | OK |
| ls | OK (con diagnostica inline) |
| cd | OK |
| open | OK (pager full-screen, testo/bin/ELF) |
| edit | OK (editor testo, Ctrl+S salva, ESC esce) |
| tree | OK (parte da cwd) |
| clear | OK |
| halt | OK (ACPI S5) |
| reboot | OK |
| easteregg | OK |
| diag | OK (dump VFS su VGA + seriale) |
| mattia_hello | In PATH, non eseguibile (Phase 13) |

### Feature console funzionanti
- History comandi (Su/Giu, ring buffer 32 voci)
- Scrollback terminale (Shift+Su/Giu, 128 righe, salva/ripristina schermo)
- Ctrl+C funzionante (ETX, interrompe loop lunghi)
- KP_SLASH sempre '/' indipendente da NumLock
- CP437 corretto (niente UTF-8 multi-byte)
- AR reset su Enter (niente Enter spurio)

### Bug ancora aperti
- `ls /` può mostrare directory come vuota (indagine in corso, diag integrata)
- ELF loader non implementato → nessun programma userspace eseguibile

### File sorgenti modificati rispetto a v4.14 (baseline)
| File | Modifiche chiave |
|---|---|
| `kernel/arch/x86_64/entry.c` | Ctrl+C fix, AR fix, CP437, edit, scrollback, history, PATH v5.7, diag |
| `kernel/arch/x86_64/cpu.c` | scrollback ring buffer, vga_scroll hook, vga_scrollback_render |
| `kernel/arch/x86_64/cpu.h` | API scrollback |
| `kernel/drivers/input/keyboard.c` | Ctrl+C ordering fix, KP_SLASH fix |
| `kernel/fs/vfs.c` | vfs_is_dir fix, vfs_debug_dump, vfs_diag_* |
| `kernel/fs/vfs.h` | dichiarazioni diag |
| `kernel/fs/tmpfs.c` | tmpfs_write/read/stat: n->vnode.size canonico |
| `boot/stage2.asm` | paddr aggiornato a ogni recompile |
| `docs/OS_PROJECT_BLUEPRINT.md` | questo file |

### Toolchain (invariata)
- NASM 3.01
- x86_64-elf-gcc 13.3
- GNU Binutils 2.42
- xorriso 1.5.6
- Host: Ubuntu 24.04

### VirtualBox settings (invariate)
- Type: Other/Other 64-bit, PIIX3
- I/O APIC: ON, EFI: OFF, IDE controller
- VBoxVGA 16MB, no HPET
