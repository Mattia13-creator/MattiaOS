# MattiaOS: An AI-Generated Operating System

This project is a fully functional operating system whose architecture and codebase were generated entirely by **Artificial Intelligence**. Developed in Italy as a proof-of-concept, it demonstrates the extraordinary programming capabilities of modern Large Language Models, in this case Claude Sonnet 4.6.

The result is an operating system created by a 14-year-old and an AI, without a single line of code written manually by a human author.

---

## Development Methodology

The entire development process — from kernel design to the generation of the bootable ISO image — was managed by delegating tasks to the AI.

- **In-Chat Compilation:** The necessary compilers were provided to the AI directly through the chat interface, allowing it to compile source code into binaries and assemble the ISO image autonomously.
- **Toolchain:** The system was compiled using **NASM 3.01** for Assembly components and **GCC 13.3 Cross-Compiler** (`x86_64-elf-gcc`) for C code, ensuring a total absence of external system library dependencies.

## Technical Architecture

The boot process follows a custom two-stage chain:

```
BIOS -> stage1.asm (El Torito, 512B) -> stage2.asm (custom loader)
     -> patches Limine protocol responses in memory
     -> kernel.elf (higher-half, 0xFFFFFFFF80000000)
```

The kernel runs in Long Mode (64-bit) in the upper half of the address space. Physical memory starts at 0x200000. The HHDM offset is 0xFFFF800000000000.

**Memory Management**
- PMM: bitmap allocator, placed at `max(0x400000, kernel_phys_end)` to avoid overwriting the kernel BSS.
- VMM: 4-level page table management.
- Slab allocator: 9 fixed-size caches (16–4096 bytes).

**Interrupts and CPU**
- GDT, IDT, exception handlers.
- IRQ remapping via 8259 PIC and I/O APIC.
- LAPIC timer calibrated against PIT channel 2 (1 ms tick).

**Drivers**
- PS/2 keyboard: scan code set 2, Ctrl+C produces ETX.
- VGA text mode: 80×25, CP437 codepage, hardware cursor, 128-line scrollback ring buffer.
- PCI: bus and device enumeration.
- AHCI (SATA), NVMe.
- VirtIO-Net and e1000 (network cards).
- GOP framebuffer.

**Filesystem**
- VFS: mount table, path resolution, `open/close/read/write`, two-phase directory enumeration (real entries + synthetic mount-point entries).
- tmpfs: RAM filesystem. Critical fix applied: data written to files persists correctly across `open/close` cycles.
- devfs: mounted at `/dev`, exposes `null` and `zero`.
- FAT32 and MattiaFS: additional filesystem drivers.

**Networking**
- Full stack: Ethernet, ARP, IPv4, ICMP, TCP, UDP, socket layer.

**Custom Kernel and Syscalls:** While the filesystem design takes inspiration from Linux, the kernel and system calls (syscalls) were written from scratch and are entirely proprietary. Because of this custom architecture, the AI developed a set of built-in commands for direct interaction with the system before the ELF loader (Phase 13) is implemented.

## Available Commands

The system shell currently supports the following native commands:

| Command | Description |
| :--- | :--- |
| `help` | Lists all available commands |
| `ver` | Displays the current OS version |
| `mem` | Shows RAM statistics and active processes |
| `pci` | Lists connected PCI devices and peripherals |
| `ls [path]` | Lists files and directories |
| `cd [path]` | Changes the current working directory |
| `open [path]` | Full-screen pager for text, binary, and ELF files |
| `edit [path]` | Integrated text editor (Ctrl+S to save, ESC to exit) |
| `tree [path]` | Prints the complete filesystem tree |
| `clear` | Clears the terminal screen |
| `halt` | Safe ACPI system shutdown |
| `reboot` | Reboots the system |
| `easteregg` | Surprise |
| `diag` | Runs internal VFS diagnostics |

Console features:
- Up/Down arrows: navigate the last 32 commands in history.
- Shift+Up: enter scrollback mode (128 lines); Shift+Down to exit.
- Ctrl+C: interrupts running commands (including `tree` and `ls`).

## Filesystem Layout

```
/
├── dev/                  (devfs)
│   ├── null
│   └── zero
├── etc/
├── home/
│   ├── hello.txt
│   └── mattia_hello      (demo program, executable in Phase 13)
├── tmp/
├── var/
├── sys/
│   └── PATH              (command registry: name=exe:dep1:dep2)
├── Executables/          (built-in command stubs, pending Phase 13)
└── Dependencies/
    └── libmattiac.so     (standard library stub)
```

## Build

**Requirements**
- `x86_64-elf-gcc` 13.3 (cross-compiler)
- NASM 3.01
- GNU Binutils 2.42
- xorriso 1.5.6
- Linux host (Ubuntu 24.04 tested)

```bash
make kernel   # compile kernel only
make iso      # full build: kernel + bootloader + ISO image
```

Output: `mattiaos.iso` — bootable El Torito ISO image.

## Testing on VirtualBox

Tested with the following settings:

| Setting | Value |
| :--- | :--- |
| Type | Other / Other (64-bit) |
| Chipset | PIIX3 |
| Memory | 256 MB minimum |
| Boot order | Optical only |
| I/O APIC | Enabled (required) |
| EFI | Disabled (required — BIOS legacy boot only) |
| Storage controller | IDE (not SATA) |
| Video | VBoxVGA, 16 MB |
| HPET | Disabled |

## Key Bugs Fixed During Development

- **tmpfs write/read:** `tmpfs_write` was updating only the local vnode copy (`node->size`), not the canonical field inside `tmpfs_node_t` (`n->vnode.size`). Every `vfs_open` produces a shallow copy of the vnode via `readdir`; the copy's size was always 0, making all runtime-written files appear empty on re-open.
- **Ctrl+C:** `ascii_from_vk` checked Ctrl+letter after the letter check, so Ctrl+C produced `'c'` instead of ETX (3). Fixed by moving the Ctrl check first.
- **vfs_is_dir:** Used `ops->readdir != NULL` as a fallback for directory detection. All tmpfs nodes share the same ops table, so every file was reported as a directory.
- **Autorepeat spurious Enter:** AR state was not reset on Enter, causing repeated Enter keypresses after any command that took longer than 250 ms.

## Roadmap (Phase 13+)

- ELF loader: `process_execve()`, `load_elf()`, initial stack with `argc/argv/envp/auxv`
- Syscall dispatcher: MSR_LSTAR + assembly handler + dispatch table
- Priority syscalls: `execve`, `rt_sigaction`, `setsid`, `getdents64`, `nanosleep`
- COW page fault handler
- libc completion
- Userspace: init, shell, coreutils (sources already present, awaiting ELF loader)

---

> **Note**: This text was written by Claude (Anthropic).

> **Project version**: v5.9. Full development history documented in `OS_PROJECT_BLUEPRINT.md`.
