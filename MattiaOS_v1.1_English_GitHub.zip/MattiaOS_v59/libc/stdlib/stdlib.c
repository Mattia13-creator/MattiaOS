#include "../include/stdlib.h"
#include "../include/string.h"
#include "../include/unistd.h"
#include "../include/errno.h"
#include "../include/stdint.h"

/* =========================================================================
 * errno global (single-thread for ora)
 * ========================================================================= */
int errno = 0;

/* =========================================================================
 * HEAP ALLOCATOR — first-fit with boundary tags
 *
 * Layout of every block in memory:
 *
 *   [ block_hdr_t (16 byte) | data utente (size byte) | uint64_t footer ]
 *
 * footer = stesso value of block_hdr_t.size|free for rilevare corruzioni
 * AND for coalescenza verso left (optional — implementata in free).
 *
 * Il block "free" in testa è the sentinel: size=0, free=0.
 * La heap cresce via sbrk(SYS_BRK).
 * ========================================================================= */

#define HEAP_ALIGN        16u
#define HEAP_MIN_EXPAND   (64u * 1024u)   /* Espansione minima: 64 KB */
#define BLOCK_MAGIC       0xBEEFDEADu

typedef struct block_hdr {
    uint64_t         size;       /* Size of the data utente (allineata) */
    uint32_t         free;       /* 1 = free, 0 = occupato */
    uint32_t         magic;      /* BLOCK_MAGIC — sanity check */
    struct block_hdr *prev;      /* Block previous (lista lineare) */
    struct block_hdr *next;      /* Block next */
} block_hdr_t;

#define HDR_SIZE sizeof(block_hdr_t)

static block_hdr_t *s_heap_head = (block_hdr_t *)0;
static block_hdr_t *s_heap_tail = (block_hdr_t *)0;
static char         s_heap_initialized = 0;

static inline uint64_t align_up(uint64_t v, uint64_t a) {
    return (v + a - 1) & ~(a - 1);
}

static block_hdr_t *expand_heap(uint64_t min_size) {
    uint64_t expand = align_up(min_size + HDR_SIZE, HEAP_MIN_EXPAND);
    void *base = sbrk((long)expand);
    if (!base || base == (void *)-1) return (block_hdr_t *)0;

    block_hdr_t *new_block = (block_hdr_t *)base;
    new_block->size  = expand - HDR_SIZE;
    new_block->free  = 1;
    new_block->magic = BLOCK_MAGIC;
    new_block->prev  = s_heap_tail;
    new_block->next  = (block_hdr_t *)0;

    if (s_heap_tail) {
        /* Tenta coalescenza with l'last block if è free */
        if (s_heap_tail->free) {
            s_heap_tail->size += HDR_SIZE + new_block->size;
            return s_heap_tail;
        }
        s_heap_tail->next = new_block;
    } else {
        s_heap_head = new_block;
    }
    s_heap_tail = new_block;
    return new_block;
}

static void heap_init(void) {
    s_heap_initialized = 1;
    /* Prima espansione of the heap */
    expand_heap(0);
}

void *malloc(size_t size) {
    if (!size) return (void *)0;

    if (!s_heap_initialized) heap_init();

    uint64_t asize = align_up((uint64_t)size, HEAP_ALIGN);
    if (asize < size) { errno = ENOMEM; return (void *)0; }  /* overflow */

    /* Risearch first-fit */
    block_hdr_t *b = s_heap_head;
    while (b) {
        if (b->magic != BLOCK_MAGIC) break;  /* Heap corrotta */
        if (b->free && b->size >= asize) {
            /* Splitti if the block è molto più grande */
            if (b->size >= asize + HDR_SIZE + HEAP_ALIGN) {
                block_hdr_t *split = (block_hdr_t *)((uint8_t *)b + HDR_SIZE + asize);
                split->size  = b->size - asize - HDR_SIZE;
                split->free  = 1;
                split->magic = BLOCK_MAGIC;
                split->prev  = b;
                split->next  = b->next;
                if (b->next) b->next->prev = split;
                else         s_heap_tail   = split;
                b->next = split;
                b->size = asize;
            }
            b->free = 0;
            return (void *)((uint8_t *)b + HDR_SIZE);
        }
        b = b->next;
    }

    /* No block free abbastanza: espandi the heap */
    block_hdr_t *new_b = expand_heap(asize);
    if (!new_b) { errno = ENOMEM; return (void *)0; }

    return malloc(size);   /* Riprova with the nuovo block */
}

void free(void *ptr) {
    if (!ptr) return;
    block_hdr_t *b = (block_hdr_t *)((uint8_t *)ptr - HDR_SIZE);
    if (b->magic != BLOCK_MAGIC || b->free) return;  /* Double-free / corruzione */

    b->free = 1;

    /* Coalescenza with the next */
    if (b->next && b->next->free && b->next->magic == BLOCK_MAGIC) {
        block_hdr_t *nx = b->next;
        b->size += HDR_SIZE + nx->size;
        b->next  = nx->next;
        if (nx->next) nx->next->prev = b;
        else          s_heap_tail    = b;
        nx->magic = 0;  /* Invalid the vecchio header */
    }

    /* Coalescenza with the previous */
    if (b->prev && b->prev->free && b->prev->magic == BLOCK_MAGIC) {
        block_hdr_t *pv = b->prev;
        pv->size += HDR_SIZE + b->size;
        pv->next  = b->next;
        if (b->next) b->next->prev = pv;
        else         s_heap_tail   = pv;
        b->magic = 0;
    }
}

void *calloc(size_t nmemb, size_t size) {
    uint64_t total = (uint64_t)nmemb * size;
    if (nmemb && total / nmemb != size) { errno = ENOMEM; return (void *)0; }
    void *p = malloc((size_t)total);
    if (p) memset(p, 0, (size_t)total);
    return p;
}

void *realloc(void *ptr, size_t size) {
    if (!ptr) return malloc(size);
    if (!size) { free(ptr); return (void *)0; }

    block_hdr_t *b = (block_hdr_t *)((uint8_t *)ptr - HDR_SIZE);
    if (b->magic != BLOCK_MAGIC) return (void *)0;

    uint64_t old_size = b->size;
    uint64_t new_size = align_up((uint64_t)size, HEAP_ALIGN);

    if (old_size >= new_size) return ptr;  /* Abbastanza spazio */

    /* Tenta of espandere assorbendo the next if free */
    if (b->next && b->next->free &&
        b->next->magic == BLOCK_MAGIC &&
        old_size + HDR_SIZE + b->next->size >= new_size) {
        b->size += HDR_SIZE + b->next->size;
        block_hdr_t *nx = b->next;
        b->next = nx->next;
        if (nx->next) nx->next->prev = b;
        else          s_heap_tail    = b;
        nx->magic = 0;
        return ptr;
    }

    void *new_ptr = malloc(size);
    if (!new_ptr) return (void *)0;
    memcpy(new_ptr, ptr, (size_t)old_size);
    free(ptr);
    return new_ptr;
}

/* =========================================================================
 * sbrk — invoca SYS_BRK for espandere the heap
 * ========================================================================= */
#include "../include/syscall.h"
#define SYS_BRK 12

void *sbrk(long increment) {
    static unsigned long s_brk = 0;
    if (!s_brk) {
        s_brk = (unsigned long)__syscall1(SYS_BRK, 0);
    }
    if (increment == 0) return (void *)s_brk;
    unsigned long new_brk = s_brk + (unsigned long)increment;
    unsigned long ret = (unsigned long)__syscall1(SYS_BRK, (long)new_brk);
    if (ret < new_brk) { errno = ENOMEM; return (void *)-1; }
    void *old = (void *)s_brk;
    s_brk = ret;
    return old;
}

/* =========================================================================
 * Conversions stringa ↔ number
 * ========================================================================= */

static inline int isspace_c(int c) {
    return c == ' ' || c == '\t' || c == '\n' || c == '\r' || c == '\f' || c == '\v';
}
static inline int isdigit_c(int c) { return c >= '0' && c <= '9'; }
static inline int isalpha_c(int c) {
    return (c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z');
}
static inline int digitval(int c, int base) {
    if (c >= '0' && c <= '9') { int v = c - '0'; return v < base ? v : -1; }
    if (c >= 'a' && c <= 'z') { int v = c - 'a' + 10; return v < base ? v : -1; }
    if (c >= 'A' && c <= 'Z') { int v = c - 'A' + 10; return v < base ? v : -1; }
    return -1;
}

long strtol(const char *s, char **endptr, int base) {
    while (isspace_c(*s)) s++;
    int neg = 0;
    if (*s == '-') { neg = 1; s++; }
    else if (*s == '+') s++;

    if (base == 0) {
        if (*s == '0' && (s[1] == 'x' || s[1] == 'X')) { base = 16; s += 2; }
        else if (*s == '0') { base = 8; s++; }
        else base = 10;
    } else if (base == 16 && *s == '0' && (s[1] == 'x' || s[1] == 'X')) {
        s += 2;
    }

    long val = 0;
    const char *start = s;
    int d;
    while ((d = digitval(*s, base)) >= 0) {
        val = val * base + d;
        s++;
    }
    if (s == start) { if (endptr) *endptr = (char *)s; return 0; }
    if (endptr) *endptr = (char *)s;
    return neg ? -val : val;
}

unsigned long strtoul(const char *s, char **endptr, int base) {
    while (isspace_c(*s)) s++;
    if (*s == '+') s++;
    if (base == 0) {
        if (*s == '0' && (s[1] == 'x' || s[1] == 'X')) { base = 16; s += 2; }
        else if (*s == '0') { base = 8; s++; }
        else base = 10;
    } else if (base == 16 && *s == '0' && (s[1] == 'x' || s[1] == 'X')) {
        s += 2;
    }
    unsigned long val = 0;
    int d;
    while ((d = digitval(*s, base)) >= 0) { val = val * base + d; s++; }
    if (endptr) *endptr = (char *)s;
    return val;
}

long long strtoll(const char *s, char **endptr, int base) {
    return (long long)strtol(s, endptr, base);
}
unsigned long long strtoull(const char *s, char **endptr, int base) {
    return (unsigned long long)strtoul(s, endptr, base);
}

int    atoi (const char *s) { return (int) strtol(s, (char **)0, 10); }
long   atol (const char *s) { return strtol(s, (char **)0, 10); }
long long atoll(const char *s) { return strtoll(s, (char **)0, 10); }

double strtod(const char *s, char **endptr) {
    while (isspace_c(*s)) s++;
    int neg = 0;
    if (*s == '-') { neg = 1; s++; }
    else if (*s == '+') s++;

    double val = 0.0;
    while (isdigit_c(*s)) { val = val * 10.0 + (*s++ - '0'); }
    if (*s == '.') {
        s++;
        double frac = 0.1;
        while (isdigit_c(*s)) { val += (*s++ - '0') * frac; frac *= 0.1; }
    }
    if (*s == 'e' || *s == 'E') {
        s++;
        int eneg = 0;
        if (*s == '-') { eneg = 1; s++; } else if (*s == '+') s++;
        int exp = 0;
        while (isdigit_c(*s)) exp = exp * 10 + (*s++ - '0');
        double mul = 1.0;
        for (int i = 0; i < exp; i++) mul *= 10.0;
        if (eneg) val /= mul; else val *= mul;
    }
    if (endptr) *endptr = (char *)s;
    return neg ? -val : val;
}

double atof(const char *s) { return strtod(s, (char **)0); }

char *itoa(int value, char *buf, int base) {
    if (base < 2 || base > 36) { *buf = '\0'; return buf; }
    char tmp[66];
    int i = 0, neg = 0;
    unsigned int uv;
    if (value < 0 && base == 10) { neg = 1; uv = (unsigned int)-value; }
    else uv = (unsigned int)value;
    if (uv == 0) { tmp[i++] = '0'; }
    while (uv) {
        int r = uv % base;
        tmp[i++] = (char)(r < 10 ? '0' + r : 'a' + r - 10);
        uv /= base;
    }
    if (neg) tmp[i++] = '-';
    char *p = buf;
    while (i-- > 0) *p++ = tmp[i];
    *p = '\0';
    return buf;
}

/* =========================================================================
 * rand / srand — LCG semplice
 * ========================================================================= */
static unsigned long s_rand_state = 1;

void srand(unsigned int seed) { s_rand_state = seed; }

int rand(void) {
    s_rand_state = s_rand_state * 6364136223846793005ULL + 1442695040888963407ULL;
    return (int)((s_rand_state >> 33) & (unsigned long)RAND_MAX);
}

/* =========================================================================
 * qsort — Introsort semplificato (insertion sort + quicksort recursivo)
 * ========================================================================= */
static void swap_bytes(uint8_t *a, uint8_t *b, size_t size) {
    while (size--) { uint8_t t = *a; *a++ = *b; *b++ = t; }
}

static void insertion_sort(uint8_t *base, size_t nmemb, size_t size,
                            int (*cmp)(const void *, const void *)) {
    for (size_t i = 1; i < nmemb; i++) {
        for (size_t j = i; j > 0 &&
             cmp(base + (j-1)*size, base + j*size) > 0; j--) {
            swap_bytes(base + (j-1)*size, base + j*size, size);
        }
    }
}

static void quicksort(uint8_t *base, size_t nmemb, size_t size,
                      int (*cmp)(const void *, const void *)) {
    if (nmemb <= 16) { insertion_sort(base, nmemb, size, cmp); return; }

    /* Pivot: mediana tra first, medio, last */
    size_t mid = nmemb / 2;
    if (cmp(base, base + mid*size) > 0) swap_bytes(base, base + mid*size, size);
    if (cmp(base, base + (nmemb-1)*size) > 0)
        swap_bytes(base, base + (nmemb-1)*size, size);
    if (cmp(base + mid*size, base + (nmemb-1)*size) > 0)
        swap_bytes(base + mid*size, base + (nmemb-1)*size, size);

    /* Move the pivot in penultima posizione */
    swap_bytes(base + mid*size, base + (nmemb-2)*size, size);
    uint8_t *pivot = base + (nmemb-2)*size;

    size_t i = 0, j = nmemb - 2;
    while (1) {
        while (cmp(base + (++i)*size, pivot) < 0 && i < nmemb-1) {}
        while (cmp(base + (--j)*size, pivot) > 0 && j > 0) {}
        if (i >= j) break;
        swap_bytes(base + i*size, base + j*size, size);
    }
    swap_bytes(base + i*size, pivot, size);

    quicksort(base, i, size, cmp);
    quicksort(base + (i+1)*size, nmemb - i - 1, size, cmp);
}

void qsort(void *base, size_t nmemb, size_t size,
           int (*cmp)(const void *, const void *)) {
    if (nmemb < 2 || !size) return;
    quicksort((uint8_t *)base, nmemb, size, cmp);
}

void *bsearch(const void *key, const void *base, size_t nmemb,
              size_t size, int (*cmp)(const void *, const void *)) {
    const uint8_t *lo = (const uint8_t *)base;
    const uint8_t *hi = lo + nmemb * size;
    while (lo < hi) {
        const uint8_t *mid = lo + ((hi - lo) / size / 2) * size;
        int r = cmp(key, mid);
        if      (r < 0) hi  = mid;
        else if (r > 0) lo  = mid + size;
        else            return (void *)mid;
    }
    return (void *)0;
}

/* =========================================================================
 * exit / abort
 * ========================================================================= */
#define SYS_EXIT 60

void exit(int status) {
    /* Flush of all the buffer stdio — fatto in stdio.c via atexit (TODO) */
    __syscall1(SYS_EXIT, (long)status);
    __builtin_unreachable();
}

void abort(void) {
    /* Send SIGABRT to sé stessi */
    __syscall2(62 /* SYS_KILL */, (long)__syscall0(39 /* SYS_GETPID */), 6 /* SIGABRT */);
    exit(1);
}

/* =========================================================================
 * abs / labs / llabs
 * ========================================================================= */
int       abs  (int x)       { return x < 0 ? -x : x; }
long      labs (long x)      { return x < 0 ? -x : x; }
long long llabs(long long x) { return x < 0 ? -x : x; }

div_t div(int numer, int denom) {
    div_t r; r.quot = numer / denom; r.rem = numer % denom; return r;
}
ldiv_t ldiv(long numer, long denom) {
    ldiv_t r; r.quot = numer / denom; r.rem = numer % denom; return r;
}
