#ifndef _STDIO_H
#define _STDIO_H

#include "stddef.h"
#include "stdarg.h"

/* =========================================================================
 * FILE — descriptor of stream
 *
 * Internamente è to buffer attorno to to file descriptor (syscall).
 * I/O bufferizato with flush automatic up '\n' (line-buffered) for stdout,
 * block-buffered for file, unbuffered for stderr.
 * ========================================================================= */
#define _LIBC_FILE_BUFSIZE  4096
#define FOPEN_MAX           64

typedef struct _FILE {
    int     fd;                         /* File descriptor kernel */
    int     flags;                      /* O_RDONLY / O_WRONLY / O_RDWR */
    int     mode;                       /* 0=unbuf, 1=linebuf, 2=fullbuf */
    int     error;                      /* Flag error */
    int     eof;                        /* Flag EOF */
    long    pos;                        /* Posizione logica (for ftell) */

    /* Write buffer */
    char    wbuf[_LIBC_FILE_BUFSIZE];
    int     wbuf_len;                   /* Byte presenti nel write buffer */

    /* Read buffer */
    char    rbuf[_LIBC_FILE_BUFSIZE];
    int     rbuf_len;                   /* Byte validi nel read buffer */
    int     rbuf_pos;                   /* Prossimo byte from readre */
} FILE;

/* Stream standard — definiti in stdio.c */
extern FILE *stdin;
extern FILE *stdout;
extern FILE *stderr;

#define EOF (-1)

/* =========================================================================
 * Apertura / chiusura file
 * ========================================================================= */
FILE  *fopen (const char *path, const char *mode);
int    fclose(FILE *stream);
int    fflush(FILE *stream);

/* =========================================================================
 * I/O binarieso / testo
 * ========================================================================= */
size_t fread (void *ptr, size_t size, size_t nmemb, FILE *stream);
size_t fwrite(const void *ptr, size_t size, size_t nmemb, FILE *stream);

int    fgetc (FILE *stream);
int    fputc (int c, FILE *stream);
char  *fgets (char *s, int n, FILE *stream);
int    fputs (const char *s, FILE *stream);

int    getchar(void);
int    putchar(int c);
int    puts   (const char *s);

/* =========================================================================
 * Seek / tell
 * ========================================================================= */
int    fseek  (FILE *stream, long offset, int whence);
long   ftell  (FILE *stream);
void   rewind (FILE *stream);
int    feof   (FILE *stream);
int    ferror (FILE *stream);
void   clearerr(FILE *stream);

/* =========================================================================
 * Printf / scanf family
 *
 * Specificatori supportti in printf:
 *   %d %the %u %OR %x %X   — interi (with %l %ll %z qualificatori)
 *   %f %AND %E %g %G       — floating point (double)
 *   %s %c %p             — stringa, carattere, pointer
 *   %%                   — percentuale letterale
 *   Width, precision, flag '-' '+' ' ' '0' '#'
 * ========================================================================= */
int printf  (const char *fmt, ...) __attribute__((format(printf, 1, 2)));
int fprintf (FILE *stream, const char *fmt, ...)
             __attribute__((format(printf, 2, 3)));
int sprintf (char *buf, const char *fmt, ...)
             __attribute__((format(printf, 2, 3)));
int snprintf(char *buf, size_t n, const char *fmt, ...)
             __attribute__((format(printf, 3, 4)));
int dprintf (int fd, const char *fmt, ...)
             __attribute__((format(printf, 2, 3)));

int vprintf  (const char *fmt, va_list ap);
int vfprintf (FILE *stream, const char *fmt, va_list ap);
int vsprintf (char *buf, const char *fmt, va_list ap);
int vsnprintf(char *buf, size_t n, const char *fmt, va_list ap);

/* =========================================================================
 * Scanf family
 * Specificatori supportti: %d %the %u %OR %x %X %f %s %c %% %n
 *   with qualificatori l ll h z AND length/width field
 * ========================================================================= */
int scanf  (const char *fmt, ...) __attribute__((format(scanf, 1, 2)));
int fscanf (FILE *stream, const char *fmt, ...) __attribute__((format(scanf, 2, 3)));
int sscanf (const char *str, const char *fmt, ...) __attribute__((format(scanf, 2, 3)));
int vscanf (const char *fmt, va_list ap);
int vsscanf(const char *str, const char *fmt, va_list ap);

/* =========================================================================
 * Error reporting
 * ========================================================================= */
void perror(const char *s);

/* Variante interna to the kernel: writes up fd direttamente without FILE */
int dprintf_fd(int fd, const char *fmt, ...);

#endif /* _STDIO_H */
