#ifndef _STDDEF_H
#define _STDDEF_H

/*
 * stddef.h — types AND macro fondamentali (userspace MattiaOS libc)
 */

typedef __SIZE_TYPE__     size_t;
typedef __PTRDIFF_TYPE__  ptrdiff_t;
typedef __PTRDIFF_TYPE__  ssize_t;

#ifndef NULL
#  define NULL ((void *)0)
#endif

#define offsetof(type, member) __builtin_offsetof(type, member)

#endif /* _STDDEF_H */
