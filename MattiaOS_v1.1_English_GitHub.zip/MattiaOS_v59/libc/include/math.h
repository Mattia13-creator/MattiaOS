#ifndef _MATH_H
#define _MATH_H

/*
 * math.h — functions matematiche floating point (userspace MattiaOS libc)
 * Implementate with instructions x87 inline asm (fsin, fcos, fsqrt, ecc.)
 * Userspace può usare x87 freemente (to differenza of the kernel).
 */

/* Costanti */
#define M_PI        3.14159265358979323846
#define M_E         2.71828182845904523536
#define M_LN2       0.69314718055994530942
#define M_LN10      2.30258509299404568402
#define M_LOG2E     1.44269504088896340736
#define M_LOG10E    0.43429448190325182765
#define M_SQRT2     1.41421356237309504880
#define M_1_PI      0.31830988618379067154
#define M_PI_2      1.57079632679489661923
#define M_PI_4      0.78539816339744830962

#define HUGE_VAL  __builtin_huge_val()
#define INFINITY  __builtin_inff()
#define NAN       __builtin_nanf("")

/* =========================================================================
 * Funzioni trigonometriche (argomento in radianti)
 * ========================================================================= */
double sin (double x);
double cos (double x);
double tan (double x);
double asin(double x);
double acos(double x);
double atan(double x);
double atan2(double y, double x);

float sinf (float x);
float cosf (float x);
float tanf (float x);
float atanf(float x);

/* =========================================================================
 * Esponenziali AND logaritmi
 * ========================================================================= */
double exp (double x);
double exp2(double x);
double log (double x);
double log2(double x);
double log10(double x);

/* =========================================================================
 * Potenze AND radici
 * ========================================================================= */
double pow  (double base, double exp);
double sqrt (double x);
double cbrt (double x);
double hypot(double x, double y);

float sqrtf(float x);
float powf (float base, float exp_v);

/* =========================================================================
 * Arrotondamento
 * ========================================================================= */
double floor(double x);
double ceil (double x);
double round(double x);
double trunc(double x);
double fmod (double x, double y);

float floorf(float x);
float ceilf (float x);
float roundf(float x);

/* =========================================================================
 * Valore assoluto AND segno
 * ========================================================================= */
double fabs (double x);
float  fabsf(float x);
double copysign(double x, double y);

/* =========================================================================
 * Classificazione
 * ========================================================================= */
int isinf(double x);
int isnan(double x);
int isfinite(double x);

/* =========================================================================
 * Iperboliche
 * ========================================================================= */
double sinh(double x);
double cosh(double x);
double tanh(double x);

/* =========================================================================
 * ldexp / frexp / modf
 * ========================================================================= */
double ldexp(double x, int exp);
double frexp(double x, int *exp);
double modf (double x, double *iptr);

#endif /* _MATH_H */
