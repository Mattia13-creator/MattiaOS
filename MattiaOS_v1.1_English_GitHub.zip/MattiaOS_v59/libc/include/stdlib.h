#ifndef _STDLIB_H
#define _STDLIB_H

#include "stddef.h"
#include "stdint.h"

/* =========================================================================
 * Gestione memory heap
 * ========================================================================= */
void  *malloc (size_t size);
void  *calloc (size_t nmemb, size_t size);
void  *realloc(void *ptr, size_t size);
void   free   (void *ptr);

/* =========================================================================
 * Conversions stringa ↔ number
 * ========================================================================= */
int           atoi  (const char *s);
long          atol  (const char *s);
long long     atoll (const char *s);
double        atof  (const char *s);

long          strtol  (const char *s, char **endptr, int base);
unsigned long strtoul (const char *s, char **endptr, int base);
long long     strtoll (const char *s, char **endptr, int base);
unsigned long long strtoull(const char *s, char **endptr, int base);
double        strtod  (const char *s, char **endptr);

/* Format to intero in stringa (NOT standard ma utile) */
char *itoa(int value, char *buf, int base);

/* =========================================================================
 * Numeri casuali
 * ========================================================================= */
#define RAND_MAX 0x7FFFFFFF
int  rand (void);
void srand(unsigned int seed);

/* =========================================================================
 * Sortmento AND risearch
 * ========================================================================= */
void  qsort   (void *base, size_t nmemb, size_t size,
                int (*cmp)(const void *, const void *));
void *bsearch (const void *key, const void *base, size_t nmemb,
                size_t size, int (*cmp)(const void *, const void *));

/* =========================================================================
 * Terminazione process
 * ========================================================================= */
#define EXIT_SUCCESS 0
#define EXIT_FAILURE 1

void exit (int status)  __attribute__((noreturn));
void abort(void)        __attribute__((noreturn));

/* =========================================================================
 * Varie
 * ========================================================================= */
int abs  (int x);
long labs (long x);
long long llabs(long long x);

/* Structure restituita from div() */
typedef struct { int  quot; int  rem; } div_t;
typedef struct { long quot; long rem; } ldiv_t;
div_t  div (int  numer, int  denom);
ldiv_t ldiv(long numer, long denom);

#endif /* _STDLIB_H */
