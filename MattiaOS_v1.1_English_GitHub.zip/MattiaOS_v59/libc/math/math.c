#include "../include/math.h"
#include "../include/stdint.h"

/*
 * math.c — functions matematiche with x87 inline asm
 *
 * Il queues userspace può usare l'FPU x87 freemente.
 * Le instructions as FSIN, FCOS, FSQRT, FLDL2E ecc. are available
 * up qualsiasi x86-64.  Non si usano SSE qui for massima portbilità
 * with qualunque set of flag of the compilatore.
 *
 * Costanti utili pre-loadte with the instructions x87:
 *   FLD1    = 1.0         FLDPI   = π
 *   FLDL2E  = log2(AND)     FLDL2T  = log2(10)
 *   FLDLG2  = log10(2)    FLDLN2  = ln(2)
 *   FLDZ    = 0.0
 */

/* =========================================================================
 * Helper union for manipolazione bit of double
 * ========================================================================= */
typedef union { double d; uint64_t u; } du64_t;

static inline int __isinf_d(double x) {
    du64_t u; u.d = x;
    return (u.u & 0x7FFFFFFFFFFFFFFFULL) == 0x7FF0000000000000ULL;
}
static inline int __isnan_d(double x) {
    du64_t u; u.d = x;
    return (u.u & 0x7FFFFFFFFFFFFFFFULL) > 0x7FF0000000000000ULL;
}
static inline int __isfinite_d(double x) {
    du64_t u; u.d = x;
    return (u.u & 0x7FF0000000000000ULL) != 0x7FF0000000000000ULL;
}

int isinf   (double x) { return __isinf_d(x);    }
int isnan   (double x) { return __isnan_d(x);     }
int isfinite(double x) { return __isfinite_d(x);  }

/* =========================================================================
 * sin / cos / tan — FSIN, FCOS, FPTAN
 * ========================================================================= */
double sin(double x) {
    double r;
    __asm__ ("fsin" : "=t"(r) : "0"(x));
    return r;
}

double cos(double x) {
    double r;
    __asm__ ("fcos" : "=t"(r) : "0"(x));
    return r;
}

double tan(double x) {
    /* FPTAN mette 1.0 AND tan(x) nello stack; sload 1.0 */
    double r;
    __asm__ ("fptan; fstp %%st(0)" : "=&t"(r) : "0"(x) : "st(1)");
    return r;
}

float sinf(float x) { return (float)sin((double)x); }
float cosf(float x) { return (float)cos((double)x); }
float tanf(float x) { return (float)tan((double)x); }

/* =========================================================================
 * asin / acos / atan / atan2
 *
 * FPATAN: calculate atan(ST1/ST0), utile for atan2.
 * asin(x) = atan2(x, sqrt(1 - x*x))
 * acos(x) = atan2(sqrt(1 - x*x), x)
 * ========================================================================= */
double atan2(double y, double x) {
    double r;
    __asm__ ("fpatan" : "=t"(r) : "0"(x), "u"(y) : "st(1)");
    return r;
}

double atan(double x) { return atan2(x, 1.0); }
float  atanf(float x) { return (float)atan((double)x); }

double asin(double x) {
    return atan2(x, sqrt(1.0 - x * x));
}

double acos(double x) {
    return atan2(sqrt(1.0 - x * x), x);
}

/* =========================================================================
 * sqrt / sqrtf — FSQRT
 * ========================================================================= */
double sqrt(double x) {
    double r;
    __asm__ ("fsqrt" : "=t"(r) : "0"(x));
    return r;
}

float sqrtf(float x) { return (float)sqrt((double)x); }

/* =========================================================================
 * exp — AND^x = 2^(x * log2(AND)) via F2XM1 + FSCALE
 *
 * Algorithm:
 *   y = x * log2(AND)         (FLDL2E + FMUL)
 *   n = floor(y)            (FRNDINT)
 *   f = y - n               (0 ≤ f < 1)
 *   AND^x = 2^f * 2^n         (F2XM1 calculate 2^f - 1; aggiungi 1; poi FSCALE)
 * ========================================================================= */
double exp(double x) {
    double r, tmp;
    __asm__ (
        "fldl2e\n\t"        /* st0 = log2(AND) */
        "fmulp\n\t"         /* st0 = x*log2(AND) */
        "fld %%st(0)\n\t"   /* st0 = y, st1 = y */
        "frndint\n\t"       /* st0 = n = floor(y) */
        "fsubr %%st(0),%%st(1)\n\t"  /* st1 = f = y - n */
        "fxch\n\t"          /* st0 = f, st1 = n */
        "f2xm1\n\t"         /* st0 = 2^f - 1 */
        "fld1\n\t"
        "faddp\n\t"         /* st0 = 2^f */
        "fscale\n\t"        /* st0 = 2^f * 2^n */
        "fstp %%st(1)\n\t"  /* Pop n */
        : "=t"(r), "=u"(tmp) : "0"(x)
    );
    return r;
}

double exp2(double x) { return exp(x * M_LN2); }

/* =========================================================================
 * log — ln(x) = log2(x) / log2(AND) = log2(x) * ln(2)
 *
 * FYL2X: calculate y * log2(x)  (st0=x, st1=y → st0 = y*log2(x))
 * Per ln: y = ln(2) = FLDLN2
 * ========================================================================= */
double log(double x) {
    double r;
    __asm__ (
        "fldln2\n\t"
        "fxch\n\t"
        "fyl2x"
        : "=t"(r) : "0"(x) : "st(1)"
    );
    return r;
}

double log2(double x) {
    double r;
    __asm__ (
        "fld1\n\t"
        "fxch\n\t"
        "fyl2x"
        : "=t"(r) : "0"(x) : "st(1)"
    );
    return r;
}

double log10(double x) {
    double r;
    __asm__ (
        "fldlg2\n\t"
        "fxch\n\t"
        "fyl2x"
        : "=t"(r) : "0"(x) : "st(1)"
    );
    return r;
}

/* =========================================================================
 * pow — b^AND = exp(AND * ln(b))
 * Caso speciale: b^0 = 1, 0^0 = 1 (convenzione C99).
 * ========================================================================= */
double pow(double base, double exp_v) {
    if (exp_v == 0.0) return 1.0;
    if (base == 0.0) return 0.0;
    if (base < 0.0) {
        /* base negativa: valid only for exp intero */
        long long n = (long long)exp_v;
        if ((double)n != exp_v) return NAN;
        double r = pow(-base, exp_v);
        return (n & 1) ? -r : r;
    }
    return exp(exp_v * log(base));
}

float powf(float base, float exp_v) { return (float)pow((double)base, (double)exp_v); }

/* cbrt — root cubica via exp(log(x)/3) */
double cbrt(double x) {
    if (x < 0.0) return -pow(-x, 1.0/3.0);
    return pow(x, 1.0/3.0);
}

double hypot(double x, double y) { return sqrt(x*x + y*y); }

/* =========================================================================
 * floor / ceil / round / trunc — FRNDINT with controllo of the modo arrotondamento
 * ========================================================================= */
double floor(double x) {
    /* Set modo arrotondamento verso -∞ (RC=01 → bits 10-11 of the CW = 01) */
    unsigned short cw, new_cw;
    __asm__ ("fnstcw %0" : "=m"(cw));
    new_cw = (cw & 0xF3FFu) | 0x0400u;
    __asm__ ("fldcw %0" :: "m"(new_cw));
    double r;
    __asm__ ("frndint" : "=t"(r) : "0"(x));
    __asm__ ("fldcw %0" :: "m"(cw));
    return r;
}

double ceil(double x) {
    /* Arrotondamento verso +∞ (RC=10 → bits 10-11 = 10) */
    unsigned short cw, new_cw;
    __asm__ ("fnstcw %0" : "=m"(cw));
    new_cw = (cw & 0xF3FFu) | 0x0800u;
    __asm__ ("fldcw %0" :: "m"(new_cw));
    double r;
    __asm__ ("frndint" : "=t"(r) : "0"(x));
    __asm__ ("fldcw %0" :: "m"(cw));
    return r;
}

double trunc(double x) {
    /* Arrotondamento verso zero (RC=11 → bits 10-11 = 11) */
    unsigned short cw, new_cw;
    __asm__ ("fnstcw %0" : "=m"(cw));
    new_cw = (cw & 0xF3FFu) | 0x0C00u;
    __asm__ ("fldcw %0" :: "m"(new_cw));
    double r;
    __asm__ ("frndint" : "=t"(r) : "0"(x));
    __asm__ ("fldcw %0" :: "m"(cw));
    return r;
}

double round(double x) {
    return (x >= 0.0) ? floor(x + 0.5) : ceil(x - 0.5);
}

float floorf(float x) { return (float)floor((double)x); }
float ceilf (float x) { return (float)ceil ((double)x); }
float roundf(float x) { return (float)round((double)x); }

/* =========================================================================
 * fabs / fabs / copysign
 * ========================================================================= */
double fabs(double x) {
    double r;
    __asm__ ("fabs" : "=t"(r) : "0"(x));
    return r;
}

float fabsf(float x) { return (float)fabs((double)x); }

double copysign(double x, double y) {
    du64_t ux; ux.d = x;
    du64_t uy; uy.d = y;
    ux.u = (ux.u & 0x7FFFFFFFFFFFFFFFULL) | (uy.u & 0x8000000000000000ULL);
    return ux.d;
}

/* =========================================================================
 * fmod — x - trunc(x/y)*y
 * x87 FPREM calculate the partial — loop finché C2=0
 * ========================================================================= */
double fmod(double x, double y) {
    double r;
    __asm__ (
        "1:\n\t"
        "fprem\n\t"
        "fnstsw %%ax\n\t"
        "testb $4, %%ah\n\t"
        "jne 1b"
        : "=t"(r) : "0"(x), "u"(y) : "ax", "st(1)"
    );
    return r;
}

/* =========================================================================
 * Iperboliche — definite via exp
 * ========================================================================= */
double sinh(double x) { return (exp(x) - exp(-x)) * 0.5; }
double cosh(double x) { return (exp(x) + exp(-x)) * 0.5; }
double tanh(double x) {
    double e2 = exp(2.0 * x);
    return (e2 - 1.0) / (e2 + 1.0);
}

/* =========================================================================
 * ldexp / frexp / modf
 * ========================================================================= */
double ldexp(double x, int exp_i) {
    du64_t u; u.d = x;
    int e = (int)((u.u >> 52) & 0x7FF) + exp_i;
    if (e <= 0) return 0.0;
    if (e >= 0x7FF) return HUGE_VAL;
    u.u = (u.u & 0x800FFFFFFFFFFFFFULL) | ((uint64_t)e << 52);
    return u.d;
}

double frexp(double x, int *exp_out) {
    if (x == 0.0) { *exp_out = 0; return 0.0; }
    du64_t u; u.d = x;
    int e = (int)((u.u >> 52) & 0x7FF) - 1022;
    *exp_out = e;
    /* Set esponente to 1022 (value assoluto tra 0.5 AND 1.0) */
    u.u = (u.u & 0x800FFFFFFFFFFFFFULL) | (0x3FEULL << 52);
    return u.d;
}

double modf(double x, double *iptr) {
    *iptr = trunc(x);
    return x - *iptr;
}
