#ifndef MATTIAOS_ACPI_H
#define MATTIAOS_ACPI_H

#include "../include/types.h"

/* =========================================================================
 * acpi.h — Parser tables ACPI (ACPI Specification 6.4)
 *
 * Parsifica the RSDP fornito from Limine, support sia RSDT (32-bit, legacy)
 * that XSDT (64-bit, preferito when revision >= 2).  Espone MADT, HPET,
 * MCFG, FADT via l'indice internal of tables.
 *
 * ORDINE DI CHIAMATA OBBLIGATORIO in entry.c:
 *   vmm_init() → acpi_init() → lapic_init() → apic_timer_init()
 * acpi_init() deve precedere lapic_init() perché apic_timer_calibrate()
 * usa the timer HPET scoperto from acpi_init().
 * ========================================================================= */

/* -------------------------------------------------------------------------
 * RSDP — Root System Description Pointer (ACPI §5.2.5)
 * Signature: "RSD PTR " (8 byte with spazio finale)
 * ------------------------------------------------------------------------- */
typedef struct __attribute__((packed)) {
    char     signature[8];    /* "RSD PTR " */
    uint8_t  checksum;        /* Sum of all the byte of the fields v1.0 = 0 */
    char     oem_id[6];
    uint8_t  revision;        /* 0 = ACPI 1.0 (only RSDT); >= 2 = XSDT presente */
    uint32_t rsdt_address;    /* Address physical 32-bit RSDT */
    /* Fields ACPI 2.0+ — presenti only when revision >= 2 */
    uint32_t length;          /* Length total RSDP v2 */
    uint64_t xsdt_address;    /* Address physical 64-bit XSDT */
    uint8_t  xchecksum;       /* Checksum esteso up all the fields v2 */
    uint8_t  reserved[3];
} acpi_rsdp_t;

/* -------------------------------------------------------------------------
 * SDT header — comune to all the tables of system (ACPI §5.2.6)
 * ------------------------------------------------------------------------- */
typedef struct __attribute__((packed)) {
    char     signature[4];        /* Identificatore table (4 char, NOT NULL-terminated) */
    uint32_t length;              /* Length total of the table in byte */
    uint8_t  revision;
    uint8_t  checksum;            /* Sum of all the byte of the table = 0 */
    char     oem_id[6];
    char     oem_table_id[8];
    uint32_t oem_revision;
    uint32_t creator_id;
    uint32_t creator_revision;
} acpi_sdt_header_t;

/* -------------------------------------------------------------------------
 * RSDT — Root System Description Table (ACPI 1.0, 32-bit)
 * Signature: "RSDT"
 * ------------------------------------------------------------------------- */
typedef struct __attribute__((packed)) {
    acpi_sdt_header_t header;
    uint32_t          entries[];  /* Array of addresses fisici 32-bit of the SDT */
} acpi_rsdt_t;

/* -------------------------------------------------------------------------
 * XSDT — Extended System Description Table (ACPI 2.0+, 64-bit)
 * Signature: "XSDT"
 * ------------------------------------------------------------------------- */
typedef struct __attribute__((packed)) {
    acpi_sdt_header_t header;
    uint64_t          entries[];  /* Array of addresses fisici 64-bit of the SDT */
} acpi_xsdt_t;

/* =========================================================================
 * MADT — Multiple APIC Description Table (ACPI §5.2.12)
 * Signature: "APIC"
 * Contiene the lista of the Local APIC (to for core) AND of the I/O APIC.
 * Necessaria for SMP AND for the corretto routing of the interrupt.
 * ========================================================================= */

/* Tipi of structure variable all'internal of the MADT */
#define MADT_TYPE_LOCAL_APIC        0   /* Processr Local APIC */
#define MADT_TYPE_IO_APIC           1   /* I/O APIC */
#define MADT_TYPE_ISO               2   /* Interrupt Source Override */
#define MADT_TYPE_NMI_SOURCE        3   /* NMI Source */
#define MADT_TYPE_LOCAL_APIC_NMI    4   /* Local APIC NMI connection */
#define MADT_TYPE_LOCAL_APIC_OVR    5   /* Local APIC Address Override (64-bit) */
#define MADT_TYPE_IO_SAPIC          6   /* I/O SAPIC */
#define MADT_TYPE_LOCAL_SAPIC       7   /* Local SAPIC */
#define MADT_TYPE_PLATFORM_INT      8   /* Platform Interrupt Sources */
#define MADT_TYPE_LOCAL_X2APIC      9   /* Processr Local x2APIC */
#define MADT_TYPE_LOCAL_X2APIC_NMI  10  /* Local x2APIC NMI */

/* Header comune to all the structures variabili of the MADT */
typedef struct __attribute__((packed)) {
    uint8_t type;
    uint8_t length;
} acpi_madt_entry_hdr_t;

/* Tipo 0: Processr Local APIC — to record for every core logico */
typedef struct __attribute__((packed)) {
    acpi_madt_entry_hdr_t hdr;   /* type=0, length=8 */
    uint8_t  acpi_processr_uid;
    uint8_t  apic_id;
    uint32_t flags;              /* bit 0: Enabled; bit 1: Online Capable */
} acpi_madt_lapic_t;

#define MADT_LAPIC_FLAG_ENABLED        (1u << 0)
#define MADT_LAPIC_FLAG_ONLINE_CAPABLE (1u << 1)

/* Tipo 1: I/O APIC */
typedef struct __attribute__((packed)) {
    acpi_madt_entry_hdr_t hdr;   /* type=1, length=12 */
    uint8_t  io_apic_id;
    uint8_t  reserved;
    uint32_t io_apic_address;    /* Address physical base MMIO I/O APIC */
    uint32_t gsi_base;           /* Global System Interrupt base of this I/O APIC */
} acpi_madt_ioapic_t;

/* Tipo 2: Interrupt Source Override
 * Ridefinisce the mapping tra IRQ legacy ISA AND Global System Interrupt */
typedef struct __attribute__((packed)) {
    acpi_madt_entry_hdr_t hdr;   /* type=2, length=10 */
    uint8_t  bus;                /* 0 = ISA */
    uint8_t  source;             /* Numero IRQ source (IRQ bus) */
    uint32_t gsi;                /* Global System Interrupt destination */
    uint16_t flags;              /* Bit 0-1: Polarity; bit 2-3: Trigger Mode */
} acpi_madt_iso_t;

/* Tipo 4: Local APIC NMI — specifica quale LINT# of every CPU è connected to NMI */
typedef struct __attribute__((packed)) {
    acpi_madt_entry_hdr_t hdr;   /* type=4, length=6 */
    uint8_t  acpi_processr_uid; /* 0xFF = all the processrs */
    uint16_t flags;
    uint8_t  lint;               /* LINT# number (0 OR 1) */
} acpi_madt_lapic_nmi_t;

/* Table MADT — header fixed + stream of structures variabili */
typedef struct __attribute__((packed)) {
    acpi_sdt_header_t header;
    uint32_t          local_apic_address;  /* Address physical LAPIC of default */
    uint32_t          flags;               /* bit 0: PCAT_COMPAT (8259A presente) */
    /* Seguito immediatamente from the structures variabili of type MADT_TYPE_* */
} acpi_madt_t;

/* =========================================================================
 * HPET — High Precision Event Timer (HPET Spec 1.0a)
 * Signature: "HPET"
 * Usata for calibrare the timer APIC with precisione femtosecondo.
 * ========================================================================= */
typedef struct __attribute__((packed)) {
    acpi_sdt_header_t header;
    uint32_t          event_timer_block_id;  /* Hardware rev AND number timer */
    uint8_t           address_space_id;      /* 0 = System Memory; 1 = System I/O */
    uint8_t           register_bit_width;
    uint8_t           register_bit_offset;
    uint8_t           reserved;
    uint64_t          base_address;          /* Address physical base MMIO of the block HPET */
    uint8_t           hpet_number;           /* Numero of the block HPET (0 = first) */
    uint16_t          minimum_tick;          /* Periodo minimo in unità of the clock principale */
    uint8_t           page_protection;
} acpi_hpet_t;

/* Offset registers HPET (relativi to the base_address MMIO, registers to 64-bit) */
#define HPET_REG_CAP_ID     0x000   /* General Capabilities AND ID */
#define HPET_REG_CONFIG     0x010   /* General Configuration */
#define HPET_REG_INT_STS    0x020   /* General Interrupt Status */
#define HPET_REG_MAIN_CNT   0x0F0   /* Main Counter Value */

/* Bit of the register General Configuration */
#define HPET_CFG_ENABLE     (1ULL << 0)  /* Enable the main counter */
#define HPET_CFG_LEGACY     (1ULL << 1)  /* Legacy IRQ routing (ridefinisce IRQ0/IRQ8) */

/* Il periodo of the clock in femtosecondi è nei bit 63:32 of the register CAP_ID */
#define HPET_CAP_PERIOD_SHIFT   32

/* Macro accesso MMIO HPET (byte offset, pointer void*) */
#define HPET_READ(base, off)  \
    (*(volatile uint64_t *)((uint8_t *)(base) + (off)))
#define HPET_WRITE(base, off, val)  \
    (*(volatile uint64_t *)((uint8_t *)(base) + (off)) = (uint64_t)(val))

/* =========================================================================
 * MCFG — PCI Express Memory Mapped Configuration Space (PCIe Spec §7.2.2)
 * Signature: "MCFG"
 * Necessaria for enablere PCIe ECAM (extended config space oltre 256 byte).
 * ========================================================================= */
typedef struct __attribute__((packed)) {
    uint64_t base_address;   /* Address physical base ECAM for this segmento */
    uint16_t pci_segment;    /* Numero segmento PCI (0 for the maggior parte of the systems) */
    uint8_t  start_bus;      /* Numero bus iniziale (of solito 0) */
    uint8_t  end_bus;        /* Numero bus finale */
    uint32_t reserved;
} acpi_mcfg_alloc_t;

typedef struct __attribute__((packed)) {
    acpi_sdt_header_t header;
    uint64_t          reserved;
    acpi_mcfg_alloc_t allocatetions[];  /* Array of record ECAM (n = (length - 44) / 16) */
} acpi_mcfg_t;

/* =========================================================================
 * FADT — Fixed ACPI Description Table (ACPI §5.2.9)
 * Signature: "FACP"
 * Contiene addresses of the registers hardware PM AND the posizione of the DSDT.
 * Solo the fields necessari are dichiarati qui.
 * ========================================================================= */
typedef struct __attribute__((packed)) {
    acpi_sdt_header_t header;
    uint32_t firmware_ctrl;       /* Address physical FACS */
    uint32_t dsdt;                /* Address physical DSDT */
    uint8_t  reserved0;
    uint8_t  preferred_pm_profile;
    uint16_t sci_int;             /* Numero IRQ SCI (System Control Interrupt) */
    uint32_t smi_cmd;             /* Port I/O SMI Command */
    uint8_t  acpi_enable;         /* Valore from writere in smi_cmd for activere ACPI */
    uint8_t  acpi_disable;        /* Valore from writere in smi_cmd for disactivere ACPI */
    uint8_t  s4bios_req;
    uint8_t  pstate_cnt;
    uint32_t pm1a_evt_blk;
    uint32_t pm1b_evt_blk;
    uint32_t pm1a_cnt_blk;
    uint32_t pm1b_cnt_blk;
    uint32_t pm2_cnt_blk;
    uint32_t pm_tmr_blk;
    uint32_t gpe0_blk;
    uint32_t gpe1_blk;
    /* Fields aggiuntivi NOT utilizzati attualmente — omessi for brevità */
} acpi_fadt_t;

/* =========================================================================
 * Dati estratti from the MADT — available after acpi_init()
 * ========================================================================= */

/* Numero massimo of CPU (Local APIC) AND I/O APIC supportti */
#define ACPI_MAX_CPUS    256
#define ACPI_MAX_IOAPICS 8

/* Informazioni up every CPU rilevata nel MADT */
typedef struct {
    uint8_t apic_id;    /* APIC ID usato for IPI AND identificazione core */
    uint8_t acpi_uid;   /* ACPI Processr UID */
    bool    enabled;    /* true if the processr è active all'boot */
} acpi_cpu_info_t;

/* Informazioni up every I/O APIC rilevato nel MADT */
typedef struct {
    uint8_t  id;        /* I/O APIC ID */
    uint32_t address;   /* Address physical base MMIO I/O APIC */
    uint32_t gsi_base;  /* Primo GSI gestito from this I/O APIC */
} acpi_ioapic_info_t;

/* =========================================================================
 * API pubblica
 * ========================================================================= */

/*
 * acpi_init — parsifica all the tables ACPI from the RSDP.
 *
 * Deve essere chiamata in entry.c PRIMA of lapic_init() AND
 * apic_timer_init(), perché apic_timer_calibrate() dipende dall'HPET
 * that is scoperto qui.
 *
 * @rsdp_phys: address FISICO of the RSDP (from rsdp_request.response->address
 *             of Limine).  acpi_init() converte internamente via g_hhdm_offset.
 */
void acpi_init(uint64_t rsdp_phys);

/*
 * acpi_find_table — search to table ACPI for signature to 4 caratteri.
 *
 * @sig: pointer to 4 caratteri (NOT necessariamente NULL-terminated).
 * @return: pointer virtual all'header of the table, NULL if NOT found.
 */
acpi_sdt_header_t *acpi_find_table(const char *sig);

/*
 * acpi_get_madt — returns the informazioni estratte from the MADT.
 *
 * @cpus_out:     array of output of almeno ACPI_MAX_CPUS elementi.
 * @nioapics_out: riceve the number of I/O APIC findti.
 * @ioapics_out:  array of output of almeno ACPI_MAX_IOAPICS elementi.
 * @return: number of CPU findte (>= 1), 0 if MADT NOT available.
 *
 * I data are copyti from the array statici interni — sicuro chiamare più volte.
 */
int acpi_get_madt(acpi_cpu_info_t    *cpus_out,
                  int                *nioapics_out,
                  acpi_ioapic_info_t *ioapics_out);

/*
 * acpi_get_hpet — returns the pointer virtual to the block MMIO HPET.
 *
 * Usa the macro HPET_READ/HPET_WRITE for accedere to the registers.
 * @return: address virtual base of the first block HPET, NULL if NOT found.
 */
void *acpi_get_hpet(void);

/*
 * acpi_hpet_period_fs — periodo of the clock HPET in femtosecondi.
 *
 * Tipicamente ~69841279 fs (~14.318 MHz).  Usato from apic_timer_calibrate()
 * for calculatere l'intervallo of attesa preciso.
 * @return: periodo in fs, 0 if HPET NOT available.
 */
uint64_t acpi_hpet_period_fs(void);

#endif /* MATTIAOS_ACPI_H */
