bits 64
section .text

global context_switch
global gdt_flush
global tss_flush
global isr_stubs

; context_switch(cpu_context_t *old, cpu_context_t *new, uint64_t cr3_new)
; rdi = old context pointer
; rsi = new context pointer
; rdx = new CR3 (0 = no switch)
context_switch:
    ; Save general purpose registers into old context
    mov [rdi + 0x00], rax
    mov [rdi + 0x08], rbx
    mov [rdi + 0x10], rcx
    mov [rdi + 0x18], rdx
    mov [rdi + 0x20], rsi
    mov [rdi + 0x28], rdi
    mov [rdi + 0x30], rbp
    mov [rdi + 0x38], r8
    mov [rdi + 0x40], r9
    mov [rdi + 0x48], r10
    mov [rdi + 0x50], r11
    mov [rdi + 0x58], r12
    mov [rdi + 0x60], r13
    mov [rdi + 0x68], r14
    mov [rdi + 0x70], r15

    ; Save RIP (return address on stack)
    mov rax, [rsp]
    mov [rdi + 0x78], rax

    ; Save RSP (adjusted for return address)
    lea rax, [rsp + 8]
    mov [rdi + 0x80], rax

    ; Switch page map if CR3 is provided
    test rdx, rdx
    jz .no_cr3_switch
    mov cr3, rdx
.no_cr3_switch:

    ; Restore registers from new context
    mov rax, [rsi + 0x00]
    mov rbx, [rsi + 0x08]
    mov rcx, [rsi + 0x10]
    mov rdx, [rsi + 0x18]
    mov rbp, [rsi + 0x30]
    mov r8,  [rsi + 0x38]
    mov r9,  [rsi + 0x40]
    mov r10, [rsi + 0x48]
    mov r11, [rsi + 0x50]
    mov r12, [rsi + 0x58]
    mov r13, [rsi + 0x60]
    mov r14, [rsi + 0x68]
    mov r15, [rsi + 0x70]

    ; Restore RSP first
    mov rsp, [rsi + 0x80]

    ; Push new RIP onto new stack for ret
    push qword [rsi + 0x78]

    ; Restore rdi and rsi last (were used as pointers)
    mov rdi, [rsi + 0x28]
    mov rsi, [rsi + 0x20]

    ret

; gdt_flush(gdtr_t *gdtr)
gdt_flush:
    lgdt [rdi]
    mov ax, 0x10    ; KERNEL_DS
    mov ds, ax
    mov es, ax
    mov fs, ax
    mov gs, ax
    mov ss, ax
    push 0x08       ; KERNEL_CS
    lea  rax, [rel .reload_cs]
    push rax
    retfq
.reload_cs:
    ret

; tss_flush(uint16_t sel)
tss_flush:
    ltr di
    ret

; ISR stubs — 256 entries
; Each stub pushes a dummy error queues (for exceptions without one),
; pushes the vector number, and jumps to the common handler.
%macro ISR_NOERRCODE 1
isr_stub_%1:
    push 0          ; dummy error queues
    push %1         ; vector number
    jmp isr_common
%endmacro

%macro ISR_ERRCODE 1
isr_stub_%1:
    push %1         ; vector number (error queues already on stack)
    jmp isr_common
%endmacro

; Push all registers, call C handler, pop all registers, iret
extern isr_handler

isr_common:
    push rax
    push rbx
    push rcx
    push rdx
    push rsi
    push rdi
    push rbp
    push r8
    push r9
    push r10
    push r11
    push r12
    push r13
    push r14
    push r15

    mov rdi, rsp    ; pointer to interrupt_frame_t
    call isr_handler

    pop r15
    pop r14
    pop r13
    pop r12
    pop r11
    pop r10
    pop r9
    pop r8
    pop rbp
    pop rdi
    pop rsi
    pop rdx
    pop rcx
    pop rbx
    pop rax

    add rsp, 16     ; pop vector + error_queues
    iretq

; Generate all 256 ISR stubs
ISR_NOERRCODE  0
ISR_NOERRCODE  1
ISR_NOERRCODE  2
ISR_NOERRCODE  3
ISR_NOERRCODE  4
ISR_NOERRCODE  5
ISR_NOERRCODE  6
ISR_NOERRCODE  7
ISR_ERRCODE    8
ISR_NOERRCODE  9
ISR_ERRCODE   10
ISR_ERRCODE   11
ISR_ERRCODE   12
ISR_ERRCODE   13
ISR_ERRCODE   14
ISR_NOERRCODE 15
ISR_NOERRCODE 16
ISR_ERRCODE   17
ISR_NOERRCODE 18
ISR_NOERRCODE 19
%assign i 20
%rep 236
ISR_NOERRCODE i
%assign i i+1
%endrep

section .data
isr_stubs:
%assign i 0
%rep 256
    dq isr_stub_%+i
%assign i i+1
%endrep

section .note.GNU-stack noalloc noexec nowrite progbits
