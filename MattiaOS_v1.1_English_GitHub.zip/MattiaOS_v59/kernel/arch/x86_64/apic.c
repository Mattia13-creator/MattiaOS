#include "apic.h"
#include "cpu.h"
#include "../../mm/vmm.h"    /* g_hhdm_offset — LAPIC accessed via HHDM */
#include "../../acpi/acpi.h" /* acpi_get_hpet, acpi_hpet_period_fs — calibration HPET */

/*
 * s_lapic_virt — address VIRTUALE of the register base LAPIC.
 * Il LAPIC AND' MMIO: NOT AND' in RAM AND Limine NOT the map in modo identita'.
 * L'unica maptura valid after vmm_init() AND' l'HHDM
 * (g_hhdm_offset + address_fisico_LAPIC).
 */
static volatile uint32_t *s_lapic_virt = NULL;

static void lapic_write(uint32_t reg, uint32_t val) {
    s_lapic_virt[reg / 4] = val;
}

static uint32_t lapic_read(uint32_t reg) {
    return s_lapic_virt[reg / 4];
}

void lapic_init(void) {
    uint64_t msr = rdmsr(MSR_IA32_APIC_BASE);
    uint64_t lapic_phys = msr & 0xFFFFF000ULL;

    wrmsr(MSR_IA32_APIC_BASE, msr | APIC_BASE_ENABLE);

    /* Map the LAPIC via HHDM */
    s_lapic_virt = (volatile uint32_t *)(lapic_phys + g_hhdm_offset);

    /* Enable the LAPIC software (Spurious Interrupt Vector Register bit 8) */
    lapic_write(LAPIC_SPURIOUS, LAPIC_SPURIOUS_ENABLE | 0xFF);

    /*
     * FIX v3.8: configura LVT LINT0 AND LINT1.
     *
     * LINT0 — connected to the PIC 8259 in "Virtual Wire Mode".
     * Deve essere in modalità ExtINT (delivery mode 7) for permettere to the PIC
     * of consegnare interrupt via the ciclo INTA.  Senza this riga,
     * the LAPIC lascia LINT0 in modalità "Fixed/Masked" (value of reset
     * 0x00010000) AND the IRQ of the PIC NOT raggiungono mai the CPU.
     *
     * Nota: in systems with I/O APIC, LINT0 ExtINT è to path of fallback.
     * La via principale è I/O APIC → LAPIC, configurata from ioapic_init().
     * Teniamo EntINT active up LINT0 as backup for robustezza.
     *
     * LINT1 — NMI (Non-Maskable Interrupt).
     * Delivery mode 4 = NMI, NOT maskto.
     */
    lapic_write(LAPIC_LVT_LINT0, LAPIC_LVT_DELIVERY_EXTINT);  /* 0x700 */
    lapic_write(LAPIC_LVT_LINT1, LAPIC_LVT_DELIVERY_NMI);      /* 0x400 */

    serial_puts("[LAPIC] Enableto. LINT0=ExtINT(0x700) LINT1=NMI(0x400)\r\n");
}

void lapic_eoi(void) {
    lapic_write(LAPIC_EOI, 0);
}

uint32_t lapic_id(void) {
    return lapic_read(LAPIC_ID) >> 24;
}

void lapic_send_ipi(uint8_t cpu, uint8_t vector) {
    lapic_write(LAPIC_ICR_HIGH, (uint32_t)cpu << 24);
    lapic_write(LAPIC_ICR_LOW, vector);
}

/*
 * g_apic_ticks_per_ms — number of decrementi of the LAPIC timer every millisecondo,
 * calculated from apic_timer_calibrate().
 * Usato from apic_timer_init() as LAPIC_TIMER_INITCNT for tick from 1ms.
 *
 * Strategie of calibration (in ordine of priorità):
 *   1. HPET — if available (QEMU, hardware moderno)
 *   2. PIT 8254 channel 2 — fallback for VirtualBox/hardware without HPET
 *      Il PIT ha clock fixed 1.193182 MHz garantito dallo standard PC.
 *      Usiamo channel 2 for NOT disturbare IRQ0 (channel 0).
 */
uint32_t g_apic_ticks_per_ms = 0;

/* ── Calibration via PIT 8254 channel 2 ────────────────────────────────
 *
 * PIT channel 2, clock fixed 1.193182 MHz.
 *
 * METODO: counter latch polling (NON bit5 of port 0x61).
 * -------------------------------------------------------
 * Il bit5 of port 0x61 dipende from as VirtualBox aggiorna the register
 * lazily — if OUT era già HIGH for to stato residuo, the loop escirebbe
 * IMMEDIATAMENTE, dando elapsed ≈ 0 → g_apic_ticks_per_ms ≈ 0 →
 * LAPIC INITCNT = 0 → timer fermo → g_con_ms scatta to velocità assurda.
 *
 * Il counter latch reads DIRETTAMENTE the counter of the PIT via the
 * comando 0x80 (latch channel 2) seguito from due letture from 0x42.
 * Tracciamo quanto è sceso the counter rispetto to the value iniziale
 * (with management of the wrap to 0xFFFF) finché NOT accumuliamo PIT_TICKS_10MS
 * tick = 10 ms esatti. Completamente indipendente from bit5 / OUT.
 *
 * Sanity check finale: if the risultato è outside range [10000, 5000000]
 * (impossibile up hardware/VM reale), usiamo the fallback 200000
 * (≈ LAPIC to 200 MHz = CPU ~3.2 GHz with div/16, tipico for VirtualBox).
 */
#define PIT_CH2_DATA      0x42U
#define PIT_CMD           0x43U
#define PIT_GATE_PORT     0x61U
#define PIT_TICKS_10MS    11932U  /* 1193182 Hz × 0.010 s = 11932 tick  */
#define APIC_TPM_MIN      10000U  /* sanity: min ticks/ms (≈ 160 MHz LAPIC) */
#define APIC_TPM_MAX   5000000U  /* sanity: max ticks/ms (≈ 80 GHz LAPIC)  */
#define APIC_TPM_FALLBACK 200000U /* fallback if calibration outside range   */

static void apic_calibrate_pit(void) {
    /* 1. Start LAPIC one-shot (maskto) for misurare */
    lapic_write(LAPIC_LVT_TIMER, LAPIC_TIMER_VECTOR | (1u << 16)); /* masked */
    lapic_write(LAPIC_TIMER_DIV,  LAPIC_TIMER_DIV16);
    lapic_write(LAPIC_TIMER_INITCNT, 0xFFFFFFFFU);

    /* 2. Gate ch2 LOW, speaker off */
    uint8_t p61 = inb(PIT_GATE_PORT) & 0xFCU;
    outb(PIT_GATE_PORT, p61);

    /* 3. Programma ch2 mode 2 (rate generator), lobyte/hibyte, binary.
     *    Mode 2 count continuamente without fermarsi: più robusto of mode 0
     *    for the counter latch polling (no dubbio sul wrap semantics). */
    outb(PIT_CMD,      0xB4U);  /* ch2=10, RW=11, mode=010, bin=0 */
    outb(PIT_CH2_DATA, (uint8_t)(0xFFFFU & 0xFFU));
    outb(PIT_CH2_DATA, (uint8_t)(0xFFFFU >> 8));

    /* 4. Gate HIGH → counter parte from 0xFFFF */
    outb(PIT_GATE_PORT, p61 | 0x01U);

    /* 5. Leggi value iniziale of the counter */
    outb(PIT_CMD, 0x80U);  /* Counter Latch for ch2 */
    uint8_t lo = inb(PIT_CH2_DATA);
    uint8_t hi = inb(PIT_CH2_DATA);
    uint16_t prev = (uint16_t)(lo | ((uint16_t)hi << 8));

    uint32_t accumulated = 0;

    /* 6. Accumula tick PIT fino to PIT_TICKS_10MS (10 ms) */
    while (accumulated < PIT_TICKS_10MS) {
        outb(PIT_CMD, 0x80U);
        lo = inb(PIT_CH2_DATA);
        hi = inb(PIT_CH2_DATA);
        uint16_t cur = (uint16_t)(lo | ((uint16_t)hi << 8));

        /* Quanti tick are passati dall'ultima read?
         * In mode 2 the counter scende AND si riload from 0xFFFF every ciclo.
         * Se cur <= prev: normale decremento.
         * Se cur > prev:  the counter ha fatto wrap. */
        if (cur <= prev) {
            accumulated += prev - cur;
        } else {
            accumulated += (uint32_t)prev + (0x10000U - cur);
        }
        prev = cur;
    }

    /* 7. Leggi LAPIC remaining AND calculate */
    uint32_t remaining = lapic_read(LAPIC_TIMER_CURCNT);
    lapic_write(LAPIC_TIMER_INITCNT, 0);    /* stop one-shot */
    outb(PIT_GATE_PORT, p61);               /* gate LOW (pulizia) */

    uint32_t elapsed  = 0xFFFFFFFFU - remaining;
    uint32_t tpm      = elapsed / 10U;  /* ticks in 10ms → ticks_per_ms */

    /* 8. Sanity check */
    if (tpm < APIC_TPM_MIN || tpm > APIC_TPM_MAX) {
        serial_puts("[APIC] WARN: calibration fuori range (");
        /* print tpm grezzo */
        uint32_t v = tpm; char b2[12]; int p2 = 10; b2[11]='\0';
        if(!v){b2[p2--]='0';}else{while(v&&p2>=0){b2[p2--]='0'+(v%10);v/=10;}}
        serial_puts(b2+p2+1);
        serial_puts("), uso fallback 200000\r\n");
        tpm = APIC_TPM_FALLBACK;
    }

    g_apic_ticks_per_ms = tpm;

    serial_puts("[APIC] Calibrato via PIT (counter latch): ");
    uint32_t khz = tpm;
    char buf[12]; int pos = 10; buf[11] = '\0';
    if (!khz) { buf[pos--] = '0'; }
    else { while (khz && pos >= 0) { buf[pos--] = '0' + (khz % 10); khz /= 10; } }
    serial_puts(buf + pos + 1);
    serial_puts(" ticks/ms\r\n");
}

void apic_timer_calibrate(void) {
    void    *hpet        = acpi_get_hpet();
    uint64_t hpet_period = acpi_hpet_period_fs();

    if (!hpet || hpet_period == 0) {
        /* HPET NOT available (es. VirtualBox): usa PIT 8254 channel 2. */
        serial_puts("[APIC] HPET non disponibile, calibration via PIT 8254\r\n");
        apic_calibrate_pit();
        return;
    }

    /*
     * Calibration with HPET — 10 ms
     * --------------------------------
     * 1. Configura APIC timer in one-shot, divisore 16, count massimo.
     * 2. Register the value iniziale of the main counter HPET.
     * 3. Attende finché l'HPET NOT misura esattamente 10 ms.
     * 4. Read the tick rimanenti of the LAPIC timer.
     * 5. Calculate ticks_per_ms = tick_elapsed / 10.
     *
     * 10 ms in femtosecondi = 10 * 10^12 fs = 10_000_000_000_000 fs
     * Ticks HPET for 10ms  = 10_000_000_000_000 / hpet_period_fs
     */
    const uint64_t WAIT_FS = 10000000000000ULL;   /* 10 ms in femtosecondi */
    uint64_t hpet_ticks_10ms = WAIT_FS / hpet_period;

    /* Configura LAPIC timer: one-shot, divisore 16, count 0xFFFFFFFF */
    lapic_write(LAPIC_TIMER_DIV, LAPIC_TIMER_DIV16);
    lapic_write(LAPIC_LVT_TIMER, LAPIC_TIMER_VECTOR); /* one-shot: bit 17 = 0 */
    lapic_write(LAPIC_TIMER_INITCNT, 0xFFFFFFFF);

    /* Register counter HPET of partenza */
    uint64_t hpet_start = HPET_READ(hpet, HPET_REG_MAIN_CNT);

    /* Busy-wait for 10 ms esatti */
    while (HPET_READ(hpet, HPET_REG_MAIN_CNT) - hpet_start < hpet_ticks_10ms) {
        __asm__ __volatile__("pause");
    }

    /* Read quanto è rimasto nel LAPIC timer */
    uint32_t remaining = lapic_read(LAPIC_TIMER_CURCNT);

    /* Stop timer one-shot */
    lapic_write(LAPIC_TIMER_INITCNT, 0);

    uint32_t elapsed = 0xFFFFFFFF - remaining;
    g_apic_ticks_per_ms = elapsed / 10;

    serial_puts("[APIC] Timer calibrato via HPET: ");
    /* Print approssimata in kHz (ticks/ms = kHz) — max 6 cifre */
    uint32_t khz = g_apic_ticks_per_ms;
    /* Converti in stringa decimale (semplice, without libc) */
    char buf[12];
    int  pos = 10;
    buf[11] = '\0';
    if (khz == 0) {
        buf[pos--] = '0';
    } else {
        while (khz > 0 && pos >= 0) {
            buf[pos--] = '0' + (khz % 10);
            khz /= 10;
        }
    }
    serial_puts(buf + pos + 1);
    serial_puts(" ticks/ms\n");
}

void apic_timer_init(void) {
    apic_timer_calibrate();

    /* Configura LAPIC timer in periodic mode, vector 0x20, divisore 16 */
    lapic_write(LAPIC_LVT_TIMER, LAPIC_TIMER_VECTOR | LAPIC_TIMER_PERIODIC);
    lapic_write(LAPIC_TIMER_DIV, LAPIC_TIMER_DIV16);

    /*
     * Set the counter iniziale for tick from 1 ms.
     * g_apic_ticks_per_ms è stato calculated from apic_timer_calibrate()
     * usando l'HPET as riferimento of tempo.  Se HPET NOT available,
     * usa the value of fallback (1 000 000).
     */
    lapic_write(LAPIC_TIMER_INITCNT, g_apic_ticks_per_ms);
}

/* =========================================================================
 * I/O APIC — initialisation redirect table for peripherals legacy
 *
 * L'I/O APIC è the router principale of the interrupt hardware in modalità APIC.
 * Intercetta the IRQ of the device (keyboard, mouse, ecc.) AND li consegna to the LAPIC
 * of the core of destination to the vector corretto.
 *
 * Registers I/O APIC (accesso indiretto via IOREGSEL/IOWIN):
 *   IOAPICID    (0x00): ID dell'I/O APIC
 *   IOAPICVER   (0x01): version + number max redirect entries
 *   IOREDTBL[n] (0x10 + 2*n, 0x11 + 2*n): redirect entry n (64-bit)
 *
 * Redirect Entry (64 bit):
 *   [7:0]   Vector         — vector IDT destination (0x21 for IRQ1)
 *   [10:8]  Delivery Mode  — 000=Fixed, 100=NMI, 111=ExtINT
 *   [11]    Dest Mode      — 0=Physical, 1=Logical
 *   [13]    Pin Polarity   — 0=Active High, 1=Active Low
 *   [15]    Trigger Mode   — 0=Edge, 1=Level
 *   [16]    Mask           — 1=maskto, 0=active
 *   [63:56] Destination    — LAPIC ID destination (Physical Mode)
 * ========================================================================= */

/* Accesso I/O APIC via IOREGSEL (offset 0x00) AND IOWIN (offset 0x10) */
static volatile uint32_t *s_ioapic_virt = NULL;

static void ioapic_write(uint8_t reg, uint32_t val) {
    s_ioapic_virt[0] = reg;          /* scrivi indice in IOREGSEL */
    s_ioapic_virt[4] = val;          /* scrivi datum in IOWIN (offset 0x10 = indice 4) */
}

static uint32_t ioapic_read(uint8_t reg) {
    s_ioapic_virt[0] = reg;
    return s_ioapic_virt[4];
}

/* Write to redirect entry to 64-bit (due write to 32-bit) */
static void ioapic_set_redir(uint8_t intin, uint32_t lo, uint32_t hi) {
    ioapic_write(0x10 + 2 * intin,     lo);
    ioapic_write(0x10 + 2 * intin + 1, hi);
}

void ioapic_init(void) {
    /*
     * Recupera l'address physical dell'I/O APIC from the MADT ACPI.
     * In VirtualBox with chipset PIIX3, c'è sempre to I/O APIC to 0xFEC00000.
     */
    acpi_cpu_info_t    cpus[ACPI_MAX_CPUS];
    acpi_ioapic_info_t ioapics[ACPI_MAX_IOAPICS];
    int nioapics = 0;

    int ncpus = acpi_get_madt(cpus, &nioapics, ioapics);
    (void)ncpus;

    uint32_t ioapic_phys = 0xFEC00000;  /* default if MADT NOT available */
    if (nioapics > 0) {
        ioapic_phys = ioapics[0].address;
        serial_printf("[IOAPIC] Findto in MADT: phys=0x%x gsi_base=%u\r\n",
                      ioapic_phys, ioapics[0].gsi_base);
    } else {
        serial_puts("[IOAPIC] MADT senza I/O APIC, uso default 0xFEC00000\r\n");
    }

    /* L'I/O APIC è MMIO to address physical noto, accessibile via HHDM */
    s_ioapic_virt = (volatile uint32_t *)(ioapic_phys + g_hhdm_offset);

    /* Leggi version AND number massimo of redirect entries */
    uint32_t ver      = ioapic_read(0x01);
    uint32_t max_redir = (ver >> 16) & 0xFF;
    serial_printf("[IOAPIC] ver=0x%x max_redir=%u\r\n", ver, max_redir);

    /*
     * Mask TUTTE the redirect entries before of configurare.
     * Il firmware (SeaBIOS) potrebbe aver lasciato entries attive with vectors
     * arbitrari that potrebbero causare interrupt spuri nella nostra IDT.
     */
    for (uint32_t i = 0; i <= max_redir; i++) {
        ioapic_set_redir((uint8_t)i, 0x00010000, 0);  /* vector=0, masked */
    }

    /* LAPIC ID of the BSP (CPU 0) — destination of the interrupt */
    uint32_t bsp_lapic_id = lapic_id();
    uint32_t dest_hi = bsp_lapic_id << 24;

    /*
     * IRQ1 → INTIN#1 → vector 0x21
     *   Delivery: Fixed (000)
     *   Dest mode: Physical (0)
     *   Polarity:  Active High (0)
     *   Trigger:   Edge (0)
     *   Mask:      0 (active!)
     *   Dest:      BSP LAPIC ID
     *
     * Standard PC: IRQ1 (keyboard) = GSI 1 = INTIN#1 (no ISO override).
     */
    ioapic_set_redir(1, 0x21, dest_hi);
    serial_printf("[IOAPIC] IRQ1 → INTIN#1 → vec 0x21, LAPIC %u\r\n", bsp_lapic_id);

    /*
     * IRQ12 → INTIN#12 → vector 0x2C  (mouse PS/2)
     */
    if (max_redir >= 12) {
        ioapic_set_redir(12, 0x2C, dest_hi);
        serial_printf("[IOAPIC] IRQ12 → INTIN#12 → vec 0x2C, LAPIC %u\r\n", bsp_lapic_id);
    }

    /*
     * CRITICO: mask completely the PIC 8259 after aver programmato
     * l'I/O APIC. In modalità I/O APIC, the PIC opera in "legacy mode" AND
     * NON deve più sendre interrupt to the processr — the fa only l'IOAPIC.
     *
     * Se the PIC rimane active with IRQ1 NOT maskto, può generare
     * interrupt spuri (vector 0x21) in parallelo all'IOAPIC, causando
     * doppio handling dello stesso keypress AND comportmento imprevedibile.
     *
     * Mascheriamo 0xFF master AND 0xFF slave: all the IRQ periferici
     * passano ora ESCLUSIVAMENTE via I/O APIC → LAPIC.
     *
     * Nota: the PIC rimane remapped to 0x20/0x28 (fatto from pic_init)
     * ma with all the IRQ maskti NOT genera mai interrupt.
     */
    outb(0x21, 0xFF);   /* Mask all the IRQ PIC master */
    outb(0xA1, 0xFF);   /* Mask all the IRQ PIC slave  */
    serial_puts("[IOAPIC] PIC 8259 completamente maskto (IOAPIC-only mode)\r\n");

}
