#include "idt.h"
#include "cpu.h"
#include "gdt.h"
#include "../../include/errno.h"

static idt_entry_t s_idt[IDT_ENTRIES];
static idtr_t      s_idtr;

extern void *isr_stubs[IDT_ENTRIES];

void idt_set_handler(uint8_t vector, void *handler, uint8_t type, uint8_t ist) {
    uint64_t addr = (uint64_t)handler;
    s_idt[vector].offset_low  = addr & 0xFFFF;
    s_idt[vector].offset_mid  = (addr >> 16) & 0xFFFF;
    s_idt[vector].offset_high = (addr >> 32) & 0xFFFFFFFF;
    s_idt[vector].selector    = KERNEL_CS;
    s_idt[vector].ist         = ist;
    s_idt[vector].type_attr   = type;
    s_idt[vector].reserved    = 0;
}

void idt_init(void) {
    for (int i = 0; i < IDT_ENTRIES; i++) {
        idt_set_handler(i, isr_stubs[i], IDT_GATE_INT, 0);
    }
    /* Double Fault must use IST1 (guaranteed valid stack) */
    idt_set_handler(8,  isr_stubs[8],  IDT_GATE_INT, 1);
    /* NMI uses IST2 */
    idt_set_handler(2,  isr_stubs[2],  IDT_GATE_INT, 2);
    /* Machine Check uses IST3 */
    idt_set_handler(18, isr_stubs[18], IDT_GATE_INT, 3);

    s_idtr.size   = sizeof(s_idt) - 1;
    s_idtr.offset = (uint64_t)&s_idt;

    asm volatile("lidt %0" : : "m"(s_idtr));
}

/* IRQ dispatch table — definita in drivers/irq.c */
typedef void (*irq_handler_t)(interrupt_frame_t *frame);
extern irq_handler_t g_irq_handlers[256];

/* LAPIC EOI — definita in arch/x86_64/apic.c */
extern void lapic_eoi(void);

static void serial_hex64(uint64_t v) {
    const char *h = "0123456789abcdef";
    serial_puts("0x");
    for (int i = 60; i >= 0; i -= 4)
        serial_putchar(h[(v >> i) & 0xF]);
}

static const char *s_exc_names[32] = {
    "Divide-by-zero",    "Debug",               "NMI",               "Breakpoint",
    "Overflow",          "Bound Range",          "Invalid Opcode",    "Device NA",
    "Double Fault",      "Copro Seg Overrun",    "Invalid TSS",       "Seg Not Present",
    "Stack Fault",       "General Protection",   "Page Fault",        "Reserved",
    "x87 FP",            "Alignment Check",      "Machine Check",     "SIMD FP",
    "Virt Exception",    "Control Protection",   "Reserved",          "Reserved",
    "Reserved",          "Reserved",             "Reserved",          "Reserved",
    "Hypervisor Inj",    "VMM Comm",             "Security",          "Reserved"
};

/* VGA of emergenza — writes direttamente in VGA text 0xB8000, riga 23-24 */
static void panic_vga_puts(const char *s, uint16_t attr) {
    volatile uint16_t *vga = (volatile uint16_t *)0xB8000;
    /* Riga 23: header rosso up nero */
    static int panic_col = 0;
    static int panic_row = 23;
    while (*s) {
        if (*s == '\n') { panic_row++; panic_col = 0; s++; continue; }
        if (panic_row >= 25) panic_row = 23;
        vga[panic_row * 80 + panic_col] = attr | (uint8_t)*s;
        panic_col++;
        if (panic_col >= 80) { panic_col = 0; panic_row++; }
        s++;
    }
}

static void panic_vga_hex64(uint64_t v) {
    static const char h[] = "0123456789ABCDEF";
    char buf[19]; buf[0]='0'; buf[1]='x';
    for (int i = 0; i < 16; i++)
        buf[2+i] = h[(v >> (60 - i*4)) & 0xF];
    buf[18] = '\0';
    panic_vga_puts(buf, 0x4F00); /* rosso brillante up nero */
}

static void dump_exception(interrupt_frame_t *frame) {
    uint64_t vec = frame->vector;

    /* --- VGA: riga 22 = barra rossa, righe 23-24 = dettagli --- */
    volatile uint16_t *vga = (volatile uint16_t *)0xB8000;
    /* Barra rossa riga 22 */
    for (int c = 0; c < 80; c++) vga[22*80+c] = 0x4F00 | ' ';

    /* "*** KERNEL PANIC *** EXC XX: <name>" */
    panic_vga_puts("*** KERNEL PANIC *** EXC ", 0x4F00);
    {
        char d[3];
        d[0] = '0' + (vec / 10) % 10;
        d[1] = '0' + vec % 10;
        d[2] = '\0';
        panic_vga_puts(d, 0x4F00);
    }
    panic_vga_puts(": ", 0x4F00);
    panic_vga_puts(vec < 32 ? s_exc_names[vec] : "Unknown", 0x4F00);
    panic_vga_puts("\n", 0x4F00);

    /* RIP, CR2, ERR */
    panic_vga_puts("RIP=", 0x4E00);  panic_vga_hex64(frame->rip);
    panic_vga_puts(" RSP=", 0x4E00); panic_vga_hex64(frame->rsp);
    if (vec == 14) {
        uint64_t cr2;
        asm volatile("mov %%cr2, %0" : "=r"(cr2));
        panic_vga_puts(" CR2=", 0x4E00); panic_vga_hex64(cr2);
    }
    panic_vga_puts(" ERR=", 0x4E00); panic_vga_hex64(frame->error_code);

    /* --- Serial (stesso output) --- */
    serial_puts("\r\n\r\n*** KERNEL PANIC *** Exception ");
    serial_putchar('0' + (vec / 10) % 10);
    serial_putchar('0' + vec % 10);
    serial_puts(": ");
    serial_puts(vec < 32 ? s_exc_names[vec] : "Unknown");
    serial_puts("\r\n  RIP="); serial_hex64(frame->rip);
    serial_puts("  RSP="); serial_hex64(frame->rsp);
    serial_puts("\r\n  ERR="); serial_hex64(frame->error_code);
    if (vec == 14) {
        uint64_t cr2;
        asm volatile("mov %%cr2, %0" : "=r"(cr2));
        serial_puts("  CR2="); serial_hex64(cr2);
    }
    serial_puts("\r\n");

    asm volatile("cli");
    for (;;) asm volatile("hlt");
}

void isr_handler(interrupt_frame_t *frame) {
    uint64_t vec = frame->vector;

    /* CPU exceptions (vectors 0-31) */
    if (vec < 0x20) {
        dump_exception(frame);
        return;
    }

    /* Hardware IRQ (vectors 0x20-0xFF) — dispatch to the table of the driver */
    if (g_irq_handlers[vec])
        g_irq_handlers[vec](frame);

    /*
     * EOI to the PIC 8259 for the IRQ periferici (vectors 0x21-0x2F).
     *
     * Vector 0x20 = LAPIC timer (NOT passa from the PIC → EOI only to the LAPIC).
     * Vectors 0x21-0x27 = IRQ1-7 of the PIC master  → EOI only to the master.
     * Vectors 0x28-0x2F = IRQ8-15 of the PIC slave   → EOI to slave + master.
     *
     * Senza this EOI the PIC mantiene the linea IRQ asserted AND NOT genera
     * mai più interrupt for the stesso device (es. keyboard).
     *
     * Nota: the numbers of the ports are costanti PIC, definite in cpu.c.
     * Li ripetiamo qui as letterali for evitare dependencies circolari.
     *   0x20 = PIC_MASTER_CMD  (EOI command = 0x20)
     *   0xA0 = PIC_SLAVE_CMD
     */
    if (vec >= 0x21 && vec <= 0x2F) {
        if (vec >= 0x28) outb(0xA0, 0x20);  /* EOI to the PIC slave  */
        outb(0x20, 0x20);                    /* EOI to the PIC master */
    }

    /* Segnala end interrupt to the LAPIC (EOI LAPIC — sempre necessary) */
    lapic_eoi();
}
