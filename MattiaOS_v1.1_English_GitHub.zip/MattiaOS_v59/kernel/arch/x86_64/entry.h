#ifndef MATTIAOS_ENTRY_H
#define MATTIAOS_ENTRY_H

/*
 * kernel/arch/x86_64/entry.h — punto of entry kernel
 *
 * entry.c implementa kernel_main() chiamata direttamente from the boot loader
 * (Limine) via the linker script.  Non ha API pubblica: the structures
 * data Limine (fb_request, memmap_request, …) usate from altri moduli
 * are dichiarate extern nei rispettivi header (fb.h, pmm.h, vmm.h).
 */

/* Dichiarazione simbolo of entrata — usata from the linker script */
void kernel_main(void);

#endif /* MATTIAOS_ENTRY_H */
