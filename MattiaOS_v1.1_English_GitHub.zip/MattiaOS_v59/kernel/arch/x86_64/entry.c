#include <limine.h>
#include "gdt.h"
#include "idt.h"
#include "apic.h"
#include "cpu.h"
#include "../mm/pmm.h"
#include "../mm/vmm.h"
#include "../mm/slab.h"
#include "../acpi/acpi.h"
#include "../fs/vfs.h"
#include "../fs/tmpfs.h"
#include "../fs/devfs.h"
#include "../drivers/pci.h"
#include "../drivers/input/keyboard.h"
#include "../drivers/input/ps2.h"

/* ── Limine boot protocol requests ─────────────────────────────────────── */
__attribute__((used, section(".limine_requests_start")))
static volatile LIMINE_REQUESTS_START_MARKER;
__attribute__((used, section(".limine_requests")))
static volatile LIMINE_BASE_REVISION(2);
__attribute__((used, section(".limine_requests")))
volatile struct limine_framebuffer_request fb_request = {
    .id = LIMINE_FRAMEBUFFER_REQUEST, .revision = 0 };
__attribute__((used, section(".limine_requests")))
static volatile struct limine_memmap_request memmap_request = {
    .id = LIMINE_MEMMAP_REQUEST, .revision = 0 };
__attribute__((used, section(".limine_requests")))
static volatile struct limine_kernel_address_request kaddr_request = {
    .id = LIMINE_KERNEL_ADDRESS_REQUEST, .revision = 0 };
__attribute__((used, section(".limine_requests")))
static volatile struct limine_hhdm_request hhdm_request = {
    .id = LIMINE_HHDM_REQUEST, .revision = 0 };
__attribute__((used, section(".limine_requests")))
static volatile struct limine_rsdp_request rsdp_request = {
    .id = LIMINE_RSDP_REQUEST, .revision = 0 };
__attribute__((used, section(".limine_requests")))
static volatile struct limine_smp_request smp_request = {
    .id = LIMINE_SMP_REQUEST, .revision = 0 };
__attribute__((used, section(".limine_requests_end")))
static volatile LIMINE_REQUESTS_END_MARKER;

extern void pci_enumerate(void);
extern void drivers_init(void);

#include "../proc/process.h"

#define MATTIAOS_VERSION "v1.1"

/* ═══════════════════════════════════════════════════════════════════════════
 * INTERNAL UTILITIES (no libc)
 * ═══════════════════════════════════════════════════════════════════════════ */

static void u64_to_dec(uint64_t v, char *out) {
    char tmp[22]; int i = 20; tmp[21] = 0;
    if (v == 0) { out[0] = '0'; out[1] = 0; return; }
    while (v > 0) { tmp[--i] = '0' + (int)(v % 10); v /= 10; }
    int j = 0; while (tmp[i]) out[j++] = tmp[i++]; out[j] = 0;
}

/* Converts signed int to decimal string (for negative errno codes) */
static void int_to_dec(int v, char *out) {
    if (v >= 0) { u64_to_dec((uint64_t)v, out); return; }
    out[0] = '-'; u64_to_dec((uint64_t)(-v), out + 1);
}

static int kstrcmp(const char *a, const char *b) {
    while (*a && *b && *a == *b) { a++; b++; }
    return (unsigned char)*a - (unsigned char)*b;
}

static int kstrncmp(const char *a, const char *b, size_t n) {
    for (size_t i = 0; i < n; i++) {
        if (a[i] != b[i]) return (unsigned char)a[i] - (unsigned char)b[i];
        if (!a[i]) return 0;
    }
    return 0;
}

/* ═══════════════════════════════════════════════════════════════════════════
 * LOGGING: klog_vga + klog_detail
 * ═══════════════════════════════════════════════════════════════════════════ */

void klog_vga(int level, const char *sub, const char *msg) {
    static const char * const pfx_ser[] = {
        "[BOOT] ", "[OK]   ", "[INFO] ", "[WARN] ", "[ERROR]", "[PANIC]" };
    static const uint16_t pfx_vga[] = {
        0x0700, 0x0A00, 0x0B00, 0x0E00, 0x0C00, 0x0C00 };
    if ((unsigned)level > 5) level = 2;

    /* VGA FIRST — guarantees visual output even if serial stalls */
    uint16_t a = pfx_vga[level];
    vga_puts_attr(pfx_ser[level], a); vga_putchar_attr(' ', a);
    if (sub) {
        vga_putchar_attr('[', 0x0800); vga_puts_attr(sub, 0x0800);
        vga_putchar_attr(']', 0x0800); vga_putchar_attr(' ', 0x0700);
    }
    vga_puts_attr(msg, 0x0F00); vga_putchar_attr('\n', 0x0700);

    /* Serial after */
    serial_puts("\r\n"); serial_puts(pfx_ser[level]); serial_putchar(' ');
    if (sub) { serial_putchar('['); serial_puts(sub); serial_puts("] "); }
    serial_puts(msg);
}

static void klog_detail(const char *label, const char *val) {
    vga_puts_attr("         +-- ", 0x0800);
    vga_puts_attr(label, 0x0700); vga_puts_attr(val, 0x0B00);
    vga_putchar_attr('\n', 0x0700);
    serial_puts("\r\n         +-- "); serial_puts(label); serial_puts(val);
}

/* ═══════════════════════════════════════════════════════════════════════════
 * EARLY PANIC
 * ═══════════════════════════════════════════════════════════════════════════ */

static void __attribute__((noreturn)) kpanic_early(const char *msg) {
    vga_puts_attr("\n\n  *** KERNEL PANIC ***\n  ", 0x4F00);
    vga_puts_attr(msg, 0x4F00);
    vga_puts_attr("\n  System halted.\n", 0x4F00);
    serial_printf("\r\n[PANIC] %s\r\n", msg);
    for (;;) asm volatile("cli; hlt");
}

/* ═══════════════════════════════════════════════════════════════════════════
 * DUMP HELPERS
 * ═══════════════════════════════════════════════════════════════════════════ */

static void dump_pci_vga(void) {
    static const char hx[] = "0123456789ABCDEF";
    char buf[8];
    u64_to_dec(g_pci_device_count, buf);
    klog_detail("Devices found: ", buf);

    for (uint32_t i = 0; i < g_pci_device_count; i++) {
        pci_device_t *d = &g_pci_devices[i];
        serial_printf("    [%02u] %02x:%02x.%x  ven=%04x dev=%04x  cls=%02x/%02x\r\n",
            i, d->bus, d->dev, d->func,
            d->vendor_id, d->device_id, d->class_code, d->subclass);
    }

    /* Show on VGA non-bridge devices (max 4) */
    uint32_t shown = 0;
    for (uint32_t i = 0; i < g_pci_device_count && shown < 4; i++) {
        pci_device_t *d = &g_pci_devices[i];
        if (d->class_code == 0x06 && d->subclass == 0x00) continue;

        const char *cls = "?";
        if      (d->class_code==0x01 && d->subclass==0x06) cls = "AHCI";
        else if (d->class_code==0x01 && d->subclass==0x08) cls = "NVMe";
        else if (d->class_code==0x02)                       cls = "NIC";
        else if (d->class_code==0x03)                       cls = "VGA";
        else if (d->class_code==0x0C && d->subclass==0x03) cls = "USB";
        else if (d->class_code==0x06 && d->subclass==0x01) cls = "ISA Bridge";
        else if (d->class_code==0x01)                       cls = "Storage";

        vga_puts_attr("         +-- ", 0x0800);
        char h[5]; h[4]=0;
        h[0]=hx[(d->vendor_id>>12)&0xF]; h[1]=hx[(d->vendor_id>>8)&0xF];
        h[2]=hx[(d->vendor_id>>4)&0xF];  h[3]=hx[d->vendor_id&0xF];
        vga_puts_attr(h, 0x0B00); vga_putchar_attr(':', 0x0700);
        h[0]=hx[(d->device_id>>12)&0xF]; h[1]=hx[(d->device_id>>8)&0xF];
        h[2]=hx[(d->device_id>>4)&0xF];  h[3]=hx[d->device_id&0xF];
        vga_puts_attr(h, 0x0B00);
        vga_putchar_attr(' ', 0x0700); vga_puts_attr(cls, 0x0F00);
        vga_putchar_attr('\n', 0x0700);
        shown++;
    }
}

/* ═══════════════════════════════════════════════════════════════════════════
 * KERNEL CONSOLE — interactive terminal v3.12 (clean input architecture)
 *
 * INPUT ARCHITECTURE:
 *   - IRQ1 handler: deposits raw bytes ONLY, does not call keyboard_process.
 *   - LAPIC timer (vec 0x20): increments g_con_ms every millisecond.
 *   - Console loop: sti;hlt → keyboard_process() → poll events → autorepeat.
 * ═══════════════════════════════════════════════════════════════════════════ */

#define CON_MAX 256

static char s_line[CON_MAX];
static int  s_len = 0;
static int  s_cur = 0;
static int  s_input_row = 0;
static int  s_input_col = 0;

/* ── Command history ─────────────────────────────────────────────────────
 * Ring buffer of HIST_MAX strings. s_hist_tail points to the last added
 * entry. s_hist_idx is the navigation index (-1 = none, 0 = last,
 * 1 = second-to-last, ...). Reset to -1 on every Enter or Ctrl+C. */
#define HIST_MAX 32
static char s_hist[HIST_MAX][CON_MAX];
static int  s_hist_count = 0;   /* valid entries, max HIST_MAX */
static int  s_hist_tail  = -1;  /* ring index of last added entry */
static int  s_hist_idx   = -1;  /* -1 = not navigating */
static char s_hist_saved[CON_MAX]; /* saves current line during navigation */

/* Adds a line to history (if non-empty and different from the last) */
static void hist_push(const char *line) {
    if (!line || !line[0]) return;
    /* Do not duplicate the last entry */
    if (s_hist_count > 0) {
        int last = (s_hist_tail + HIST_MAX) % HIST_MAX;
        int eq = 1;
        for (int i = 0; line[i] || s_hist[last][i]; i++)
            if (line[i] != s_hist[last][i]) { eq = 0; break; }
        if (eq) return;
    }
    s_hist_tail = (s_hist_tail + 1) % HIST_MAX;
    int j = 0;
    while (line[j] && j < CON_MAX - 1) { s_hist[s_hist_tail][j] = line[j]; j++; }
    s_hist[s_hist_tail][j] = '\0';
    if (s_hist_count < HIST_MAX) s_hist_count++;
}

/* ── Scrollback ──────────────────────────────────────────────────────────
 * s_sb_active: true when we are in scrollback mode.
 * s_sb_offset: how many lines back we are looking (1=last). */
static bool s_sb_active = false;
static int  s_sb_offset = 0;

/* ── Current working directory ───────────────────────────────────────── */
static char s_cwd[256] = "/";

/* Builds absolute path: if arg starts with '/' it is already absolute,
 * otherwise it is appended to s_cwd. */
static void con_build_path(const char *arg, char *out, size_t sz) {
    if (!arg || !*arg) {
        /* no argument: use cwd */
        size_t i = 0;
        while (s_cwd[i] && i < sz - 1) { out[i] = s_cwd[i]; i++; }
        out[i] = '\0';
        return;
    }
    if (arg[0] == '/') {
        /* absolute path */
        size_t i = 0;
        while (arg[i] && i < sz - 1) { out[i] = arg[i]; i++; }
        out[i] = '\0';
        return;
    }
    /* relative path: cwd + "/" + arg */
    size_t clen = 0; while (s_cwd[clen]) clen++;
    size_t alen = 0; while (arg[alen])   alen++;
    if (clen == 1 && s_cwd[0] == '/') {
        /* cwd is root: avoid double slash */
        out[0] = '/';
        size_t i = 0;
        while (arg[i] && i + 1 < sz - 1) { out[i + 1] = arg[i]; i++; }
        out[i + 1] = '\0';
    } else {
        size_t i = 0;
        while (s_cwd[i] && i < sz - 1) { out[i] = s_cwd[i]; i++; }
        if (i < sz - 1) { out[i++] = '/'; }
        size_t j = 0;
        while (arg[j] && i < sz - 1) { out[i++] = arg[j++]; }
        out[i] = '\0';
    }
}

/* Simple local kstrcpy (no libc in kernel) */
static void con_strcpy(char *d, const char *s, size_t n) {
    size_t i=0; while(s[i] && i<n-1){d[i]=s[i];i++;} d[i]='\0';
}

/* LAPIC timer → ms counter.
 * GLOBAL (not static): visible from keyboard.c if needed. */
volatile uint32_t g_con_ms  = 0;
volatile int      g_ctrlc   = 0;   /* set by Ctrl+C; read in loop and commands */

static void con_timer_handler(interrupt_frame_t *frame) {
    (void)frame;
    g_con_ms++;
}

/* ── Software autorepeat ──────────────────────────────────────────────────
 *
 * VirtualBox NEM sends repeated MAKE codes during hardware typematic
 * (not MAKE+BREAK+MAKE pairs). The bitset s_pressed in keyboard.c filters
 * all duplicate MAKEs. A BREAK always corresponds to a real key release.
 *
 * Simple 3-state state machine:
 *   AR_IDLE   → no key held
 *   AR_DELAY  → key pressed, waiting for initial delay (1/4 s)
 *   AR_REPEAT → delay elapsed, inserts 20 characters per second
 *
 * We do NOT use AR_HOLDOFF: it would cause false negatives on rapid
 * re-presses (< ~15ms between release and re-press, normal for fast typists).
 */
#define AR_DELAY_MS   250U   /* 1/4 second before repeat starts */
#define AR_REPEAT_MS   50U   /* 50ms between repeats = 20 cps   */

typedef enum { AR_IDLE=0, AR_DELAY, AR_REPEAT } ar_state_t;
static ar_state_t s_ar_state = AR_IDLE;
static vk_t       s_ar_key   = VK_NONE;
static char       s_ar_ascii = 0;
static uint32_t   s_ar_ms    = 0;


static void con_puts(const char *s, uint16_t a) {
    vga_puts_attr(s, a); serial_puts(s);
}
static void con_putc(char c) {
    vga_putchar_attr(c, 0x0F00); serial_putchar(c);
}
static void con_nl(void) {
    vga_putchar_attr('\n', 0x0700); serial_puts("\r\n");
}
static void con_hex16(uint16_t v) {
    static const char h[] = "0123456789ABCDEF";
    char b[5]; b[4]=0;
    b[0]=h[(v>>12)&0xF]; b[1]=h[(v>>8)&0xF];
    b[2]=h[(v>>4)&0xF];  b[3]=h[v&0xF];
    vga_puts_attr(b, 0x0B00); serial_puts(b);
}
static void con_prompt(void) {
    vga_puts_attr("\nMattiaOS:", 0x0A00);
    vga_puts_attr(s_cwd,        0x0B00);
    vga_puts_attr("> ",         0x0F00);
    serial_puts("\r\nMattiaOS:");
    serial_puts(s_cwd);
    serial_puts("> ");
    s_len = 0;
    s_cur = 0;
    vga_get_pos(&s_input_row, &s_input_col);
}

/* ── commands ─────────────────────────────────────────────────────────── */

/* ── Easter egg — ASCII art "MattiaOS" ────────────────────────────────────
 *
 * Font: 5x5 pixel block letters (I = 3 wide), 1-space gap between letters.
 * Layout "M A T T I A O S":
 *   M(5) + gap(1) + A(5) + gap(1) + T(5) + gap(1) + T(5) + gap(1) +
 *   I(3) + gap(1) + A(5) + gap(1) + O(5) + gap(1) + S(5) = 44 chars content
 *   + 2-space indent = 46 chars per row (fits in 80-col VGA).
 *
 * Letter bitmaps (5 rows each, '#' = pixel on, ' ' = pixel off):
 *   M: #   #  ## ##  # # #  #   #  #   #
 *   A:  ###   #   #  #####  #   #  #   #
 *   T: #####    #      #      #      #
 *   I: ###    #     #     #    ###
 *   O:  ###   #   #  #   #  #   #   ###
 *   S:  ####  #      ###      #  ####
 */
static void cmd_easteregg(void) {
    con_nl();
    /* Row 1 */
    con_puts("  #   #  ###  ##### ##### ###  ###   ###   ####\n", 0x0B00);
    /* Row 2 */
    con_puts("  ## ## #   #   #     #    #  #   # #   # #    \n", 0x0A00);
    /* Row 3 */
    con_puts("  # # # #####   #     #    #  ##### #   #  ### \n", 0x0E00);
    /* Row 4 */
    con_puts("  #   # #   #   #     #    #  #   # #   #     #\n", 0x0D00);
    /* Row 5 */
    con_puts("  #   # #   #   #     #   ### #   #  ###  #### \n", 0x0900);
    con_nl();
    con_puts("        your OS built from scratch. enjoy, Mattia.\n", 0x0800);
    con_nl();
}

static void cmd_help(void) {
    con_nl();
    con_puts("  Available commands:\n",                  0x0B00);
    con_puts("    help         -- this message\n",       0x0700);
    con_puts("    ver          -- version and build info\n", 0x0700);
    con_puts("    mem          -- memory + processes\n", 0x0700);
    con_puts("    pci          -- list PCI devices\n",   0x0700);
    con_puts("    ls [path]    -- list directory\n",     0x0700);
    con_puts("    cd <path>    -- change directory\n\n", 0x0700);
    con_puts("    open <path>  -- view file (pager)\n",  0x0700);
    con_puts("                   arrows=scroll  q/ESC=exit\n", 0x0800);
    con_puts("    edit <path>  -- text editor  Ctrl+S=save  ESC=exit\n", 0x0700);
    con_puts("    tree [path]  -- recursive filesystem tree\n\n", 0x0700);
    con_puts("    clear        -- clear screen\n",       0x0700);
    con_puts("    reboot       -- reboot machine\n",     0x0700);
    con_puts("    halt         -- power off system\n",   0x0700);
    con_puts("    easteregg    -- ?\n",                  0x0800);
    con_puts("    diag         -- internal VFS diagnostics\n", 0x0800);
    con_puts("  Special keys:\n", 0x0B00);
    con_puts("    Ctrl+C       -- cancel current command/input\n", 0x0800);
    con_puts("    UP/DOWN      -- command history\n", 0x0800);
    con_puts("    Shift+UP     -- terminal scrollback\n", 0x0800);
}

static void cmd_ver(void) {
    char buf[16];
    con_nl();
    con_puts("  MattiaOS " MATTIAOS_VERSION " -- Kernel debug build\n", 0x0B00);
    con_puts("  Entry point:   0xFFFFFFFF80000000+\n", 0x0700);
    con_puts("  APIC timer:    ", 0x0700);
    u64_to_dec(g_apic_ticks_per_ms, buf);
    con_puts(buf, 0x0B00); con_puts(" ticks/ms\n", 0x0700);
    con_puts("  Toolchain:     GCC 13.3 x86_64-elf + NASM 3.01\n", 0x0700);
    con_puts("  PMM total:     ", 0x0700);
    u64_to_dec(pmm_total_memory()/(1024*1024), buf);
    con_puts(buf, 0x0B00); con_puts(" MB\n", 0x0700);
}

static void cmd_mem(void) {
    char buf[16];
    con_nl();
    uint64_t total = pmm_total_memory();
    uint64_t free  = pmm_free_memory();
    uint64_t used  = total - free;

    con_puts("  \xC4\xC4 Physical Memory \xC4\xC4\xC4\xC4\xC4\xC4\xC4\xC4\xC4\xC4\xC4\xC4\xC4\xC4\xC4\xC4\xC4\xC4\xC4\xC4\n", 0x0800);
    con_puts("  Total RAM:   ", 0x0700);
    u64_to_dec(total/(1024*1024), buf); con_puts(buf, 0x0B00);
    con_puts(" MB\n", 0x0700);

    con_puts("  Free RAM:    ", 0x0700);
    u64_to_dec(free/(1024*1024), buf);  con_puts(buf, 0x0A00);
    con_puts(" MB\n", 0x0700);

    con_puts("  Used RAM:    ", 0x0700);
    u64_to_dec(used/(1024*1024), buf);  con_puts(buf, 0x0E00);
    con_puts(" MB\n", 0x0700);

    uint64_t pct = total ? (used * 40) / total : 0;
    con_puts("  [", 0x0700);
    for (uint64_t i = 0; i < 40; i++) {
        if (i < pct) { vga_putchar_attr('#', 0x0C00); serial_putchar('#'); }
        else         { vga_putchar_attr('-', 0x0800); serial_putchar('-'); }
    }
    con_puts("] ", 0x0700);
    u64_to_dec(total ? (used*100)/total : 0, buf);
    con_puts(buf, 0x0E00); con_puts("%\n", 0x0700);

    /* ── Running processes ── */
    con_puts("\n  \xC4\xC4 Processes \xC4\xC4\xC4\xC4\xC4\xC4\xC4\xC4\xC4\xC4\xC4\xC4\xC4\xC4\xC4\xC4\xC4\xC4\xC4\xC4\xC4\xC4\xC4\xC4\n", 0x0800);
    con_puts("  PID  STATE       NAME\n", 0x0B00);

    process_t *p = process_get_list();
    if (!p) {
        con_puts("  (no processes in the system)\n", 0x0800);
    } else {
        while (p) {
            u64_to_dec((uint64_t)p->pid, buf);
            size_t blen = 0; while(buf[blen]) blen++;
            con_puts("  ", 0x0700);
            for (size_t i = blen; i < 4; i++) vga_putchar_attr(' ', 0x0700);
            con_puts(buf, 0x0B00);
            con_puts("  ", 0x0700);
            const char *st = "?          ";
            switch(p->state) {
            case PROCESS_RUNNING:  st = "RUNNING    "; break;
            case PROCESS_READY:    st = "READY      "; break;
            case PROCESS_BLOCKED:  st = "BLOCKED    "; break;
            case PROCESS_ZOMBIE:   st = "ZOMBIE     "; break;
            case PROCESS_SLEEPING: st = "SLEEPING   "; break;
            }
            uint16_t sc = (p->state == PROCESS_RUNNING) ? 0x0A00 :
                          (p->state == PROCESS_ZOMBIE)  ? 0x0C00 : 0x0E00;
            con_puts(st, sc);
            con_puts(p->name[0] ? p->name : "(unnamed)", 0x0F00);
            con_putc('\n');
            p = p->next;
        }
    }
}

static void cmd_pci(void) {
    char buf[8];
    con_nl();
    con_puts("  PCI Devices (", 0x0700);
    u64_to_dec(g_pci_device_count, buf);
    con_puts(buf, 0x0B00); con_puts("):\n", 0x0700);

    for (uint32_t i = 0; i < g_pci_device_count; i++) {
        pci_device_t *d = &g_pci_devices[i];
        const char *cls = "?";
        if      (d->class_code==0x01 && d->subclass==0x06) cls = "AHCI";
        else if (d->class_code==0x01 && d->subclass==0x08) cls = "NVMe";
        else if (d->class_code==0x01)                       cls = "Storage";
        else if (d->class_code==0x02)                       cls = "NIC";
        else if (d->class_code==0x03)                       cls = "VGA";
        else if (d->class_code==0x06 && d->subclass==0x00) cls = "Host bridge";
        else if (d->class_code==0x06 && d->subclass==0x01) cls = "ISA bridge";
        else if (d->class_code==0x06)                       cls = "PCI bridge";
        else if (d->class_code==0x0C && d->subclass==0x03) cls = "USB";
        else if (d->class_code==0x04)                       cls = "Multimedia";

        con_puts("  ven=", 0x0700); con_hex16(d->vendor_id);
        con_puts(" dev=", 0x0700);  con_hex16(d->device_id);
        con_puts("  ", 0x0700);
        vga_puts_attr(cls, 0x0B00); serial_puts(cls);
        vga_putchar_attr('\n', 0x0700); serial_puts("\r\n");
    }
}

/* ═══════════════════════════════════════════════════════════════════════════
 * con_check_ctrlc — check Ctrl+C without blocking
 *
 * Calls keyboard_process() to drain the PS/2 port, then drains the event
 * ring looking for ascii==3 (ETX). If found, sets g_ctrlc=1.
 * Must be called inside all long-running loops (cmd_ls, cmd_tree, etc.)
 * so that Ctrl+C interrupts the command immediately without waiting for
 * the return to the main kernel_console loop.
 *
 * Why it did not work before:
 *   Commands ran inside con_exec() → the kernel_console loop was
 *   blocked → keyboard_poll_event() was never called → g_ctrlc
 *   stayed 0 → inner loops never interrupted.
 * ═══════════════════════════════════════════════════════════════════════════ */
static bool con_check_ctrlc(void) {
    keyboard_process();
    key_event_t ev;
    while (keyboard_poll_event(&ev)) {
        if (ev.pressed && ev.ascii == 3) {   /* ETX = Ctrl+C */
            g_ctrlc = 1;
            vga_puts_attr("^C\n", 0x0C00);
            serial_puts("^C\r\n");
        }
    }
    return g_ctrlc != 0;
}

/* ═══════════════════════════════════════════════════════════════════════════
 * cmd_open — full-screen file viewer with scrolling
 *
 * Enters full-screen mode (saves and restores VGA buffer).
 * Supports three types:
 *   TEXT   → lines with line number on left, wrapping at 72 columns
 *   BINARY → hex dump at 4 bytes/row: offset | bits×32 | hex | ASCII
 *   ELF64  → like BINARY with coloured header
 *
 * Navigation:
 *   Up / Down       -- scroll 1 line
 *   PgUp / PgDn     -- scroll OPEN_ROWS lines
 *   Home / End      -- beginning / end of file
 *   q / ESC / ^C    -- exit and restore console screen
 *
 * Lazy loading (text only):
 *   s_ol_off[] stores the start offset of each visual line.
 *   Lines beyond the current screen are indexed on-demand
 *   when scrolling down (never the whole file in RAM).
 *   BSS budget: OPEN_MAX_LINES x 8B = 16KB.
 * ═══════════════════════════════════════════════════════════════════════════ */

#define OPEN_MAX_LINES  2000   /* max indexed lines       -- 16KB BSS */
#define OPEN_ROWS         23   /* visible content rows (25-1-1)       */
#define OPEN_TEXT_W       72   /* text content width (80-8)           */
#define OPEN_BIN_COLS      4   /* bytes per hex dump row              */

/* Static buffers -- BSS */
static uint16_t s_ol_vga[80 * 25];        /* VGA screen save               */
static off_t    s_ol_off[OPEN_MAX_LINES];  /* start offset of each text row */
static uint8_t  s_ol_rbuf[4096];          /* general read buffer           */

/* Screen save for scrollback (16KB BSS, separate from s_ol_vga) */
static uint16_t s_sb_live[80 * 25];

/* ── Editor buffer (used by cmd_open in edit mode) ──────────────────────
 * BSS budget: 8192 bytes. Max editable file size: ED_MAX_SIZE-1 bytes. */
#define ED_MAX_SIZE 8192
static char s_ed_buf[ED_MAX_SIZE];

/* ── VGA helper for open: writes string at absolute position ─────────── */
static int open_at(int row, int col, const char *s, uint16_t attr) {
    while (*s && col < 80) { vga_write_at(row, col++, *s++, attr); }
    return col;
}
static int open_at_u32(int row, int col, uint32_t v, uint16_t attr) {
    char b[12]; u64_to_dec((uint64_t)v, b); return open_at(row, col, b, attr);
}
static int open_at_hex8(int row, int col, uint8_t v, uint16_t attr) {
    static const char h[] = "0123456789abcdef";
    if (col < 80) vga_write_at(row, col++, h[v >> 4], attr);
    if (col < 80) vga_write_at(row, col++, h[v & 0xF], attr);
    return col;
}
static int open_at_hex32(int row, int col, uint32_t v, uint16_t attr) {
    for (int i = 28; i >= 0; i -= 4) {
        static const char h[] = "0123456789abcdef";
        if (col < 80) vga_write_at(row, col++, h[(v >> i) & 0xF], attr);
    }
    return col;
}
static void open_fill(int row, char c, uint16_t attr) {
    for (int col = 0; col < 80; col++) vga_write_at(row, col, c, attr);
}

/* ── Wait for a key (blocking) -- used only inside cmd_open ─────────── */
static key_event_t open_wait_key(void) {
    key_event_t ev;
    for (;;) {
        asm volatile("pause");
        keyboard_process();
        if (keyboard_poll_event(&ev) && ev.pressed) return ev;
    }
}

/* ── Index text lines up to `target` (lazy, append-only) ────────────── */
/* Persistent state between successive calls -- zeroed on file open */
static int  s_ol_cnt;    /* lines already indexed */
static bool s_ol_eof;    /* EOF reached during indexing */
static off_t s_ol_scan;  /* next offset to scan */

static void open_index_until(file_t *f, int target) {
    if (s_ol_eof || s_ol_cnt >= target || s_ol_cnt >= OPEN_MAX_LINES) return;

    int col = 0;

    /* Count columns in the last partially indexed row:
     * If s_ol_cnt>0, s_ol_off[s_ol_cnt-1] is the start of the last row.
     * We need to know which column we reached. Re-read from there. */
    if (s_ol_cnt > 0 && s_ol_scan > s_ol_off[s_ol_cnt - 1]) {
        /* Already past that row -- col = 0 of the next (s_ol_scan already advanced) */
        col = 0;
    }

    off_t read_off = s_ol_scan;

    while (s_ol_cnt < target && s_ol_cnt < OPEN_MAX_LINES) {
        /* Read a chunk */
        f->offset = read_off;
        ssize_t nr = vfs_read(f, s_ol_rbuf, sizeof(s_ol_rbuf));
        if (nr <= 0) { s_ol_eof = true; break; }

        for (ssize_t i = 0; i < nr; i++) {
            uint8_t c = s_ol_rbuf[i];
            if (c == '\n') {
                /* End of line: record start of next line */
                off_t next = read_off + i + 1;
                s_ol_scan = next;
                if (s_ol_cnt < OPEN_MAX_LINES) {
                    if (s_ol_cnt + 1 < OPEN_MAX_LINES) {
                        s_ol_off[s_ol_cnt + 1] = next;
                    }
                    s_ol_cnt++;
                    col = 0;
                }
                if (s_ol_cnt >= target || s_ol_cnt >= OPEN_MAX_LINES) goto done;
            } else if (c == '\r') {
                /* Ignore \r (CRLF support) */
            } else {
                col++;
                if (col >= OPEN_TEXT_W) {
                    /* Wrap: visual line complete without \n */
                    off_t next = read_off + i + 1;
                    s_ol_scan = next;
                    if (s_ol_cnt + 1 < OPEN_MAX_LINES) {
                        s_ol_off[s_ol_cnt + 1] = next;
                    }
                    s_ol_cnt++;
                    col = 0;
                    if (s_ol_cnt >= target || s_ol_cnt >= OPEN_MAX_LINES) goto done;
                }
            }
        }
        read_off += nr;
        s_ol_scan = read_off;
    }
done:;
}

/* ── Draw one text content row (VGA row 1..OPEN_ROWS) ───────────────── */
static void open_draw_text_row(int vga_row, int line_idx, file_t *f) {
    open_fill(vga_row, ' ', 0x0700);

    /* Line number (1-indexed, 5 digits + ": ") */
    int col = 1;
    char lnbuf[8]; u64_to_dec((uint64_t)(line_idx + 1), lnbuf);
    int lnlen = 0; while (lnbuf[lnlen]) lnlen++;
    for (int pad = lnlen; pad < 5; pad++)
        vga_write_at(vga_row, col++, ' ', 0x0800);
    col = open_at(vga_row, col, lnbuf, 0x0800);
    vga_write_at(vga_row, col++, ':', 0x0800);
    vga_write_at(vga_row, col++, ' ', 0x0700);

    /* Read row content from file */
    f->offset = s_ol_off[line_idx];
    ssize_t nr = vfs_read(f, s_ol_rbuf, (size_t)OPEN_TEXT_W);
    if (nr <= 0) return;

    /* Print characters up to \n or end of columns */
    for (ssize_t i = 0; i < nr && col < 80; i++) {
        uint8_t c = s_ol_rbuf[i];
        if (c == '\n' || c == '\r') break;
        if (c < 0x20 || c > 0x7E) c = '.';
        vga_write_at(vga_row, col++, (char)c, 0x0F00);
    }
}

/* ── Draw one binary/ELF content row ────────────────────────────────── */
static void open_draw_bin_row(int vga_row, int bin_row, file_t *f, bool is_elf) {
    open_fill(vga_row, ' ', 0x0700);

    f->offset = (off_t)(bin_row * OPEN_BIN_COLS);
    ssize_t nr = vfs_read(f, s_ol_rbuf, (size_t)OPEN_BIN_COLS);
    if (nr <= 0) return;

    uint16_t bit_attr = is_elf ? 0x0B00 : 0x0A00;
    static const char hx[] = "0123456789abcdef";

    int col = 1;

    /* Column 1: offset 8 hex digits */
    col = open_at_hex32(vga_row, col, (uint32_t)(bin_row * OPEN_BIN_COLS), 0x0800);
    vga_write_at(vga_row, col++, ':', 0x0800);
    vga_write_at(vga_row, col++, ' ', 0x0700);

    /* Column 2: groups of 8 bits */
    for (ssize_t j = 0; j < OPEN_BIN_COLS; j++) {
        uint8_t byte = (j < nr) ? s_ol_rbuf[j] : 0;
        uint16_t ba  = (j < nr) ? bit_attr : 0x0800;
        for (int b = 7; b >= 0; b--) {
            if (col < 80)
                vga_write_at(vga_row, col++, ((byte >> b) & 1) ? '1' : '0', ba);
        }
        if (j < OPEN_BIN_COLS - 1 && col < 80)
            vga_write_at(vga_row, col++, ' ', 0x0700);
    }

    /* Separator */
    if (col < 80) { vga_write_at(vga_row, col++, ' ', 0x0700); }
    if (col < 80) { vga_write_at(vga_row, col++, '|', 0x0800); }
    if (col < 80) { vga_write_at(vga_row, col++, ' ', 0x0700); }

    /* Column 3: hex bytes */
    for (ssize_t j = 0; j < OPEN_BIN_COLS; j++) {
        if (j < nr) {
            col = open_at_hex8(vga_row, col, s_ol_rbuf[j], 0x0B00);
        } else {
            if (col < 80) vga_write_at(vga_row, col++, ' ', 0x0700);
            if (col < 80) vga_write_at(vga_row, col++, ' ', 0x0700);
        }
        if (j < OPEN_BIN_COLS - 1 && col < 80) vga_write_at(vga_row, col++, ' ', 0x0700);
    }

    /* Separator */
    if (col < 80) vga_write_at(vga_row, col++, ' ', 0x0700);
    if (col < 80) vga_write_at(vga_row, col++, '|', 0x0800);
    if (col < 80) vga_write_at(vga_row, col++, ' ', 0x0700);

    /* Column 4: ASCII */
    for (ssize_t j = 0; j < nr && col < 80; j++) {
        uint8_t c = s_ol_rbuf[j];
        char d = (c >= 0x20 && c <= 0x7E) ? (char)c : '.';
        vga_write_at(vga_row, col++, d, 0x0F00);
    }

    (void)hx;
}

/* ── Repaint the full pager screen ──────────────────────────────────── */
static void open_repaint(file_t *f, bool is_text, bool is_elf,
                          int top, int total, const char *name) {
    /* ── Header (row 0) ── */
    open_fill(0, ' ', 0x1F00);
    int col = 1;
    col = open_at(0, col, "[OPEN] ", 0x1E00);
    col = open_at(0, col, name,     0x1F00);
    col = open_at(0, col, "  ",     0x1F00);
    if      (is_elf)   col = open_at(0, col, "ELF64",  0x1B00);
    else if (!is_text) col = open_at(0, col, "BINARY", 0x1A00);
    else               col = open_at(0, col, "TEXT",   0x1F00);
    col = open_at(0, col, "  row ", 0x1700);
    col = open_at_u32(0, col, (uint32_t)(top + 1), 0x1E00);
    col = open_at(0, col, "/", 0x1700);
    col = open_at_u32(0, col, (uint32_t)total,     0x1E00);
    /* Key hint -- right-aligned */
    const char *hint = "ESC/q=exit  \x18\x19=line  PgUp/Dn=page  Home/End ";
    int hlen = 0; while (hint[hlen]) hlen++;
    int hcol = 80 - hlen - 1; if (hcol < col) hcol = col;
    open_at(0, hcol, hint, 0x1700);

    /* ── Content (rows 1..OPEN_ROWS) ── */
    for (int r = 0; r < OPEN_ROWS; r++) {
        int line = top + r;
        int vga_row = r + 1;
        if (line >= total) {
            open_fill(vga_row, ' ', 0x0700);
            if (line == total) open_at(vga_row, 1, "~", 0x0800);
        } else if (is_text) {
            open_draw_text_row(vga_row, line, f);
        } else {
            open_draw_bin_row(vga_row, line, f, is_elf);
        }
    }

    /* ── Footer (row 24) ── */
    open_fill(24, ' ', 0x7000);
    col = 1;
    col = open_at(24, col, " Lines ", 0x7000);
    col = open_at_u32(24, col, (uint32_t)(top + 1), 0x7000);
    col = open_at(24, col, "-", 0x7000);
    int bot = top + OPEN_ROWS; if (bot > total) bot = total;
    col = open_at_u32(24, col, (uint32_t)bot, 0x7000);
    col = open_at(24, col, " of ", 0x7000);
    col = open_at_u32(24, col, (uint32_t)total, 0x7000);
    if (total > 0) {
        uint32_t pct = (uint32_t)((uint64_t)top * 100 / (uint64_t)total);
        col = open_at(24, col, "  (", 0x7000);
        col = open_at_u32(24, col, pct, 0x7000);
        col = open_at(24, col, "%)", 0x7000);
    }
    bool more = (top + OPEN_ROWS) < total;
    open_at(24, col, more ? "  \x19 more..." : "  [END]", 0x7000);

    /* Hide HW cursor during pager (position it off-screen) */
    vga_set_cursor_hw(24, 79);
}

/* ── Main command ───────────────────────────────────────────────────── */
static void cmd_open(const char *arg) {
    if (!arg || !*arg) {
        con_nl();
        con_puts("  usage: open <path>\n", 0x0C00);
        return;
    }
    char path[256];
    con_build_path(arg, path, sizeof(path));
    con_nl();

    file_t *f = vfs_open(path, 0);
    if (!f) {
        con_puts("  open: '", 0x0C00); con_puts(path, 0x0C00);
        con_puts("': file not found\n", 0x0C00);
        return;
    }

    /* ── Detect type from first chunk ── */
    f->offset = 0;
    ssize_t probe = vfs_read(f, s_ol_rbuf, 16);
    if (probe <= 0) {
        con_puts("  open: empty file\n", 0x0800);
        vfs_close(f); return;
    }
    bool is_elf = (probe >= 4 &&
                   s_ol_rbuf[0] == 0x7F && s_ol_rbuf[1] == 'E' &&
                   s_ol_rbuf[2] == 'L'  && s_ol_rbuf[3] == 'F');
    bool is_text = false;
    if (!is_elf) {
        /* Sample first 512 bytes to decide text/binary */
        f->offset = 0;
        ssize_t sample = vfs_read(f, s_ol_rbuf, 512);
        is_text = true;
        for (ssize_t i = 0; i < sample && is_text; i++) {
            uint8_t c = s_ol_rbuf[i];
            if (c != '\t' && c != '\n' && c != '\r' && (c < 0x20 || c > 0x7E))
                is_text = false;
        }
    }

    uint64_t fsize = f->vnode->size;

    /* ── Initialise indexer state (text) ── */
    s_ol_cnt   = 1;           /* row 0 starts at offset 0 */
    s_ol_eof   = false;
    s_ol_scan  = 0;
    s_ol_off[0] = 0;

    /* ── Calculate total rows ── */
    int total;
    if (is_text) {
        open_index_until(f, OPEN_ROWS + 1);
        total = s_ol_cnt;
    } else {
        total = (int)((fsize + OPEN_BIN_COLS - 1) / OPEN_BIN_COLS);
        if (total == 0) total = 1;
    }

    /* ── Save VGA screen and cursor ── */
    volatile uint16_t *vga_base = (volatile uint16_t *)0xB8000;
    for (int i = 0; i < 80 * 25; i++) s_ol_vga[i] = vga_base[i];

    /* ── Pager loop ── */
    int top = 0;

    for (;;) {
        if (is_text) {
            if (!s_ol_eof) open_index_until(f, top + OPEN_ROWS + 2);
            total = s_ol_cnt;
        }

        int max_top = total - OPEN_ROWS;
        if (max_top < 0) max_top = 0;
        if (top > max_top) top = max_top;
        if (top < 0)       top = 0;

        open_repaint(f, is_text, is_elf, top, total, path);

        key_event_t ev = open_wait_key();

        if (ev.ascii == 'q' || ev.ascii == 'Q' ||
            ev.ascii == 3   ||
            ev.keycode == VK_ESCAPE) {
            break;
        }

        if (ev.keycode == VK_UP)   { top--; }
        if (ev.keycode == VK_DOWN) { top++; }
        if (ev.keycode == VK_PGUP) { top -= OPEN_ROWS; }
        if (ev.keycode == VK_PGDN) { top += OPEN_ROWS; }
        if (ev.keycode == VK_HOME) { top = 0; }
        if (ev.keycode == VK_END)  {
            if (is_text) {
                while (!s_ol_eof && s_ol_cnt < OPEN_MAX_LINES)
                    open_index_until(f, s_ol_cnt + OPEN_ROWS);
                total = s_ol_cnt;
            }
            top = total - OPEN_ROWS;
        }
    }

    /* ── Restore VGA screen ── */
    for (int i = 0; i < 80 * 25; i++) vga_base[i] = s_ol_vga[i];
    int crow, ccol;
    vga_get_pos(&crow, &ccol);
    vga_set_cursor_hw(crow, ccol);

    /* Flush keyboard ring buffer and AR state: open consumes keys with
     * open_wait_key() but may have left residual events. Without this
     * flush the main loop sees "old" keys (e.g. ESC/q -> Enter) -> spurious Enter.
     * BUG v5.9: this flush was missing -> newlines burst after open. */
    g_kbd_events.head = g_kbd_events.tail = 0;
    s_ar_state = AR_IDLE;
    s_ar_key   = VK_NONE;

    vfs_close(f);
}

/* ═══════════════════════════════════════════════════════════════════════════
 * cmd_edit — full-screen text editor
 *
 * Works on text files <= ED_MAX_SIZE bytes (8KB).
 * Loads the file into s_ed_buf, displays it line by line.
 * Keys in edit mode:
 *   Arrows     -- move cursor
 *   Backspace  -- delete character before cursor
 *   Delete     -- delete character under cursor
 *   Enter      -- insert newline
 *   Ctrl+S     -- save (truncate+rewrite)
 *   ESC        -- exit without saving
 *   Ctrl+C     -- exit without saving
 * Header row 0:  path | EDIT | instructions
 * Footer row 24: row:col | status
 * Content rows 1..23 (23 visible rows).
 * ═══════════════════════════════════════════════════════════════════════════ */
#define ED_ROWS   23
#define ED_COLS   78   /* max visible columns per row */

static void cmd_edit(const char *arg) {
    if (!arg || !*arg) {
        con_nl();
        con_puts("  usage: edit <path>\n", 0x0C00);
        return;
    }
    char path[256];
    con_build_path(arg, path, sizeof(path));
    con_nl();

    /* ── Load file into s_ed_buf ── */
    int ed_len = 0;   /* content length in s_ed_buf (bytes) */
    int ed_cur = 0;   /* cursor position in buffer (bytes) */

    /* Try to open for reading */
    file_t *f = vfs_open(path, 0);
    if (f) {
        ssize_t nr = vfs_read(f, (uint8_t*)s_ed_buf, ED_MAX_SIZE - 1);
        vfs_close(f);
        if (nr < 0) nr = 0;
        /* Validate printable ASCII + \n\r\t */
        int ok = 1;
        for (ssize_t i = 0; i < nr && ok; i++) {
            uint8_t c = (uint8_t)s_ed_buf[i];
            if (c != '\n' && c != '\r' && c != '\t' && (c < 0x20 || c > 0x7E)) ok = 0;
        }
        if (!ok) {
            con_puts("  edit: binary file -- use 'open' to view\n", 0x0C00);
            return;
        }
        ed_len = (int)nr;
        s_ed_buf[ed_len] = '\0';
        ed_cur = ed_len;  /* cursor at end */
    } else {
        /* File does not exist: create empty */
        s_ed_buf[0] = '\0';
        ed_len = 0; ed_cur = 0;
    }

    /* ── Save screen ── */
    volatile uint16_t *vga_base = (volatile uint16_t *)0xB8000;
    for (int i = 0; i < 80 * 25; i++) s_ol_vga[i] = vga_base[i];

    bool ed_dirty = false;
    bool ed_quit  = false;

    for (;;) {
        /* ── Calculate top_row (first visible row) and cursor position ── */
        int cur_line = 0, cur_col = 0;
        for (int i = 0; i < ed_cur; i++) {
            if (s_ed_buf[i] == '\n') { cur_line++; cur_col = 0; }
            else cur_col++;
        }
        /* Total lines */
        int total_lines = 0;
        for (int i = 0; i < ed_len; i++) if (s_ed_buf[i] == '\n') total_lines++;
        if (ed_len == 0 || (ed_len > 0 && s_ed_buf[ed_len-1] != '\n')) total_lines++;

        /* Vertical scroll: top_row */
        static int ed_top = 0;
        if (cur_line < ed_top) ed_top = cur_line;
        if (cur_line >= ed_top + ED_ROWS) ed_top = cur_line - ED_ROWS + 1;

        /* ── Redraw header ── */
        uint16_t hattr = 0x1700; /* white on dark blue */
        for (int c = 0; c < 80; c++) vga_base[c] = hattr | ' ';
        {
            int c = 1;
            for (int i = 0; path[i] && c < 40; i++, c++)
                vga_base[c] = hattr | (uint8_t)path[i];
            const char *em = ed_dirty ? " [EDIT*]  Ctrl+S=save  ESC=exit" :
                                        " [EDIT]   Ctrl+S=save  ESC=exit";
            for (int i = 0; em[i] && c < 78; i++, c++)
                vga_base[c] = hattr | (uint8_t)em[i];
        }

        /* ── Redraw content (rows 1..ED_ROWS) ── */
        int line = 0, bi = 0;
        while (line < ed_top && bi < ed_len) {
            if (s_ed_buf[bi++] == '\n') line++;
        }
        for (int vrow = 1; vrow <= ED_ROWS; vrow++) {
            int base = vrow * 80;
            uint16_t lnattr = 0x0800;
            int lnum = ed_top + (vrow - 1) + 1;
            char lbuf[6];
            lbuf[0] = '0' + (lnum / 1000) % 10;
            lbuf[1] = '0' + (lnum / 100)  % 10;
            lbuf[2] = '0' + (lnum / 10)   % 10;
            lbuf[3] = '0' +  lnum          % 10;
            lbuf[4] = ':'; lbuf[5] = ' ';
            for (int c = 0; c < 6; c++) vga_base[base + c] = lnattr | (uint8_t)lbuf[c];
            int col = 0;
            if (line < total_lines) {
                while (bi < ed_len && s_ed_buf[bi] != '\n' && col < ED_COLS) {
                    vga_base[base + 6 + col] = 0x0F00 | (uint8_t)s_ed_buf[bi];
                    bi++; col++;
                }
                if (bi < ed_len && s_ed_buf[bi] == '\n') { bi++; line++; }
            }
            while (col < ED_COLS) { vga_base[base + 6 + col] = 0x0700 | ' '; col++; }
        }

        /* ── Footer row 24 ── */
        uint16_t fattr = 0x7000;
        for (int c = 0; c < 80; c++) vga_base[24*80 + c] = fattr | ' ';
        {
            char fbuf[32];
            int fi = 0;
            fbuf[fi++] = ' ';
            fbuf[fi++] = 'r'; fbuf[fi++] = ':';
            int n = cur_line + 1;
            char d[6]; int di = 0;
            do { d[di++] = '0' + n % 10; n /= 10; } while (n);
            while (di > 0) fbuf[fi++] = d[--di];
            fbuf[fi++] = ' '; fbuf[fi++] = 'c'; fbuf[fi++] = ':';
            n = cur_col + 1;
            di = 0;
            do { d[di++] = '0' + n % 10; n /= 10; } while (n);
            while (di > 0) fbuf[fi++] = d[--di];
            fbuf[fi++] = ' '; fbuf[fi] = '\0';
            for (int i = 0; fbuf[i] && i < 20; i++)
                vga_base[24*80 + i] = fattr | (uint8_t)fbuf[i];
            const char *st = ed_dirty ? "  modified  " : "  saved  ";
            int si = 20;
            for (int i = 0; st[i] && si < 78; i++, si++)
                vga_base[24*80 + si] = fattr | (uint8_t)st[i];
        }

        /* ── Position hardware cursor ── */
        int vis_row = (cur_line - ed_top) + 1;
        int vis_col = (cur_col < ED_COLS) ? cur_col + 6 : 6 + ED_COLS - 1;
        if (vis_row < 1) vis_row = 1;
        if (vis_row > ED_ROWS) vis_row = ED_ROWS;
        vga_set_cursor_hw(vis_row, vis_col);

        if (ed_quit) break;

        /* ── Wait for key ── */
        key_event_t ev = open_wait_key();
        uint8_t ev_mods = ev.modifiers;

        /* ESC or Ctrl+C: exit without saving */
        if (ev.keycode == VK_ESCAPE || ev.ascii == 3) { ed_quit = true; continue; }

        /* Ctrl+S: save */
        if (ev.ascii == 0x13) {  /* ascii 19 = Ctrl+S */
            vfs_unlink(path);
            vfs_create_file(path, 0x81A4U);
            file_t *wf = vfs_open(path, 1);
            if (wf) {
                vfs_write(wf, s_ed_buf, (size_t)ed_len);
                vfs_close(wf);
                ed_dirty = false;
            }
            continue;
        }

        /* Arrow keys */
        if (ev.keycode == VK_UP) {
            if (ed_cur == 0) continue;
            int sol = ed_cur - 1;
            while (sol > 0 && s_ed_buf[sol-1] != '\n') sol--;
            if (sol == 0) { ed_cur = 0; continue; }
            int prev_eol = sol - 1;
            int prev_sol = prev_eol - 1;
            while (prev_sol > 0 && s_ed_buf[prev_sol-1] != '\n') prev_sol--;
            int prev_len = prev_eol - prev_sol;
            int target_col = (cur_col < prev_len) ? cur_col : prev_len;
            ed_cur = prev_sol + target_col;
            continue;
        }
        if (ev.keycode == VK_DOWN) {
            int sol = ed_cur;
            while (sol > 0 && s_ed_buf[sol-1] != '\n') sol--;
            int eol = sol;
            while (eol < ed_len && s_ed_buf[eol] != '\n') eol++;
            if (eol >= ed_len) continue;
            int next_sol = eol + 1;
            int next_eol = next_sol;
            while (next_eol < ed_len && s_ed_buf[next_eol] != '\n') next_eol++;
            int next_len = next_eol - next_sol;
            int target_col = (cur_col < next_len) ? cur_col : next_len;
            ed_cur = next_sol + target_col;
            continue;
        }
        if (ev.keycode == VK_LEFT)  { if (ed_cur > 0) ed_cur--; continue; }
        if (ev.keycode == VK_RIGHT) { if (ed_cur < ed_len) ed_cur++; continue; }
        if (ev.keycode == VK_HOME)  {
            while (ed_cur > 0 && s_ed_buf[ed_cur-1] != '\n') ed_cur--;
            continue;
        }
        if (ev.keycode == VK_END) {
            while (ed_cur < ed_len && s_ed_buf[ed_cur] != '\n') ed_cur++;
            continue;
        }
        if (ev.keycode == VK_PGUP) {
            for (int i = 0; i < ED_ROWS; i++) {
                int sol = ed_cur;
                while (sol > 0 && s_ed_buf[sol-1] != '\n') sol--;
                if (sol == 0) break;
                int prev_eol = sol - 1;
                int prev_sol = prev_eol - 1;
                while (prev_sol > 0 && s_ed_buf[prev_sol-1] != '\n') prev_sol--;
                int prev_len = prev_eol - prev_sol;
                int cc = ed_cur - sol;
                int target = (cc < prev_len) ? cc : prev_len;
                ed_cur = prev_sol + target;
            }
            continue;
        }
        if (ev.keycode == VK_PGDN) {
            for (int i = 0; i < ED_ROWS; i++) {
                int sol = ed_cur;
                while (sol > 0 && s_ed_buf[sol-1] != '\n') sol--;
                int eol = sol;
                while (eol < ed_len && s_ed_buf[eol] != '\n') eol++;
                if (eol >= ed_len) break;
                int next_sol = eol + 1;
                int next_eol = next_sol;
                while (next_eol < ed_len && s_ed_buf[next_eol] != '\n') next_eol++;
                int next_len = next_eol - next_sol;
                int cc = ed_cur - sol;
                int target = (cc < next_len) ? cc : next_len;
                ed_cur = next_sol + target;
            }
            continue;
        }

        /* Backspace */
        if (ev.keycode == VK_BACKSPACE || ev.ascii == '\b') {
            if (ed_cur > 0 && ed_len > 0) {
                ed_cur--;
                for (int i = ed_cur; i < ed_len - 1; i++) s_ed_buf[i] = s_ed_buf[i+1];
                ed_len--;
                s_ed_buf[ed_len] = '\0';
                ed_dirty = true;
            }
            continue;
        }
        /* Delete */
        if (ev.keycode == VK_DELETE) {
            if (ed_cur < ed_len) {
                for (int i = ed_cur; i < ed_len - 1; i++) s_ed_buf[i] = s_ed_buf[i+1];
                ed_len--;
                s_ed_buf[ed_len] = '\0';
                ed_dirty = true;
            }
            continue;
        }

        /* Printable character or \n */
        char ch = ev.ascii;
        if ((ch == '\n') || ((unsigned char)ch >= 0x20 && (unsigned char)ch != 0x7F)) {
            if (ed_len < ED_MAX_SIZE - 1) {
                for (int i = ed_len; i > ed_cur; i--) s_ed_buf[i] = s_ed_buf[i-1];
                s_ed_buf[ed_cur++] = ch;
                ed_len++;
                s_ed_buf[ed_len] = '\0';
                ed_dirty = true;
            }
        }
        (void)ev_mods;
    }

    /* ── Restore screen ── */
    for (int i = 0; i < 80 * 25; i++) vga_base[i] = s_ol_vga[i];
    int crow, ccol; vga_get_pos(&crow, &ccol);
    vga_set_cursor_hw(crow, ccol);
    g_kbd_events.head = g_kbd_events.tail = 0;
    s_ar_state = AR_IDLE; s_ar_key = VK_NONE;
}

/* ── cmd_tree: prints recursive filesystem tree ───────────────────────
 *
 * Unix-style tree output:
 *   /
 *   +-- etc/
 *   |   +-- hostname
 *   +-- lib/
 *   |   +-- lib.cfg
 *   +-- tmp/
 *
 * Implemented with explicit stack (no kernel recursion -- limited stack).
 * Maximum depth: TREE_MAX_DEPTH levels.
 */

#define TREE_MAX_DEPTH   8    /* max recursion depth (was 16 -- BSS too large) */
#define TREE_MAX_ITEMS  32    /* max entries per directory (was 256 -- BSS too large)
                               * With TREE_MAX_DEPTH*TREE_MAX_ITEMS=256 entries in tree_frame_t
                               * the total BSS for cmd_tree drops from ~1.1MB to ~68KB. */

typedef struct {
    char path[256];
    int  depth;
    int  parent_idx;   /* entry index in parent */
    bool last;
} tree_frame_t;

static void cmd_tree(const char *arg) {
    char root_path[256];
    /* If no argument: use current directory (not always /)
     * BUG v5.9: hardcoded "/" instead of NULL -> tree ignored cwd. */
    con_build_path((arg && *arg) ? arg : NULL, root_path, sizeof(root_path));
    con_nl();

    if (!vfs_is_dir(root_path)) {
        con_puts("  tree: '", 0x0C00); con_puts(root_path, 0x0C00);
        con_puts("': not a directory\n", 0x0C00);
        return;
    }

    /* Print root */
    con_puts("  ", 0x0700);
    con_puts(root_path[1] == '\0' ? "/" : root_path, 0x0E00);
    con_putc('\n');

    /* Stack for iterative DFS */
    static tree_frame_t s_stack[TREE_MAX_DEPTH * TREE_MAX_ITEMS];
    int sp = 0;
    int total_dirs  = 0;
    int total_files = 0;

    /* Enumerate root directory and push entries in reverse order */
    static char   e_name[TREE_MAX_ITEMS][64];
    int    e_count = 0;

    for (size_t idx = 0; idx < (size_t)TREE_MAX_ITEMS && !con_check_ctrlc(); idx++) {
        char name[64];
        int is_dir = 0;
        int r = vfs_readdir_entry(root_path, idx, name, sizeof(name), &is_dir);
        if (r < 0) break;
        if (e_count < TREE_MAX_ITEMS) {
            int ni = 0;
            while (name[ni] && ni < 63) { e_name[e_count][ni] = name[ni]; ni++; }
            e_name[e_count][ni] = '\0';
            e_count++;
        }
    }

    /* Push in reverse order so first pop gives first entry */
    for (int i = e_count - 1; i >= 0 && sp < TREE_MAX_DEPTH * TREE_MAX_ITEMS; i--) {
        tree_frame_t *fr = &s_stack[sp++];
        int pi = 0;
        const char *rp = root_path;
        if (rp[0] == '/' && rp[1] == '\0') {
            fr->path[pi++] = '/';
        } else {
            while (*rp && pi < 250) fr->path[pi++] = *rp++;
            fr->path[pi++] = '/';
        }
        int ni = 0;
        while (e_name[i][ni] && pi < 254) fr->path[pi++] = e_name[i][ni++];
        fr->path[pi] = '\0';
        fr->depth      = 1;
        fr->last       = (i == e_count - 1);
        fr->parent_idx = i;
    }

    while (sp > 0 && !con_check_ctrlc()) {
        tree_frame_t frame = s_stack[--sp];

        const char *name = frame.path;
        const char *slash = frame.path;
        for (const char *p = frame.path; *p; p++) if (*p == '/') slash = p;
        name = slash + 1;
        if (!*name) name = frame.path;

        bool is_dir = vfs_is_dir(frame.path);

        if (is_dir) total_dirs++;
        else        total_files++;

        /* Print indentation */
        con_puts("  ", 0x0700);
        for (int d = 1; d < frame.depth; d++) {
            con_puts("\xB3   ", 0x0800);
        }
        con_puts(frame.last ? "\xC0\xC4\xC4 " : "\xC3\xC4\xC4 ", 0x0800);
        if (is_dir) {
            con_puts(name, 0x0A00); con_puts("/\n", 0x0A00);
        } else {
            con_puts(name, 0x0F00); con_putc('\n');
        }

        /* If directory, enumerate children and push them */
        if (is_dir && frame.depth < TREE_MAX_DEPTH) {
            static char   c_name[TREE_MAX_ITEMS][64];
            int    c_count = 0;

            for (size_t idx = 0; idx < (size_t)TREE_MAX_ITEMS && !con_check_ctrlc(); idx++) {
                char nm[64];
                int isd = 0;
                int r = vfs_readdir_entry(frame.path, idx, nm, sizeof(nm), &isd);
                if (r < 0) break;
                if (c_count < TREE_MAX_ITEMS) {
                    int ni = 0;
                    while (nm[ni] && ni < 63) { c_name[c_count][ni] = nm[ni]; ni++; }
                    c_name[c_count][ni] = '\0';
                    c_count++;
                }
            }

            /* Push in reverse order */
            for (int i = c_count - 1; i >= 0 && sp < TREE_MAX_DEPTH * TREE_MAX_ITEMS - 1; i--) {
                tree_frame_t *fr = &s_stack[sp++];
                int pi = 0;
                const char *pp = frame.path;
                while (*pp && pi < 248) fr->path[pi++] = *pp++;
                fr->path[pi++] = '/';
                int ni = 0;
                while (c_name[i][ni] && pi < 254) fr->path[pi++] = c_name[i][ni++];
                fr->path[pi] = '\0';
                fr->depth = frame.depth + 1;
                fr->last  = (i == c_count - 1);
                fr->parent_idx = i;
            }
        }
    }

    /* Summary */
    char buf[12];
    con_nl();
    con_puts("  ", 0x0700);
    u64_to_dec((uint64_t)total_dirs,  buf); con_puts(buf, 0x0A00);
    con_puts(" dir", 0x0700);
    con_puts(", ", 0x0700);
    u64_to_dec((uint64_t)total_files, buf); con_puts(buf, 0x0F00);
    con_puts(" file\n", 0x0700);
}

static void cmd_ls(const char *arg) {
    char path[256];
    con_build_path(arg, path, sizeof(path));
    con_nl();

    int count = 0;
    for (size_t idx = 0; idx < 512; idx++) {
        char name[256];
        int is_dir = 0;
        int r = vfs_readdir_entry(path, idx, name, sizeof(name), &is_dir);
        if (r < 0) {
            char dbuf[16];
            serial_puts("[LS] readdir('"); serial_puts(path);
            serial_puts("', "); int_to_dec((int)idx, dbuf); serial_puts(dbuf);
            serial_puts(") = "); int_to_dec(r, dbuf); serial_puts(dbuf);
            serial_puts("\r\n");
            break;
        }
        con_puts("  ", 0x0700);
        if (is_dir) { con_puts(name, 0x0A00); con_puts("/", 0x0A00); }
        else          con_puts(name, 0x0F00);
        con_putc('\n');
        count++;
        if (con_check_ctrlc()) break;
    }

    if (count == 0 && !g_ctrlc) {
        if (!vfs_is_dir(path)) {
            con_puts("  ls: '", 0x0C00); con_puts(path, 0x0C00);
            con_puts("': not found\n", 0x0C00);
        } else {
            /* ── Inline VGA diagnostics: show what is happening on screen ── */
            extern int  vfs_diag_mount_count(void);
            extern int  vfs_diag_root_children(void);
            extern int  vfs_diag_synth_count(const char *path);
            char dbuf[16];
            con_puts("  (empty) diag: mounts=", 0x0E00);
            int_to_dec(vfs_diag_mount_count(), dbuf); con_puts(dbuf, 0x0F00);
            con_puts(" root_children=", 0x0E00);
            int_to_dec(vfs_diag_root_children(), dbuf); con_puts(dbuf, 0x0F00);
            con_puts(" synth=", 0x0E00);
            int_to_dec(vfs_diag_synth_count(path), dbuf); con_puts(dbuf, 0x0F00);
            con_putc('\n');
        }
    }
}

/* ── diag: internal VFS diagnostics ────────────────────────────────── */
static void cmd_diag(void) {
    extern void vfs_debug_dump(void);
    con_nl();
    con_puts("  [DIAG] dumping internal VFS...\n", 0x0E00);
    vfs_debug_dump();
    con_puts("  [DIAG] done. Full output on serial.\n", 0x0E00);
}

static void cmd_cd(const char *arg) {
    if (!arg || !*arg) {
        /* cd with no arguments -> go back to root */
        s_cwd[0] = '/'; s_cwd[1] = '\0';
        return;
    }
    char path[256];
    con_build_path(arg, path, sizeof(path));

    if (!vfs_is_dir(path)) {
        con_nl();
        con_puts("  cd: '", 0x0C00);
        con_puts(path, 0x0C00);
        con_puts("': directory not found\n", 0x0C00);
        return;
    }
    con_strcpy(s_cwd, path, sizeof(s_cwd));
}

static void cmd_clear(void) {
    for (int i = 0; i < 25; i++) vga_putchar_attr('\n', 0x0700);
    serial_puts("\r\n\033[2J\033[H");
    vga_banner(MATTIAOS_VERSION);
}

/* ── halt: helper to find RSDP locally ───────────────────────────────────
 *
 * stage2 does not patch the Limine RSDP response, so acpi_init() is never
 * called and acpi_find_table("FACP") returns NULL.
 * Manually scan the EBDA and BIOS ROM for "RSD PTR ".
 */
static uint8_t *halt_find_rsdp(void) {
    /* EBDA: segment address at 0x40E, shifted left by 4 */
    volatile uint16_t *bda_ebda = (volatile uint16_t *)(g_hhdm_offset + 0x40EUL);
    uint64_t ebda_phys = (uint64_t)(*bda_ebda) << 4;
    if (ebda_phys >= 0x80000UL && ebda_phys < 0xA0000UL) {
        uint8_t *p = (uint8_t *)(g_hhdm_offset + ebda_phys);
        for (int i = 0; i < 1024; i += 16) {
            if (p[i]=='R'&&p[i+1]=='S'&&p[i+2]=='D'&&p[i+3]==' '&&
                p[i+4]=='P'&&p[i+5]=='T'&&p[i+6]=='R'&&p[i+7]==' ')
                return p + i;
        }
    }
    /* BIOS ROM 0xE0000-0xFFFFF */
    uint8_t *rom = (uint8_t *)(g_hhdm_offset + 0xE0000UL);
    for (int i = 0; i < 0x20000; i += 16) {
        if (rom[i]=='R'&&rom[i+1]=='S'&&rom[i+2]=='D'&&rom[i+3]==' '&&
            rom[i+4]=='P'&&rom[i+5]=='T'&&rom[i+6]=='R'&&rom[i+7]==' ')
            return rom + i;
    }
    return NULL;
}

static void cmd_halt(void) {
    con_nl();
    con_puts("  Shutting down via ACPI S5...\n", 0x0E00);
    asm volatile("cli");

    /*
     * ACPI S5 power-off -- robust procedure.
     *
     * VirtualBox PIIX3:
     *   pm1a_cnt_blk = 0x4004  (from FADT, or hardcoded as default)
     *   DSDT _S5_ = {5, 5, 0, 0}  -> SLP_TYP_A = 5
     *   Correct value: (5 << 10) | SLP_EN(bit13) = 0x1400 | 0x2000 = 0x3400
     *
     * Sequence:
     *   1. Try to find FADT via RSDP scan for exact pm1a
     *   2. Try all plausible SLP_TYP values on pm1a: 5,0,3,6,7
     *   3. Fallback to QEMU port 0x604
     */

    /* --- Step 1: find pm1a_cnt_blk from FADT (if available) --- */
    uint16_t pm1a = 0x4004;   /* default VirtualBox PIIX3 */
    uint16_t pm1b = 0x0000;

    uint8_t *rsdp_ptr = halt_find_rsdp();
    if (rsdp_ptr) {
        serial_puts("[HALT] RSDP found via scan\r\n");
        uint32_t rsdt_phys = 0;
        for (int b = 0; b < 4; b++)
            rsdt_phys |= (uint32_t)rsdp_ptr[16 + b] << (b * 8);

        if (rsdt_phys) {
            uint8_t *rsdt = (uint8_t *)(g_hhdm_offset + rsdt_phys);
            uint32_t rsdt_len = 0;
            for (int b = 0; b < 4; b++)
                rsdt_len |= (uint32_t)rsdt[4 + b] << (b * 8);

            uint32_t num_entries = (rsdt_len - 36) / 4;
            for (uint32_t e = 0; e < num_entries && e < 32; e++) {
                uint32_t tbl_phys = 0;
                for (int b = 0; b < 4; b++)
                    tbl_phys |= (uint32_t)rsdt[36 + e*4 + b] << (b * 8);
                if (!tbl_phys) continue;
                uint8_t *tbl = (uint8_t *)(g_hhdm_offset + tbl_phys);
                /* Check signature "FACP" */
                if (tbl[0]=='F'&&tbl[1]=='A'&&tbl[2]=='C'&&tbl[3]=='P') {
                    /* pm1a_cnt_blk at offset 64 (uint32_t) */
                    uint32_t v = 0;
                    for (int b = 0; b < 4; b++) v |= (uint32_t)tbl[64+b]<<(b*8);
                    if (v) pm1a = (uint16_t)v;
                    /* pm1b_cnt_blk at offset 68 (uint32_t) */
                    v = 0;
                    for (int b = 0; b < 4; b++) v |= (uint32_t)tbl[68+b]<<(b*8);
                    if (v) pm1b = (uint16_t)v;
                    serial_puts("[HALT] FADT found, pm1a=0x");
                    const char *hx = "0123456789ABCDEF";
                    char h[5]; h[4]='\0';
                    h[0]=hx[(pm1a>>12)&0xF]; h[1]=hx[(pm1a>>8)&0xF];
                    h[2]=hx[(pm1a>>4)&0xF];  h[3]=hx[pm1a&0xF];
                    serial_puts(h); serial_puts("\r\n");
                    break;
                }
            }
        }
    } else {
        serial_puts("[HALT] RSDP not found, using pm1a=0x4004\r\n");
    }

    /* --- Step 2: try all plausible SLP_TYP values --- */
    /* SLP_EN = bit 13 = 0x2000.  SLP_TYP_A = bits 10-12. */
    /* Order: 5 (VirtualBox), 0 (generic), 3, 6, 7 */
    static const uint16_t slp_types[] = { 5, 0, 3, 6, 7 };
    for (int t = 0; t < 5; t++) {
        uint16_t val = (uint16_t)((slp_types[t] << 10) | 0x2000U);
        outw(pm1a, val);
        if (pm1b) outw(pm1b, val);
        for (volatile int d = 0; d < 100000; d++) asm volatile("pause");
    }

    /* --- Step 3: QEMU/Bochs fallback --- */
    outw(0x604, 0x2000);
    for (volatile int d = 0; d < 100000; d++) asm volatile("pause");

    /* --- Step 4: Triple-fault fallback --- */
    con_puts("  (ACPI did not respond -- CPU halted)\n", 0x0C00);
    for (;;) asm volatile("cli; hlt");
}

static void cmd_reboot(void) {
    con_nl(); con_puts("  Rebooting...\n", 0x0E00);
    outb(0x64, 0xFE);
    asm volatile("cli");
    /* triple fault fallback */
    asm volatile("lidt %0" :: "m"(*(uint8_t*)0));
    asm volatile("int $0");
    for (;;);
}

static void con_exec(void) {
    int s = 0; while (s_line[s] == ' ') s++;
    char *line = s_line + s;
    if (!*line) return;

    /* Extract command (first token) */
    int cmdlen = 0;
    while (line[cmdlen] && line[cmdlen] != ' ') cmdlen++;

    /* Extract argument (second token, optional) */
    const char *arg = line + cmdlen;
    while (*arg == ' ') arg++;

    /* Compare only the command */
    char cmd[32]; int i=0;
    while (i < cmdlen && i < (int)sizeof(cmd)-1) { cmd[i]=line[i]; i++; }
    cmd[i] = '\0';

    if      (kstrcmp(cmd,"help")      == 0) { g_ctrlc=0; cmd_help(); }
    else if (kstrcmp(cmd,"ver")       == 0) { g_ctrlc=0; cmd_ver(); }
    else if (kstrcmp(cmd,"mem")       == 0) { g_ctrlc=0; cmd_mem(); }
    else if (kstrcmp(cmd,"pci")       == 0) { g_ctrlc=0; cmd_pci(); }
    else if (kstrcmp(cmd,"ls")        == 0) { g_ctrlc=0; cmd_ls(*arg ? arg : NULL); }
    else if (kstrcmp(cmd,"cd")        == 0) { g_ctrlc=0; cmd_cd(*arg ? arg : NULL); }
    else if (kstrcmp(cmd,"open")      == 0) { g_ctrlc=0; cmd_open(*arg ? arg : NULL); }
    else if (kstrcmp(cmd,"edit")      == 0) { g_ctrlc=0; cmd_edit(*arg ? arg : NULL); }
    else if (kstrcmp(cmd,"tree")      == 0) { g_ctrlc=0; cmd_tree(*arg ? arg : NULL); }
    else if (kstrcmp(cmd,"clear")     == 0) { g_ctrlc=0; cmd_clear(); }
    else if (kstrcmp(cmd,"halt")      == 0) { g_ctrlc=0; cmd_halt(); }
    else if (kstrcmp(cmd,"reboot")    == 0) { g_ctrlc=0; cmd_reboot(); }
    else if (kstrcmp(cmd,"easteregg") == 0) { g_ctrlc=0; cmd_easteregg(); }
    else if (kstrcmp(cmd,"diag")      == 0) { g_ctrlc=0; cmd_diag(); }
    else {
        /* Non built-in command: look in /sys/PATH.
         * FORMAT v5.9: name=exe_path:dep1:dep2:...
         *   - First field after '=' is the executable path.
         *   - Subsequent ':'-separated fields are dependencies.
         * Show exe + deps; Phase 13 will actually execute the binary. */
        con_nl();
        bool found_in_path = false;
        file_t *pf = vfs_open("/sys/PATH", 0);
        if (pf) {
            static uint8_t s_pathbuf[2048];
            ssize_t pn = vfs_read(pf, s_pathbuf, sizeof(s_pathbuf) - 1);
            vfs_close(pf);
            if (pn > 0) {
                s_pathbuf[pn] = '\0';
                size_t ci = 0;
                while (ci < (size_t)pn && !found_in_path) {
                    /* Skip comments and blank lines */
                    if (s_pathbuf[ci] == '#' || s_pathbuf[ci] == '\n') {
                        while (ci < (size_t)pn && s_pathbuf[ci] != '\n') ci++;
                        ci++; continue;
                    }
                    /* Name up to '=' */
                    size_t ns = ci;
                    while (ci < (size_t)pn && s_pathbuf[ci] != '=' && s_pathbuf[ci] != '\n') ci++;
                    if (ci >= (size_t)pn || s_pathbuf[ci] == '\n') { ci++; continue; }
                    size_t nl = ci - ns;
                    ci++; /* skip '=' */
                    /* Whole line after '=' up to '\n' */
                    size_t val_start = ci;
                    while (ci < (size_t)pn && s_pathbuf[ci] != '\n') ci++;
                    size_t val_end = ci;
                    ci++;

                    if (nl != (size_t)i) continue;
                    if (kstrncmp((char*)s_pathbuf + ns, cmd, nl) != 0) continue;

                    /* Found. Extract exe and deps from value "exe:dep1:dep2" */
                    size_t fp = val_start;
                    while (fp < val_end && s_pathbuf[fp] != ':') fp++;
                    char exepath[128];
                    size_t el = fp - val_start;
                    if (el > 127) el = 127;
                    for (size_t k = 0; k < el; k++) exepath[k] = (char)s_pathbuf[val_start+k];
                    exepath[el] = '\0';

                    con_puts("  Command:    ", 0x0E00); con_puts(cmd, 0x0B00); con_puts("\n", 0x0700);
                    con_puts("  Executable: ", 0x0700); con_puts(exepath, 0x0F00); con_puts("\n", 0x0700);

                    /* Deps: ':'-separated fields after the first */
                    size_t dp = fp;
                    bool has_deps = false;
                    while (dp < val_end) {
                        dp++;
                        size_t dep_start = dp;
                        while (dp < val_end && s_pathbuf[dp] != ':') dp++;
                        size_t dep_len = dp - dep_start;
                        if (dep_len == 0) continue;
                        if (!has_deps) {
                            con_puts("  Dependencies:\n", 0x0700);
                            has_deps = true;
                        }
                        char deppath[128];
                        if (dep_len > 127) dep_len = 127;
                        for (size_t k = 0; k < dep_len; k++) deppath[k] = (char)s_pathbuf[dep_start+k];
                        deppath[dep_len] = '\0';
                        con_puts("    - ", 0x0800); con_puts(deppath, 0x0A00); con_puts("\n", 0x0700);
                    }
                    if (!has_deps) con_puts("  Dependencies: none\n", 0x0800);
                    con_puts("  [Phase 13: ELF loader not yet active]\n", 0x0800);
                    found_in_path = true;
                }
            }
        }
        if (!found_in_path) {
            con_puts("  Unrecognised command: '", 0x0C00);
            con_puts(cmd, 0x0C00);
            con_puts("'  (type 'help')\n", 0x0C00);
        }
    }
}

/* ── Redraw input line from s_input_row/col, position cursor ─────────── */
static void con_redraw_line(void) {
    int row = s_input_row, col = s_input_col;
    for (int i = 0; i < s_len; i++) {
        vga_write_at(row, col, s_line[i], 0x0F00);
        if (++col >= 80) { col = 0; row++; }
    }
    /* Clear residual characters to end of current VGA row
     * (needed when new line is shorter than previous -- e.g. history) */
    int clear_col = col, clear_row = row;
    while (clear_col < 80) {
        vga_write_at(clear_row, clear_col, ' ', 0x0700);
        clear_col++;
    }
    /* Position hardware cursor at s_cur */
    int crow = s_input_row, ccol = s_input_col + s_cur;
    crow += ccol / 80; ccol %= 80;
    vga_set_cursor_hw(crow, ccol);
}

/* ── Helper: load history entry into s_line ─────────────────────────── */
static void hist_load(int idx) {
    /* idx = current s_hist_idx (0=last, 1=second-to-last, ...) */
    if (s_hist_count == 0) return;
    if (idx < 0 || idx >= s_hist_count) return;
    /* Convert idx (0=last) to ring index */
    int ring = (s_hist_tail - idx + HIST_MAX) % HIST_MAX;
    int j = 0;
    while (s_hist[ring][j] && j < CON_MAX - 1) { s_line[j] = s_hist[ring][j]; j++; }
    s_line[j] = '\0';
    s_len = j; s_cur = j;
    con_redraw_line();
}

/* ── Helper: exit scrollback mode restoring real screen ─────────────── */
static void sb_exit(void) {
    if (!s_sb_active) return;
    s_sb_active = false;
    s_sb_offset = 0;
    /* Restore the screen we saved before entering */
    volatile uint16_t *vga_base = (volatile uint16_t *)0xB8000;
    for (int i = 0; i < 80 * 25; i++) vga_base[i] = s_sb_live[i];
    /* Restore HW cursor to input row */
    int crow = s_input_row, ccol = s_input_col + s_cur;
    crow += ccol / 80; ccol %= 80;
    vga_set_cursor_hw(crow, ccol);
}

/* ── Process a single key (press or autorepeat) ──────────────────────── */
static void con_handle_key(vk_t vk, char ascii) {
    uint8_t mods = keyboard_get_modifiers();

    /* ── Scrollback mode ──────────────────────────────────────────────────
     * Shift+UP: scroll up.  Shift+DOWN: scroll down or exit.
     * Any other key: exit and process normally. */
    if (s_sb_active) {
        bool shift = (mods & MOD_SHIFT) != 0;
        if (vk == VK_UP && shift) {
            s_sb_offset++;
            if (s_sb_offset > vga_sb_lines()) s_sb_offset = vga_sb_lines();
            vga_scrollback_render(s_sb_offset);
            return;
        }
        if (vk == VK_DOWN && shift) {
            s_sb_offset--;
            if (s_sb_offset <= 0) { sb_exit(); return; }
            vga_scrollback_render(s_sb_offset);
            return;
        }
        /* Any other key (including ESC) exits scrollback */
        sb_exit();
        /* Then process the received key normally (fall-through) */
    }

    /* ── Shift+UP: enter scrollback ─────────────────────────────────────── */
    {
        bool shift = (mods & MOD_SHIFT) != 0;
        if (vk == VK_UP && shift) {
            if (vga_sb_lines() > 0) {
                /* Save current screen BEFORE overwriting it */
                volatile uint16_t *vga_base = (volatile uint16_t *)0xB8000;
                for (int i = 0; i < 80 * 25; i++) s_sb_live[i] = vga_base[i];
                s_sb_active = true;
                s_sb_offset = 1;
                vga_scrollback_render(s_sb_offset);
            }
            return;
        }
    }

    /* Ctrl+C */
    if (ascii == 3) {
        con_puts("^C\n", 0x0C00);
        s_len = 0; s_cur = 0; s_line[0] = '\0';
        g_ctrlc = 1;
        s_hist_idx = -1;
        s_ar_state = AR_IDLE; s_ar_key = VK_NONE;
        con_prompt();
        return;
    }

    /* Enter */
    if (vk == VK_ENTER || ascii == '\n' || ascii == '\r') {
        s_ar_state = AR_IDLE;
        s_ar_key   = VK_NONE;
        s_line[s_len] = '\0';
        hist_push(s_line);
        s_hist_idx = -1;
        int erow = s_input_row, ecol = s_input_col + s_len;
        erow += ecol / 80; ecol %= 80;
        vga_set_pos(erow, ecol);
        con_nl(); con_exec(); con_prompt();
        return;
    }

    /* UP without Shift = previous history entry */
    if (vk == VK_UP) {
        if (s_hist_count == 0) return;
        if (s_hist_idx == -1) {
            /* First press: save current line */
            int j = 0;
            while (s_line[j] && j < CON_MAX - 1) { s_hist_saved[j] = s_line[j]; j++; }
            s_hist_saved[j] = '\0';
            s_hist_idx = 0;
        } else if (s_hist_idx < s_hist_count - 1) {
            s_hist_idx++;
        }
        hist_load(s_hist_idx);
        return;
    }

    /* DOWN without Shift = next history entry */
    if (vk == VK_DOWN) {
        if (s_hist_idx < 0) return;
        s_hist_idx--;
        if (s_hist_idx < 0) {
            /* Return to saved line */
            int j = 0;
            while (s_hist_saved[j] && j < CON_MAX - 1) { s_line[j] = s_hist_saved[j]; j++; }
            s_line[j] = '\0';
            s_len = j; s_cur = j;
            con_redraw_line();
        } else {
            hist_load(s_hist_idx);
        }
        return;
    }

    /* Backspace */
    if (vk == VK_BACKSPACE || ascii == '\b') {
        if (s_cur > 0) {
            s_cur--;
            for (int i = s_cur; i < s_len - 1; i++) s_line[i] = s_line[i+1];
            s_len--;
            con_redraw_line();
        }
        return;
    }

    /* Delete */
    if (vk == VK_DELETE) {
        if (s_cur < s_len) {
            for (int i = s_cur; i < s_len - 1; i++) s_line[i] = s_line[i+1];
            s_len--;
            con_redraw_line();
        }
        return;
    }

    if (vk == VK_LEFT)  { if (s_cur > 0)     { s_cur--; con_redraw_line(); } return; }
    if (vk == VK_RIGHT) { if (s_cur < s_len)  { s_cur++; con_redraw_line(); } return; }
    if (vk == VK_HOME)  { s_cur = 0;           con_redraw_line(); return; }
    if (vk == VK_END)   { s_cur = s_len;        con_redraw_line(); return; }

    if ((unsigned char)ascii >= 0x20 && (unsigned char)ascii != 0x7F) {
        /* Any typed character resets history navigation */
        s_hist_idx = -1;
        if (s_len < CON_MAX - 1) {
            for (int i = s_len; i > s_cur; i--) s_line[i] = s_line[i-1];
            s_line[s_cur++] = ascii;
            s_len++;
            con_redraw_line();
        }
    }
}

static void __attribute__((noreturn)) kernel_console(void) {
    /* Register LAPIC timer handler vec 0x20 -> increments g_con_ms every 1ms */
    register_irq_handler(0x20, con_timer_handler);

    vga_puts_attr("\n", 0x0700);
    vga_puts_attr("  \xC4\xC4\xC4\xC4\xC4\xC4\xC4\xC4\xC4\xC4\xC4\xC4\xC4\xC4\xC4\xC4\xC4\xC4\xC4\xC4\xC4\xC4\xC4\xC4\xC4\xC4\xC4\xC4\xC4\xC4\xC4\xC4\xC4\xC4\xC4\xC4\n", 0x0800);
    vga_puts_attr("  MattiaOS " MATTIAOS_VERSION
                  " - Boot OK. Keyboard EN. Type 'help' for commands.\n", 0x0A00);
    vga_puts_attr("  \xC4\xC4\xC4\xC4\xC4\xC4\xC4\xC4\xC4\xC4\xC4\xC4\xC4\xC4\xC4\xC4\xC4\xC4\xC4\xC4\xC4\xC4\xC4\xC4\xC4\xC4\xC4\xC4\xC4\xC4\xC4\xC4\xC4\xC4\xC4\xC4\n", 0x0800);
    serial_puts("\r\n[CONSOLE] Boot OK.\r\n");

    con_prompt();

    /* Enable interrupts ONCE: LAPIC timer + keyboard IRQ will arrive
     * to interrupt handlers. We do not use `hlt` to avoid race conditions
     * on VirtualBox NEM (Hyper-V): hlt can return on spurious interrupts,
     * causing spurious loop iterations that corrupt AR timing. */
    asm volatile("sti");

    for (;;) {
        /* pause: hint to processor that we are in a spin loop.
         * Interrupts are enabled (sti outside the loop): the LAPIC timer
         * ISR increments g_con_ms every 1ms, the keyboard IRQ just does EOI. */
        asm volatile("pause");

        /* Decode PS/2 bytes -> events. Single consumer: no race. */
        keyboard_process();

        /* Drain ALL available events in this iteration. */
        key_event_t ev;
        while (keyboard_poll_event(&ev)) {
            if (ev.pressed) {
                /* Every genuine MAKE (duplicates already filtered by
                 * bitset s_pressed in keyboard.c): start/restart AR. */
                s_ar_key   = ev.keycode;
                s_ar_ascii = ev.ascii;
                s_ar_state = AR_DELAY;
                s_ar_ms    = g_con_ms;
                con_handle_key(ev.keycode, ev.ascii);
            } else {
                /* BREAK = real release (VirtualBox sends repeated MAKEs,
                 * not BREAK+MAKE, during typematic). Cancel AR. */
                if (ev.keycode == s_ar_key) {
                    s_ar_state = AR_IDLE;
                    s_ar_key   = VK_NONE;
                }
            }
        }

        /* Autorepeat state machine. */
        if (s_ar_state != AR_IDLE) {
            uint32_t elapsed = g_con_ms - s_ar_ms;
            if (s_ar_state == AR_DELAY && elapsed >= AR_DELAY_MS) {
                s_ar_state = AR_REPEAT;
                s_ar_ms    = g_con_ms;
                con_handle_key(s_ar_key, s_ar_ascii);
            } else if (s_ar_state == AR_REPEAT && elapsed >= AR_REPEAT_MS) {
                s_ar_ms = g_con_ms;
                con_handle_key(s_ar_key, s_ar_ascii);
            }
        }
    }
}

/* ═══════════════════════════════════════════════════════════════════════════
 * kernel_main -- entry point
 * ═══════════════════════════════════════════════════════════════════════════ */


/* Dedicated boot stack: 128KB, aligned to 16 bytes.
 * Stage2 jumps to kernel with RSP=0x7C00 (only 3KB of stack).
 * CRITICAL ORDER:
 *   1. BSS clear (still uses stage2 stack of 3KB -- sufficient for the loop)
 *   2. Stack switch to g_boot_stack just zeroed
 * DO NOT invert: g_boot_stack is in BSS; if we switch first the BSS clear
 * zeroes the active stack -> stack corruption -> immediate crash. */
static uint8_t g_boot_stack[131072] __attribute__((aligned(16)));

void kernel_main(void) {
    /* 1a. BSS clear -- BEFORE stack switch, still using RSP=0x7C00 */
    extern char _bss_start[], _bss_end[];
    for (char *p = _bss_start; p < _bss_end; p++) *p = 0;

    /* 1b. Switch to dedicated stack (now safe: BSS already zeroed) */
    asm volatile(
        "lea %0, %%rax\n\t"
        "add %1, %%rax\n\t"
        "mov %%rax, %%rsp\n\t"
        :
        : "m"(g_boot_stack), "i"(sizeof(g_boot_stack))
        : "rax", "memory"
    );

    /* 1. GDT / IDT / Serial / VGA banner */
    gdt_init(); idt_init(); serial_init();
    vga_banner(MATTIAOS_VERSION);

    klog_vga(KLOG_OK,   "GDT",    "Descriptor tables (6 entries + TSS 128-bit)");
    klog_vga(KLOG_OK,   "IDT",    "256 interrupt vectors -- IST1 DF, IST2 NMI, IST3 MCE");
    klog_vga(KLOG_OK,   "SERIAL", "COM1 @ 38400 baud + VGA text 80x25");

    /*
     * PIC 8259 -- MUST be remapped before sti().
     *
     * Without pic_init() the master PIC has IRQ1 (keyboard) mapped to CPU
     * vector 0x09 (Coprocessor Segment Overrun). Every keypress generates a
     * CPU exception instead of calling our handler -> immediate KERNEL PANIC.
     *
     * pic_init() remaps the PIC to 0x20/0x28 and masks all IRQs except
     * IRQ1 (kbd) and IRQ12 (mouse). Called BEFORE lapic_init() and sti().
     */
    pic_init();
    klog_vga(KLOG_OK, "PIC", "8259 remapped: IRQ0-7->0x20, IRQ8-15->0x28. IRQ1/IRQ12 active");

    /* 2. Limine responses */
    klog_vga(KLOG_INFO, "LIMINE", "Checking boot protocol responses...");
    if (!memmap_request.response) kpanic_early("Limine memmap response NULL");
    if (!hhdm_request.response)   kpanic_early("Limine HHDM response NULL");
    if (!kaddr_request.response)  kpanic_early("Limine kernel address response NULL");
    klog_vga(KLOG_OK, "LIMINE", "Responses valid");
    klog_detail("Kernel phys:  ", "0x200000  virt: 0xFFFFFFFF80000000");
    klog_detail("HHDM offset:  ", "0xFFFF800000000000");

    /* 3. PMM */
    klog_vga(KLOG_INFO, "PMM", "Physical Memory Manager...");

    /*
     * Calculate kernel_phys_end BEFORE pmm_init.
     *
     * BUG v5.9 ROOT CAUSE: with large BSS (cmd_tree statics = 2.2MB) the
     * physical kernel extended beyond PMM_RESERVED_BELOW=0x400000.
     * pmm_init placed the PMM bitmap at 0x400000 (inside BSS!) and zeroed
     * it with memset(0xFF) -> BSS corruption -> triple fault on STI.
     * FIX v5.9: pass ke_phys to pmm_init -> bitmap always AFTER the kernel.
     */
    {
        extern char _kernel_end[];
        const uint64_t KBASE_VIRT = 0xFFFFFFFF80000000ULL;
        const uint64_t KBASE_PHYS = 0x200000ULL;
        uint64_t ke_phys = (uint64_t)_kernel_end - KBASE_VIRT + KBASE_PHYS;
        ke_phys = (ke_phys + 0xFFFULL) & ~0xFFFULL;

        pmm_init(memmap_request.response, ke_phys);

        /* Reserve critical regions not marked by E820/Limine:
         *   [A] 0x000000-0x200000: stage2 PTs, Limine responses, ELF staging
         *   [B] 0x200000-ke_phys:  kernel ELF + BSS (E820 sees these as USABLE) */
        pmm_mark_used(0x000000ULL, 0x200000ULL);
        pmm_mark_used(0x200000ULL, ke_phys);
    }

    klog_vga(KLOG_OK,   "PMM", "PMM bitmap ready");
    {
        char b[12];
        u64_to_dec(pmm_total_memory()/(1024*1024), b);
        klog_detail("Total RAM: ", b);
        u64_to_dec(pmm_free_memory()/(1024*1024), b);
        klog_detail("Free RAM:  ", b);
    }

    /* 4. VMM */
    klog_vga(KLOG_INFO, "VMM", "Virtual Memory Manager (4-level paging)...");
    vmm_init(hhdm_request.response->offset, kaddr_request.response);
    klog_vga(KLOG_OK,   "VMM", "PML4 active -- EFER.NXE + EFER.SCE enabled");
    klog_detail("Kernel:  ", "0xFFFFFFFF80000000 (higher half)");
    klog_detail("HHDM:    ", "0xFFFF800000000000 -- 4GB identity");
    klog_detail("Low mem: ", "0x0000-0xFFFFF identity (boot stack + VGA 0xB8000)");

    /* 5. Slab */
    klog_vga(KLOG_INFO, "SLAB", "Slab allocator...");
    slab_init();
    klog_vga(KLOG_OK,   "SLAB", "kmalloc/kfree -- 9 caches (16-4096B) + large");

    /* 6. ACPI */
    if (rsdp_request.response && rsdp_request.response->address) {
        klog_vga(KLOG_INFO, "ACPI", "RSDP found -- parsing RSDT/XSDT...");
        acpi_init(rsdp_request.response->address);
        klog_vga(KLOG_OK,   "ACPI", "MADT + HPET parsed");
    } else {
        klog_vga(KLOG_WARN, "ACPI", "RSDP not available -- timer uses 1M fallback");
    }

    /* 7. LAPIC + APIC timer + I/O APIC */
    klog_vga(KLOG_INFO, "APIC", "LAPIC init + timer calibration...");
    lapic_init();
    apic_timer_init();
    klog_vga(KLOG_OK,   "APIC", "LAPIC active -- periodic timer 1ms (vec 0x20)");
    {
        char b[12];
        u64_to_dec(g_apic_ticks_per_ms, b);
        klog_detail("HPET calibration: ", b);
        klog_detail("  ticks/ms", "");
    }

    /*
     * I/O APIC -- redirect table initialisation.
     *
     * In APIC mode (after lapic_init), hardware IRQs (keyboard, mouse, etc.)
     * pass through the I/O APIC before reaching the LAPIC. Without this
     * initialisation, IRQ1 (keyboard) never reaches the CPU regardless of
     * how correctly the 8259 PIC is configured.
     *
     * ioapic_init() programs INTIN#1 -> vector 0x21 (kbd) and masks all
     * unused intins to avoid spurious interrupts.
     */
    klog_vga(KLOG_INFO, "IOAPIC", "Programming I/O APIC redirect table...");
    ioapic_init();
    klog_vga(KLOG_OK,   "IOAPIC", "IRQ1->0x21(kbd) IRQ12->0x2C(mouse) active");

    /* 8. PCI */
    klog_vga(KLOG_INFO, "PCI", "Enumerating PCI bus (I/O port 0xCF8/0xCFC)...");
    pci_enumerate();
    klog_vga(KLOG_OK,   "PCI", "PCI bus enumerated");
    dump_pci_vga();

    /* 9. VFS */
    klog_vga(KLOG_INFO, "VFS", "Mounting Virtual Filesystem...");
    vfs_init();
    vfs_mount("/",    tmpfs_get_fs(), NULL);   /* root tmpfs */
    vfs_mount("/dev", devfs_get_fs(), NULL);   /* device fs  */

    /* ── Base directory structure ──────────────────────────────────────────── */
    vfs_mkdir("/tmp",  0x41EDU);
    vfs_mkdir("/etc",  0x41EDU);
    vfs_mkdir("/home", 0x41EDU);
    vfs_mkdir("/var",  0x41EDU);
    vfs_mkdir("/sys",  0x41EDU);

    /* /home/hello.txt -- welcome file */
    vfs_create_file("/home/hello.txt", 0x81A4U);
    {
        file_t *f = vfs_open("/home/hello.txt", 1);
        if (f) { vfs_write(f, "hello\n", 6); vfs_close(f); }
    }

    /* ── /home/mattia_hello -- demo executable ──────────────────────────── *
     * Will be the first "executable" of MattiaOS (Phase 13: ELF loader).   *
     * For now it is a text file describing what it would do.               */
    vfs_create_file("/home/mattia_hello", 0x81EDU); /* -rwxr-xr-x */
    {
        static const char s_hello[] =
            "#!/mattiaos\n"
            "# mattia_hello -- MattiaOS v5.9 demo program\n"
            "# Author: Mattia\n"
            "#\n"
            "# When Phase 13 (ELF loader) is ready, this file\n"
            "# will be replaced by a real x86-64 ELF that prints:\n"
            "#   \"Hello from the first MattiaOS userspace program!\"\n"
            "print \"Hello from the first MattiaOS userspace program!\"\n";
        file_t *f = vfs_open("/home/mattia_hello", 1);
        if (f) { vfs_write(f, s_hello, sizeof(s_hello)-1); vfs_close(f); }
    }

    /* ── /bin -- built-in commands + link to /home/mattia_hello ─────────── */
    vfs_mkdir("/Executables", 0x41EDU);
    {
        static const struct { const char *name; const char *desc; } s_cmds[] = {
            { "help",        "# built-in\nUSAGE: help\n" },
            { "ver",         "# built-in\nUSAGE: ver\n" },
            { "mem",         "# built-in\nUSAGE: mem\n" },
            { "pci",         "# built-in\nUSAGE: pci\n" },
            { "ls",          "# built-in\nUSAGE: ls [path]\n" },
            { "cd",          "# built-in\nUSAGE: cd <path>\n" },
            { "open",        "# built-in\nUSAGE: open <path>\n" },
            { "edit",        "# built-in\nUSAGE: edit <path>\n" },
            { "tree",        "# built-in\nUSAGE: tree [path]\n" },
            { "clear",       "# built-in\nUSAGE: clear\n" },
            { "reboot",      "# built-in\nUSAGE: reboot\n" },
            { "halt",        "# built-in\nUSAGE: halt\n" },
            { "easteregg",   "# built-in\nUSAGE: easteregg\n" },
            { "mattia_hello","# demo Phase 13\nSRC: /home/mattia_hello\nUSAGE: mattia_hello\n" },
        };
        char bp[72];
        for (int i = 0; i < 14; i++) {
            int pi = 0;
            const char *pre = "/Executables/";
            while (pre[pi] && pi < 40) { bp[pi] = pre[pi]; pi++; }
            int ni = 0;
            while (s_cmds[i].name[ni] && pi < 70) { bp[pi] = s_cmds[i].name[ni]; pi++; ni++; }
            bp[pi] = '\0';
            vfs_create_file(bp, 0x81A4U);
            file_t *f = vfs_open(bp, 1);
            if (f) {
                size_t dl = 0; while (s_cmds[i].desc[dl]) dl++;
                vfs_write(f, s_cmds[i].desc, dl); vfs_close(f);
            }
        }
    }

    /* ── /lib -- system libraries ──────────────────────────────────────── *
     * One library per demo program. Built-ins do not need any.            */
    vfs_mkdir("/Dependencies", 0x41EDU);
    vfs_create_file("/Dependencies/libmattiac.so", 0x81A4U);
    {
        static const char s_lib[] =
            "# libmattiac.so -- MattiaOS standard library\n"
            "# Provides: print, input, open, close, read, write\n"
            "# Version: 1.0  (stub -- Phase 13)\n";
        file_t *f = vfs_open("/Dependencies/libmattiac.so", 1);
        if (f) { vfs_write(f, s_lib, sizeof(s_lib)-1); vfs_close(f); }
    }

    /* ── /sys/PATH -- format v5.9 ──────────────────────────────────────────
     * LINE FORMAT: name=exe_path:dep1:dep2:...
     *   name         = command name
     *   exe_path     = absolute path to executable in /Executables/
     *   dep1,dep2,...= absolute paths to dependencies in /Dependencies/
     *                  (':'-separated; absent = no deps)
     * The interpreter (con_exec) reads this line to:
     *   1. find the executable path
     *   2. load dependencies before execution
     * Kernel built-ins have no deps; mattia_hello depends on libmattiac. */
    vfs_create_file("/sys/PATH", 0x81A4U);
    {
        static const char s_path[] =
            "# MattiaOS /sys/PATH v5.9\n"
            "# FORMAT: name=exe_path:dep1:dep2\n"
            "# Kernel built-ins have no dependencies.\n"
            "#\n"
            "help=/Executables/help\n"
            "ver=/Executables/ver\n"
            "mem=/Executables/mem\n"
            "pci=/Executables/pci\n"
            "ls=/Executables/ls\n"
            "cd=/Executables/cd\n"
            "open=/Executables/open\n"
            "edit=/Executables/edit\n"
            "tree=/Executables/tree\n"
            "clear=/Executables/clear\n"
            "reboot=/Executables/reboot\n"
            "halt=/Executables/halt\n"
            "easteregg=/Executables/easteregg\n"
            "mattia_hello=/home/mattia_hello:/Dependencies/libmattiac.so\n";
        file_t *f = vfs_open("/sys/PATH", 1);
        if (f) { vfs_write(f, s_path, sizeof(s_path)-1); vfs_close(f); }
    }

    klog_vga(KLOG_OK,   "VFS", "/ (tmpfs) + /dev (devfs) mounted");
    klog_detail("/sys/PATH: ", "14 entries (built-ins + mattia_hello)");
    klog_detail("/Executables: ", "14 stubs | /home/mattia_hello: demo");
    klog_detail("/Dependencies/libmattiac.so: ", "standard library stub");

    /* 10. Enable interrupts */
    asm volatile("sti");
    klog_vga(KLOG_OK, "CPU", "Interrupts enabled (STI -- RFLAGS.IF=1)");

    /* 11. Hardware drivers */
    klog_vga(KLOG_INFO, "DRV", "Initialising hardware drivers...");
    drivers_init();
    klog_vga(KLOG_OK,   "DRV", "Drivers ready");
    klog_detail("fb:      ", "/dev/fb0 (framebuffer GOP)");
    klog_detail("kbd:     ", "PS/2 IRQ1 -- keyboard_process() on every keypress");
    klog_detail("storage: ", "AHCI + NVMe (if present)");
    klog_detail("net:     ", "virtio-net + e1000 (if present)");

    /* 12. Interactive console (noreturn) */
    kernel_console();
}
