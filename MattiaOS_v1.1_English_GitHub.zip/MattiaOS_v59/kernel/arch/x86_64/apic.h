#ifndef MATTIAOS_APIC_H
#define MATTIAOS_APIC_H

#include "../../include/types.h"

#define LAPIC_BASE         0xFEE00000ULL
#define LAPIC_ID           0x020
#define LAPIC_VERSION      0x030
#define LAPIC_TPR          0x080
#define LAPIC_EOI          0x0B0
#define LAPIC_SPURIOUS     0x0F0
#define LAPIC_ICR_LOW      0x300
#define LAPIC_ICR_HIGH     0x310
#define LAPIC_LVT_TIMER    0x320
#define LAPIC_LVT_LINT0    0x350   /* Local Vector Table: LINT0 pin — connected to the PIC via virtual wire */
#define LAPIC_LVT_LINT1    0x360   /* Local Vector Table: LINT1 pin — NMI */
#define LAPIC_TIMER_INITCNT 0x380
#define LAPIC_TIMER_CURCNT 0x390
#define LAPIC_TIMER_DIV    0x3E0

#define LAPIC_SPURIOUS_ENABLE (1 << 8)
#define LAPIC_TIMER_PERIODIC  (1 << 17)
#define LAPIC_TIMER_VECTOR    0x20
#define LAPIC_TIMER_DIV16     0x03

/* LVT LINT delivery mode field (bits 10:8) */
#define LAPIC_LVT_DELIVERY_FIXED  (0 << 8)  /* vector fixed              */
#define LAPIC_LVT_DELIVERY_NMI    (4 << 8)  /* NMI, ignora the field vector */
#define LAPIC_LVT_DELIVERY_EXTINT (7 << 8)  /* ExtINT: INTA from the PIC external */
#define LAPIC_LVT_MASKED          (1 << 16) /* mask the pin */

#define MSR_IA32_APIC_BASE 0x1B
#define APIC_BASE_ENABLE   (1 << 11)

void lapic_init(void);
void lapic_eoi(void);
void lapic_send_ipi(uint8_t cpu, uint8_t vector);
uint32_t lapic_id(void);

void apic_timer_init(void);
void apic_timer_calibrate(void);

/*
 * ioapic_init — initialise l'I/O APIC for the peripherals legacy.
 *
 * DEVE essere chiamata after acpi_init() (usa l'address I/O APIC from the MADT)
 * AND after lapic_init() (usa lapic_id() for the field destination).
 *
 * Programma the redirect table I/O APIC for:
 *   IRQ1 (keyboard PS/2) → vector 0x21, CPU 0, edge, active high, unmasked
 *   IRQ12 (mouse PS/2)   → vector 0x2C, CPU 0, edge, active high, unmasked
 *   all the altre entrate → masked
 *
 * In VirtualBox with I/O APIC enabled (mandatory for MattiaOS), the IRQ
 * hardware passano for l'I/O APIC, NOT for the path PIC→LINT0. Senza
 * this function, IRQ1 NOT arriva mai to the CPU AND the keyboard NOT risponde.
 */
void ioapic_init(void);

/*
 * g_apic_ticks_per_ms — calculated from apic_timer_calibrate() via HPET.
 * Corrisponde to the number of decrementi of the LAPIC timer in 1 millisecondo
 * with divisore LAPIC_TIMER_DIV16.  Usato dalthe scheduler for tick from 1ms.
 */
extern uint32_t g_apic_ticks_per_ms;

#endif
