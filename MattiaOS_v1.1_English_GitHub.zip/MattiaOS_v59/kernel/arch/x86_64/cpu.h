#ifndef MATTIAOS_CPU_H
#define MATTIAOS_CPU_H

#include "../../include/types.h"

#define COM1_PORT 0x3F8

static inline void outb(uint16_t port, uint8_t val) {
    asm volatile("outb %0, %1" : : "a"(val), "Nd"(port));
}

/*
 * io_wait — delay of ~1 µs via write up port 0x80 (POST code port).
 * Necessario tra write consecutive to PIC/PS2 up hardware reale lento.
 * Su VirtualBox/QEMU NOT è strettamente required ma è best practice.
 */
static inline void io_wait(void) {
    asm volatile("outb %%al, $0x80" : : "a"((uint8_t)0));
}

static inline uint8_t inb(uint16_t port) {
    uint8_t ret;
    asm volatile("inb %1, %0" : "=a"(ret) : "Nd"(port));
    return ret;
}

static inline void outw(uint16_t port, uint16_t val) {
    asm volatile("outw %0, %1" : : "a"(val), "Nd"(port));
}

static inline uint16_t inw(uint16_t port) {
    uint16_t ret;
    asm volatile("inw %1, %0" : "=a"(ret) : "Nd"(port));
    return ret;
}

static inline void outl(uint16_t port, uint32_t val) {
    asm volatile("outl %0, %1" : : "a"(val), "Nd"(port));
}

static inline uint32_t inl(uint16_t port) {
    uint32_t ret;
    asm volatile("inl %1, %0" : "=a"(ret) : "Nd"(port));
    return ret;
}

static inline uint64_t rdmsr(uint32_t msr) {
    uint32_t lo, hi;
    asm volatile("rdmsr" : "=a"(lo), "=d"(hi) : "c"(msr));
    return ((uint64_t)hi << 32) | lo;
}

static inline void wrmsr(uint32_t msr, uint64_t val) {
    asm volatile("wrmsr" : : "a"((uint32_t)val), "d"((uint32_t)(val >> 32)), "c"(msr));
}

static inline uint64_t read_cr2(void) {
    uint64_t val;
    asm volatile("mov %%cr2, %0" : "=r"(val));
    return val;
}

static inline uint64_t read_cr3(void) {
    uint64_t val;
    asm volatile("mov %%cr3, %0" : "=r"(val));
    return val;
}

static inline void write_cr3(uint64_t val) {
    asm volatile("mov %0, %%cr3" : : "r"(val) : "memory");
}

static inline void invlpg(uint64_t addr) {
    asm volatile("invlpg (%0)" : : "r"(addr) : "memory");
}

#define MSR_EFER   0xC0000080
#define MSR_STAR   0xC0000081
#define MSR_LSTAR  0xC0000082
#define MSR_SFMASK 0xC0000084
#define MSR_FS_BASE 0xC0000100
#define MSR_GS_BASE 0xC0000101

#define EFER_SCE   (1 << 0)
#define EFER_LME   (1 << 8)
#define EFER_LMA   (1 << 10)
#define EFER_NXE   (1 << 11)

#define RFLAGS_IF  (1 << 9)
#define RFLAGS_DF  (1 << 10)

typedef struct {
    uint32_t reserved0;
    uint64_t rsp[3];
    uint64_t reserved1;
    uint64_t ist[7];
    uint64_t reserved2;
    uint16_t reserved3;
    uint16_t iopb_offset;
} __attribute__((packed)) tss_t;

void serial_init(void);
void serial_putchar(char c);
void serial_puts(const char *s);
void serial_printf(const char *fmt, ...);

/*
 * pic_init — rimap the PIC 8259 to vectors 0x20/0x28 AND mask the IRQ
 * NOT usati.  DEVE essere chiamata before of sti() for evitare that IRQ
 * hardware (es. IRQ1 keyboard) vengano mapti to the eccezioni CPU 0x08-0x0F.
 *
 * Stato after pic_init():
 *   Master: IRQ0 maskto (usiamo LAPIC timer), IRQ1 active (kbd),
 *           IRQ2 active (cascata slave), IRQ3-7 maskti.
 *   Slave:  IRQ12 active (mouse PS/2), all the altri maskti.
 */
void pic_init(void);

/* klog: livelli of log */
#define KLOG_BOOT   0
#define KLOG_OK     1
#define KLOG_INFO   2
#define KLOG_WARN   3
#define KLOG_ERROR  4
#define KLOG_PANIC  5
void klog(int level, const char *subsystem, const char *fmt, ...);

/* VGA text mode (80×25, 0xB8000) */
void vga_clear(void);
void vga_banner(const char *version);
void vga_putchar_attr(char c, uint16_t attr);
void vga_puts_attr(const char *s, uint16_t attr);
void vga_update_cursor(void);
void vga_get_pos(int *row, int *col);
void vga_set_pos(int row, int col);
void vga_write_at(int row, int col, char c, uint16_t attr);
void vga_set_cursor_hw(int row, int col);
/* Scrollback buffer API */
int  vga_sb_lines(void);
void vga_scrollback_render(int offset);

#endif
