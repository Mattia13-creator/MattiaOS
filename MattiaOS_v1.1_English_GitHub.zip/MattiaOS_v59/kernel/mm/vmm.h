#ifndef MATTIAOS_VMM_H
#define MATTIAOS_VMM_H

#include <limine.h>
#include "../include/types.h"

#define PTE_PRESENT     (1ULL << 0)
#define PTE_WRITABLE    (1ULL << 1)
#define PTE_USER        (1ULL << 2)
#define PTE_WRITE_THRU  (1ULL << 3)
#define PTE_NO_CACHE    (1ULL << 4)
#define PTE_ACCESSED    (1ULL << 5)
#define PTE_DIRTY       (1ULL << 6)
#define PTE_HUGE        (1ULL << 7)
#define PTE_GLOBAL      (1ULL << 8)
#define PTE_NX          (1ULL << 63)

#define PTE_ADDR_MASK   0x000FFFFFFFFFF000ULL

/*
 * Virtual address space layout:
 *   0x0000000000000000 - 0x00007FFFFFFFFFFF  Userspace (128 TB)
 *   0xFFFF800000000000 - 0xFFFFFFFF7FFFFFFF  HHDM (Higher Half Direct Map)
 *   0xFFFFFFFF80000000 - 0xFFFFFFFFFFFFFFFF  Kernel queues + data (2 GB)
 */

typedef uint64_t pml4_t;

void     vmm_init(uint64_t hhdm_offset, struct limine_kernel_address_response *kaddr);
void     vmm_map(pml4_t *pml4, uint64_t virt, uint64_t phys, uint64_t flags);
void     vmm_unmap(pml4_t *pml4, uint64_t virt);
pml4_t  *vmm_new_pagemap(void);
void     vmm_switch_pagemap(pml4_t *pml4);
uint64_t vmm_virt_to_phys(pml4_t *pml4, uint64_t virt);
void     vmm_destroy_pagemap(pml4_t *pml4);
pml4_t  *vmm_clone_pagemap_cow(pml4_t *src);

extern pml4_t  *g_kernel_pml4;
extern uint64_t g_hhdm_offset;

static inline void *phys_to_virt(uint64_t phys) {
    return (void *)(phys + g_hhdm_offset);
}

static inline uint64_t virt_to_phys(void *virt) {
    return (uint64_t)virt - g_hhdm_offset;
}

/* vmm_get_cr3 — value physical from loadre in CR3 for this pagemap */
static inline uint64_t vmm_get_cr3(pml4_t *pml4) {
    return virt_to_phys((void *)pml4);
}

#endif
