#include "slab.h"
#include "pmm.h"
#include "vmm.h"

#define NUM_CACHES 9
static const size_t CACHE_SIZES[NUM_CACHES] = {16,32,64,128,256,512,1024,2048,4096};

/*
 * Ogni oggetto nel slab ha to header nascosto of 8 byte PRIMA of the pointer
 * restituito all'utente.  L'header contiene:
 *   - l'indice of the cache (0-8) for allocatezioni slab
 *   - UINT64_MAX for grandi allocatezioni via PMM
 * Questo garantisce that kfree identifichi sempre the pool corretto without
 * dipendere from euristiche of alignment (that falliscono for the first
 * oggetto of every page AND for offset multipli of più cache-size).
 */
#define SLAB_HDR_SIZE   sizeof(uint64_t)
#define SLAB_LARGE_TAG  UINT64_MAX   /* tag for grandi allocatezioni */

typedef struct slab_header {
    struct slab_header *next_free;
} slab_header_t;

typedef struct slab_cache {
    size_t         obj_size;   /* size TOTALE dell'oggetto, incluso l'header */
    slab_header_t *free_list;
} slab_cache_t;

static slab_cache_t s_caches[NUM_CACHES];

static void slab_grow(slab_cache_t *cache) {
    uint64_t phys = pmm_alloc_frame();
    uint8_t *page = (uint8_t *)phys_to_virt(phys);
    size_t   n    = PAGE_SIZE / cache->obj_size;

    for (size_t i = 0; i < n; i++) {
        slab_header_t *obj = (slab_header_t *)(page + i * cache->obj_size);
        obj->next_free = cache->free_list;
        cache->free_list = obj;
    }
}

void slab_init(void) {
    for (int i = 0; i < NUM_CACHES; i++) {
        s_caches[i].obj_size  = CACHE_SIZES[i];
        s_caches[i].free_list = NULL;
        slab_grow(&s_caches[i]);
    }
}

/*
 * kmalloc — allocate almeno `size` byte.
 *
 * Structure of every block slab:
 *   [ uint64_t cache_idx ][ <size byte utente> ... ]
 *   ^--- obj_base                ^--- pointer restituito
 *
 * Per grandi allocatezioni (size > MAX_SLAB_USABLE):
 *   [ uint64_t LARGE_TAG ][ <size byte utente> ... ]
 * aligned to page physical.
 */
void *kmalloc(size_t size) {
    if (size == 0) return NULL;

    /* search the cache with abbastanza spazio for header + data utente */
    for (int i = 0; i < NUM_CACHES; i++) {
        if (size + SLAB_HDR_SIZE <= s_caches[i].obj_size) {
            if (!s_caches[i].free_list) slab_grow(&s_caches[i]);
            slab_header_t *obj = s_caches[i].free_list;
            s_caches[i].free_list = obj->next_free;
            /* scrivi l'indice of the cache nell'header */
            *(uint64_t *)obj = (uint64_t)i;
            return (uint8_t *)obj + SLAB_HDR_SIZE;
        }
    }

    /* Grande allocation: NOT entra in no cache */
    size_t pages = (size + SLAB_HDR_SIZE + PAGE_SIZE - 1) / PAGE_SIZE;
    uint64_t phys = pmm_alloc_frames(pages);
    if (!phys) return NULL;
    uint64_t *hdr = (uint64_t *)phys_to_virt(phys);
    *hdr = SLAB_LARGE_TAG;
    return hdr + 1;   /* returns the byte subito after l'header */
}

void *kzalloc(size_t size) {
    void *p = kmalloc(size);
    if (p) __builtin_memset(p, 0, size);
    return p;
}

/*
 * kfree — returns the block to the pool originale.
 *
 * Read the tag nascosto to (ptr - 8):
 *   - UINT64_MAX → grande alloc: free the page physical via PMM
 *   - 0..8       → indice cache: returns l'oggetto to the free_list
 */
void kfree(void *ptr) {
    if (!ptr) return;

    uint64_t *hdr = (uint64_t *)ptr - 1;   /* header precede the pointer utente */
    uint64_t  tag = *hdr;

    if (tag == SLAB_LARGE_TAG) {
        /* Grande allocation: hdr AND' page-aligned */
        pmm_free_frame(virt_to_phys(hdr));
        return;
    }

    if (tag >= (uint64_t)NUM_CACHES) return;   /* header corrotto — ignora */

    slab_header_t *obj = (slab_header_t *)hdr;
    obj->next_free = s_caches[tag].free_list;
    s_caches[tag].free_list = obj;
}

/*
 * krealloc — ridimensiona to'allocation.
 * Copy min(old_usable, new_size) byte nel nuovo block.
 */
void *krealloc(void *ptr, size_t new_size) {
    if (!ptr) return kmalloc(new_size);
    if (!new_size) { kfree(ptr); return NULL; }

    /* Calculate the size utente of the block current */
    uint64_t *hdr = (uint64_t *)ptr - 1;
    uint64_t  tag = *hdr;
    size_t old_usable;
    if (tag == SLAB_LARGE_TAG) {
        old_usable = PAGE_SIZE - SLAB_HDR_SIZE;   /* almeno to page */
    } else if (tag < (uint64_t)NUM_CACHES) {
        old_usable = s_caches[tag].obj_size - SLAB_HDR_SIZE;
    } else {
        return NULL;   /* header corrotto */
    }

    void *new_ptr = kmalloc(new_size);
    if (new_ptr) {
        size_t copy_size = old_usable < new_size ? old_usable : new_size;
        __builtin_memcpy(new_ptr, ptr, copy_size);
        kfree(ptr);
    }
    return new_ptr;
}
