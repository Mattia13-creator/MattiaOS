#include "pmm.h"
#include "../arch/x86_64/cpu.h"

pmm_t g_pmm;

#define BITMAP_SET(n)   (g_pmm.bitmap[(n) / 8] |=  (1 << ((n) % 8)))
#define BITMAP_CLEAR(n) (g_pmm.bitmap[(n) / 8] &= ~(1 << ((n) % 8)))
#define BITMAP_TEST(n)  (g_pmm.bitmap[(n) / 8] &   (1 << ((n) % 8)))

#define PMM_MAX_PHYS        0x100000000ULL   /* 4 GB — limite HHDM */
#define PMM_RESERVED_BELOW  0x400000ULL      /* 4 MB — page tables + staging */

/*
 * pmm_init — initialise the Physical Memory Manager.
 *
 * PARAMETRI:
 *   memmap          — rimove Limine with the map E820 of the BIOS.
 *   kernel_phys_end — address physical OLTRE the end of the kernel (BSS incluso,
 *                     aligned to PAGE_SIZE). Usato for garantire that the
 *                     bitmap PMM venga posizionato DOPO the kernel.
 *
 * BUG v5.9 — ROOT CAUSE AND FIX (Appendix C of the Blueprint):
 *   Con the variabili statiche of cmd_tree/cmd_cat the BSS of the kernel cresceva
 *   to 2.2MB, portndo kernel_phys_end to ~0x453000 (above PMM_RESERVED_BELOW).
 *   Con 4.8GB RAM bitmap_size=128KB. Il vecchio algorithm posizionava the
 *   bitmap to the first address usable >= PMM_RESERVED_BELOW = 0x400000, ossia
 *   inside the BSS of the kernel. La conseguente
 *       memset(bitmap, 0xFF, 128KB)
 *   sovrawriteva the BSS with 0xFF corrompendo variabili statiche critiche.
 *   La corruzione si manifestava as triple fault all'STI iniziale (first
 *   timer interrupt up stato corrotto). Sistema host: VirtualBox 4.8GB/6CPU.
 *
 *   Fix: bitmap_min = max(PMM_RESERVED_BELOW, kernel_phys_end).
 *   Il bitmap è sempre posizionato DOPO the kernel, indipendentemente from the
 *   size of the BSS OR from the quantità of RAM of the system host.
 */
void pmm_init(struct limine_memmap_response *memmap, uint64_t kernel_phys_end) {
    uint64_t highest_addr = 0;

    for (uint64_t i = 0; i < memmap->entry_count; i++) {
        struct limine_memmap_entry *entry = memmap->entries[i];
        uint64_t end = entry->base + entry->length;
        if (end > PMM_MAX_PHYS) end = PMM_MAX_PHYS;
        if (end > highest_addr) highest_addr = end;
    }

    g_pmm.total_frames = highest_addr / PAGE_SIZE;
    g_pmm.bitmap_size  = (g_pmm.total_frames + 7) / 8;

    /* Soglia minima: bitmap DOPO kernel E DOPO 4MB riservati to the boot */
    uint64_t bitmap_min = kernel_phys_end;
    if (bitmap_min < PMM_RESERVED_BELOW) bitmap_min = PMM_RESERVED_BELOW;
    bitmap_min = (bitmap_min + 0xFFFULL) & ~0xFFFULL;

    for (uint64_t i = 0; i < memmap->entry_count; i++) {
        struct limine_memmap_entry *entry = memmap->entries[i];
        if (entry->type != LIMINE_MEMMAP_USABLE) continue;

        uint64_t start = entry->base < bitmap_min ? bitmap_min : entry->base;
        uint64_t end   = entry->base + entry->length;
        if (end > PMM_MAX_PHYS) end = PMM_MAX_PHYS;
        if (start >= end) continue;

        if ((end - start) >= g_pmm.bitmap_size) {
            g_pmm.bitmap      = (uint8_t *)(start + HHDM_OFFSET);
            g_pmm.bitmap_phys = start;
            break;
        }
    }

    if (!g_pmm.bitmap) {
        extern void serial_puts(const char *);
        serial_puts("\r\nPANIC: PMM none regione >= bitmap_size!\r\n");
        asm volatile("cli; hlt");
        __builtin_unreachable();
    }

    __builtin_memset(g_pmm.bitmap, 0xFF, g_pmm.bitmap_size);
    g_pmm.free_frames = 0;

    for (uint64_t i = 0; i < memmap->entry_count; i++) {
        struct limine_memmap_entry *entry = memmap->entries[i];
        if (entry->type != LIMINE_MEMMAP_USABLE) continue;

        uint64_t base_adj = entry->base < bitmap_min ? bitmap_min : entry->base;
        uint64_t end      = entry->base + entry->length;
        if (end > PMM_MAX_PHYS) end = PMM_MAX_PHYS;
        if (base_adj >= end) continue;

        for (uint64_t addr = base_adj; addr < end; addr += PAGE_SIZE) {
            uint64_t frame = addr / PAGE_SIZE;
            BITMAP_CLEAR(frame);
            g_pmm.free_frames++;
        }
    }

    /* Re-mark the bitmap stessa as usata */
    for (uint64_t i = 0; i < (g_pmm.bitmap_size + PAGE_SIZE - 1) / PAGE_SIZE; i++) {
        uint64_t frame = g_pmm.bitmap_phys / PAGE_SIZE + i;
        if (!BITMAP_TEST(frame)) {
            BITMAP_SET(frame);
            g_pmm.free_frames--;
        }
    }
}

uint64_t pmm_alloc_frame(void) {
    uint64_t first = PMM_RESERVED_BELOW / PAGE_SIZE;
    for (uint64_t i = first; i < g_pmm.total_frames; i++) {
        if (!BITMAP_TEST(i)) {
            BITMAP_SET(i);
            g_pmm.free_frames--;
            return i * PAGE_SIZE;
        }
    }
    return 0;
}

void pmm_free_frame(uint64_t phys_addr) {
    uint64_t frame = phys_addr / PAGE_SIZE;
    if (frame < g_pmm.total_frames && BITMAP_TEST(frame)) {
        BITMAP_CLEAR(frame);
        g_pmm.free_frames++;
    }
}

uint64_t pmm_alloc_frames(size_t count) {
    uint64_t first = PMM_RESERVED_BELOW / PAGE_SIZE;
    uint64_t start = 0, run = 0;
    for (uint64_t i = first; i < g_pmm.total_frames; i++) {
        if (!BITMAP_TEST(i)) {
            if (run == 0) start = i;
            run++;
            if (run == count) {
                for (uint64_t j = start; j < start + count; j++) {
                    BITMAP_SET(j);
                    g_pmm.free_frames--;
                }
                return start * PAGE_SIZE;
            }
        } else {
            run = 0;
        }
    }
    return 0;
}

uint64_t pmm_total_memory(void) { return g_pmm.total_frames * PAGE_SIZE; }
uint64_t pmm_free_memory(void)  { return g_pmm.free_frames  * PAGE_SIZE; }

void pmm_mark_used(uint64_t phys_start, uint64_t phys_end) {
    for (uint64_t addr = phys_start & ~0xFFFULL; addr < phys_end; addr += PAGE_SIZE) {
        uint64_t frame = addr / PAGE_SIZE;
        if (frame < g_pmm.total_frames && !BITMAP_TEST(frame)) {
            BITMAP_SET(frame);
            if (g_pmm.free_frames > 0) g_pmm.free_frames--;
        }
    }
}
