#ifndef MATTIAOS_PMM_H
#define MATTIAOS_PMM_H

#include <limine.h>
#include "../include/types.h"

typedef struct {
    uint8_t  *bitmap;
    uint64_t  total_frames;
    uint64_t  free_frames;
    uint64_t  bitmap_size;
    uint64_t  bitmap_phys;
} pmm_t;

/* kernel_phys_end: address physical OLTRE the end of the kernel (BSS incluso).
 * Usato for posizionare the bitmap PMM DOPO the kernel AND NOT sovrawritere the BSS.
 * BUG v5.9: with BSS>1MB the kernel superava PMM_RESERVED_BELOW=0x400000,
 * the bitmap veniva piazzato to 0x400000 sovrawritendo the BSS with 0xFF → triple fault. */
void     pmm_init(struct limine_memmap_response *memmap, uint64_t kernel_phys_end);
uint64_t pmm_alloc_frame(void);
void     pmm_free_frame(uint64_t phys_addr);
uint64_t pmm_alloc_frames(size_t count);
uint64_t pmm_total_memory(void);
uint64_t pmm_free_memory(void);
void     pmm_mark_used(uint64_t phys_start, uint64_t phys_end);

extern pmm_t g_pmm;

#endif
