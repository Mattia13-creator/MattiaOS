#ifndef MATTIAOS_KEYBOARD_H
#define MATTIAOS_KEYBOARD_H

/*
 * kernel/drivers/input/keyboard.h — layer of astrazione keyboard
 *
 * Converte the byte grezzi PS/2 (scan code set 2) in key_event_t:
 *   - keycode virtual (vk_t) — identifica the tasto physical
 *   - flag pressed/released
 *   - stato of the modificatori (Shift, Ctrl, Alt, CapsLock, NumLock)
 *   - carattere ASCII (0 if NOT printable)
 *
 * Questo layer NON sa nulla of finestre, focus OR GUI (Principio 4).
 * Produce only eventi grezzi that vengono letti from:
 *   - shell (in modalita' CLI via /dev/kbd0 OR direct poll)
 *   - compositor (in modalita' GUI, Fase 13+)
 *
 * Scan code set 2:
 *   Byte singolo: make code (pressed)
 *   Prefixed F0:  break code (released)
 *   Prefixed E0:  tasto esteso (frecce, ins, of the, home, end, pg…)
 *   Prefixed E0 F0: break code of tasto esteso
 *
 * Dependencies:
 *   ps2.h   — ps2_kbd_read_byte, ps2_kbd_set_leds
 *   types.h — types primitivi
 */

#include "ps2.h"

/* =========================================================================
 * Virtual Keycodess (vk_t)
 *
 * Identificano the tasto physical indipendentemente from the layout.
 * I values < 128 corrispondono to the caratteri ASCII for the tasti printbili.
 * I values >= 128 identificano tasti speciali.
 * ========================================================================= */

typedef enum {
    /* Tasti NOT validi / sconosciuti */
    VK_NONE        = 0,

    /* Tasti alfabetici — values ASCII of the minuscole */
    VK_A = 'a', VK_B = 'b', VK_C = 'c', VK_D = 'd', VK_E = 'e',
    VK_F = 'f', VK_G = 'g', VK_H = 'h', VK_I = 'i', VK_J = 'j',
    VK_K = 'k', VK_L = 'l', VK_M = 'm', VK_N = 'n', VK_O = 'o',
    VK_P = 'p', VK_Q = 'q', VK_R = 'r', VK_S = 's', VK_T = 't',
    VK_U = 'u', VK_V = 'v', VK_W = 'w', VK_X = 'x', VK_Y = 'y',
    VK_Z = 'z',

    /* Cifre (riga superiore keyboard) */
    VK_0 = '0', VK_1 = '1', VK_2 = '2', VK_3 = '3', VK_4 = '4',
    VK_5 = '5', VK_6 = '6', VK_7 = '7', VK_8 = '8', VK_9 = '9',

    /* Tasti of punteggiatura / simboli (values ASCII corrispondenti) */
    VK_SPACE      = ' ',
    VK_ENTER      = '\n',
    VK_TAB        = '\t',
    VK_BACKSPACE  = '\b',
    VK_ESCAPE     = 0x1B,

    VK_MINUS      = '-',   /* - _ */
    VK_EQUALS     = '=',   /* = + */
    VK_LBRACKET   = '[',   /* [ { */
    VK_RBRACKET   = ']',   /* ] } */
    VK_BACKSLASH  = '\\',  /* \ | */
    VK_SEMICOLON  = ';',   /* ; : */
    VK_APOSTROPHE = '\'',  /* ' " */
    VK_GRAVE      = '`',   /* ` ~ */
    VK_COMMA      = ',',   /* , < */
    VK_PERIOD     = '.',   /* . > */
    VK_SLASH      = '/',   /* / ? */

    /* Tasti function — values >= 128 */
    VK_F1  = 128, VK_F2,  VK_F3,  VK_F4,
    VK_F5,        VK_F6,  VK_F7,  VK_F8,
    VK_F9,        VK_F10, VK_F11, VK_F12,

    /* Modificatori */
    VK_LSHIFT = 144, VK_RSHIFT,
    VK_LCTRL,        VK_RCTRL,
    VK_LALT,         VK_RALT,
    VK_LMETA,        VK_RMETA,   /* tasto Windows/Super */

    /* Lock keys */
    VK_CAPSLOCK  = 160,
    VK_NUMLOCK,
    VK_SCROLLLOCK,

    /* Navigazione */
    VK_UP    = 168, VK_DOWN,  VK_LEFT,  VK_RIGHT,
    VK_HOME,        VK_END,
    VK_PGUP,        VK_PGDN,
    VK_INSERT,      VK_DELETE,

    /* Tastierino numerico */
    VK_KP0 = 184, VK_KP1, VK_KP2, VK_KP3, VK_KP4,
    VK_KP5,       VK_KP6, VK_KP7, VK_KP8, VK_KP9,
    VK_KP_DOT,    VK_KP_ENTER, VK_KP_PLUS, VK_KP_MINUS,
    VK_KP_STAR,   VK_KP_SLASH,

    /* Vari */
    VK_PRINT_SCREEN = 200,
    VK_PAUSE,
    VK_SYSRQ,

    VK_MAX = 255
} vk_t;

/* =========================================================================
 * Stato modificatori
 *
 * Bitmask usata in key_event_t.modifiers.
 * ========================================================================= */

#define MOD_LSHIFT   (1 << 0)
#define MOD_RSHIFT   (1 << 1)
#define MOD_SHIFT    (MOD_LSHIFT | MOD_RSHIFT)
#define MOD_LCTRL    (1 << 2)
#define MOD_RCTRL    (1 << 3)
#define MOD_CTRL     (MOD_LCTRL | MOD_RCTRL)
#define MOD_LALT     (1 << 4)
#define MOD_RALT     (1 << 5)
#define MOD_ALT      (MOD_LALT | MOD_RALT)
#define MOD_CAPSLOCK (1 << 6)
#define MOD_NUMLOCK  (1 << 7)

/* =========================================================================
 * key_event_t — evento keyboard prodotto from keyboard.c
 *
 * Consumato from the shell (CLI) AND from the compositor (GUI).
 * ========================================================================= */

typedef struct {
    vk_t    keycode;    /* tasto physical premuto/rilasciato          */
    bool    pressed;    /* true = pressed, false = released         */
    uint8_t modifiers;  /* bitmask MOD_*                            */
    char    ascii;      /* carattere ASCII (0 if NOT printable)    */
} key_event_t;

/* =========================================================================
 * Ring buffer eventi keyboard
 *
 * keyboard.c deposita key_event_t qui; the consumatori leggono with
 * keyboard_poll_event().
 * ========================================================================= */

#define KBD_EVENT_BUF_SIZE 128  /* potenza of 2 for masktura O(1) */

typedef struct {
    key_event_t events[KBD_EVENT_BUF_SIZE];
    uint32_t    head;
    uint32_t    tail;
    spinlock_t  lock;
} kbd_event_ring_t;

extern kbd_event_ring_t g_kbd_events;

/* =========================================================================
 * API pubblica
 * ========================================================================= */

/*
 * keyboard_init — initialise the state machine AND the ring buffer eventi.
 *   Chiamata from drivers_init() after ps2_init().
 *   Non ha bisogno of accedere all'hardware direttamente.
 */
void keyboard_init(void);

/*
 * keyboard_process — processa the byte grezzi accumulati in g_ps2_kbd_buf
 *   AND li converte in key_event_t depositati in g_kbd_events.
 *   Deve essere chiamata periodicamente (es. from the tick delthe scheduler
 *   OR from to loop of polling nella shell).
 *   Non blocking: esce when g_ps2_kbd_buf AND' empty.
 */
void keyboard_process(void);

/*
 * keyboard_poll_event — estrae the next evento from the ring buffer.
 *   Non blocking: returns false if NOT ci are eventi.
 *   out: pointer all'evento from riempire (NOT NULL).
 */
bool keyboard_poll_event(key_event_t *out);

/*
 * keyboard_getchar — returns the next carattere ASCII printable.
 *   Ignora eventi of release AND tasti NOT-ASCII.
 *   Non blocking: returns 0 if no carattere available.
 *   Comodo for the shell in modalita' CLI.
 */
char keyboard_getchar(void);

/*
 * keyboard_get_modifiers — returns the bitmask MOD_* current.
 */
uint8_t keyboard_get_modifiers(void);

#endif /* MATTIAOS_KEYBOARD_H */
