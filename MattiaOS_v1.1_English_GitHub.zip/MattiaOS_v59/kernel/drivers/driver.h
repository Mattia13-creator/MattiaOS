#ifndef MATTIAOS_DRIVER_H
#define MATTIAOS_DRIVER_H

/*
 * kernel/drivers/driver.h — interface base of the sottosistema driver
 *
 * Questo file definisce the structures AND the API usate from all the driver kernel.
 * Ogni file .c of driver include this header as before dependency.
 *
 * Contenuto:
 *   §1  Classificazione device      (dev_type_t, device_state_t)
 *   §2  Vtable operations           (char_ops_t, block_ops_t, net_ops_t)
 *   §3  Structures driver_t, device_t
 *   §4  Primitive spinlock IRQ-safe
 *   §5  Helper MMIO
 *   §6  Table dispatch IRQ        (g_irq_handlers[256])
 *   §7  API device tree
 *   §8  Punto of entry global   (drivers_init)
 *
 * Dependencies dirette (sempre available nel kernel):
 *   kernel/include/types.h   — types primitivi, spinlock_t, HHDM_OFFSET
 *   kernel/include/errno.h   — codici error EOK / E*
 *   kernel/arch/x86_64/idt.h — interrupt_frame_t
 *
 * Principi rispettati:
 *   Principio 2 — no refcount: device_remove() AND' immediato.
 *   Principio 3 — massimo controllo hardware: MMIO helpers espongono
 *                 l'accesso diretto to the registers fisici via HHDM.
 */

#include "../include/types.h"
#include "../mm/vmm.h"   /* g_hhdm_offset for mmio helpers */
#include "../include/errno.h"
#include "../arch/x86_64/idt.h"

/* =========================================================================
 * §1 — Classificazione device
 *
 * dev_type_t identifica the categoria funzionale of to device.
 * I values DEV_TYPE_CHAR / BLOCK / NET corrispondono esattamente to quelli
 * attesi from devfs.h, that include this header.
 * ========================================================================= */

typedef enum {
    DEV_TYPE_UNKNOWN = 0,
    DEV_TYPE_CHAR,      /* fb0, tty0, ttyS0, null, zero, random, kbd0 */
    DEV_TYPE_BLOCK,     /* sda, sdb, nvme0 — accesso to sectors         */
    DEV_TYPE_NET,       /* eth0, wlan0 — network interface             */
    DEV_TYPE_INPUT,     /* ps2kbd, ps2mouse — input events             */
    DEV_TYPE_BUS,       /* node virtual: pci_root, ps2_ctrl           */
    DEV_TYPE_MISC,      /* all the resto                              */
} dev_type_t;

typedef enum {
    DEV_STATE_UNINITIALIZED = 0,
    DEV_STATE_PROBING,
    DEV_STATE_ACTIVE,
    DEV_STATE_SUSPENDED,
    DEV_STATE_ERROR,
    DEV_STATE_REMOVED,
} device_state_t;

/* Forward declarations for the types ricorsivi */
struct driver;
struct device;

/* =========================================================================
 * §2 — Vtable operations
 *
 * Ogni famiglia of device espone to propria vtable.
 * Solo the vtable corrispondente to dev_type_t AND' NOT-NULL in device_t.
 * ========================================================================= */

/* -------------------------------------------------------------------------
 * char_ops_t — character device (fb, tty, null, zero, random)
 *
 * open/close: management of the fd; possono essere NULL if NOT serve stato.
 * read/write: trasferimento data; returnsno bytes trasferiti (>= 0)
 *             or negative error negative from errno.h.
 * ioctl:      comandi device-specific; arg AND' interpretato from the driver.
 * ------------------------------------------------------------------------- */
typedef struct {
    int     (*open) (struct device *dev, uint32_t flags);
    int     (*close)(struct device *dev);
    ssize_t (*read) (struct device *dev, void *buf, size_t count,
                     off_t offset);
    ssize_t (*write)(struct device *dev, const void *buf, size_t count,
                     off_t offset);
    int     (*ioctl)(struct device *dev, uint32_t cmd, uint64_t arg);
} char_ops_t;

/* -------------------------------------------------------------------------
 * block_ops_t — block device (AHCI/SATA, NVMe)
 *
 * lba:   Logical Block Address (0-based, 48-bit for SATA, 64-bit for NVMe).
 * count: number of sectors from trasferire.
 * buf:   buffer in memory virtual (HHDM-mapto, aligned to 4 KB for DMA).
 * Returns EOK or negative error negative.
 *
 * sector_count AND sector_size are fields of stato setti from init():
 *   sector_size AND' 512 for SATA legacy, 4096 for Advanced Format AND NVMe.
 * flush(): sload cache write-back interna (FUA). Puo' essere NULL.
 * ------------------------------------------------------------------------- */
typedef struct {
    int (*read_sectors) (struct device *dev, uint64_t lba, uint32_t count,
                         void *buf);
    int (*write_sectors)(struct device *dev, uint64_t lba, uint32_t count,
                         const void *buf);
    int (*flush)        (struct device *dev);
    int (*ioctl)        (struct device *dev, uint32_t cmd, uint64_t arg);

    uint64_t sector_count;  /* total sectors — set from ahci_init/nvme_init */
    uint32_t sector_size;   /* 512 OR 4096 bytes for sector                      */
} block_ops_t;

/* -------------------------------------------------------------------------
 * net_ops_t — network device (virtio-net, e1000)
 *
 * send_packet: send to frame Ethernet grezzo; data punta to the frame complete
 *              (header Ethernet incluso), len in bytes.
 * rx_callback: pointer installato dallo stack ethernet (ethernet_init())
 *              after the registerzione of the device; the driver the chiama in IRQ
 *              passando the frame received.
 * get_mac/set_mac: MAC address in formato 6 byte big-endian.
 * enable_rx/disable_rx: enableno/disenableno the ricezione hardware.
 * mtu: Maximum Transmission Unit in bytes (default 1500).
 * ------------------------------------------------------------------------- */
typedef struct {
    int  (*send_packet) (struct device *dev, const void *data, uint16_t len);
    void (*get_mac)     (struct device *dev, uint8_t mac[6]);
    int  (*set_mac)     (struct device *dev, const uint8_t mac[6]);
    void (*enable_rx)   (struct device *dev);
    void (*disable_rx)  (struct device *dev);
    int  (*ioctl)       (struct device *dev, uint32_t cmd, uint64_t arg);

    /* installato from ethernet_init() after device_add() — chiamato in IRQ */
    void (*rx_callback) (struct device *dev, const void *data, uint16_t len);

    uint32_t mtu;
} net_ops_t;

/* =========================================================================
 * §3 — driver_t AND device_t
 * ========================================================================= */

/* -------------------------------------------------------------------------
 * driver_t — descriptor of to class of device
 *
 * Una istanza for every driver (ahci_driver, e1000_driver, ...).
 * I callback are chiamati from the sottosistema nell'ordine:
 *
 *   probe()   — the kernel chiede if the driver gestisce this device.
 *               Esamina dev->driver_data (es. pci_device_t*).
 *               Returns EOK (sì) OR EINVAL (no).
 *   init()    — allocate risorse, initialise hardware, register IRQ AND devfs.
 *               Set dev->state = DEV_STATE_ACTIVE if va to buon end.
 *   remove()  — de-initialise hardware, free risorse, de-register IRQ.
 *               Rimozione immediata without attese (Principio 2).
 *   suspend() — risparmio energetico — stub that returns EOK inizialmente.
 *   resume()  — risveglio from suspend.
 *
 * I callback possono essere NULL if l'operation NOT AND' applicabile.
 * ------------------------------------------------------------------------- */
typedef struct driver {
    char     name[64];     /* "ahci", "e1000", "ps2kbd", "virtio_net", ... */
    uint32_t version;      /* 0x00010000 = v1.0 — (major << 16) | minor    */

    int (*probe)  (struct device *dev);
    int (*init)   (struct device *dev);
    int (*remove) (struct device *dev);
    int (*suspend)(struct device *dev);
    int (*resume) (struct device *dev);

    struct driver *next;   /* lista collegata global of the driver registerti */
} driver_t;

/* -------------------------------------------------------------------------
 * device_t — node nel device tree
 *
 * Ogni device physical OR virtual ha to node in this albero.
 * I nodes are collegati in structure ad albero (parent/children/sibling)
 * AND in to lista piatta global (g_device_root -> next) for enumeratezione.
 *
 * NOTA — no refcount (Principio 2):
 *   device_remove() rimuove the node immediatamente from the tree, without
 *   attendere that qualcuno smetta of usare the device.
 *
 * lock: spinlock for proteggere state AND driver_data from accessi concorrenti.
 *       NON usare for I/O: the operations lunghe hanno the propri lock interni.
 * ------------------------------------------------------------------------- */
typedef struct device {
    char           name[64];    /* "sda", "eth0", "fb0", "kbd0", ...        */
    dev_type_t     type;
    device_state_t state;

    driver_t      *driver;      /* driver owner — NULL if NOT ancora bound  */
    void          *driver_data; /* stato private of the driver (cast nel .c)   */

    /* vtable — to sola AND' NOT-NULL in base to type */
    char_ops_t    *char_ops;
    block_ops_t   *block_ops;
    net_ops_t     *net_ops;

    /* albero of the device */
    struct device *parent;      /* NULL for the children of g_device_root        */
    struct device *children;    /* first child                             */
    struct device *sibling;     /* next fratello nella lista of the parent */
    struct device *next;        /* lista piatta global                     */

    spinlock_t     lock;        /* protezione accesso concurrent to state   */
} device_t;

/* =========================================================================
 * §4 — Primitive spinlock IRQ-safe
 *
 * Tutte the primitive (spinlock_acquire, spinlock_release, irq_save,
 * irq_restore, spinlock_irqsave, spinlock_irqrestore) are definite
 * as static inline in kernel/include/types.h, dove spinlock_t vive.
 * ========================================================================= */

/* =========================================================================
 * §5 — Helper MMIO
 *
 * Tutta the memory physical AND' mapta linearmente nell'HHDM (Higher Half
 * Direct Map) to partire from HHDM_OFFSET (definito in types.h as
 * 0xFFFF800000000000).
 *
 * I driver ottengono l'address virtual of to address physical with
 * phys_to_virt() OR mmio_base(), poi leggono/scrivono with mmio_readXX/mmio_writeXX.
 *
 * Il qualificatore volatile impedisce to the compilatore of risortre OR
 * removere accessi to registers hardware.
 * mmio_barrier() aggiunge to barriera esplicita for sequences of write
 * that devono essere completate in ordine before of continuare.
 *
 * Uso tipico (AHCI HBA memory):
 *   uint32_t cap = mmio_read32(hba_phys + HBA_CAP);
 *   mmio_write32(hba_phys + HBA_GHC, GHC_RESET);
 *   mmio_barrier();
 * ========================================================================= */

/* virt_to_phys_hhdm — inverso of phys_to_virt (usa g_hhdm_offset) */
static inline uint64_t virt_to_phys_hhdm(void *virt) {
    return (uint64_t)virt - g_hhdm_offset;
}

/* Pointer base up cui fare accesso to struct MMIO (zero-overhead cast) */
static inline void *mmio_base(uint64_t phys) {
    return (void *)(phys + g_hhdm_offset);
}

static inline uint8_t mmio_read8(uint64_t phys) {
    return *(volatile uint8_t  *)(phys + g_hhdm_offset);
}

static inline uint16_t mmio_read16(uint64_t phys) {
    return *(volatile uint16_t *)(phys + g_hhdm_offset);
}

static inline uint32_t mmio_read32(uint64_t phys) {
    return *(volatile uint32_t *)(phys + g_hhdm_offset);
}

static inline uint64_t mmio_read64(uint64_t phys) {
    return *(volatile uint64_t *)(phys + g_hhdm_offset);
}

static inline void mmio_write8(uint64_t phys, uint8_t val) {
    *(volatile uint8_t  *)(phys + g_hhdm_offset) = val;
}

static inline void mmio_write16(uint64_t phys, uint16_t val) {
    *(volatile uint16_t *)(phys + g_hhdm_offset) = val;
}

static inline void mmio_write32(uint64_t phys, uint32_t val) {
    *(volatile uint32_t *)(phys + g_hhdm_offset) = val;
}

static inline void mmio_write64(uint64_t phys, uint64_t val) {
    *(volatile uint64_t *)(phys + g_hhdm_offset) = val;
}

/*
 * mmio_barrier — memory barrier compilatore.
 *   Garantisce that the accessi scritti before NOT vengano risortti
 *   after this instruction from the compilatore.
 *   Per barriera hardware complete usare MFENCE (necessaria up x86 SMP
 *   for store-load ordering, NOT richiesta up UP OR for MMIO with UC pages).
 */
static inline void mmio_barrier(void) {
    __asm__ __volatile__("" ::: "memory");
}

/* =========================================================================
 * §6 — Table dispatch IRQ
 *
 * g_irq_handlers[vector] AND' chiamato from isr_handler() (idt.c) ad every
 * interrupt hardware. Dopo the chiamata, isr_handler chiama lapic_eoi().
 *
 * Mapping vectors — LAPIC remapped, base 0x20 (vector = IRQ + 0x20):
 *   0x20  APIC timer       (riservato — gestito internamente from apic.c)
 *   0x21  PS/2 keyboard    IRQ1
 *   0x28  RTC              IRQ8
 *   0x2A  NVMe             IRQ10 (OR MSI dynamic)
 *   0x2B  AHCI             IRQ11 (OR MSI dynamic)
 *   0x2C  PS/2 mouse       IRQ12
 *   0x2E  e1000/virtio-net IRQ14 (OR MSI dynamic)
 *
 * Driver with MSI registerno the vector assegnato dinamicamente from the PCI layer.
 * ========================================================================= */

typedef void (*irq_handler_t)(interrupt_frame_t *frame);

/* Table global — definita AND initialiseta in irq.c */
extern irq_handler_t g_irq_handlers[256];

/*
 * register_irq_handler — installa handler for the vector vector.
 *   Sovrawrite without avviso the previous handler.
 *   Da chiamare in driver->init(), before of enablere the IRQ sul device.
 */
void register_irq_handler(uint8_t vector, irq_handler_t handler);

/*
 * unregister_irq_handler — set g_irq_handlers[vector] = NULL.
 *   Da chiamare in driver->remove().
 */
void unregister_irq_handler(uint8_t vector);

/* =========================================================================
 * §7 — API device tree
 *
 * Il device tree AND' to gerarchia of device_t with root g_device_root.
 * Ogni device AND' also in to lista piatta for l'enumeratezione O(n).
 *
 * NOTA sulle dependencies:
 *   device_alloc() usa kmalloc() from slab.h.
 *   I file .c that chiamano device_alloc includono slab.h separatamente.
 *   Questo header NON include slab.h for evitare dependencies circolari.
 * ========================================================================= */

/* Radice global of the device tree — initialiseta from drivers_init() */
extern device_t *g_device_root;

/*
 * device_alloc — allocate AND zero to node device_t via kmalloc.
 *   name: stringa identificativa (copyta, max 63 caratteri).
 *   type: classificazione funzionale.
 *   Returns pointer to the nuovo device_t, OR NULL if OOM.
 */
device_t *device_alloc(const char *name, dev_type_t type);

/*
 * device_add — inserisce dev nel device tree as child of parent.
 *   Se parent AND' NULL, dev AND' child of g_device_root.
 *   Inserisce also nella lista piatta global.
 *   Se dev->driver != NULL chiama probe(); if EOK chiama init().
 */
void device_add(device_t *dev, device_t *parent);

/*
 * device_remove — rimuove dev from the device tree AND from the lista piatta.
 *   Se driver active chiama driver->remove(dev).
 *   Rimozione immediata, without refcount (Principio 2).
 */
void device_remove(device_t *dev);

/*
 * device_find_by_name — risearch lineare for name esatto.
 *   Returns the first match OR NULL.
 */
device_t *device_find_by_name(const char *name);

/*
 * device_find_by_type — returns the first device with the type required.
 *   Utile for findre the first disk (DEV_TYPE_BLOCK), the before NIC, ecc.
 */
device_t *device_find_by_type(dev_type_t type);

/* driver_register — register to driver_t nella lista global.
 * Chiamata from ciascun modulo driver during drivers_init().
 */
void driver_register(driver_t *drv);

/* =========================================================================
 * §8 — Initialisezione global of the sottosistema driver
 *
 * drivers_init() AND' chiamata from kernel_main() after:
 *   acpi_init()       — MADT, HPET, MCFG noti
 *   pci_enumerate()   — g_pci_devices[] popolato
 *
 * Sequence interna:
 *   1. Zero g_irq_handlers[]
 *   2. Initialise g_device_root (node virtual "root")
 *   3. fb_init()          — framebuffer GOP    → /dev/fb0
 *   4. ps2_init()         — PS/2 controller   → /dev/kbd0, /dev/mouse0
 *   5. ahci_init()        — SATA              → /dev/sda, /dev/sdb, ...
 *   6. nvme_init()        — NVMe              → /dev/nvme0, ...
 *   7. virtio_net_init()  — virtio-net QEMU   → /dev/eth0
 *   8. e1000_init()       — Intel e1000       → /dev/eth0
 * ========================================================================= */

void drivers_init(void);

#endif /* MATTIAOS_DRIVER_H */
