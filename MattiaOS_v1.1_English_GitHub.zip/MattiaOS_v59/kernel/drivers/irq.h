#ifndef MATTIAOS_IRQ_H
#define MATTIAOS_IRQ_H

/*
 * kernel/drivers/irq.h — stub of inclusione for simmetria .h/.c
 *
 * irq.c implementa the functions NOT-inline dichiarate in driver.h:
 *   register_irq_handler, unregister_irq_handler,
 *   device_alloc, device_add, device_remove,
 *   device_find_by_name, device_find_by_type,
 *   driver_register, drivers_init.
 *
 * Tutta the dichiarazione pubblica è in driver.h — includere quello.
 */

#include "driver.h"

#endif /* MATTIAOS_IRQ_H */
