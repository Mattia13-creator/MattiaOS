#ifndef MATTIAOS_VIRTIO_NET_H
#define MATTIAOS_VIRTIO_NET_H

/*
 * kernel/drivers/net/virtio_net.h — driver VirtIO-Net (QEMU/KVM)
 *
 * Gestisce the device of network paravirtualizzato VirtIO (legacy PCI,
 * spec VirtIO 0.9.5 / transitional device).  Usato from QEMU with:
 *   -netdev user,id=net0 -device virtio-net-pci,netdev=net0
 *
 * Architettura:
 *   - Legacy PCI device: vendor 0x1AF4, device 0x1000, subsystem 1
 *   - BAR0: I/O port space (32 byte, accesso via inb/outb/inw/outw)
 *   - 2 virtqueue: RX (vq 0) AND TX (vq 1)
 *   - Ogni virtqueue: descriptor table + available ring + used ring
 *   - RX: pre-populated with buffer liberi (ring size VNET_VRING_SIZE)
 *   - TX: fill-on-demand, notifica host via doorbell
 *   - IRQ: PCI INT line (vector = irq_line + 0x20)
 *   - MTU: 1514 byte (Ethernet frame without FCS)
 *
 * Dependencies:
 *   driver.h — device_t, net_ops_t, mmio helpers, spinlock
 *   pci.h    — pci_device_t, pci_read8 (BAR0 I/O port base)
 *   pmm.h    — pmm_alloc_frames (vring DMA)
 *   vmm.h    — phys_to_virt, virt_to_phys
 *   slab.h   — kzalloc
 */

#include "../driver.h"
#include "../pci.h"

/* =========================================================================
 * VirtIO Legacy PCI — I/O port register offsets (BAR0)
 * ========================================================================= */

#define VIRTIO_PCI_HOST_FEATURES    0x00   /* 32-bit: device features (R)   */
#define VIRTIO_PCI_GUEST_FEATURES   0x04   /* 32-bit: driver features (W)   */
#define VIRTIO_PCI_QUEUE_PFN        0x08   /* 32-bit: queue address / 4096  */
#define VIRTIO_PCI_QUEUE_SIZE       0x0C   /* 16-bit: queue entries         */
#define VIRTIO_PCI_QUEUE_SEL        0x0E   /* 16-bit: queue select          */
#define VIRTIO_PCI_QUEUE_NOTIFY     0x10   /* 16-bit: queue notify doorbell */
#define VIRTIO_PCI_STATUS           0x12   /* 8-bit: device status          */
#define VIRTIO_PCI_ISR              0x13   /* 8-bit: ISR status (clear on read) */
/* Offset 0x14-0x17: device-specific config (MAC addr for net device) */
#define VIRTIO_PCI_NET_MAC          0x14   /* 6 byte: MAC address           */
#define VIRTIO_PCI_NET_STATUS       0x1A   /* 16-bit: network status        */

/* Device status bits */
#define VIRTIO_STATUS_RESET         0x00
#define VIRTIO_STATUS_ACK           0x01   /* OS riconosce the device        */
#define VIRTIO_STATUS_DRIVER        0x02   /* OS ha to driver for the device */
#define VIRTIO_STATUS_DRIVER_OK     0x04   /* Driver initialised          */
#define VIRTIO_STATUS_FAILED        0x80   /* Error fatale                 */

/* Feature bits VirtIO-Net */
#define VIRTIO_NET_F_MAC        (1 << 5)   /* MAC address valid in config  */
#define VIRTIO_NET_F_STATUS     (1 << 16)  /* Status field in config        */
#define VIRTIO_NET_F_CSUM       (1 << 0)   /* Checksum offload              */
#define VIRTIO_NET_F_GUEST_CSUM (1 << 1)

/* ISR bits */
#define VIRTIO_ISR_QUEUE        0x01   /* Almeno to queue ha entry usate    */
#define VIRTIO_ISR_CONFIG       0x02   /* Configurazione device cambiata    */

/* =========================================================================
 * VirtIO Vring — structures DMA
 *
 * Una virtqueue è composta from tre sezioni in memory physical contigua:
 *   1. Descriptor Table: VRING_SIZE entry from 16 byte — desc[the] dewrite
 *      to buffer physical (addr, len, flags, next).
 *   2. Available Ring: header + ring[VRING_SIZE] — the driver pubblica
 *      indici of descriptor for the device.
 *   3. Used Ring: header + ring[VRING_SIZE] — the device pubblica the
 *      indici of the descriptor completati.
 *
 * Allineamento required (spec VirtIO legacy):
 *   Descriptor table: 16 byte
 *   Available ring:   2 byte
 *   Used ring:        4096 byte (page intera)
 *
 * Layout in to allocation singola for semplicità:
 *   [0    …  16*N-1]  Descriptor table
 *   [16*N … 16*N+6+2*N-1]  Available ring
 *   [PAGE_ALIGN …]  Used ring (aligned to PAGE_SIZE)
 * ========================================================================= */

#define VNET_VRING_SIZE   256   /* Numero of entry for queue (potenza of 2)   */

/* Descriptor flags */
#define VRING_DESC_F_NEXT      (1 << 0)  /* chain: c'è to next            */
#define VRING_DESC_F_WRITE     (1 << 1)  /* write-only for the device      */
#define VRING_DESC_F_INDIRECT  (1 << 2)

typedef struct {
    uint64_t addr;   /* Address physical of the buffer                          */
    uint32_t len;    /* Length buffer in byte                             */
    uint16_t flags;  /* VRING_DESC_F_*                                       */
    uint16_t next;   /* Indice of the next descriptor (if F_NEXT)           */
} __attribute__((packed)) vring_desc_t;

typedef struct {
    uint16_t flags;              /* 0 = normale                             */
    uint16_t idx;                /* next slot free (incrementle)     */
    uint16_t ring[VNET_VRING_SIZE];
    uint16_t used_event;         /* ottimizzazione notifiche (ignorato)     */
} __attribute__((packed)) vring_avail_t;

typedef struct {
    uint32_t id;    /* indice descriptor table                               */
    uint32_t len;   /* byte scritti from the device nel buffer                    */
} __attribute__((packed)) vring_used_elem_t;

typedef struct {
    uint16_t           flags;
    uint16_t           idx;
    vring_used_elem_t  ring[VNET_VRING_SIZE];
    uint16_t           avail_event;
} __attribute__((packed)) vring_used_t;

/* =========================================================================
 * VirtIO-Net header — prepend mandatory to every pacchetto
 *
 * Il device richiede VIRTIO_NET_HDR (12 byte) before of the data Ethernet.
 * Con VIRTIO_NET_F_CSUM NOT negoziato, all the fields are 0.
 * ========================================================================= */

typedef struct {
    uint8_t  flags;         /* VIRTIO_NET_HDR_F_* (0 = no offload)      */
    uint8_t  gso_type;      /* VIRTIO_NET_HDR_GSO_NONE = 0                  */
    uint16_t hdr_len;       /* 0 if gso_type = NONE                         */
    uint16_t gso_size;      /* 0 if gso_type = NONE                         */
    uint16_t csum_start;    /* offset for checksum (ignorato)               */
    uint16_t csum_offset;   /* offset checksum rispetto to csum_start        */
    uint16_t num_buffers;   /* usato only in RX for packet merging          */
} __attribute__((packed)) virtio_net_hdr_t;

#define VIRTIO_NET_HDR_SIZE  sizeof(virtio_net_hdr_t)   /* 12 byte          */

/* =========================================================================
 * Stato internal of the virtqueue
 * ========================================================================= */

typedef struct {
    vring_desc_t  *desc;    /* descriptor table — HHDM virtual              */
    vring_avail_t *avail;   /* available ring — HHDM virtual                */
    vring_used_t  *used;    /* used ring — HHDM virtual                     */

    uint64_t  desc_phys;    /* address physical descriptor table            */
    uint16_t  last_used;    /* last_used_idx consumato from the driver           */
    uint16_t  free_head;    /* indice of the first descriptor free           */
    uint16_t  num_free;     /* descriptor liberi nella catena               */
} vnet_queue_t;

/* =========================================================================
 * Buffer RX — pre-allocateti AND pubblicati nella RX queue
 * ========================================================================= */

#define VNET_BUF_SIZE   1526   /* VIRTIO_NET_HDR (12) + frame Ethernet max (1514) */

/* =========================================================================
 * Stato global of the driver
 * ========================================================================= */

typedef struct {
    uint16_t   io_base;       /* BAR0 I/O port base                         */
    uint8_t    mac[6];        /* MAC address letto from the config              */
    uint8_t    irq_vector;    /* vector IRQ = pci->irq_line + 0x20         */

    vnet_queue_t rx_q;        /* virtqueue 0 — RX                           */
    vnet_queue_t tx_q;        /* virtqueue 1 — TX                           */

    /* Buffer fisici for RX (pre-pubblicati nella RX avail ring) */
    uint64_t rx_bufs_phys;    /* base physical array buffer RX                */

    /* Buffer physical for TX (usato for the net_hdr + frame from sendre) */
    uint64_t tx_buf_phys;     /* buffer TX singolo (no pipelining)          */

    spinlock_t tx_lock;       /* protegge TX queue                          */
} vnet_state_t;

/* =========================================================================
 * API pubblica
 * ========================================================================= */

/*
 * virtio_net_init — probing PCI, reset device, negoziazione feature,
 * setup vring RX/TX, pubblicazione buffer RX, registerzione /dev/eth0.
 * Debole in irq.c — sovrascritta from this implementazione.
 */
void virtio_net_init(void);

/*
 * virtio_net_send — send to frame Ethernet grezzo (max 1514 byte).
 * Aggiunge automaticamente the virtio_net_hdr before dell'invio.
 * Returns EOK or negative error negative.
 */
int virtio_net_send(const void *data, uint16_t len);

#endif /* MATTIAOS_VIRTIO_NET_H */
