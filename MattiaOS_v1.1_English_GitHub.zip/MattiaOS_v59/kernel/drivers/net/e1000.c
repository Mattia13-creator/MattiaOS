#include "e1000.h"
#include "../pci.h"
#include "../../mm/pmm.h"
#include "../../mm/vmm.h"
#include "../../mm/slab.h"
#include "../../fs/devfs.h"
#include "../../include/errno.h"
#include "../../arch/x86_64/cpu.h"

/*
 * e1000.c — driver Intel e1000 Gigabit Ethernet for MattiaOS
 *
 * Implementa:
 *   - Rilevamento PCI (vendor 0x8086, device 0x100E/100F/10D3/153A)
 *   - Enablezione BAR0 MMIO + Bus Master
 *   - Reset hardware (CTRL.RST)
 *   - Lettura MAC from EEPROM (EERD)
 *   - Configurazione RCTL (receiver), TCTL (transmitter)
 *   - Allocation AND setup TX/RX descriptor ring (DMA via PMM)
 *   - Pre-popolamento RX descriptor ring with buffer
 *   - IRQ handler: drena RX ring, chiama rx_callback
 *   - TX polled: attende TDD bit nel descriptor status
 *   - Registerzione /dev/eth0 (OR /dev/eth1 if eth0 già presente) in devfs
 *
 * Note:
 *   - Un only device for system (first found nella enumeratezione PCI)
 *   - EEPROM read usa EERD with busy-wait (max 100000 cicli)
 *   - TX single-descriptor for pacchetto (no gather)
 *   - RX buffer size: 2048 B (RCTL_BSIZE_2048)
 */

/* =========================================================================
 * Stato global
 * ========================================================================= */

static e1000_state_t s_e1000;
static bool          s_initialized = false;

static devnode_t     s_dev_node  = {0};
static device_t      s_device    = {0};
static net_ops_t     s_net_ops   = {0};

/* =========================================================================
 * Helper: memset/memcpy minimali
 * ========================================================================= */

static inline void *e_memset(void *d, int c, size_t n) {
    uint8_t *p = (uint8_t *)d; while (n--) *p++ = (uint8_t)c; return d;
}
static inline void *e_memcpy(void *d, const void *s, size_t n) {
    uint8_t *dd=(uint8_t*)d; const uint8_t*ss=(const uint8_t*)s;
    while (n--) *dd++ = *ss++;
    return d;
}
static inline int e_strcmp(const char *a, const char *b) {
    while (*a && *a == *b) { a++; b++; }
    return (unsigned char)*a - (unsigned char)*b;
}

/* =========================================================================
 * Helper MMIO — accesso to the registers e1000 via BAR0 + HHDM
 * ========================================================================= */

static inline uint32_t e1k_read(uint32_t reg) {
    return mmio_read32(s_e1000.bar0_phys + reg);
}

static inline void e1k_write(uint32_t reg, uint32_t val) {
    mmio_write32(s_e1000.bar0_phys + reg, val);
    mmio_barrier();
}

/* =========================================================================
 * EEPROM read — usa EERD register
 *
 * Algorithm:
 *   1. Scrivi address EEPROM AND bit START in EERD
 *   2. Poll finché DONE bit = 1 (max 100000 loop)
 *   3. Leggi DATA from EERD[31:16]
 * ========================================================================= */

static uint16_t eeprom_read(uint8_t addr) {
    e1k_write(E1000_EERD,
              ((uint32_t)addr << E1000_EERD_ADDR_SHIFT) | E1000_EERD_START);

    for (uint32_t i = 0; i < 100000; i++) {
        uint32_t v = e1k_read(E1000_EERD);
        if (v & E1000_EERD_DONE)
            return (uint16_t)(v >> E1000_EERD_DATA_SHIFT);
        __asm__ __volatile__("pause");
    }
    return 0xFFFF;  /* timeout */
}

/* =========================================================================
 * Lettura MAC address
 *
 * Prova before RAL/RAH (if AV bit è set, the BIOS ha già loaded the MAC).
 * Se RAH.AV = 0, reads the 3 word from the EEPROM.
 * ========================================================================= */

static void read_mac(void) {
    uint32_t ral = e1k_read(E1000_RAL);
    uint32_t rah = e1k_read(E1000_RAH);

    if (rah & E1000_RAH_AV) {
        /* MAC già loaded from the firmware */
        s_e1000.mac[0] = (uint8_t)( ral        & 0xFF);
        s_e1000.mac[1] = (uint8_t)((ral >>  8) & 0xFF);
        s_e1000.mac[2] = (uint8_t)((ral >> 16) & 0xFF);
        s_e1000.mac[3] = (uint8_t)((ral >> 24) & 0xFF);
        s_e1000.mac[4] = (uint8_t)( rah        & 0xFF);
        s_e1000.mac[5] = (uint8_t)((rah >>  8) & 0xFF);
        return;
    }

    /* Leggi from EEPROM: word0 = mac[1:0], word1 = mac[3:2], word2 = mac[5:4] */
    uint16_t w0 = eeprom_read(E1000_EEPROM_MAC_WORD0);
    uint16_t w1 = eeprom_read(E1000_EEPROM_MAC_WORD1);
    uint16_t w2 = eeprom_read(E1000_EEPROM_MAC_WORD2);

    s_e1000.mac[0] = (uint8_t)( w0       & 0xFF);
    s_e1000.mac[1] = (uint8_t)((w0 >> 8) & 0xFF);
    s_e1000.mac[2] = (uint8_t)( w1       & 0xFF);
    s_e1000.mac[3] = (uint8_t)((w1 >> 8) & 0xFF);
    s_e1000.mac[4] = (uint8_t)( w2       & 0xFF);
    s_e1000.mac[5] = (uint8_t)((w2 >> 8) & 0xFF);
}

/* =========================================================================
 * Allocation TX descriptor ring + buffer DMA
 * ========================================================================= */

#define E1000_TX_RING_PAGES  \
    ((sizeof(e1000_tx_desc_t) * E1000_TX_DESC_COUNT + PAGE_SIZE - 1) / PAGE_SIZE)
#define E1000_TX_BUF_PAGES   \
    ((1514UL * E1000_TX_DESC_COUNT + PAGE_SIZE - 1) / PAGE_SIZE)

static bool tx_init(void) {
    s_e1000.tx_phys = pmm_alloc_frames(E1000_TX_RING_PAGES);
    if (!s_e1000.tx_phys) return false;
    e_memset(phys_to_virt(s_e1000.tx_phys), 0,
             E1000_TX_RING_PAGES * PAGE_SIZE);
    s_e1000.tx_descs = (e1000_tx_desc_t *)phys_to_virt(s_e1000.tx_phys);

    /* Un buffer physical for every TX slot */
    s_e1000.tx_bufs_phys = pmm_alloc_frames(E1000_TX_BUF_PAGES);
    if (!s_e1000.tx_bufs_phys) {
        pmm_free_frame(s_e1000.tx_phys);
        return false;
    }

    /* Initialise all the descriptor with buffer address */
    for (uint32_t i = 0; i < E1000_TX_DESC_COUNT; i++) {
        s_e1000.tx_descs[i].buffer_addr =
            s_e1000.tx_bufs_phys + (uint64_t)i * 1514;
        s_e1000.tx_descs[i].status = E1000_TXD_STAT_DD; /* free */
    }

    s_e1000.tx_tail = 0;

    /* Configura registers TX ring */
    e1k_write(E1000_TDBAL, (uint32_t)(s_e1000.tx_phys & 0xFFFFFFFF));
    e1k_write(E1000_TDBAH, (uint32_t)(s_e1000.tx_phys >> 32));
    e1k_write(E1000_TDLEN, E1000_TX_DESC_COUNT * sizeof(e1000_tx_desc_t));
    e1k_write(E1000_TDH, 0);
    e1k_write(E1000_TDT, 0);

    return true;
}

/* =========================================================================
 * Allocation RX descriptor ring + buffer DMA
 * ========================================================================= */

#define E1000_RX_RING_PAGES  \
    ((sizeof(e1000_rx_desc_t) * E1000_RX_DESC_COUNT + PAGE_SIZE - 1) / PAGE_SIZE)
#define E1000_RX_BUF_PAGES   \
    ((E1000_RX_BUF_SIZE * E1000_RX_DESC_COUNT + PAGE_SIZE - 1) / PAGE_SIZE)

static bool rx_init(void) {
    s_e1000.rx_phys = pmm_alloc_frames(E1000_RX_RING_PAGES);
    if (!s_e1000.rx_phys) return false;
    e_memset(phys_to_virt(s_e1000.rx_phys), 0,
             E1000_RX_RING_PAGES * PAGE_SIZE);
    s_e1000.rx_descs = (e1000_rx_desc_t *)phys_to_virt(s_e1000.rx_phys);

    /* Buffer fisici for RX */
    s_e1000.rx_bufs_phys = pmm_alloc_frames(E1000_RX_BUF_PAGES);
    if (!s_e1000.rx_bufs_phys) {
        pmm_free_frame(s_e1000.rx_phys);
        return false;
    }
    e_memset(phys_to_virt(s_e1000.rx_bufs_phys), 0,
             E1000_RX_BUF_PAGES * PAGE_SIZE);

    /* Popola descriptor ring */
    for (uint32_t i = 0; i < E1000_RX_DESC_COUNT; i++) {
        s_e1000.rx_descs[i].buffer_addr =
            s_e1000.rx_bufs_phys + (uint64_t)i * E1000_RX_BUF_SIZE;
        s_e1000.rx_descs[i].status = 0;
    }

    s_e1000.rx_head = 0;

    /* Configura registers RX ring */
    e1k_write(E1000_RDBAL, (uint32_t)(s_e1000.rx_phys & 0xFFFFFFFF));
    e1k_write(E1000_RDBAH, (uint32_t)(s_e1000.rx_phys >> 32));
    e1k_write(E1000_RDLEN, E1000_RX_DESC_COUNT * sizeof(e1000_rx_desc_t));
    e1k_write(E1000_RDH, 0);
    /* Tail = N-1: indica to the device all the slot are liberi */
    e1k_write(E1000_RDT, E1000_RX_DESC_COUNT - 1);

    return true;
}

/* =========================================================================
 * IRQ handler — drena RX ring
 * ========================================================================= */

static void e1000_irq_handler(interrupt_frame_t *frame) {
    (void)frame;

    /* Leggi AND zero ICR */
    uint32_t icr = e1k_read(E1000_ICR);

    if (icr & E1000_ICR_RXT0) {
        /* Drena all the descriptor completati */
        while (s_e1000.rx_descs[s_e1000.rx_head].status & E1000_RXD_STAT_DD) {
            e1000_rx_desc_t *desc = &s_e1000.rx_descs[s_e1000.rx_head];

            if ((desc->status & E1000_RXD_STAT_EOP) && desc->errors == 0) {
                uint8_t *buf = (uint8_t *)phys_to_virt(desc->buffer_addr);
                uint16_t len = desc->length;

                if (s_net_ops.rx_callback)
                    s_net_ops.rx_callback(&s_device, buf, len);
            }

            /* Zero status AND re-pubblica descriptor */
            desc->status = 0;
            e1k_write(E1000_RDT, s_e1000.rx_head);
            s_e1000.rx_head = (s_e1000.rx_head + 1) % E1000_RX_DESC_COUNT;
        }
    }

    /* Link Status Change */
    if (icr & E1000_ICR_LSC) {
        /* Solo log — the link state è letto dallo STATUS register */
        (void)e1k_read(E1000_STATUS);
    }
}

/* =========================================================================
 * net_ops_t callbacks
 * ========================================================================= */

static int e1000_do_send(device_t *dev, const void *data, uint16_t len) {
    (void)dev;
    if (!s_initialized || !data || len == 0 || len > 1514) return -EINVAL;

    uint64_t flags = spinlock_irqsave(&s_e1000.tx_lock);

    uint32_t slot = s_e1000.tx_tail;
    e1000_tx_desc_t *desc = &s_e1000.tx_descs[slot];

    /* Attendi that the descriptor sia free (status DD = 1) */
    for (uint32_t i = 0; i < 500000; i++) {
        if (desc->status & E1000_TXD_STAT_DD) break;
        __asm__ __volatile__("pause");
    }
    if (!(desc->status & E1000_TXD_STAT_DD)) {
        spinlock_irqrestore(&s_e1000.tx_lock, flags);
        return -EIO;
    }

    /* Copy frame nel buffer DMA */
    void *buf_virt = phys_to_virt(desc->buffer_addr);
    e_memcpy(buf_virt, data, len);

    /* Configura descriptor */
    desc->length  = len;
    desc->cso     = 0;
    desc->css     = 0;
    desc->special = 0;
    desc->cmd     = E1000_TXD_CMD_EOP | E1000_TXD_CMD_IFCS | E1000_TXD_CMD_RS;
    desc->status  = 0;   /* zero DD — the device the setterà to the completamento */

    /* Avanza tail */
    s_e1000.tx_tail = (slot + 1) % E1000_TX_DESC_COUNT;
    e1k_write(E1000_TDT, s_e1000.tx_tail);

    spinlock_irqrestore(&s_e1000.tx_lock, flags);
    return EOK;
}

static void e1000_get_mac(device_t *dev, uint8_t mac[6]) {
    (void)dev;
    e_memcpy(mac, s_e1000.mac, 6);
}

static int e1000_set_mac_cb(device_t *dev, const uint8_t mac[6]) {
    (void)dev;
    e_memcpy(s_e1000.mac, mac, 6);
    uint32_t ral = ((uint32_t)mac[0]) | ((uint32_t)mac[1] << 8) |
                   ((uint32_t)mac[2] << 16) | ((uint32_t)mac[3] << 24);
    uint32_t rah = ((uint32_t)mac[4]) | ((uint32_t)mac[5] << 8) |
                   E1000_RAH_AV;
    e1k_write(E1000_RAL, ral);
    e1k_write(E1000_RAH, rah);
    return EOK;
}

static void e1000_enable_rx_cb(device_t *dev) {
    (void)dev;
    uint32_t rctl = e1k_read(E1000_RCTL);
    rctl |= E1000_RCTL_EN;
    e1k_write(E1000_RCTL, rctl);
}

static void e1000_disable_rx_cb(device_t *dev) {
    (void)dev;
    uint32_t rctl = e1k_read(E1000_RCTL);
    rctl &= ~E1000_RCTL_EN;
    e1k_write(E1000_RCTL, rctl);
}

static int e1000_ioctl_cb(device_t *dev, uint32_t cmd, uint64_t arg) {
    (void)dev;
    switch (cmd) {
    case E1000_IOCTL_GET_MAC:
        if (!arg) return -EINVAL;
        e_memcpy((void *)(uintptr_t)arg, s_e1000.mac, 6);
        return EOK;
    case E1000_IOCTL_SET_PROMISC: {
        uint32_t rctl = e1k_read(E1000_RCTL);
        if (arg) rctl |=  (E1000_RCTL_UPE | E1000_RCTL_MPE);
        else     rctl &= ~(E1000_RCTL_UPE | E1000_RCTL_MPE);
        e1k_write(E1000_RCTL, rctl);
        return EOK;
    }
    default: return -EINVAL;
    }
}

/* =========================================================================
 * VFS ops for /dev/eth0 (e1000)
 * ========================================================================= */

static ssize_t e1000_vfs_write(vnode_t *node, const void *buf,
                                size_t count, off_t offset) {
    (void)node; (void)offset;
    if (count > 1514) return -EINVAL;
    int r = e1000_do_send(&s_device, buf, (uint16_t)count);
    return r == EOK ? (ssize_t)count : (ssize_t)r;
}

static int e1000_vfs_ioctl(vnode_t *node, uint64_t req, void *arg) {
    (void)node;
    if (req == 0x8927 && arg) { e_memcpy(arg, s_e1000.mac, 6); return EOK; }
    return e1000_ioctl_cb(&s_device, (uint32_t)req, (uint64_t)(uintptr_t)arg);
}

static vfs_ops_t s_e1000_vfs_ops = {
    .open    = NULL, .close   = NULL,
    .read    = NULL, .write   = e1000_vfs_write,
    .ioctl   = e1000_vfs_ioctl,
    .readdir = NULL, .stat    = NULL,
    .create  = NULL, .mkdir   = NULL,
    .unlink  = NULL, .mmap    = NULL,
};

/* =========================================================================
 * e1000_init — punto of entry of the driver
 * ========================================================================= */

void e1000_init(void) {
    /* 1 — Search device PCI e1000 */
    uint16_t dev_ids[] = {
        PCI_DEV_E1000_82540EM,
        PCI_DEV_E1000_82545EM,
        PCI_DEV_E1000_82574L,
        PCI_DEV_E1000_I217LM
    };
    pci_device_t *pci = pci_find_device_any_id(PCI_VENDOR_INTEL, dev_ids, 4);
    if (!pci) {
        serial_puts("[E1000] no device findto\n");
        return;
    }

    pci_enable_busmaster(pci->bus, pci->dev, pci->func);
    pci_enable_mmio(pci->bus, pci->dev, pci->func);

    /* 2 — Leggi BAR0 (128 KB MMIO) */
    uint64_t bar0 = pci_get_bar(pci->bus, pci->dev, pci->func, 0);
    if (!bar0 || (bar0 & 0x1)) {   /* bit 0 = I/O space, noi vogliamo MMIO */
        serial_puts("[E1000] BAR0 non valido o I/O space\n");
        return;
    }
    s_e1000.bar0_phys = bar0 & ~0xFULL;   /* strip 4 flag bits */

    s_e1000.irq_vector = pci->irq_line + 0x20;

    /* 3 — Reset hardware */
    e1k_write(E1000_CTRL, e1k_read(E1000_CTRL) | E1000_CTRL_RST);
    for (volatile int i = 0; i < 100000; i++) __asm__ __volatile__("pause");
    /* Attendi that RST si azzeri */
    for (uint32_t i = 0; i < 1000000; i++) {
        if (!(e1k_read(E1000_CTRL) & E1000_CTRL_RST)) break;
        __asm__ __volatile__("pause");
    }

    /* 4 — Configura CTRL: Set Link Up, Full Duplex, Auto-Speed */
    e1k_write(E1000_CTRL,
              E1000_CTRL_SLU | E1000_CTRL_ASDE | E1000_CTRL_FD);

    /* 5 — Disenable interrupt before of the setup */
    e1k_write(E1000_IMC, 0xFFFFFFFF);

    /* 6 — Leggi MAC */
    read_mac();

    /* 7 — Scrivi MAC in RAL/RAH */
    e1k_write(E1000_RAL,
              ((uint32_t)s_e1000.mac[0])       |
              ((uint32_t)s_e1000.mac[1] <<  8) |
              ((uint32_t)s_e1000.mac[2] << 16) |
              ((uint32_t)s_e1000.mac[3] << 24));
    e1k_write(E1000_RAH,
              ((uint32_t)s_e1000.mac[4])       |
              ((uint32_t)s_e1000.mac[5] << 8)  |
              E1000_RAH_AV);

    /* 8 — Zero Multicast Table Array */
    for (uint32_t i = 0; i < 128; i++)
        e1k_write(E1000_MTA + i * 4, 0);

    /* 9 — Setup TX ring */
    if (!tx_init()) {
        serial_puts("[E1000] OOM TX ring\n");
        return;
    }

    /* 10 — Configura TCTL */
    e1k_write(E1000_TCTL,
              E1000_TCTL_EN  |
              E1000_TCTL_PSP |
              (15   << E1000_TCTL_CT_SHIFT)   |   /* collision threshold */
              (E1000_TCTL_COLD_FD << E1000_TCTL_COLD_SHIFT));

    /* Inter Packet Gap: value raccomandato for Gigabit Ethernet */
    e1k_write(E1000_TIPG, 0x0060200A);

    /* 11 — Setup RX ring */
    if (!rx_init()) {
        serial_puts("[E1000] OOM RX ring\n");
        return;
    }

    /* 12 — Configura RCTL */
    e1k_write(E1000_RCTL,
              E1000_RCTL_EN          |
              E1000_RCTL_BAM         |
              E1000_RCTL_BSIZE_2048  |
              E1000_RCTL_SECRC       |
              E1000_RCTL_LBM_NONE    |
              E1000_RCTL_RDMTS_HALF);

    /* 13 — Installa IRQ handler AND enable interrupt RXT0 + LSC */
    register_irq_handler(s_e1000.irq_vector, e1000_irq_handler);
    e1k_write(E1000_IMS, E1000_ICR_RXT0 | E1000_ICR_LSC);

    /* 14 — net_ops_t */
    s_net_ops.send_packet  = e1000_do_send;
    s_net_ops.get_mac      = e1000_get_mac;
    s_net_ops.set_mac      = e1000_set_mac_cb;
    s_net_ops.enable_rx    = e1000_enable_rx_cb;
    s_net_ops.disable_rx   = e1000_disable_rx_cb;
    s_net_ops.ioctl        = e1000_ioctl_cb;
    s_net_ops.rx_callback  = NULL;
    s_net_ops.mtu          = 1514;

    /* 15 — Scegli name device: /dev/eth0 if NOT occupato, altrimenti eth1 */
    const char *name = device_find_by_name("eth0") ? "eth1" : "eth0";

    /* devnode_t */
    uint32_t i = 0;
    while (name[i] && i < sizeof(s_dev_node.name) - 1) {
        s_dev_node.name[i] = name[i]; i++;
    }
    s_dev_node.name[i]     = '\0';
    s_dev_node.type        = DEV_TYPE_NET;
    s_dev_node.ops         = &s_e1000_vfs_ops;
    s_dev_node.driver_data = &s_e1000;
    devfs_register(&s_dev_node);

    /* device_t */
    i = 0;
    while (name[i] && i < sizeof(s_device.name) - 1) {
        s_device.name[i] = name[i]; i++;
    }
    s_device.name[i]     = '\0';
    s_device.type        = DEV_TYPE_NET;
    s_device.state       = DEV_STATE_ACTIVE;
    s_device.net_ops     = &s_net_ops;
    s_device.driver_data = &s_e1000;
    device_add(&s_device, NULL);

    s_initialized = true;
    serial_puts("[E1000] init completato\n");
}

/* =========================================================================
 * e1000_send — API diretta kernel
 * ========================================================================= */

int e1000_send(const void *data, uint16_t len) {
    if (!s_initialized) return -EIO;
    return e1000_do_send(&s_device, data, len);
}
