#include "ahci.h"
#include "../pci.h"
#include "../../mm/pmm.h"
#include "../../mm/vmm.h"
#include "../../mm/slab.h"
#include "../../fs/devfs.h"
#include "../../include/errno.h"
#include "../../arch/x86_64/cpu.h"

/*
 * ahci.c — driver controller AHCI/SATA for MattiaOS
 *
 * Implementa:
 *   - Rilevamento HBA via PCI (class 0x01, subclass 0x06)
 *   - Reset HBA AND enablezione AHCI mode
 *   - Enumeratezione ports SATA (skip ATAPI/semaphore/PM)
 *   - Allocation DMA: command list + FIS buffer + command table for port
 *   - ATA IDENTIFY DEVICE for geometria drive
 *   - Read/Write DMA Extended (LBA48, 48-bit addressing)
 *   - Flush Write Cache Extended
 *   - Registerzione /dev/sdX in devfs AND device tree
 *
 * I/O: completely polled (PxCI + PxTFD).
 * No IRQ in Phase 8 — the timeout of 1M cicli copre ~1 ms to 1 GHz.
 *
 * Thread safety:
 *   Ogni port ha the proprio ahci_port_t.lock (spinlock_irqsave).
 *   Il lock copre l'intera transazione DMA for escludere accessi concorrenti.
 */

/* =========================================================================
 * Stato global — file-scope
 * ========================================================================= */

static ahci_hba_t s_hba;
static bool       s_initialized = false;

/*
 * Nodes statici for devfs AND device tree.
 * Dimensionati for AHCI_MAX_PORTS device, to for port.
 */
static devnode_t s_dev_nodes[AHCI_MAX_PORTS];
static device_t  s_devices[AHCI_MAX_PORTS];
static device_t  s_bus_dev;           /* node bus "ahci0"                   */

/* block_ops_t for port: read_sectors / write_sectors / flush puntano to
 * functions that usano l'indice port codificato in driver_data. */
static block_ops_t s_port_block_ops[AHCI_MAX_PORTS];

/* =========================================================================
 * Helper: stringhe minimali (no libc)
 * ========================================================================= */

static inline void *ah_memset(void *d, int c, size_t n) {
    uint8_t *p = (uint8_t *)d;
    while (n--) *p++ = (uint8_t)c;
    return d;
}

static inline void *ah_memcpy(void *d, const void *s, size_t n) {
    uint8_t *dd = (uint8_t *)d;
    const uint8_t *ss = (const uint8_t *)s;
    while (n--) *dd++ = *ss++;
    return d;
}

/* Write the name "sdX" in buf[4] */
static void port_name(char *buf, uint32_t port) {
    buf[0] = 's'; buf[1] = 'd';
    buf[2] = (char)('a' + (char)port);
    buf[3] = '\0';
}

/* =========================================================================
 * Helper: accesso to the registers HBA via MMIO
 * ========================================================================= */

static inline uint32_t hba_read(uint32_t reg) {
    return mmio_read32(s_hba.hba_phys + reg);
}

static inline void hba_write(uint32_t reg, uint32_t val) {
    mmio_write32(s_hba.hba_phys + reg, val);
    mmio_barrier();
}

static inline uint32_t port_read(uint32_t port, uint32_t reg) {
    return mmio_read32(s_hba.hba_phys + AHCI_PORT_BASE(port) + reg);
}

static inline void port_write(uint32_t port, uint32_t reg, uint32_t val) {
    mmio_write32(s_hba.hba_phys + AHCI_PORT_BASE(port) + reg, val);
    mmio_barrier();
}

/* =========================================================================
 * Gestione port: start / stop DMA engine
 * ========================================================================= */

static void port_stop_dma(uint32_t port) {
    uint32_t cmd = port_read(port, AHCI_PxCMD);

    /* Clear ST — ferma DMA engine */
    cmd &= ~AHCI_PxCMD_ST;
    port_write(port, AHCI_PxCMD, cmd);

    /* Attendi CR = 0 (max ~500 ms, qui 100K loop) */
    for (uint32_t i = 0; i < 100000; i++) {
        if (!(port_read(port, AHCI_PxCMD) & AHCI_PxCMD_CR))
            break;
        __asm__ __volatile__("pause");
    }

    /* Clear FRE */
    cmd = port_read(port, AHCI_PxCMD);
    cmd &= ~AHCI_PxCMD_FRE;
    port_write(port, AHCI_PxCMD, cmd);

    /* Attendi FR = 0 */
    for (uint32_t i = 0; i < 100000; i++) {
        if (!(port_read(port, AHCI_PxCMD) & AHCI_PxCMD_FR))
            break;
        __asm__ __volatile__("pause");
    }
}

static void port_start_dma(uint32_t port) {
    /* Attendi BSY AND DRQ liberi */
    uint32_t tfd;
    for (uint32_t i = 0; i < 1000000; i++) {
        tfd = port_read(port, AHCI_PxTFD);
        if (!(tfd & (AHCI_TFD_STS_BSY | AHCI_TFD_STS_DRQ)))
            break;
        __asm__ __volatile__("pause");
    }

    uint32_t cmd = port_read(port, AHCI_PxCMD);
    cmd |= AHCI_PxCMD_FRE;
    port_write(port, AHCI_PxCMD, cmd);

    cmd |= AHCI_PxCMD_ST;
    port_write(port, AHCI_PxCMD, cmd);
}

/* =========================================================================
 * Allocation DMA for port
 *
 * Ogni port necessita of:
 *   - Command List: 1 KB (32 command header from 32 byte)
 *   - FIS Buffer:   256 B (Received FIS)
 *   - Command Table: 256 B (for slot 0 — polled, 1 slot active)
 *   - Data Buffer:   128 KB (max 128 sectors * 512 B = 65536 B → 32 pages
 *                            arrotondato to 128 KB for sicurezza)
 *
 * Tutto allocateto up pages fisiche contigue for DMA corretto.
 * La spec richiede that CLB AND FB siano allineati to 1 KB AND 256 B rispettivamente.
 * pmm_alloc_frames garantisce pages fisiche contigue allineate to PAGE_SIZE.
 * ========================================================================= */

#define AHCI_DATA_BUF_PAGES  32   /* 32 * 4096 = 128 KB                     */

static bool port_alloc_dma(uint32_t port) {
    ahci_port_t *p = &s_hba.ports[port];

    /* Command list: 1 KB = 1 page */
    p->cmd_list_phys = pmm_alloc_frame();
    if (!p->cmd_list_phys) return false;
    ah_memset(phys_to_virt(p->cmd_list_phys), 0, PAGE_SIZE);

    /* FIS buffer: 256 B, allocateta nella stessa page of the cmd table for
     * semplicità; usa to page separata for garantire alignment */
    p->fis_buf_phys = pmm_alloc_frame();
    if (!p->fis_buf_phys) {
        pmm_free_frame(p->cmd_list_phys);
        return false;
    }
    ah_memset(phys_to_virt(p->fis_buf_phys), 0, PAGE_SIZE);

    /* Command table: 256 B (slot 0). Un'intera page for semplicità. */
    p->cmd_table_phys = pmm_alloc_frame();
    if (!p->cmd_table_phys) {
        pmm_free_frame(p->cmd_list_phys);
        pmm_free_frame(p->fis_buf_phys);
        return false;
    }
    ah_memset(phys_to_virt(p->cmd_table_phys), 0, PAGE_SIZE);

    /* Data buffer: 128 KB = 32 pages fisicamente contigue */
    p->data_buf_phys = pmm_alloc_frames(AHCI_DATA_BUF_PAGES);
    if (!p->data_buf_phys) {
        pmm_free_frame(p->cmd_list_phys);
        pmm_free_frame(p->fis_buf_phys);
        pmm_free_frame(p->cmd_table_phys);
        return false;
    }
    ah_memset(phys_to_virt(p->data_buf_phys), 0,
              AHCI_DATA_BUF_PAGES * PAGE_SIZE);

    return true;
}

static void port_setup_dma_ptrs(uint32_t port) {
    ahci_port_t *p = &s_hba.ports[port];

    /* Set CLB (command list base) nel register of port */
    port_write(port, AHCI_PxCLB,  (uint32_t)(p->cmd_list_phys & 0xFFFFFFFF));
    port_write(port, AHCI_PxCLBU, (uint32_t)(p->cmd_list_phys >> 32));

    /* Set FB (FIS base) */
    port_write(port, AHCI_PxFB,   (uint32_t)(p->fis_buf_phys & 0xFFFFFFFF));
    port_write(port, AHCI_PxFBU,  (uint32_t)(p->fis_buf_phys >> 32));

    /* Configura command header [0]: punta to the command table */
    ahci_cmd_header_t *hdr =
        (ahci_cmd_header_t *)phys_to_virt(p->cmd_list_phys);
    hdr[0].ctba  = (uint32_t)(p->cmd_table_phys & 0xFFFFFFFF);
    hdr[0].ctbau = (uint32_t)(p->cmd_table_phys >> 32);
}

/* =========================================================================
 * Esecuzione comando DMA (polled)
 * ========================================================================= */

/*
 * port_send_cmd — emette the comando nello slot 0 AND attende the completamento.
 * I fields command header AND CFIS devono essere già setti from the chiamante.
 * Returns EOK or negative error.
 */
static int port_send_cmd(uint32_t port) {
    /* Zero interrupt status of port */
    port_write(port, AHCI_PxIS, 0xFFFFFFFF);

    /* Issue command slot 0 */
    port_write(port, AHCI_PxCI, 1 << 0);

    /* Poll fino to CI = 0 (comando completato) OR timeout */
    for (uint32_t i = 0; i < 1000000; i++) {
        if (!(port_read(port, AHCI_PxCI) & 1)) {
            /* Controlla errors nel task file data */
            uint32_t tfd = port_read(port, AHCI_PxTFD);
            if (tfd & (AHCI_TFD_STS_ERR | ATA_STS_DF))
                return -EIO;
            return EOK;
        }
        __asm__ __volatile__("pause");
    }
    return -EIO;   /* Timeout */
}

/*
 * port_build_rw_cmd — build command header AND CFIS for to'operation
 * READ DMA EXT OR WRITE DMA EXT (LBA48).
 *
 * max sectors for comando: 128 (AHCI_DATA_BUF_PAGES * 4096 / 512).
 */
#define AHCI_MAX_SECTORS_PER_CMD  128

static void port_build_rw_cmd(uint32_t port, uint64_t lba,
                               uint32_t count, bool write) {
    ahci_port_t       *p   = &s_hba.ports[port];
    ahci_cmd_header_t *hdr =
        (ahci_cmd_header_t *)phys_to_virt(p->cmd_list_phys);
    ahci_cmd_table_t  *tbl =
        (ahci_cmd_table_t  *)phys_to_virt(p->cmd_table_phys);

    /* Zero command table */
    ah_memset(tbl, 0, sizeof(ahci_cmd_table_t));

    /* Command FIS — H2D Register FIS */
    fis_reg_h2d_t *fis = (fis_reg_h2d_t *)tbl->cfis;
    fis->fis_type = FIS_TYPE_REG_H2D;
    fis->c        = 1;   /* Command register update */
    fis->command  = write ? ATA_CMD_WRITE_DMA_EXT : ATA_CMD_READ_DMA_EXT;
    fis->device   = ATA_DEV_LBA;

    /* LBA48 */
    fis->lba0 = (uint8_t)( lba        & 0xFF);
    fis->lba1 = (uint8_t)((lba >>  8) & 0xFF);
    fis->lba2 = (uint8_t)((lba >> 16) & 0xFF);
    fis->lba3 = (uint8_t)((lba >> 24) & 0xFF);
    fis->lba4 = (uint8_t)((lba >> 32) & 0xFF);
    fis->lba5 = (uint8_t)((lba >> 40) & 0xFF);

    fis->countl = (uint8_t)( count       & 0xFF);
    fis->counth = (uint8_t)((count >> 8) & 0xFF);

    /* PRDT: to'unica entry that copre all the sectors */
    uint32_t byte_count = count * p->sector_size;
    tbl->prdt[0].dba  = (uint32_t)(p->data_buf_phys & 0xFFFFFFFF);
    tbl->prdt[0].dbau = (uint32_t)(p->data_buf_phys >> 32);
    tbl->prdt[0].dbc  = byte_count - 1;  /* 0-based */
    tbl->prdt[0].i    = 0;

    /* Command Header */
    hdr[0].cfl   = sizeof(fis_reg_h2d_t) / 4;   /* FIS length in DW       */
    hdr[0].w     = write ? 1 : 0;
    hdr[0].prdtl = 1;
    hdr[0].prdbc = 0;
}

/* =========================================================================
 * ATA IDENTIFY DEVICE — ricava sector_count AND sector_size
 * ========================================================================= */

static int port_identify(uint32_t port) {
    ahci_port_t       *p   = &s_hba.ports[port];
    ahci_cmd_header_t *hdr =
        (ahci_cmd_header_t *)phys_to_virt(p->cmd_list_phys);
    ahci_cmd_table_t  *tbl =
        (ahci_cmd_table_t  *)phys_to_virt(p->cmd_table_phys);

    ah_memset(tbl, 0, sizeof(ahci_cmd_table_t));

    fis_reg_h2d_t *fis = (fis_reg_h2d_t *)tbl->cfis;
    fis->fis_type = FIS_TYPE_REG_H2D;
    fis->c        = 1;
    fis->command  = ATA_CMD_IDENTIFY;
    fis->device   = 0;

    /* 512 byte of rimove nel data_buf */
    tbl->prdt[0].dba  = (uint32_t)(p->data_buf_phys & 0xFFFFFFFF);
    tbl->prdt[0].dbau = (uint32_t)(p->data_buf_phys >> 32);
    tbl->prdt[0].dbc  = 511;   /* 512 - 1 */
    tbl->prdt[0].i    = 0;

    hdr[0].cfl   = sizeof(fis_reg_h2d_t) / 4;
    hdr[0].w     = 0;   /* read */
    hdr[0].prdtl = 1;
    hdr[0].prdbc = 0;

    int ret = port_send_cmd(port);
    if (ret != EOK) return ret;

    /* Identifica buffer (512 byte, word-addressed for spec ATA) */
    uint16_t *id = (uint16_t *)phys_to_virt(p->data_buf_phys);

    /* Word 83 bit 10: LBA48 supportsd */
    bool lba48 = (id[83] >> 10) & 1;

    if (lba48) {
        /* Words 100-103: Maximum LBA (48-bit) */
        p->sector_count  = (uint64_t)id[100];
        p->sector_count |= (uint64_t)id[101] << 16;
        p->sector_count |= (uint64_t)id[102] << 32;
        p->sector_count |= (uint64_t)id[103] << 48;
    } else {
        /* Words 60-61: Total LBA (28-bit) */
        p->sector_count = ((uint64_t)id[61] << 16) | id[60];
    }

    /* Word 106 bit 12: logical sector size > 512 */
    if ((id[106] & 0xC000) == 0x4000 && (id[106] & (1 << 12))) {
        /* Words 117-118: Logical Sector Size (in words) */
        uint32_t words = ((uint32_t)id[118] << 16) | id[117];
        p->sector_size = words * 2;
    } else {
        p->sector_size = 512;
    }

    return EOK;
}

/* =========================================================================
 * VFS operations for /dev/sdX
 * ========================================================================= */

static ssize_t ahci_vfs_read(vnode_t *node, void *buf,
                              size_t count, off_t offset) {
    if (!node || !buf) return -EINVAL;

    /* driver_data = indice port (codificato as uintptr_t) */
    uint32_t port = (uint32_t)(uintptr_t)node->fs_data;
    if (port >= AHCI_MAX_PORTS || !s_hba.ports[port].present)
        return -ENOENT;

    ahci_port_t *p = &s_hba.ports[port];
    if (p->sector_size == 0) return -EIO;

    /* Allinea offset AND count to sectors interi */
    if (offset % (off_t)p->sector_size != 0)  return -EINVAL;
    if (count  %         p->sector_size != 0)  return -EINVAL;

    uint64_t lba         = (uint64_t)offset / p->sector_size;
    uint32_t num_sectors = (uint32_t)(count  / p->sector_size);

    if (lba + num_sectors > p->sector_count) return -EINVAL;

    ssize_t transferred = 0;
    uint8_t *dst = (uint8_t *)buf;

    while (num_sectors > 0) {
        uint32_t batch = num_sectors < AHCI_MAX_SECTORS_PER_CMD
                       ? num_sectors : AHCI_MAX_SECTORS_PER_CMD;

        uint64_t flags = spinlock_irqsave(&p->lock);
        port_build_rw_cmd(port, lba, batch, false);
        int r = port_send_cmd(port);
        if (r == EOK) {
            uint32_t bytes = batch * p->sector_size;
            ah_memcpy(dst, phys_to_virt(p->data_buf_phys), bytes);
            transferred += bytes;
            dst         += bytes;
        }
        spinlock_irqrestore(&p->lock, flags);

        if (r != EOK) return -EIO;

        lba         += batch;
        num_sectors -= batch;
    }

    return transferred;
}

static ssize_t ahci_vfs_write(vnode_t *node, const void *buf,
                               size_t count, off_t offset) {
    if (!node || !buf) return -EINVAL;

    uint32_t port = (uint32_t)(uintptr_t)node->fs_data;
    if (port >= AHCI_MAX_PORTS || !s_hba.ports[port].present)
        return -ENOENT;

    ahci_port_t *p = &s_hba.ports[port];
    if (p->sector_size == 0) return -EIO;

    if (offset % (off_t)p->sector_size != 0) return -EINVAL;
    if (count  %         p->sector_size != 0) return -EINVAL;

    uint64_t lba         = (uint64_t)offset / p->sector_size;
    uint32_t num_sectors = (uint32_t)(count  / p->sector_size);

    if (lba + num_sectors > p->sector_count) return -EINVAL;

    ssize_t transferred = 0;
    const uint8_t *src = (const uint8_t *)buf;

    while (num_sectors > 0) {
        uint32_t batch = num_sectors < AHCI_MAX_SECTORS_PER_CMD
                       ? num_sectors : AHCI_MAX_SECTORS_PER_CMD;

        uint64_t flags = spinlock_irqsave(&p->lock);
        uint32_t bytes = batch * p->sector_size;
        ah_memcpy(phys_to_virt(p->data_buf_phys), src, bytes);
        port_build_rw_cmd(port, lba, batch, true);
        int r = port_send_cmd(port);
        if (r == EOK) {
            transferred += bytes;
            src         += bytes;
        }
        spinlock_irqrestore(&p->lock, flags);

        if (r != EOK) return -EIO;

        lba         += batch;
        num_sectors -= batch;
    }

    return transferred;
}

static int ahci_vfs_ioctl(vnode_t *node, uint64_t request, void *arg) {
    if (!node) return -EINVAL;
    uint32_t port = (uint32_t)(uintptr_t)node->fs_data;
    if (port >= AHCI_MAX_PORTS || !s_hba.ports[port].present)
        return -ENOENT;

    ahci_port_t *p = &s_hba.ports[port];

    switch (request) {
    case AHCI_IOCTL_GET_SECTORS:
        if (!arg) return -EINVAL;
        *(uint64_t *)arg = p->sector_count;
        return EOK;
    case AHCI_IOCTL_GET_SECT_SIZE:
        if (!arg) return -EINVAL;
        *(uint32_t *)arg = p->sector_size;
        return EOK;
    case AHCI_IOCTL_FLUSH: {
        /* ATA Flush Cache Extended */
        ahci_cmd_header_t *hdr =
            (ahci_cmd_header_t *)phys_to_virt(p->cmd_list_phys);
        ahci_cmd_table_t  *tbl =
            (ahci_cmd_table_t  *)phys_to_virt(p->cmd_table_phys);
        ah_memset(tbl, 0, sizeof(ahci_cmd_table_t));
        fis_reg_h2d_t *fis = (fis_reg_h2d_t *)tbl->cfis;
        fis->fis_type = FIS_TYPE_REG_H2D;
        fis->c        = 1;
        fis->command  = ATA_CMD_FLUSH_CACHE_EXT;
        fis->device   = 0;
        hdr[0].cfl    = sizeof(fis_reg_h2d_t) / 4;
        hdr[0].w      = 0;
        hdr[0].prdtl  = 0;
        hdr[0].prdbc  = 0;
        uint64_t fl = spinlock_irqsave(&p->lock);
        int r = port_send_cmd(port);
        spinlock_irqrestore(&p->lock, fl);
        return r;
    }
    default:
        return -EINVAL;
    }
}

static vfs_ops_t s_ahci_vfs_ops = {
    .open    = NULL,
    .close   = NULL,
    .read    = ahci_vfs_read,
    .write   = ahci_vfs_write,
    .ioctl   = ahci_vfs_ioctl,
    .readdir = NULL,
    .stat    = NULL,
    .create  = NULL,
    .mkdir   = NULL,
    .unlink  = NULL,
    .mmap    = NULL,
};

/* =========================================================================
 * block_ops_t callbacks
 * ========================================================================= */

static int blk_read(device_t *dev, uint64_t lba, uint32_t count, void *buf) {
    uint32_t port = (uint32_t)(uintptr_t)dev->driver_data;
    return ahci_read(port, lba, count, buf);
}

static int blk_write(device_t *dev, uint64_t lba, uint32_t count,
                     const void *buf) {
    uint32_t port = (uint32_t)(uintptr_t)dev->driver_data;
    return ahci_write(port, lba, count, buf);
}

static int blk_flush(device_t *dev) {
    uint32_t port = (uint32_t)(uintptr_t)dev->driver_data;
    if (port >= AHCI_MAX_PORTS || !s_hba.ports[port].present)
        return -ENOENT;
    ahci_port_t *p = &s_hba.ports[port];
    ahci_cmd_header_t *hdr =
        (ahci_cmd_header_t *)phys_to_virt(p->cmd_list_phys);
    ahci_cmd_table_t  *tbl =
        (ahci_cmd_table_t  *)phys_to_virt(p->cmd_table_phys);
    ah_memset(tbl, 0, sizeof(ahci_cmd_table_t));
    fis_reg_h2d_t *fis = (fis_reg_h2d_t *)tbl->cfis;
    fis->fis_type = FIS_TYPE_REG_H2D;
    fis->c = 1;
    fis->command = ATA_CMD_FLUSH_CACHE_EXT;
    hdr[0].cfl = sizeof(fis_reg_h2d_t) / 4;
    hdr[0].w = 0;
    hdr[0].prdtl = 0;
    uint64_t flags = spinlock_irqsave(&p->lock);
    int r = port_send_cmd(port);
    spinlock_irqrestore(&p->lock, flags);
    return r;
}

/* =========================================================================
 * Registerzione in devfs AND device tree
 * ========================================================================= */

static void port_register_device(uint32_t port) {
    ahci_port_t *p = &s_hba.ports[port];
    char name[8];
    port_name(name, port);

    /* devnode_t for /dev/sdX */
    devnode_t *dn = &s_dev_nodes[port];
    ah_memset(dn, 0, sizeof(devnode_t));
    uint32_t i = 0;
    while (name[i] && i < sizeof(dn->name) - 1) {
        dn->name[i] = name[i]; i++;
    }
    dn->name[i]        = '\0';
    dn->type           = DEV_TYPE_BLOCK;
    dn->ops            = &s_ahci_vfs_ops;
    dn->driver_data    = (void *)(uintptr_t)port;
    devfs_register(dn);

    /* block_ops_t */
    block_ops_t *bops = &s_port_block_ops[port];
    bops->read_sectors  = blk_read;
    bops->write_sectors = blk_write;
    bops->flush         = blk_flush;
    bops->ioctl         = NULL;
    bops->sector_count  = p->sector_count;
    bops->sector_size   = p->sector_size;

    /* device_t nel device tree */
    device_t *dev = &s_devices[port];
    ah_memset(dev, 0, sizeof(device_t));
    i = 0;
    while (name[i] && i < sizeof(dev->name) - 1) {
        dev->name[i] = name[i]; i++;
    }
    dev->name[i]      = '\0';
    dev->type         = DEV_TYPE_BLOCK;
    dev->state        = DEV_STATE_ACTIVE;
    dev->block_ops    = bops;
    dev->driver_data  = (void *)(uintptr_t)port;
    device_add(dev, &s_bus_dev);
}

/* =========================================================================
 * ahci_init — punto of entry of the driver
 * ========================================================================= */

void ahci_init(void) {
    /* 1 — Search l'HBA AHCI sul bus PCI */
    pci_device_t *pci = pci_find_device(PCI_CLASS_STORAGE, PCI_SUBCLASS_AHCI);
    if (!pci) {
        serial_puts("[AHCI] no controller findto\n");
        return;
    }

    /* 2 — Enable Bus Master AND Memory Space nel PCI command register */
    pci_enable_busmaster(pci->bus, pci->dev, pci->func);
    pci_enable_mmio(pci->bus, pci->dev, pci->func);

    /* 3 — Leggi BAR5 (HBA MMIO base) */
    uint64_t bar5 = pci_get_bar(pci->bus, pci->dev, pci->func, 5);
    if (!bar5) {
        serial_puts("[AHCI] BAR5 non valido\n");
        return;
    }
    s_hba.hba_phys = bar5;

    /* 4 — Enable AHCI mode (GHC.AE) */
    uint32_t ghc = hba_read(AHCI_GHC);
    if (!(ghc & AHCI_GHC_AE)) {
        hba_write(AHCI_GHC, ghc | AHCI_GHC_AE);
    }

    /* 5 — Reset HBA */
    ghc = hba_read(AHCI_GHC);
    hba_write(AHCI_GHC, ghc | AHCI_GHC_RESET);
    for (uint32_t i = 0; i < 1000000; i++) {
        if (!(hba_read(AHCI_GHC) & AHCI_GHC_RESET))
            break;
        __asm__ __volatile__("pause");
    }
    /* Ri-enable AHCI after reset */
    hba_write(AHCI_GHC, hba_read(AHCI_GHC) | AHCI_GHC_AE);

    /* 6 — Leggi capacità */
    uint32_t cap  = hba_read(AHCI_CAP);
    uint32_t pi   = hba_read(AHCI_PI);
    s_hba.num_cmd_slots = ((cap >> AHCI_CAP_NCS_SHIFT) & AHCI_CAP_NCS_MASK) + 1;
    s_hba.cap_64bit     = (cap & AHCI_CAP_S64A) != 0;
    s_hba.num_ports     = (cap & AHCI_CAP_NP_MASK) + 1;

    ah_memset(s_hba.ports,   0, sizeof(s_hba.ports));
    ah_memset(s_dev_nodes,   0, sizeof(s_dev_nodes));
    ah_memset(s_devices,     0, sizeof(s_devices));

    /* Node bus "ahci0" nel device tree */
    ah_memset(&s_bus_dev, 0, sizeof(device_t));
    const char *bus_name = "ahci0";
    for (uint32_t i = 0; i < sizeof(s_bus_dev.name) - 1 && bus_name[i]; i++)
        s_bus_dev.name[i] = bus_name[i];
    s_bus_dev.type  = DEV_TYPE_BUS;
    s_bus_dev.state = DEV_STATE_ACTIVE;
    device_add(&s_bus_dev, NULL);

    uint32_t probed = 0;

    /* 7 — Enumerate ports implementate */
    for (uint32_t port = 0;
         port < 32 && port < AHCI_MAX_PORTS && probed < AHCI_MAX_PORTS;
         port++) {

        if (!(pi & (1u << port))) continue;   /* port NOT implementata */

        uint32_t ssts = port_read(port, AHCI_PxSSTS);
        uint32_t det  = ssts & AHCI_SSTS_DET_MASK;
        uint32_t ipm  = ssts & AHCI_SSTS_IPM_MASK;

        if (det != AHCI_SSTS_DET_PRESENT || ipm != AHCI_SSTS_IPM_ACTIVE)
            continue;

        /* Ignora ATAPI, enclosure management, port multiplier */
        uint32_t sig = port_read(port, AHCI_PxSIG);
        if (sig != AHCI_SIG_SATA) continue;

        ahci_port_t *p = &s_hba.ports[port];
        p->hba_port_phys = s_hba.hba_phys + AHCI_PORT_BASE(port);

        /* Stop DMA engine before of modificare the registers */
        port_stop_dma(port);

        /* Allocate DMA buffers */
        if (!port_alloc_dma(port)) {
            serial_puts("[AHCI] OOM per port DMA\n");
            continue;
        }

        /* Configura pointers CLB/FB */
        port_setup_dma_ptrs(port);

        /* Zero errors AND interrupts */
        port_write(port, AHCI_PxSERR, 0xFFFFFFFF);
        port_write(port, AHCI_PxIS,   0xFFFFFFFF);

        /* Start DMA engine */
        port_start_dma(port);

        /* IDENTIFY for geometria */
        if (port_identify(port) != EOK) {
            serial_puts("[AHCI] IDENTIFY fallito\n");
            port_stop_dma(port);
            continue;
        }

        p->present = true;

        port_register_device(port);
        probed++;
    }

    s_initialized = true;

    if (probed == 0)
        serial_puts("[AHCI] no drive SATA findto\n");
    else
        serial_puts("[AHCI] init completato\n");
}

/* =========================================================================
 * ahci_read / ahci_write — API diretta kernel
 * ========================================================================= */

int ahci_read(uint32_t port, uint64_t lba, uint32_t count, void *buf) {
    if (!s_initialized)                               return -EIO;
    if (port >= AHCI_MAX_PORTS)                       return -EINVAL;
    if (!s_hba.ports[port].present)                   return -ENOENT;
    if (!buf || count == 0)                           return -EINVAL;

    ahci_port_t *p = &s_hba.ports[port];
    if (lba + count > p->sector_count)                return -EINVAL;

    uint8_t *dst = (uint8_t *)buf;
    while (count > 0) {
        uint32_t batch = count < AHCI_MAX_SECTORS_PER_CMD
                       ? count : AHCI_MAX_SECTORS_PER_CMD;

        uint64_t flags = spinlock_irqsave(&p->lock);
        port_build_rw_cmd(port, lba, batch, false);
        int r = port_send_cmd(port);
        if (r == EOK)
            ah_memcpy(dst, phys_to_virt(p->data_buf_phys),
                      batch * p->sector_size);
        spinlock_irqrestore(&p->lock, flags);

        if (r != EOK) return r;

        dst   += batch * p->sector_size;
        lba   += batch;
        count -= batch;
    }
    return EOK;
}

int ahci_write(uint32_t port, uint64_t lba, uint32_t count, const void *buf) {
    if (!s_initialized)                               return -EIO;
    if (port >= AHCI_MAX_PORTS)                       return -EINVAL;
    if (!s_hba.ports[port].present)                   return -ENOENT;
    if (!buf || count == 0)                           return -EINVAL;

    ahci_port_t *p = &s_hba.ports[port];
    if (lba + count > p->sector_count)                return -EINVAL;

    const uint8_t *src = (const uint8_t *)buf;
    while (count > 0) {
        uint32_t batch = count < AHCI_MAX_SECTORS_PER_CMD
                       ? count : AHCI_MAX_SECTORS_PER_CMD;

        uint64_t flags = spinlock_irqsave(&p->lock);
        ah_memcpy(phys_to_virt(p->data_buf_phys), src,
                  batch * p->sector_size);
        port_build_rw_cmd(port, lba, batch, true);
        int r = port_send_cmd(port);
        spinlock_irqrestore(&p->lock, flags);

        if (r != EOK) return r;

        src   += batch * p->sector_size;
        lba   += batch;
        count -= batch;
    }
    return EOK;
}
