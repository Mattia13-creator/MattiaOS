#ifndef MATTIAOS_NVME_H
#define MATTIAOS_NVME_H

/*
 * kernel/drivers/storage/nvme.h — controller NVMe (PCIe SSD)
 *
 * Gestisce controller NVMe (NVM Express, spec 1.4).
 * Ogni namespace active is esposto as /dev/nvme0, /dev/nvme1, ...
 * AND inserito nel device tree below to node bus "nvme_ctrl0".
 *
 * Standard of riferimento: NVM Express 1.4 (NVMe Consortium)
 *
 * Architettura driver:
 *   - Un controller for system (unico PCI device NVMe found)
 *   - 1 Admin Queue  (SQ + CQ, 64 entry ciascuna)
 *   - 1 I/O Queue    (SQ + CQ, 256 entry ciascuna) — aggiunta after init
 *   - Fino to NVME_MAX_NS namespace (default 4)
 *   - I/O polled sulla CQ (Phase Phase 8, no IRQ MSI-X)
 *
 * Dependencies:
 *   driver.h — device_t, block_ops_t, mmio_read32/64/write32/64, spinlock_*
 *   pci.h    — pci_device_t, pci_get_bar, pci_enable_busmaster
 *   slab.h   — kzalloc
 *   pmm.h    — pmm_alloc_frames (queues DMA fisicamente contigue)
 *   vmm.h    — phys_to_virt, virt_to_phys
 */

#include "../driver.h"
#include "../pci.h"

/* =========================================================================
 * Registers controller NVMe — offset from the BAR0 (64-bit MMIO)
 * ========================================================================= */

#define NVME_CAP        0x000   /* Controller Capabilities (64-bit)          */
#define NVME_VS         0x008   /* Version                                   */
#define NVME_INTMS      0x00C   /* Interrupt Mask Set                        */
#define NVME_INTMC      0x010   /* Interrupt Mask Clear                      */
#define NVME_CC         0x014   /* Controller Configuration                  */
#define NVME_CSTS       0x01C   /* Controller Status                         */
#define NVME_NSSR       0x020   /* NVM Subsystem Reset                       */
#define NVME_AQA        0x024   /* Admin Queue Attributes                    */
#define NVME_ASQ        0x028   /* Admin Submission Queue Base (64-bit)      */
#define NVME_ACQ        0x030   /* Admin Completion Queue Base (64-bit)      */
#define NVME_CMBLOC     0x038   /* Controller Memory Buffer Location         */
#define NVME_CMBSZ      0x03C   /* Controller Memory Buffer Size             */

/* CC bits */
#define NVME_CC_EN       (1 << 0)    /* Enable                              */
#define NVME_CC_CSS_NVM  (0 << 4)    /* I/O Command Set: NVM                */
#define NVME_CC_MPS_SHIFT 7          /* Memory Page Size (2^(12+MPS))       */
#define NVME_CC_AMS_RR   (0 << 11)   /* Arbitration: Round Robin            */
#define NVME_CC_SHN_NONE (0 << 14)   /* Shutdown: no notification           */
#define NVME_CC_IOSQES   (6 << 16)   /* I/O SQ Entry Size: 2^6 = 64 bytes   */
#define NVME_CC_IOCQES   (4 << 20)   /* I/O CQ Entry Size: 2^4 = 16 bytes   */

/* CSTS bits */
#define NVME_CSTS_RDY    (1 << 0)    /* Ready                               */
#define NVME_CSTS_CFS    (1 << 1)    /* Controller Fatal Status             */
#define NVME_CSTS_PP     (1 << 5)    /* Processesng Paused                   */

/* CAP bits */
#define NVME_CAP_MQES_MASK  0xFFFFULL  /* Max Queue Entries Supportsd (0-based) */
#define NVME_CAP_DSTRD_SHIFT 32         /* Doorbell Stride (2^(2+DSTRD))     */
#define NVME_CAP_DSTRD_MASK  0xFULL
#define NVME_CAP_MPSMIN_SHIFT 48        /* Memory Page Size Minimum          */
#define NVME_CAP_MPSMIN_MASK  0xFULL
#define NVME_CAP_CSS_NVM      (1ULL << 37) /* NVM command set supportsd      */

/* Doorbell register stride: default 4 bytes (DSTRD=0) */
#define NVME_SQ0TDBL   0x1000   /* Admin SQ Tail Doorbell                    */
#define NVME_CQ0HDBL   0x1004   /* Admin CQ Head Doorbell                    */
/* I/O queues: SQ1TDBL=0x1008, CQ1HDBL=0x100C (for DSTRD=0) */
#define NVME_SQ1TDBL   0x1008
#define NVME_CQ1HDBL   0x100C

/* =========================================================================
 * Structures queues — SQ (Submission Queue) AND CQ (Completion Queue)
 * ========================================================================= */

/*
 * nvme_sq_entry_t — Submission Queue Entry: 64 byte.
 * Usata for Admin AND I/O commands.
 */
typedef struct {
    uint32_t cdw0;       /* Command DWord 0: OPC[7:0] | FUSE[9:8] | CID[31:16] */
    uint32_t nsid;       /* Namespace ID                                      */
    uint64_t rsv;        /* Reserved                                         */
    uint64_t mptr;       /* Metadata Pointer (NOT usato)                     */
    uint64_t prp1;       /* PRP Entry 1: data (phys addr)                    */
    uint64_t prp2;       /* PRP Entry 2: lista PRP OR second block          */
    uint32_t cdw10;      /* Command-specific DWord 10                        */
    uint32_t cdw11;      /* Command-specific DWord 11                        */
    uint32_t cdw12;      /* Command-specific DWord 12                        */
    uint32_t cdw13;      /* Command-specific DWord 13                        */
    uint32_t cdw14;      /* Command-specific DWord 14                        */
    uint32_t cdw15;      /* Command-specific DWord 15                        */
} __attribute__((packed)) nvme_sq_entry_t;

/*
 * nvme_cq_entry_t — Completion Queue Entry: 16 byte.
 */
typedef struct {
    uint32_t dw0;        /* Command-specific result                          */
    uint32_t dw1;        /* Reserved                                         */
    uint16_t sq_head;    /* SQ Head Pointer (aggiorna the capo of the SQ)      */
    uint16_t sq_id;      /* SQ Identifier                                    */
    uint16_t cid;        /* Command Identifier                               */
    uint16_t status;     /* Status: Phase[0] | SC[8:1] | SCT[11:9] | ...     */
} __attribute__((packed)) nvme_cq_entry_t;

/* CQ status field */
#define NVME_CQE_PHASE_BIT   (1 << 0)
#define NVME_CQE_SC_MASK     0x1FE       /* Status Queues [8:1] */
#define NVME_CQE_SCT_MASK    0xE00       /* Status Queues Type [11:9] */
#define NVME_CQE_STATUS_OK   0           /* Successful completion */

/* =========================================================================
 * Opcodes NVMe
 * ========================================================================= */

/* Admin commands */
#define NVME_ADMIN_DELETE_SQ    0x00
#define NVME_ADMIN_CREATE_SQ    0x01
#define NVME_ADMIN_GET_LOG      0x02
#define NVME_ADMIN_DELETE_CQ    0x04
#define NVME_ADMIN_CREATE_CQ    0x05
#define NVME_ADMIN_IDENTIFY     0x06
#define NVME_ADMIN_ABORT        0x08
#define NVME_ADMIN_SET_FEATURES 0x09
#define NVME_ADMIN_GET_FEATURES 0x0A

/* I/O commands */
#define NVME_IO_FLUSH    0x00
#define NVME_IO_WRITE    0x01
#define NVME_IO_READ     0x02

/* Identify CDW10 values */
#define NVME_ID_CNS_NAMESPACE   0x00   /* Identify Namespace        */
#define NVME_ID_CNS_CONTROLLER  0x01   /* Identify Controller       */
#define NVME_ID_CNS_NS_LIST     0x02   /* Active Namespace ID List  */

/* =========================================================================
 * Structures data Identify (parziali — only the fields usati)
 * ========================================================================= */

/*
 * nvme_id_ns_t — rimove to Identify Namespace (4096 byte).
 * Contiene the number of LBA (NSZE) AND the formato LBA active (FLBAS).
 */
typedef struct {
    uint64_t nsze;       /* Namespace Size (number of LBA)                   */
    uint64_t ncap;       /* Namespace Capacity                               */
    uint64_t nuse;       /* Namespace Utilization                            */
    uint8_t  nsfeat;
    uint8_t  nlbaf;      /* Number of LBA Formats (0-based)                  */
    uint8_t  flbas;      /* Formatted LBA Size: bits[3:0] = formato active   */
    uint8_t  mc;
    uint8_t  dpc;
    uint8_t  dps;
    uint8_t  nmic;
    uint8_t  rescap;
    uint8_t  fpi;
    uint8_t  dlfeat;
    uint16_t nawun;
    uint16_t nawupf;
    uint16_t nacwu;
    uint16_t nabsn;
    uint16_t nabo;
    uint16_t nabspf;
    uint16_t noiob;
    uint8_t  nvmcap[16];
    uint8_t  rsv0[40];
    uint8_t  nguid[16];
    uint8_t  eui64[8];
    /* LBA Format Support: 16 entry from 4 byte */
    uint32_t lbaf[16];   /* lbaf[the]: MS[31:16] | LBADS[15:8] | RP[1:0]      */
    uint8_t  rsv1[192];
    uint8_t  vs[3712];
} __attribute__((packed)) nvme_id_ns_t;

/* Estrae the size of the LBA in byte from lbaf[the]: 2^LBADS */
#define NVME_LBAF_LBADS(x)  (((x) >> 16) & 0xFF)

/* =========================================================================
 * Structure of stato queue
 * ========================================================================= */

typedef struct {
    nvme_sq_entry_t *sq_virt;   /* virtual address of the SQ (HHDM)           */
    nvme_cq_entry_t *cq_virt;   /* virtual address of the CQ (HHDM)           */
    uint64_t         sq_phys;   /* physical address of the SQ                 */
    uint64_t         cq_phys;   /* physical address of the CQ                 */
    uint32_t         sq_size;   /* number of entry nella SQ                  */
    uint32_t         cq_size;   /* number of entry nella CQ                  */
    uint16_t         sq_tail;   /* tail doorbell index                       */
    uint16_t         cq_head;   /* head doorbell index                       */
    uint8_t          cq_phase;  /* phase bit atteso nella CQ                 */
    uint16_t         next_cid;  /* next Command ID from assegnare          */
} nvme_queue_t;

/* =========================================================================
 * Structure namespace
 * ========================================================================= */

#define NVME_MAX_NS   4

typedef struct {
    bool     valid;
    uint32_t nsid;
    uint64_t sector_count;   /* NSZE */
    uint32_t sector_size;    /* 2^LBADS */
} nvme_ns_t;

/* =========================================================================
 * Structure controller NVMe
 * ========================================================================= */

typedef struct {
    uint64_t     bar0_phys;      /* BAR0 — controller registers base         */
    uint32_t     db_stride;      /* doorbell stride in byte (4 for DSTRD=0)  */

    nvme_queue_t admin_q;        /* Admin Queue (qid=0)                      */
    nvme_queue_t io_q;           /* I/O Queue (qid=1)                        */

    spinlock_t   admin_lock;     /* protegge admin_q                         */
    spinlock_t   io_lock;        /* protegge io_q                            */

    nvme_ns_t    ns[NVME_MAX_NS];
    uint32_t     ns_count;
} nvme_ctrl_t;

/* =========================================================================
 * Ioctl commands for /dev/nvmeX
 * ========================================================================= */

#define NVME_IOCTL_GET_SECTORS    0xE001  /* arg → uint64_t* (out) */
#define NVME_IOCTL_GET_SECT_SIZE  0xE002  /* arg → uint32_t* (out) */
#define NVME_IOCTL_FLUSH          0xE003  /* flush NVM             */

/* =========================================================================
 * API pubblica
 * ========================================================================= */

/*
 * nvme_init — scansiona PCI, initialise the controller, enumerate namespace.
 * Register every namespace as /dev/nvme0, /dev/nvme1, ... in devfs.
 * Chiamata from drivers_init() after pci_enumerate().
 */
void nvme_init(void);

/*
 * nvme_read / nvme_write — read/write diretta from kernel.
 * ns_idx: indice namespace (0-based).
 * Returns EOK or negative error negative.
 */
int nvme_read (uint32_t ns_idx, uint64_t lba, uint32_t count, void *buf);
int nvme_write(uint32_t ns_idx, uint64_t lba, uint32_t count, const void *buf);

#endif /* MATTIAOS_NVME_H */
