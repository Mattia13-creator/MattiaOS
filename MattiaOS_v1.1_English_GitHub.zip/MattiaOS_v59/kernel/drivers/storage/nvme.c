#include "nvme.h"
#include "../pci.h"
#include "../../mm/pmm.h"
#include "../../mm/vmm.h"
#include "../../mm/slab.h"
#include "../../fs/devfs.h"
#include "../../include/errno.h"
#include "../../arch/x86_64/cpu.h"

/*
 * nvme.c — driver NVMe for MattiaOS
 *
 * Implementa:
 *   - Rilevamento controller via PCI (class 0x01, subclass 0x08)
 *   - Reset controller AND setup Admin Queue (AQ)
 *   - Enablezione controller (CC.EN) with attesa CSTS.RDY
 *   - Admin commands: Identify Controller, Identify Namespace,
 *                     Create I/O SQ, Create I/O CQ
 *   - I/O commands: Read, Write, Flush
 *   - Registerzione /dev/nvme0…nvme3 in devfs AND device tree
 *
 * I/O: completely polled sulla CQ (Phase Tag bit).
 * No MSI-X in Phase 8.
 *
 * PRP (Physical Region Pages):
 *   - Se trasferimento ≤ PAGE_SIZE: prp1 = buffer physical, prp2 = 0
 *   - Se trasferimento ≤ 2*PAGE_SIZE: prp1, prp2 = due pages fisiche
 *   - Se trasferimento > 2*PAGE_SIZE: prp1 = before page,
 *     prp2 = lista PRP (array of addresses fisici in to page dedicata)
 *
 * Thread safety:
 *   admin_lock for admin_q, io_lock for io_q (spinlock_irqsave).
 */

/* =========================================================================
 * Stato global
 * ========================================================================= */

static nvme_ctrl_t s_ctrl;
static bool        s_initialized = false;

static devnode_t   s_dev_nodes[NVME_MAX_NS];
static device_t    s_devices[NVME_MAX_NS];
static device_t    s_bus_dev;
static block_ops_t s_ns_block_ops[NVME_MAX_NS];

/* Page physical for lista PRP (usata for trasferimenti > 2 pages) */
static uint64_t    s_prp_list_phys = 0;

/* =========================================================================
 * Helper: stringhe minimali
 * ========================================================================= */

static inline void *nv_memset(void *d, int c, size_t n) {
    uint8_t *p = (uint8_t *)d;
    while (n--) *p++ = (uint8_t)c;
    return d;
}

static inline void *nv_memcpy(void *d, const void *s, size_t n) {
    uint8_t *dd = (uint8_t *)d;
    const uint8_t *ss = (const uint8_t *)s;
    while (n--) *dd++ = *ss++;
    return d;
}

/* Write the name "nvmeN" in buf */
static void ns_name(char *buf, uint32_t idx) {
    /* "nvme" + digit */
    buf[0]='n'; buf[1]='v'; buf[2]='m'; buf[3]='e';
    buf[4] = (char)('0' + (char)idx);
    buf[5] = '\0';
}

/* =========================================================================
 * Helper: accesso to the registers of the controller via MMIO
 * ========================================================================= */

static inline uint32_t ctrl_read32(uint32_t reg) {
    return mmio_read32(s_ctrl.bar0_phys + reg);
}

static inline uint64_t ctrl_read64(uint32_t reg) {
    return mmio_read64(s_ctrl.bar0_phys + reg);
}

static inline void ctrl_write32(uint32_t reg, uint32_t val) {
    mmio_write32(s_ctrl.bar0_phys + reg, val);
    mmio_barrier();
}

static inline void ctrl_write64(uint32_t reg, uint64_t val) {
    mmio_write64(s_ctrl.bar0_phys + reg, val);
    mmio_barrier();
}

/* Write nel doorbell of SQ (tail) */
static inline void ring_sq_doorbell(uint32_t qid, uint16_t tail) {
    uint32_t offset = NVME_SQ0TDBL + qid * 2 * s_ctrl.db_stride;
    ctrl_write32(offset, (uint32_t)tail);
}

/* Write nel doorbell of CQ (head) */
static inline void ring_cq_doorbell(uint32_t qid, uint16_t head) {
    uint32_t offset = NVME_CQ0HDBL + qid * 2 * s_ctrl.db_stride;
    ctrl_write32(offset, (uint32_t)head);
}

/* =========================================================================
 * Queue allocation
 *
 * Admin SQ: 64 entry × 64 B = 4096 B = 1 page
 * Admin CQ: 64 entry × 16 B = 1024 B < 1 page (usa 1 page intera)
 * I/O SQ:  256 entry × 64 B = 16384 B = 4 pages
 * I/O CQ:  256 entry × 16 B =  4096 B = 1 page
 * ========================================================================= */

#define ADMIN_Q_SIZE  64
#define IO_Q_SIZE    256

static bool alloc_queue(nvme_queue_t *q, uint32_t sq_entries,
                        uint32_t cq_entries) {
    /* SQ */
    size_t sq_bytes  = sq_entries * sizeof(nvme_sq_entry_t);
    size_t sq_pages  = (sq_bytes + PAGE_SIZE - 1) / PAGE_SIZE;
    q->sq_phys = pmm_alloc_frames(sq_pages);
    if (!q->sq_phys) return false;
    q->sq_virt = (nvme_sq_entry_t *)phys_to_virt(q->sq_phys);
    nv_memset(q->sq_virt, 0, sq_pages * PAGE_SIZE);

    /* CQ */
    size_t cq_bytes  = cq_entries * sizeof(nvme_cq_entry_t);
    size_t cq_pages  = (cq_bytes + PAGE_SIZE - 1) / PAGE_SIZE;
    q->cq_phys = pmm_alloc_frames(cq_pages);
    if (!q->cq_phys) {
        for (size_t i = 0; i < sq_pages; i++)
            pmm_free_frame(q->sq_phys + i * PAGE_SIZE);
        return false;
    }
    q->cq_virt = (nvme_cq_entry_t *)phys_to_virt(q->cq_phys);
    nv_memset(q->cq_virt, 0, cq_pages * PAGE_SIZE);

    q->sq_size  = sq_entries;
    q->cq_size  = cq_entries;
    q->sq_tail  = 0;
    q->cq_head  = 0;
    q->cq_phase = 1;   /* phase iniziale = 1 (CQ zeroed → Phase=0 ≠ 1) */
    q->next_cid = 1;
    return true;
}

/* =========================================================================
 * Invio AND attesa completamento (polled)
 * ========================================================================= */

/*
 * submit_cmd — copy cmd nella SQ AND fa ring of the doorbell.
 * Deve essere chiamata with the lock of the queue acquisito.
 * Returns the CID usato.
 */
static uint16_t submit_cmd(nvme_queue_t *q, uint32_t qid,
                            nvme_sq_entry_t *cmd) {
    uint16_t cid = q->next_cid++;
    if (q->next_cid == 0) q->next_cid = 1;   /* evita CID=0 */

    /* Set CID nel CDW0 bits[31:16] */
    cmd->cdw0 = (cmd->cdw0 & 0x0000FFFF) | ((uint32_t)cid << 16);

    /* Copy nella SQ */
    q->sq_virt[q->sq_tail] = *cmd;
    q->sq_tail = (q->sq_tail + 1) % q->sq_size;

    /* Ring doorbell SQ */
    ring_sq_doorbell(qid, q->sq_tail);
    return cid;
}

/*
 * wait_completion — poll sulla CQ finché arriva l'entry with CID atteso.
 * Returns the field status of the CQE, OR 0xFFFF up timeout.
 */
static uint16_t wait_completion(nvme_queue_t *q, uint32_t qid, uint16_t cid) {
    for (uint32_t i = 0; i < 2000000; i++) {
        nvme_cq_entry_t *cqe = &q->cq_virt[q->cq_head];
        /* Phase tag: when HBA writes, toglie/mette the phase bit */
        uint16_t phase = cqe->status & NVME_CQE_PHASE_BIT;
        if (phase == q->cq_phase) {
            /* Entry valid — controlla if è the nostro comando */
            if (cqe->cid == cid) {
                uint16_t status = cqe->status;
                q->cq_head = (q->cq_head + 1) % q->cq_size;
                if (q->cq_head == 0)
                    q->cq_phase ^= 1;   /* inversion phase to the wrap-around */
                /* Ring CQ head doorbell */
                ring_cq_doorbell(qid, q->cq_head);
                return status;
            }
            /* Entry of to altro CID (NOT atteso): avanza comunque */
            q->cq_head = (q->cq_head + 1) % q->cq_size;
            if (q->cq_head == 0) q->cq_phase ^= 1;
            ring_cq_doorbell(qid, q->cq_head);
        }
        __asm__ __volatile__("pause");
    }
    return 0xFFFF;   /* timeout */
}

/*
 * admin_cmd — send to Admin command AND attende the completamento.
 * Returns EOK if status == 0, -EIO altrimenti.
 */
static int admin_cmd(nvme_sq_entry_t *cmd) {
    uint64_t flags = spinlock_irqsave(&s_ctrl.admin_lock);
    uint16_t cid = submit_cmd(&s_ctrl.admin_q, 0, cmd);
    uint16_t status = wait_completion(&s_ctrl.admin_q, 0, cid);
    spinlock_irqrestore(&s_ctrl.admin_lock, flags);

    if (status == 0xFFFF) return -EIO;   /* timeout */
    /* status bits [8:1] = SC, bits [11:9] = SCT; 0 = success */
    if ((status >> 1) & 0xFF) return -EIO;
    return EOK;
}

/*
 * io_cmd — send to I/O command (qid=1) AND attende the completamento.
 */
static int io_cmd(nvme_sq_entry_t *cmd) {
    uint64_t flags = spinlock_irqsave(&s_ctrl.io_lock);
    uint16_t cid = submit_cmd(&s_ctrl.io_q, 1, cmd);
    uint16_t status = wait_completion(&s_ctrl.io_q, 1, cid);
    spinlock_irqrestore(&s_ctrl.io_lock, flags);

    if (status == 0xFFFF) return -EIO;
    if ((status >> 1) & 0xFF) return -EIO;
    return EOK;
}

/* =========================================================================
 * Admin commands: Identify, Create CQ/SQ
 * ========================================================================= */

static int identify(uint32_t nsid, uint8_t cns, uint64_t data_phys) {
    nvme_sq_entry_t cmd;
    nv_memset(&cmd, 0, sizeof(cmd));
    cmd.cdw0  = NVME_ADMIN_IDENTIFY;
    cmd.nsid  = nsid;
    cmd.prp1  = data_phys;
    cmd.prp2  = 0;
    cmd.cdw10 = cns;
    return admin_cmd(&cmd);
}

static int create_io_cq(uint16_t qid, uint64_t cq_phys, uint16_t qsize) {
    nvme_sq_entry_t cmd;
    nv_memset(&cmd, 0, sizeof(cmd));
    cmd.cdw0  = NVME_ADMIN_CREATE_CQ;
    cmd.prp1  = cq_phys;
    /*
     * CDW10: QSIZE[31:16] | QID[15:0]
     * CDW11: IV[31:16] | IEN[1] | PC[0]
     *   PC=1: physically contiguous
     *   IEN=0: interrupt disable (polled)
     */
    cmd.cdw10 = ((uint32_t)(qsize - 1) << 16) | qid;
    cmd.cdw11 = 1;   /* PC=1 */
    return admin_cmd(&cmd);
}

static int create_io_sq(uint16_t qid, uint64_t sq_phys,
                        uint16_t qsize, uint16_t cqid) {
    nvme_sq_entry_t cmd;
    nv_memset(&cmd, 0, sizeof(cmd));
    cmd.cdw0  = NVME_ADMIN_CREATE_SQ;
    cmd.prp1  = sq_phys;
    /*
     * CDW10: QSIZE[31:16] | QID[15:0]
     * CDW11: CQID[31:16] | QPRIO[2:1] | PC[0]
     *   QPRIO=00: urgent
     *   PC=1: physically contiguous
     */
    cmd.cdw10 = ((uint32_t)(qsize - 1) << 16) | qid;
    cmd.cdw11 = ((uint32_t)cqid << 16) | 1;
    return admin_cmd(&cmd);
}

/* =========================================================================
 * I/O commands: Read, Write, Flush
 *
 * PRP setup:
 *   transfer_bytes ≤ PAGE_SIZE:          prp1=buf, prp2=0
 *   transfer_bytes ≤ 2*PAGE_SIZE:        prp1=buf, prp2=buf+PAGE_SIZE
 *   transfer_bytes > 2*PAGE_SIZE:        prp1=buf, prp2=lista PRP
 *     (lista PRP = array of phys addr, 8 byte each, in page dedicata)
 * ========================================================================= */

static void build_prp(nvme_sq_entry_t *cmd, uint64_t buf_phys,
                      uint32_t transfer_bytes) {
    cmd->prp1 = buf_phys;

    if (transfer_bytes <= PAGE_SIZE) {
        cmd->prp2 = 0;
        return;
    }

    if (transfer_bytes <= 2 * PAGE_SIZE) {
        cmd->prp2 = buf_phys + PAGE_SIZE;
        return;
    }

    /*
     * Lista PRP: every entry è to address physical of to page.
     * La lista stessa occupa s_prp_list_phys (allocateta in nvme_init).
     * Primo elemento: seconda page of the buffer.
     * Pages successive: terza, quarta, ...
     */
    uint64_t *prp_list = (uint64_t *)phys_to_virt(s_prp_list_phys);
    uint32_t pages_needed = (transfer_bytes + PAGE_SIZE - 1) / PAGE_SIZE;
    /* pages_needed - 1 entrate nella lista (the before è già in prp1) */
    for (uint32_t i = 1; i < pages_needed; i++)
        prp_list[i - 1] = buf_phys + (uint64_t)i * PAGE_SIZE;
    cmd->prp2 = s_prp_list_phys;
}

/* =========================================================================
 * Buffer DMA for I/O — allocateto in nvme_init
 * Size: NVME_IO_PAGES * PAGE_SIZE
 * ========================================================================= */

#define NVME_IO_PAGES    32    /* 128 KB — stesso of the driver AHCI             */
#define NVME_MAX_SECTORS_PER_CMD 256  /* to 512 B/sett = 128 KB               */

static uint64_t s_io_buf_phys = 0;

static int do_io_cmd(uint32_t nsid, uint64_t slba, uint16_t nlb,
                     uint64_t buf_phys, bool write) {
    nvme_sq_entry_t cmd;
    nv_memset(&cmd, 0, sizeof(cmd));
    cmd.cdw0  = write ? NVME_IO_WRITE : NVME_IO_READ;
    cmd.nsid  = nsid;

    nvme_ns_t *ns = NULL;
    for (uint32_t i = 0; i < s_ctrl.ns_count; i++) {
        if (s_ctrl.ns[i].nsid == nsid) { ns = &s_ctrl.ns[i]; break; }
    }
    if (!ns) return -ENOENT;

    uint32_t transfer_bytes = (uint32_t)nlb * ns->sector_size;
    build_prp(&cmd, buf_phys, transfer_bytes);

    /* CDW10: SLBA[31:0], CDW11: SLBA[63:32] */
    cmd.cdw10 = (uint32_t)( slba        & 0xFFFFFFFF);
    cmd.cdw11 = (uint32_t)((slba >> 32) & 0xFFFFFFFF);
    /* CDW12: NLB[15:0] (0-based) */
    cmd.cdw12 = (uint32_t)(nlb - 1);

    return io_cmd(&cmd);
}

/* =========================================================================
 * VFS operations for /dev/nvmeX
 * ========================================================================= */

static ssize_t nvme_vfs_read(vnode_t *node, void *buf,
                              size_t count, off_t offset) {
    if (!node || !buf) return -EINVAL;
    uint32_t ns_idx = (uint32_t)(uintptr_t)node->fs_data;
    if (ns_idx >= NVME_MAX_NS || !s_ctrl.ns[ns_idx].valid) return -ENOENT;

    nvme_ns_t *ns = &s_ctrl.ns[ns_idx];
    if (offset % (off_t)ns->sector_size != 0) return -EINVAL;
    if (count  %         ns->sector_size != 0) return -EINVAL;

    uint64_t slba        = (uint64_t)offset / ns->sector_size;
    uint32_t num_sectors = (uint32_t)(count  / ns->sector_size);
    if (slba + num_sectors > ns->sector_count) return -EINVAL;

    ssize_t transferred = 0;
    uint8_t *dst = (uint8_t *)buf;

    while (num_sectors > 0) {
        uint32_t batch = num_sectors < NVME_MAX_SECTORS_PER_CMD
                       ? num_sectors : NVME_MAX_SECTORS_PER_CMD;

        uint64_t flags = spinlock_irqsave(&s_ctrl.io_lock);
        int r = do_io_cmd(ns->nsid, slba, (uint16_t)batch,
                          s_io_buf_phys, false);
        if (r == EOK) {
            uint32_t bytes = batch * ns->sector_size;
            nv_memcpy(dst, phys_to_virt(s_io_buf_phys), bytes);
            transferred += bytes;
            dst         += bytes;
        }
        spinlock_irqrestore(&s_ctrl.io_lock, flags);

        if (r != EOK) return -EIO;
        slba        += batch;
        num_sectors -= batch;
    }
    return transferred;
}

static ssize_t nvme_vfs_write(vnode_t *node, const void *buf,
                               size_t count, off_t offset) {
    if (!node || !buf) return -EINVAL;
    uint32_t ns_idx = (uint32_t)(uintptr_t)node->fs_data;
    if (ns_idx >= NVME_MAX_NS || !s_ctrl.ns[ns_idx].valid) return -ENOENT;

    nvme_ns_t *ns = &s_ctrl.ns[ns_idx];
    if (offset % (off_t)ns->sector_size != 0) return -EINVAL;
    if (count  %         ns->sector_size != 0) return -EINVAL;

    uint64_t slba        = (uint64_t)offset / ns->sector_size;
    uint32_t num_sectors = (uint32_t)(count  / ns->sector_size);
    if (slba + num_sectors > ns->sector_count) return -EINVAL;

    ssize_t transferred = 0;
    const uint8_t *src = (const uint8_t *)buf;

    while (num_sectors > 0) {
        uint32_t batch = num_sectors < NVME_MAX_SECTORS_PER_CMD
                       ? num_sectors : NVME_MAX_SECTORS_PER_CMD;

        uint64_t flags = spinlock_irqsave(&s_ctrl.io_lock);
        uint32_t bytes = batch * ns->sector_size;
        nv_memcpy(phys_to_virt(s_io_buf_phys), src, bytes);
        int r = do_io_cmd(ns->nsid, slba, (uint16_t)batch,
                          s_io_buf_phys, true);
        if (r == EOK) {
            transferred += bytes;
            src         += bytes;
        }
        spinlock_irqrestore(&s_ctrl.io_lock, flags);

        if (r != EOK) return -EIO;
        slba        += batch;
        num_sectors -= batch;
    }
    return transferred;
}

static int nvme_vfs_ioctl(vnode_t *node, uint64_t request, void *arg) {
    if (!node) return -EINVAL;
    uint32_t ns_idx = (uint32_t)(uintptr_t)node->fs_data;
    if (ns_idx >= NVME_MAX_NS || !s_ctrl.ns[ns_idx].valid) return -ENOENT;
    nvme_ns_t *ns = &s_ctrl.ns[ns_idx];

    switch (request) {
    case NVME_IOCTL_GET_SECTORS:
        if (!arg) return -EINVAL;
        *(uint64_t *)arg = ns->sector_count;
        return EOK;
    case NVME_IOCTL_GET_SECT_SIZE:
        if (!arg) return -EINVAL;
        *(uint32_t *)arg = ns->sector_size;
        return EOK;
    case NVME_IOCTL_FLUSH: {
        nvme_sq_entry_t cmd;
        nv_memset(&cmd, 0, sizeof(cmd));
        cmd.cdw0 = NVME_IO_FLUSH;
        cmd.nsid = ns->nsid;
        uint64_t flags = spinlock_irqsave(&s_ctrl.io_lock);
        int r = io_cmd(&cmd);
        spinlock_irqrestore(&s_ctrl.io_lock, flags);
        return r;
    }
    default:
        return -EINVAL;
    }
}

static vfs_ops_t s_nvme_vfs_ops = {
    .open    = NULL,
    .close   = NULL,
    .read    = nvme_vfs_read,
    .write   = nvme_vfs_write,
    .ioctl   = nvme_vfs_ioctl,
    .readdir = NULL,
    .stat    = NULL,
    .create  = NULL,
    .mkdir   = NULL,
    .unlink  = NULL,
    .mmap    = NULL,
};

/* =========================================================================
 * block_ops_t callbacks
 * ========================================================================= */

static int nvblk_read(device_t *dev, uint64_t lba,
                      uint32_t count, void *buf) {
    uint32_t ns_idx = (uint32_t)(uintptr_t)dev->driver_data;
    return nvme_read(ns_idx, lba, count, buf);
}

static int nvblk_write(device_t *dev, uint64_t lba,
                       uint32_t count, const void *buf) {
    uint32_t ns_idx = (uint32_t)(uintptr_t)dev->driver_data;
    return nvme_write(ns_idx, lba, count, buf);
}

static int nvblk_flush(device_t *dev) {
    uint32_t ns_idx = (uint32_t)(uintptr_t)dev->driver_data;
    if (ns_idx >= NVME_MAX_NS || !s_ctrl.ns[ns_idx].valid) return -ENOENT;
    nvme_sq_entry_t cmd;
    nv_memset(&cmd, 0, sizeof(cmd));
    cmd.cdw0 = NVME_IO_FLUSH;
    cmd.nsid = s_ctrl.ns[ns_idx].nsid;
    uint64_t flags = spinlock_irqsave(&s_ctrl.io_lock);
    int r = io_cmd(&cmd);
    spinlock_irqrestore(&s_ctrl.io_lock, flags);
    return r;
}

/* =========================================================================
 * Registerzione in devfs AND device tree
 * ========================================================================= */

static void ns_register_device(uint32_t ns_idx) {
    nvme_ns_t *ns = &s_ctrl.ns[ns_idx];
    char name[8];
    ns_name(name, ns_idx);

    /* devnode_t */
    devnode_t *dn = &s_dev_nodes[ns_idx];
    nv_memset(dn, 0, sizeof(devnode_t));
    uint32_t i = 0;
    while (name[i] && i < sizeof(dn->name) - 1) {
        dn->name[i] = name[i]; i++;
    }
    dn->name[i]     = '\0';
    dn->type        = DEV_TYPE_BLOCK;
    dn->ops         = &s_nvme_vfs_ops;
    dn->driver_data = (void *)(uintptr_t)ns_idx;
    devfs_register(dn);

    /* block_ops_t */
    block_ops_t *bops = &s_ns_block_ops[ns_idx];
    bops->read_sectors  = nvblk_read;
    bops->write_sectors = nvblk_write;
    bops->flush         = nvblk_flush;
    bops->ioctl         = NULL;
    bops->sector_count  = ns->sector_count;
    bops->sector_size   = ns->sector_size;

    /* device_t */
    device_t *dev = &s_devices[ns_idx];
    nv_memset(dev, 0, sizeof(device_t));
    i = 0;
    while (name[i] && i < sizeof(dev->name) - 1) {
        dev->name[i] = name[i]; i++;
    }
    dev->name[i]     = '\0';
    dev->type        = DEV_TYPE_BLOCK;
    dev->state       = DEV_STATE_ACTIVE;
    dev->block_ops   = bops;
    dev->driver_data = (void *)(uintptr_t)ns_idx;
    device_add(dev, &s_bus_dev);
}

/* =========================================================================
 * nvme_init — punto of entry of the driver
 * ========================================================================= */

void nvme_init(void) {
    /* 1 — Search controller NVMe sul bus PCI */
    pci_device_t *pci = pci_find_device(PCI_CLASS_STORAGE, PCI_SUBCLASS_NVME);
    if (!pci) {
        serial_puts("[NVMe] no controller findto\n");
        return;
    }

    pci_enable_busmaster(pci->bus, pci->dev, pci->func);
    pci_enable_mmio(pci->bus, pci->dev, pci->func);
    /* Disenable interrupts legacy: useremo polling */
    pci_disable_interrupts(pci->bus, pci->dev, pci->func);

    /* 2 — Leggi BAR0 (64-bit) */
    uint64_t bar0 = pci_get_bar(pci->bus, pci->dev, pci->func, 0);
    if (!bar0) {
        serial_puts("[NVMe] BAR0 non valido\n");
        return;
    }
    s_ctrl.bar0_phys = bar0;

    nv_memset(&s_ctrl, 0, sizeof(nvme_ctrl_t));
    s_ctrl.bar0_phys = bar0;

    /* 3 — Leggi CAP: doorbell stride AND check NVM command set */
    uint64_t cap = ctrl_read64(NVME_CAP);
    s_ctrl.db_stride = 4u << (uint32_t)((cap >> NVME_CAP_DSTRD_SHIFT)
                                         & NVME_CAP_DSTRD_MASK);

    if (!(cap & NVME_CAP_CSS_NVM)) {
        serial_puts("[NVMe] NVM command set non supportto\n");
        return;
    }

    /* 4 — Disenable controller (CC.EN = 0) */
    uint32_t cc = ctrl_read32(NVME_CC);
    if (cc & NVME_CC_EN) {
        ctrl_write32(NVME_CC, cc & ~NVME_CC_EN);
        /* Attendi CSTS.RDY = 0 */
        for (uint32_t i = 0; i < 1000000; i++) {
            if (!(ctrl_read32(NVME_CSTS) & NVME_CSTS_RDY))
                break;
            __asm__ __volatile__("pause");
        }
    }

    /* 5 — Allocate Admin Queue */
    if (!alloc_queue(&s_ctrl.admin_q, ADMIN_Q_SIZE, ADMIN_Q_SIZE)) {
        serial_puts("[NVMe] OOM Admin Queue\n");
        return;
    }

    /* 6 — Configura AQA AND ASQ/ACQ */
    uint32_t aqa = (uint32_t)((ADMIN_Q_SIZE - 1) << 16) |
                   (uint32_t)(ADMIN_Q_SIZE - 1);
    ctrl_write32(NVME_AQA, aqa);
    ctrl_write64(NVME_ASQ, s_ctrl.admin_q.sq_phys);
    ctrl_write64(NVME_ACQ, s_ctrl.admin_q.cq_phys);

    /* 7 — Configura AND enable controller */
    cc = NVME_CC_EN          |
         NVME_CC_CSS_NVM     |
         NVME_CC_AMS_RR      |
         NVME_CC_SHN_NONE    |
         NVME_CC_IOSQES      |   /* SQE size = 2^6 = 64 byte */
         NVME_CC_IOCQES      |   /* CQE size = 2^4 = 16 byte */
         (0 << NVME_CC_MPS_SHIFT); /* MPS=0 → page size 4096 */
    ctrl_write32(NVME_CC, cc);

    /* 8 — Attendi CSTS.RDY = 1 */
    for (uint32_t i = 0; i < 2000000; i++) {
        uint32_t csts = ctrl_read32(NVME_CSTS);
        if (csts & NVME_CSTS_CFS) {
            serial_puts("[NVMe] controller fatal status\n");
            return;
        }
        if (csts & NVME_CSTS_RDY) break;
        __asm__ __volatile__("pause");
    }
    if (!(ctrl_read32(NVME_CSTS) & NVME_CSTS_RDY)) {
        serial_puts("[NVMe] timeout attesa RDY\n");
        return;
    }

    /* 9 — Identify Controller (for verify) */
    uint64_t id_phys = pmm_alloc_frame();
    if (!id_phys) { serial_puts("[NVMe] OOM identify\n"); return; }
    nv_memset(phys_to_virt(id_phys), 0, PAGE_SIZE);

    if (identify(0, NVME_ID_CNS_CONTROLLER, id_phys) != EOK) {
        serial_puts("[NVMe] Identify Controller fallito\n");
        pmm_free_frame(id_phys);
        return;
    }

    /* 10 — Allocate I/O Queue */
    if (!alloc_queue(&s_ctrl.io_q, IO_Q_SIZE, IO_Q_SIZE)) {
        serial_puts("[NVMe] OOM I/O Queue\n");
        pmm_free_frame(id_phys);
        return;
    }

    /* 11 — Crea I/O CQ (qid=1) AND I/O SQ (qid=1) via Admin commands */
    if (create_io_cq(1, s_ctrl.io_q.cq_phys, IO_Q_SIZE) != EOK) {
        serial_puts("[NVMe] Create IO CQ fallito\n");
        pmm_free_frame(id_phys);
        return;
    }
    if (create_io_sq(1, s_ctrl.io_q.sq_phys, IO_Q_SIZE, 1) != EOK) {
        serial_puts("[NVMe] Create IO SQ fallito\n");
        pmm_free_frame(id_phys);
        return;
    }

    /* 12 — Allocate DMA data buffer AND PRP list */
    s_io_buf_phys = pmm_alloc_frames(NVME_IO_PAGES);
    if (!s_io_buf_phys) {
        serial_puts("[NVMe] OOM I/O buffer\n");
        pmm_free_frame(id_phys);
        return;
    }

    s_prp_list_phys = pmm_alloc_frame();
    if (!s_prp_list_phys) {
        serial_puts("[NVMe] OOM PRP list\n");
        pmm_free_frame(id_phys);
        return;
    }
    nv_memset(phys_to_virt(s_prp_list_phys), 0, PAGE_SIZE);

    /* 13 — Enumeratete namespace (Identify Namespace for nsid=1…4) */
    nv_memset(&s_ctrl.ns, 0, sizeof(s_ctrl.ns));
    s_ctrl.ns_count = 0;

    /* Node bus "nvme_ctrl0" */
    nv_memset(&s_bus_dev, 0, sizeof(device_t));
    const char *bus_name = "nvme_ctrl0";
    for (uint32_t i = 0; i < sizeof(s_bus_dev.name) - 1 && bus_name[i]; i++)
        s_bus_dev.name[i] = bus_name[i];
    s_bus_dev.type  = DEV_TYPE_BUS;
    s_bus_dev.state = DEV_STATE_ACTIVE;
    device_add(&s_bus_dev, NULL);

    for (uint32_t nsid = 1;
         nsid <= NVME_MAX_NS && s_ctrl.ns_count < NVME_MAX_NS;
         nsid++) {

        nv_memset(phys_to_virt(id_phys), 0, PAGE_SIZE);
        if (identify(nsid, NVME_ID_CNS_NAMESPACE, id_phys) != EOK)
            continue;

        nvme_id_ns_t *id_ns = (nvme_id_ns_t *)phys_to_virt(id_phys);
        if (id_ns->nsze == 0) continue;   /* namespace NOT valid */

        uint32_t ns_idx = s_ctrl.ns_count;
        nvme_ns_t *ns = &s_ctrl.ns[ns_idx];
        ns->valid = true;
        ns->nsid  = nsid;
        ns->sector_count = id_ns->nsze;

        /* Formato LBA active: flbas[3:0] */
        uint8_t  lbaf_idx = id_ns->flbas & 0x0F;
        uint8_t  lbads    = (uint8_t)NVME_LBAF_LBADS(id_ns->lbaf[lbaf_idx]);
        ns->sector_size   = 1u << lbads;  /* 512 (lbads=9) OR 4096 (lbads=12) */

        ns_register_device(ns_idx);
        s_ctrl.ns_count++;
    }

    pmm_free_frame(id_phys);
    s_initialized = true;

    if (s_ctrl.ns_count == 0)
        serial_puts("[NVMe] no namespace findto\n");
    else
        serial_puts("[NVMe] init completato\n");
}

/* =========================================================================
 * nvme_read / nvme_write — API diretta kernel
 * ========================================================================= */

int nvme_read(uint32_t ns_idx, uint64_t lba, uint32_t count, void *buf) {
    if (!s_initialized)                                   return -EIO;
    if (ns_idx >= NVME_MAX_NS || !s_ctrl.ns[ns_idx].valid) return -ENOENT;
    if (!buf || count == 0)                               return -EINVAL;

    nvme_ns_t *ns = &s_ctrl.ns[ns_idx];
    if (lba + count > ns->sector_count)                   return -EINVAL;

    uint8_t *dst = (uint8_t *)buf;
    while (count > 0) {
        uint32_t batch = count < NVME_MAX_SECTORS_PER_CMD
                       ? count : NVME_MAX_SECTORS_PER_CMD;

        uint64_t flags = spinlock_irqsave(&s_ctrl.io_lock);
        int r = do_io_cmd(ns->nsid, lba, (uint16_t)batch,
                          s_io_buf_phys, false);
        if (r == EOK) {
            uint32_t bytes = batch * ns->sector_size;
            nv_memcpy(dst, phys_to_virt(s_io_buf_phys), bytes);
            dst += bytes;
        }
        spinlock_irqrestore(&s_ctrl.io_lock, flags);

        if (r != EOK) return r;
        lba   += batch;
        count -= batch;
    }
    return EOK;
}

int nvme_write(uint32_t ns_idx, uint64_t lba, uint32_t count,
               const void *buf) {
    if (!s_initialized)                                   return -EIO;
    if (ns_idx >= NVME_MAX_NS || !s_ctrl.ns[ns_idx].valid) return -ENOENT;
    if (!buf || count == 0)                               return -EINVAL;

    nvme_ns_t *ns = &s_ctrl.ns[ns_idx];
    if (lba + count > ns->sector_count)                   return -EINVAL;

    const uint8_t *src = (const uint8_t *)buf;
    while (count > 0) {
        uint32_t batch = count < NVME_MAX_SECTORS_PER_CMD
                       ? count : NVME_MAX_SECTORS_PER_CMD;

        uint64_t flags = spinlock_irqsave(&s_ctrl.io_lock);
        uint32_t bytes = batch * ns->sector_size;
        nv_memcpy(phys_to_virt(s_io_buf_phys), src, bytes);
        int r = do_io_cmd(ns->nsid, lba, (uint16_t)batch,
                          s_io_buf_phys, true);
        if (r == EOK) src += bytes;
        spinlock_irqrestore(&s_ctrl.io_lock, flags);

        if (r != EOK) return r;
        lba   += batch;
        count -= batch;
    }
    return EOK;
}
