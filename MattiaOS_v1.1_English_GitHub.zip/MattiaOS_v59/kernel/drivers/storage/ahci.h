#ifndef MATTIAOS_AHCI_H
#define MATTIAOS_AHCI_H

/*
 * kernel/drivers/storage/ahci.h — controller AHCI/SATA
 *
 * Gestisce host controller AHCI (Advanced Host Controller Interface, SATA).
 * Ogni port active is emove as block device /dev/sda, /dev/sdb, ...
 * AND inserita nel device tree below to node bus "ahci0".
 *
 * Standard of riferimento: Serial ATA AHCI 1.3.1 (Intel)
 *
 * Architettura driver:
 *   - Un HBA for system (unico PCI device AHCI found)
 *   - Fino to AHCI_MAX_PORTS ports (massimo 32 for spec AHCI, qui 8)
 *   - Ogni port: 1 command slot in uso (polled, no NCQ)
 *   - Memory DMA: command list + FIS buffer allocateti via PMM
 *   - I/O: polled up PxCI (Command Issue) — no IRQ in Phase 8
 *
 * Dependencies:
 *   driver.h  — device_t, block_ops_t, mmio_read32/write32, spinlock_*
 *   pci.h     — pci_device_t, pci_get_bar, pci_enable_busmaster
 *   slab.h    — kzalloc, kfree
 *   pmm.h     — pmm_alloc_frames (DMA buffers fisicamente contigui)
 *   vmm.h     — phys_to_virt, virt_to_phys
 */

#include "../driver.h"
#include "../pci.h"

/* =========================================================================
 * Costanti HBA — registers globali (offset from the BAR5)
 * ========================================================================= */

#define AHCI_CAP        0x000   /* Host Capabilities                         */
#define AHCI_GHC        0x004   /* Global Host Control                       */
#define AHCI_IS         0x008   /* Interrupt Status (bitmap ports)           */
#define AHCI_PI         0x00C   /* Ports Implemented (bitmap ports presenti) */
#define AHCI_VS         0x010   /* Version                                   */
#define AHCI_CAP2       0x024   /* Host Capabilities Extended                */

/* GHC bits */
#define AHCI_GHC_RESET  (1 << 0)   /* HBA Reset                             */
#define AHCI_GHC_IE     (1 << 1)   /* Interrupt Enable                      */
#define AHCI_GHC_AE     (1 << 31)  /* AHCI Enable                           */

/* CAP bits */
#define AHCI_CAP_NCS_SHIFT  8       /* Number of Command Slots (0-based)     */
#define AHCI_CAP_NCS_MASK   0x1F
#define AHCI_CAP_NP_MASK    0x1F    /* Number of Ports (0-based)             */
#define AHCI_CAP_S64A       (1 << 31) /* 64-bit addressing                   */

/* =========================================================================
 * Costanti HBA — registers for port (offset from the BAR5 + 0x100 + port*0x80)
 * ========================================================================= */

#define AHCI_PORT_BASE(port)  (0x100 + (port) * 0x80)

#define AHCI_PxCLB    0x00   /* Command List Base Address (32-bit)           */
#define AHCI_PxCLBU   0x04   /* Command List Base Address Upper (64-bit)     */
#define AHCI_PxFB     0x08   /* FIS Base Address (32-bit)                    */
#define AHCI_PxFBU    0x0C   /* FIS Base Address Upper (64-bit)              */
#define AHCI_PxIS     0x10   /* Interrupt Status                             */
#define AHCI_PxIE     0x14   /* Interrupt Enable                             */
#define AHCI_PxCMD    0x18   /* Command AND Status                           */
#define AHCI_PxTFD    0x20   /* Task File Data                               */
#define AHCI_PxSIG    0x24   /* Signature                                    */
#define AHCI_PxSSTS   0x28   /* SATA Status (SCR0: SStatus)                  */
#define AHCI_PxSCTL   0x2C   /* SATA Control (SCR2: SControl)                */
#define AHCI_PxSERR   0x30   /* SATA Error (SCR1: SError)                    */
#define AHCI_PxSACT   0x34   /* SATA Active (NCQ)                            */
#define AHCI_PxCI     0x38   /* Command Issue                                */
#define AHCI_PxSNTF   0x3C   /* SATA Notification                            */
#define AHCI_PxFBS    0x40   /* FIS-Based Switching Control                  */

/* PxCMD bits */
#define AHCI_PxCMD_ST   (1 << 0)   /* Start (DMA engine)                    */
#define AHCI_PxCMD_FRE  (1 << 4)   /* FIS Receive Enable                    */
#define AHCI_PxCMD_FR   (1 << 14)  /* FIS Receive Running                   */
#define AHCI_PxCMD_CR   (1 << 15)  /* Command List Running                  */
#define AHCI_PxCMD_POD  (1 << 2)   /* Power On Device                       */
#define AHCI_PxCMD_SUD  (1 << 1)   /* Spin-Up Device                        */
#define AHCI_PxCMD_ICC_ACTIVE (1 << 28) /* Interface Communication Control  */

/* PxSSTS: SStatus interface/device detection */
#define AHCI_SSTS_DET_MASK  0x0F
#define AHCI_SSTS_DET_PRESENT 0x3   /* Device detected, PHY ready           */
#define AHCI_SSTS_IPM_MASK  0xF00
#define AHCI_SSTS_IPM_ACTIVE 0x100  /* Interface in active state            */

/* PxTFD */
#define AHCI_TFD_STS_BSY  (1 << 7)  /* Busy                                 */
#define AHCI_TFD_STS_DRQ  (1 << 3)  /* Data Request                         */
#define AHCI_TFD_STS_ERR  (1 << 0)  /* Error                                */

/* Device signatures */
#define AHCI_SIG_SATA   0x00000101  /* SATA drive                           */
#define AHCI_SIG_SATAPI 0xEB140101  /* SATAPI (ATAPI) drive                 */
#define AHCI_SIG_SEMB   0xC33C0101  /* Enclosure Management Bridge          */
#define AHCI_SIG_PM     0x96690101  /* Port Multiplier                      */

/* =========================================================================
 * Structures DMA — devono essere fisicamente contigue AND allineate
 *
 * Tutto allocateto via PMM (pages fisiche contigue) AND acceduto via HHDM.
 * ========================================================================= */

/*
 * ahci_cmd_header_t — to entry of the Command List (32 byte for entry).
 * 32 entry for port = 1 KB total.
 */
typedef struct {
    /* DW0 */
    uint16_t cfl   : 5;   /* Command FIS Length (in DW)                     */
    uint16_t to     : 1;   /* ATAPI                                          */
    uint16_t w     : 1;   /* Write (1 = host→device)                        */
    uint16_t p     : 1;   /* Prefetchable                                   */
    uint16_t r     : 1;   /* Reset                                          */
    uint16_t b     : 1;   /* BIST                                           */
    uint16_t c     : 1;   /* Clear Busy upon R_OK                           */
    uint16_t rsv0  : 1;
    uint16_t pmp   : 4;   /* Port Multiplier Port                           */
    uint16_t prdtl;       /* Physical Region Descriptor Table Length        */
    /* DW1 */
    volatile uint32_t prdbc; /* PRD Byte Count (filled by HBA)              */
    /* DW2-3 */
    uint32_t ctba;        /* Command Table Base Address (lower 32 bit)      */
    uint32_t ctbau;       /* Command Table Base Address (upper 32 bit)      */
    /* DW4-7 — reserved */
    uint32_t rsv1[4];
} __attribute__((packed)) ahci_cmd_header_t;

/*
 * ahci_prdt_entry_t — Physical Region Descriptor Table entry (16 byte).
 * Each entry describes a buffer physical contiguo for the DMA.
 */
typedef struct {
    uint32_t dba;         /* Data Base Address (lower 32 bit)               */
    uint32_t dbau;        /* Data Base Address (upper 32 bit)               */
    uint32_t rsv;
    uint32_t dbc  : 22;   /* Data Byte Count (0-based, max 4 MB - 1)        */
    uint32_t rsv2 :  9;
    uint32_t i      :  1;   /* Interrupt on Completion                        */
} __attribute__((packed)) ahci_prdt_entry_t;

/*
 * ahci_cmd_table_t — Command Table (for command slot).
 * Contiene the Command FIS, ATAPI command, AND the PRDT.
 * Size: 128 + 64 + PRDT_SIZE * 16 byte.
 * Allineata to 128 byte second spec AHCI.
 */
#define AHCI_PRDT_ENTRIES  8   /* max 8 PRDT entry for comando (128 KB max) */

typedef struct {
    uint8_t           cfis[64];              /* Command FIS (H2D Register)  */
    uint8_t           acmd[16];              /* ATAPI Command (NOT usato)   */
    uint8_t           rsv[48];               /* Reserved                    */
    ahci_prdt_entry_t prdt[AHCI_PRDT_ENTRIES]; /* PRDT entries             */
} __attribute__((packed)) ahci_cmd_table_t;

/* =========================================================================
 * FIS types — Frame Information Structure
 * ========================================================================= */

#define FIS_TYPE_REG_H2D   0x27   /* Register FIS — Host to Device          */
#define FIS_TYPE_REG_D2H   0x34   /* Register FIS — Device to Host          */
#define FIS_TYPE_DMA_ACT   0x39
#define FIS_TYPE_DMA_SETUP 0x41
#define FIS_TYPE_DATA      0x46
#define FIS_TYPE_BIST      0x58
#define FIS_TYPE_PIO_SETUP 0x5F
#define FIS_TYPE_DEV_BITS  0xA1

/*
 * fis_reg_h2d_t — Register FIS (Host to Device): usato for ATA comandi.
 */
typedef struct {
    uint8_t  fis_type;   /* FIS_TYPE_REG_H2D                               */
    uint8_t  pmport : 4; /* Port Multiplier Port                           */
    uint8_t  rsv0   : 3;
    uint8_t  c      : 1; /* 1 = Command, 0 = Control                       */
    uint8_t  command;    /* ATA Command Register                           */
    uint8_t  featurel;   /* Features (low byte)                            */
    uint8_t  lba0;       /* LBA[7:0]                                       */
    uint8_t  lba1;       /* LBA[15:8]                                      */
    uint8_t  lba2;       /* LBA[23:16]                                     */
    uint8_t  device;     /* Device register (LBA/CHS, DEV bit)             */
    uint8_t  lba3;       /* LBA[31:24]                                     */
    uint8_t  lba4;       /* LBA[39:32]                                     */
    uint8_t  lba5;       /* LBA[47:40]                                     */
    uint8_t  featureh;   /* Features (high byte)                           */
    uint8_t  countl;     /* Sector count (low byte)                        */
    uint8_t  counth;     /* Sector count (high byte)                       */
    uint8_t  icc;        /* Isochronous Command Completion                 */
    uint8_t  control;    /* Control register                               */
    uint8_t  rsv1[4];
} __attribute__((packed)) fis_reg_h2d_t;

/* ATA commands */
#define ATA_CMD_READ_DMA_EXT    0x25   /* Read DMA Extended (48-bit LBA)    */
#define ATA_CMD_WRITE_DMA_EXT   0x35   /* Write DMA Extended (48-bit LBA)   */
#define ATA_CMD_FLUSH_CACHE_EXT 0xEA   /* Flush Write Cache Extended        */
#define ATA_CMD_IDENTIFY        0xEC   /* Identify Device                   */

/* ATA device register */
#define ATA_DEV_LBA   (1 << 6)         /* LBA mode                          */

/* ATA status bits */
#define ATA_STS_ERR   (1 << 0)
#define ATA_STS_DRQ   (1 << 3)
#define ATA_STS_DF    (1 << 5)
#define ATA_STS_DRDY  (1 << 6)
#define ATA_STS_BSY   (1 << 7)

/* =========================================================================
 * Structure of stato for port AHCI
 * ========================================================================= */

#define AHCI_MAX_PORTS   8   /* massimo ports gestite (spec: 32)             */

typedef struct {
    bool     present;         /* port with drive SATA rilevato               */
    uint64_t hba_port_phys;   /* address physical of the reg of port (BAR5)    */

    /* DMA buffers — allocateti via PMM, acceduti via HHDM */
    uint64_t  cmd_list_phys;  /* command list (32 * 32 = 1 KB)              */
    uint64_t  fis_buf_phys;   /* received FIS buffer (256 B)                */
    uint64_t  cmd_table_phys; /* command table (slot 0, 256 B)              */
    uint64_t  data_buf_phys;  /* DMA data buffer (128 KB = 32 pages)       */

    /* Geometria drive */
    uint64_t  sector_count;   /* total sectors (LBA48)                     */
    uint32_t  sector_size;    /* bytes for sector (512 OR 4096)             */

    spinlock_t lock;          /* protegge operations DMA                   */
} ahci_port_t;

/* =========================================================================
 * Structure of stato HBA (to for controller)
 * ========================================================================= */

typedef struct {
    uint64_t   hba_phys;           /* BAR5 — address physical base HBA      */
    uint32_t   num_ports;          /* number ports implementate              */
    uint32_t   num_cmd_slots;      /* number command slot for port         */
    bool       cap_64bit;          /* controller support 64-bit DMA        */
    ahci_port_t ports[AHCI_MAX_PORTS];
} ahci_hba_t;

/* =========================================================================
 * Ioctl commands for /dev/sdX
 * ========================================================================= */

#define AHCI_IOCTL_GET_SECTORS   0xA001  /* arg → uint64_t* (out) */
#define AHCI_IOCTL_GET_SECT_SIZE 0xA002  /* arg → uint32_t* (out) */
#define AHCI_IOCTL_FLUSH         0xA003  /* flush write cache      */

/* =========================================================================
 * API pubblica
 * ========================================================================= */

/*
 * ahci_init — scansiona the bus PCI, initialise l'HBA AND all the drive SATA.
 * Register every drive as /dev/sda, /dev/sdb, ... in devfs.
 * Chiamata from drivers_init() after pci_enumerate().
 * Debole (__weak in irq.c): sovrascritta from this implementazione.
 */
void ahci_init(void);

/*
 * ahci_read / ahci_write — read/write diretta from kernel
 * (usata also from fs layer before that the VFS sia completely up).
 * port_idx: indice port (0-based).
 * Returns EOK or negative error negative.
 */
int ahci_read (uint32_t port_idx, uint64_t lba, uint32_t count, void *buf);
int ahci_write(uint32_t port_idx, uint64_t lba, uint32_t count, const void *buf);

#endif /* MATTIAOS_AHCI_H */
