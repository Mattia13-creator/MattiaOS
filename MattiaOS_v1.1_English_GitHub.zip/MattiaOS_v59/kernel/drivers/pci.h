#ifndef MATTIAOS_PCI_H
#define MATTIAOS_PCI_H

#include "../include/types.h"
#include "../include/errno.h"

/* PCI configuration space access via legacy I/O ports 0xCF8/0xCFC */

#define PCI_ADDR_PORT   0xCF8
#define PCI_DATA_PORT   0xCFC

/* Config space register offsets (header type 0) */
#define PCI_VENDOR_ID        0x00
#define PCI_DEVICE_ID        0x02
#define PCI_COMMAND          0x04
#define PCI_STATUS           0x06
#define PCI_REVISION_ID      0x08
#define PCI_PROG_IF          0x09
#define PCI_SUBCLASS         0x0A
#define PCI_CLASS            0x0B
#define PCI_HEADER_TYPE      0x0E
#define PCI_BAR0             0x10
#define PCI_BAR1             0x14
#define PCI_BAR2             0x18
#define PCI_BAR3             0x1C
#define PCI_BAR4             0x20
#define PCI_BAR5             0x24
#define PCI_INTERRUPT_LINE   0x3C
#define PCI_INTERRUPT_PIN    0x3D

/* PCI_COMMAND bits */
#define PCI_CMD_IO_SPACE    (1 << 0)
#define PCI_CMD_MEM_SPACE   (1 << 1)
#define PCI_CMD_BUS_MASTER  (1 << 2)
#define PCI_CMD_INT_DISABLE (1 << 10)

/* Class queuess */
#define PCI_CLASS_STORAGE      0x01
#define PCI_SUBCLASS_AHCI      0x06
#define PCI_SUBCLASS_NVME      0x08
#define PCI_CLASS_NETWORK      0x02
#define PCI_SUBCLASS_ETHERNET  0x00

/* Vendor / Device IDs */
#define PCI_VENDOR_INTEL          0x8086
#define PCI_VENDOR_VIRTIO         0x1AF4
#define PCI_DEV_E1000_82540EM     0x100E
#define PCI_DEV_E1000_82545EM     0x100F
#define PCI_DEV_E1000_82574L      0x10D3
#define PCI_DEV_E1000_I217LM      0x153A
#define PCI_DEV_VIRTIO_NET_LEGACY 0x1000
#define PCI_DEV_VIRTIO_NET_MODERN 0x1041

#define PCI_VENDOR_NONE  0xFFFF
#define PCI_MAX_DEVICES  256

/*
 * pci_device_t — lightweight PCI device descriptor populated during
 * pci_enumerate().  Drivers search this flat list to locate their hardware.
 */
typedef struct {
    uint8_t  bus;
    uint8_t  dev;
    uint8_t  func;
    uint16_t vendor_id;
    uint16_t device_id;
    uint8_t  class_code;
    uint8_t  subclass;
    uint8_t  prog_if;
    uint8_t  header_type;
    uint8_t  irq_line;
} pci_device_t;

extern pci_device_t g_pci_devices[PCI_MAX_DEVICES];
extern uint32_t     g_pci_device_count;

/* Low-level config space access */
uint32_t pci_read32 (uint8_t bus, uint8_t dev, uint8_t func, uint8_t offset);
uint16_t pci_read16 (uint8_t bus, uint8_t dev, uint8_t func, uint8_t offset);
uint8_t  pci_read8  (uint8_t bus, uint8_t dev, uint8_t func, uint8_t offset);
void     pci_write32(uint8_t bus, uint8_t dev, uint8_t func, uint8_t offset, uint32_t val);
void     pci_write16(uint8_t bus, uint8_t dev, uint8_t func, uint8_t offset, uint16_t val);

/* BAR helpers */
uint64_t pci_get_bar     (uint8_t bus, uint8_t dev, uint8_t func, uint8_t bar_index);
bool     pci_bar_is_mmio (uint8_t bus, uint8_t dev, uint8_t func, uint8_t bar_index);
bool     pci_bar_is_64bit(uint8_t bus, uint8_t dev, uint8_t func, uint8_t bar_index);
uint64_t pci_bar_size    (uint8_t bus, uint8_t dev, uint8_t func, uint8_t bar_index);

/* Device control */
void pci_enable_busmaster  (uint8_t bus, uint8_t dev, uint8_t func);
void pci_enable_mmio       (uint8_t bus, uint8_t dev, uint8_t func);
void pci_disable_interrupts(uint8_t bus, uint8_t dev, uint8_t func);

/*
 * Enumeratetion — must be called once before any driver init.
 * Fills g_pci_devices[] AND sets g_pci_device_count.
 */
void          pci_enumerate     (void);
pci_device_t *pci_find_device   (uint8_t class_code, uint8_t subclass);
pci_device_t *pci_find_device_by_id(uint16_t vendor_id, uint16_t device_id);
pci_device_t *pci_find_device_any_id(uint16_t vendor_id,
                                     const uint16_t *device_ids,
                                     uint32_t count);

#endif /* MATTIAOS_PCI_H */
