#include <limine.h>
#include "fb.h"
#include "../../fs/devfs.h"
#include "../../mm/slab.h"
#include "../../include/errno.h"

/*
 * fb.c — driver framebuffer GOP for MattiaOS
 *
 * Il bootloader Limine fornisce gia' the framebuffer with address virtual
 * HHDM-mapto; NOT AND' richiesta none traduzione phys→virt to runtime.
 *
 * Structure interna:
 *   s_fb        — stato of the driver (to sola istanza: to only framebuffer)
 *   s_fb_lock   — spinlock that protegge the fields of s_fb
 *   s_dev_node  — devnode_t registerto in devfs → /dev/fb0
 *   s_dev       — device_t nel device tree
 *
 * Operazioni VFS up /dev/fb0:
 *   read()      — copy the pixel from the framebuffer nel buffer utente (offset = byte offset)
 *   write()     — copy the pixel from the buffer utente nel framebuffer
 *   ioctl()     — GET_INFO, FILL_RECT, BLIT, CLEAR
 *
 * Thread safety:
 *   write_pixel AND fill_rect usano spinlock_irqsave for garantire
 *   l'assenza of race up operations concorrenti to the framebuffer.
 *   Il lock NON copre l'intera operation blit (potrebbe essere lunga):
 *   the singole scritture of riga are atomiche to livello of word.
 */

/* =========================================================================
 * Stato driver — file-scope
 * ========================================================================= */

/* fb_state_t — stato internal of the driver framebuffer */
typedef struct {
    volatile uint32_t *addr;   /* address virtual HHDM of the framebuffer */
    uint32_t           width;  /* pixel                                   */
    uint32_t           height; /* pixel                                   */
    uint32_t           pitch;  /* byte for scanline                       */
    uint16_t           bpp;    /* bit for pixel (sempre 32)               */
    bool               ready;  /* true after fb_init() completato          */
} fb_state_t;

static fb_state_t  s_fb       = {0};
static spinlock_t  s_fb_lock  = {0};

/* devnode static for /dev/fb0 — valid for tutta the vita of the kernel */
static devnode_t   s_dev_node = {0};

/* device_t nel device tree */
static device_t    s_dev      = {0};

/* =========================================================================
 * Helper interni
 * ========================================================================= */

/*
 * fb_row_ptr — returns the pointer to the riga y of the framebuffer.
 * pitch AND' in byte, ma the framebuffer AND' uint32_t* → divido for 4.
 */
static inline volatile uint32_t *fb_row_ptr(uint32_t y) {
    return s_fb.addr + (uint64_t)y * (s_fb.pitch / 4);
}

/*
 * fb_memset32 — riempie n word from dst with val (equivalente of memset for uint32_t).
 * Non usa libc for NOT creare dependencies circolari before of the libc.
 */
static void fb_memset32(volatile uint32_t *dst, uint32_t val, uint32_t n) {
    for (uint32_t i = 0; i < n; i++)
        dst[i] = val;
}

/*
 * fb_memcpy32 — copy n word from src to dst.
 */
static void fb_memcpy32(volatile uint32_t *dst, const uint32_t *src, uint32_t n) {
    for (uint32_t i = 0; i < n; i++)
        dst[i] = src[i];
}

/* =========================================================================
 * Operazioni VFS for /dev/fb0
 *
 * I parametri vnode_t* are ignorati: the stato AND' in s_fb (singleton).
 * ========================================================================= */

static int fb_vfs_open(vnode_t *node, int flags) {
    (void)node; (void)flags;
    if (!s_fb.ready) return -ENOENT;
    return EOK;
}

static int fb_vfs_close(vnode_t *node) {
    (void)node;
    return EOK;
}

/*
 * fb_vfs_read — copy byte from the framebuffer nel buffer utente.
 * offset: byte offset nel framebuffer lineare.
 * Returns the number of byte copyti OR error negative.
 */
static ssize_t fb_vfs_read(vnode_t *node, void *buf, size_t count, off_t offset) {
    (void)node;
    if (!s_fb.ready) return -ENOENT;
    if (!buf)        return -EINVAL;

    uint64_t fb_size = (uint64_t)s_fb.pitch * s_fb.height;
    if ((uint64_t)offset >= fb_size) return 0; /* EOF */

    /* Clip count to the confine of the framebuffer */
    uint64_t avail = fb_size - (uint64_t)offset;
    if ((uint64_t)count > avail) count = (size_t)avail;

    /*
     * Il framebuffer AND' volatile uint32_t*; copymo byte for byte
     * via to cast to uint8_t* for gestire offset NOT allineati.
     */
    const uint8_t *src  = (const uint8_t *)s_fb.addr + offset;
    uint8_t       *dst  = (uint8_t *)buf;
    for (size_t i = 0; i < count; i++)
        dst[i] = src[i];

    return (ssize_t)count;
}

/*
 * fb_vfs_write — copy byte from the buffer utente nel framebuffer.
 * offset: byte offset nel framebuffer lineare.
 */
static ssize_t fb_vfs_write(vnode_t *node, const void *buf, size_t count,
                            off_t offset) {
    (void)node;
    if (!s_fb.ready) return -ENOENT;
    if (!buf)        return -EINVAL;

    uint64_t fb_size = (uint64_t)s_fb.pitch * s_fb.height;
    if ((uint64_t)offset >= fb_size) return 0;

    uint64_t avail = fb_size - (uint64_t)offset;
    if ((uint64_t)count > avail) count = (size_t)avail;

    const uint8_t    *src  = (const uint8_t *)buf;
    volatile uint8_t *dst  = (volatile uint8_t *)s_fb.addr + offset;
    for (size_t i = 0; i < count; i++)
        dst[i] = src[i];

    return (ssize_t)count;
}

/*
 * fb_vfs_ioctl — comandi specifici of the framebuffer.
 * request: FB_IOCTL_* (from fb.h)
 * arg:     pointer to the structure argomento (vedi fb.h)
 */
static int fb_vfs_ioctl(vnode_t *node, uint64_t request, void *arg) {
    (void)node;
    if (!s_fb.ready) return -ENOENT;

    switch (request) {

    case FB_IOCTL_GET_INFO: {
        if (!arg) return -EINVAL;
        fb_info_t *info = (fb_info_t *)arg;
        info->addr     = (uint64_t)s_fb.addr;
        info->width    = s_fb.width;
        info->height   = s_fb.height;
        info->pitch    = s_fb.pitch;
        info->bpp      = s_fb.bpp;
        info->reserved = 0;
        return EOK;
    }

    case FB_IOCTL_FILL_RECT: {
        if (!arg) return -EINVAL;
        const fb_fillrect_t *r = (const fb_fillrect_t *)arg;
        fb_fill_rect(r->x, r->y, r->w, r->h, r->color);
        return EOK;
    }

    case FB_IOCTL_BLIT: {
        if (!arg) return -EINVAL;
        const fb_blit_t *b = (const fb_blit_t *)arg;
        fb_blit(b->x, b->y, b->w, b->h, (const uint32_t *)b->src);
        return EOK;
    }

    case FB_IOCTL_CLEAR: {
        /* arg is interpretato as uint32_t color for value */
        fb_clear((uint32_t)(uint64_t)arg);
        return EOK;
    }

    default:
        return -EINVAL;
    }
}

/* Table operations VFS for /dev/fb0 */
static vfs_ops_t s_fb_vfs_ops = {
    .open    = fb_vfs_open,
    .close   = fb_vfs_close,
    .read    = fb_vfs_read,
    .write   = fb_vfs_write,
    .ioctl   = fb_vfs_ioctl,
    .readdir = NULL,
    .stat    = NULL,
    .create  = NULL,
    .mkdir   = NULL,
    .unlink  = NULL,
    .mmap    = NULL,
};

/* =========================================================================
 * API pubblica
 * ========================================================================= */

/*
 * fb_write_pixel — writes to singolo pixel with protezione spinlock.
 * I pixel outside from the bordi are ignorati silenziosamente.
 */
void fb_write_pixel(uint32_t x, uint32_t y, uint32_t color) {
    if (!s_fb.ready || x >= s_fb.width || y >= s_fb.height) return;

    uint64_t flags = spinlock_irqsave(&s_fb_lock);
    fb_row_ptr(y)[x] = color;
    spinlock_irqrestore(&s_fb_lock, flags);
}

/*
 * fb_fill_rect — riempie to rettangolo with colore uniforme.
 * Clip automatic: the porzioni outside screen vengono ignorate.
 */
void fb_fill_rect(uint32_t x, uint32_t y, uint32_t w, uint32_t h,
                  uint32_t color) {
    if (!s_fb.ready || w == 0 || h == 0) return;

    /* Clip x */
    if (x >= s_fb.width) return;
    if (x + w > s_fb.width)  w = s_fb.width  - x;

    /* Clip y */
    if (y >= s_fb.height) return;
    if (y + h > s_fb.height) h = s_fb.height - y;

    uint64_t flags = spinlock_irqsave(&s_fb_lock);
    for (uint32_t row = y; row < y + h; row++)
        fb_memset32(fb_row_ptr(row) + x, color, w);
    spinlock_irqrestore(&s_fb_lock, flags);
}

/*
 * fb_clear — riempie l'intero screen with color.
 * Piu' efficiente of fb_fill_rect(0, 0, w, h, color) perche' NOT fa clip.
 */
void fb_clear(uint32_t color) {
    if (!s_fb.ready) return;

    uint64_t flags = spinlock_irqsave(&s_fb_lock);
    for (uint32_t row = 0; row < s_fb.height; row++)
        fb_memset32(fb_row_ptr(row), color, s_fb.width);
    spinlock_irqrestore(&s_fb_lock, flags);
}

/*
 * fb_blit — copy to pixel buffer contiguo sullo screen.
 * src: array of w*h uint32_t, riga for riga without gap (stride = w).
 * Clip automatic to the bordi of the framebuffer.
 */
void fb_blit(uint32_t x, uint32_t y, uint32_t w, uint32_t h,
             const uint32_t *src) {
    if (!s_fb.ready || !src || w == 0 || h == 0) return;

    /* Clip orizzontale */
    uint32_t src_x_offset = 0;
    uint32_t blit_w = w;
    if (x >= s_fb.width) return;
    if (x + blit_w > s_fb.width) blit_w = s_fb.width - x;

    /* Clip verticale */
    uint32_t src_y_offset = 0;
    uint32_t blit_h = h;
    if (y >= s_fb.height) return;
    if (y + blit_h > s_fb.height) blit_h = s_fb.height - y;

    /*
     * No lock sull'intera operation blit (potrebbe essere molto lunga:
     * ~3.7 MB for 1280x720x32).  Le singole righe are copyte atomicamente.
     * Il compositor userspace AND' responsabile of the sincronizzazione
     * to livello applicativo (doppio buffer / vsync).
     */
    for (uint32_t row = 0; row < blit_h; row++) {
        const uint32_t *src_row = src + (src_y_offset + row) * w + src_x_offset;
        fb_memcpy32(fb_row_ptr(y + row) + x, src_row, blit_w);
    }
}

/*
 * fb_get_info — copy the informazioni sul framebuffer in *out.
 */
int fb_get_info(fb_info_t *out) {
    if (!out)          return -EINVAL;
    if (!s_fb.ready)   return -ENOENT;

    out->addr     = (uint64_t)s_fb.addr;
    out->width    = s_fb.width;
    out->height   = s_fb.height;
    out->pitch    = s_fb.pitch;
    out->bpp      = s_fb.bpp;
    out->reserved = 0;
    return EOK;
}

/*
 * fb_is_ready — returns true if the driver AND' initialised.
 */
bool fb_is_ready(void) {
    return s_fb.ready;
}

/* =========================================================================
 * fb_init — entry point of the driver (chiamato from drivers_init in irq.c)
 *
 * Sequence:
 *   1. Verify the rimove Limine (fb_request.response != NULL)
 *   2. Seleziona the first framebuffer available
 *   3. Popola s_fb with address, sizes, pitch, bpp
 *   4. Zero the framebuffer (screen nero all'boot)
 *   5. Allocate AND register /dev/fb0 in devfs
 *   6. Inserisce s_dev nel device tree
 * ========================================================================= */

/* fb_request AND' definito in entry.c (NOT piu' static) */
extern volatile struct limine_framebuffer_request fb_request;

void fb_init(void) {
    /* 1 — Verify rimove Limine */
    if (!fb_request.response ||
        fb_request.response->framebuffer_count == 0) {
        /* No framebuffer available — continua without /dev/fb0 */
        return;
    }

    struct limine_framebuffer *fb = fb_request.response->framebuffers[0];
    if (!fb || !fb->address) return;

    /* 2/3 — Popola the stato internal */
    s_fb.addr   = (volatile uint32_t *)fb->address;
    s_fb.width  = (uint32_t)fb->width;
    s_fb.height = (uint32_t)fb->height;
    s_fb.pitch  = (uint32_t)fb->pitch;
    s_fb.bpp    = fb->bpp;
    s_fb.ready  = true;

    /* 4 — Screen nero all'boot */
    fb_clear(0x00000000);

    /* 5 — Register /dev/fb0 in devfs */
    /* name */
    const char *name = "fb0";
    uint32_t i = 0;
    while (name[i] && i < sizeof(s_dev_node.name) - 1) {
        s_dev_node.name[i] = name[i]; i++;
    }
    s_dev_node.name[i]        = '\0';
    s_dev_node.type           = DEV_TYPE_CHAR;
    s_dev_node.ops            = &s_fb_vfs_ops;
    s_dev_node.driver_data    = &s_fb;

    devfs_register(&s_dev_node);

    /* 6 — device_t nel device tree */
    const char *dname = "fb0";
    i = 0;
    while (dname[i] && i < sizeof(s_dev.name) - 1) {
        s_dev.name[i] = dname[i]; i++;
    }
    s_dev.name[i]      = '\0';
    s_dev.type         = DEV_TYPE_CHAR;
    s_dev.state        = DEV_STATE_ACTIVE;
    s_dev.driver_data  = &s_fb;

    /* char_ops mapte dall'API pubblica */
    static char_ops_t s_char_ops = {
        .open  = NULL,
        .close = NULL,
        .read  = NULL,   /* accesso via vfs_ops; char_ops usate from futuri layer */
        .write = NULL,
        .ioctl = NULL,
    };
    s_dev.char_ops = &s_char_ops;

    device_add(&s_dev, NULL);   /* child of the root of the device tree */
}
