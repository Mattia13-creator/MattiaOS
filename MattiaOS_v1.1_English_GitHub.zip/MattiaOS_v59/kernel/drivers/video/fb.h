#ifndef MATTIAOS_FB_H
#define MATTIAOS_FB_H

/*
 * kernel/drivers/video/fb.h — framebuffer GOP driver
 *
 * Il framebuffer AND' fornito from Limine to the boot via GOP (Graphics Output
 * Protocol) UEFI.  Questo driver the espone as character device /dev/fb0.
 *
 * Formato colore: uint32_t = 0x00RRGGBB  (alpha ignorato, bpp = 32)
 * Resolution:    1280 x 720 (configurata in boot/limine.cfg)
 * Pitch:          >= width * 4 bytes (aligned from firmware)
 *
 * Principi rispettati:
 *   Principio 3 — accesso diretto to the framebuffer physical via HHDM;
 *                 none astrazione software tra the driver AND the firmware.
 *   Principio 4 — this driver NOT sa nulla of GUI.
 *                 Espone only pixel grezzi; the composizione vive in userspace.
 *
 * Dependencies:
 *   driver.h   — device_t, dev_type_t, spinlock_*
 *   devfs.h    — devnode_t, devfs_register
 *   types.h    — types primitivi
 */

#include "../driver.h"

/* =========================================================================
 * Costanti
 * ========================================================================= */

/*
 * Ioctl commands for /dev/fb0.
 * Sendti from userspace via ioctl(fd, FB_IOCTL_*, &arg).
 */
#define FB_IOCTL_GET_INFO    0xFB00   /* arg → fb_info_t * (out) */
#define FB_IOCTL_FILL_RECT   0xFB01   /* arg → fb_fillrect_t * (in) */
#define FB_IOCTL_BLIT        0xFB02   /* arg → fb_blit_t *     (in) */
#define FB_IOCTL_CLEAR       0xFB03   /* arg = color (uint32_t), screen intero */

/* =========================================================================
 * Structures data pubbliche
 *
 * Usate sia internamente (fb.c) sia from the syscall ioctl in userspace.
 * Devono avere layout fixed: no padding implicito tra the fields.
 * ========================================================================= */

/*
 * fb_info_t — informazioni sul framebuffer physical.
 * Restituita from FB_IOCTL_GET_INFO.
 */
typedef struct {
    uint64_t addr;       /* address virtual HHDM of the buffer (for mmap) */
    uint32_t width;      /* width in pixel                            */
    uint32_t height;     /* height in pixel                              */
    uint32_t pitch;      /* byte for scanline (>= width * bpp/8)          */
    uint16_t bpp;        /* bit for pixel — sempre 32 up MattiaOS         */
    uint16_t reserved;   /* padding — deve essere 0                       */
} __attribute__((packed)) fb_info_t;

/*
 * fb_fillrect_t — argomento for FB_IOCTL_FILL_RECT.
 * Riempie the rettangolo [x, x+w) x [y, y+h) with color (0x00RRGGBB).
 */
typedef struct {
    uint32_t x, y;       /* angolo top-left in pixel */
    uint32_t w, h;       /* width AND height      */
    uint32_t color;      /* 0x00RRGGBB               */
} __attribute__((packed)) fb_fillrect_t;

/*
 * fb_blit_t — argomento for FB_IOCTL_BLIT.
 * Copy src (buffer ARGB contiguo, w*h pixel) sullo screen to (x, y).
 * src deve essere to address virtual userspace valid.
 */
typedef struct {
    uint32_t  x, y;      /* destination sullo screen          */
    uint32_t  w, h;      /* sizes of the buffer source      */
    uint64_t  src;       /* address virtual of the pixel buffer */
} __attribute__((packed)) fb_blit_t;

/* =========================================================================
 * API pubblica of the driver
 *
 * Chiamate from altri moduli kernel (es. early output before that /dev esista).
 * Tutte the cosortte are in pixel (0-based, origin top-left).
 * ========================================================================= */

/*
 * fb_init — initialise the driver framebuffer.
 *   Read the rimove Limine, popola the stato internal, register /dev/fb0.
 *   Deve essere chiamata after slab_init() AND devfs_mount().
 *   Firma void/void for compatibilita' with irq.c (extern void fb_init(void)).
 */
void fb_init(void);

/*
 * fb_write_pixel — writes to singolo pixel.
 *   x, y:  cosortte (0-based); ignorati if outside screen.
 *   color: 0x00RRGGBB.
 */
void fb_write_pixel(uint32_t x, uint32_t y, uint32_t color);

/*
 * fb_fill_rect — riempie to rettangolo with colore uniforme.
 *   Clip automatic to the bordi of the framebuffer.
 */
void fb_fill_rect(uint32_t x, uint32_t y, uint32_t w, uint32_t h,
                  uint32_t color);

/*
 * fb_clear — riempie l'intero screen with color.
 */
void fb_clear(uint32_t color);

/*
 * fb_blit — copy to buffer of pixel (w*h uint32_t, 0x00RRGGBB) sullo screen.
 *   src:  pointer to the buffer source contiguo (riga for riga, without gap).
 *   Clip automatic: the pixel outside dallo screen vengono ignorati.
 */
void fb_blit(uint32_t x, uint32_t y, uint32_t w, uint32_t h,
             const uint32_t *src);

/*
 * fb_get_info — popola *out with the informazioni sul framebuffer current.
 *   Returns EOK, OR EINVAL if the framebuffer NOT AND' ancora initialised.
 */
int fb_get_info(fb_info_t *out);

/*
 * fb_is_ready — returns true if fb_init() AND' stato completato with successo.
 */
bool fb_is_ready(void);

#endif /* MATTIAOS_FB_H */
