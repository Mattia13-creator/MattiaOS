#ifndef MATTIAOS_ICMP_H
#define MATTIAOS_ICMP_H

/*
 * icmp.h — Internet Control Message Protocol (RFC 792)
 *
 * Implementa:
 *   - Echo Request (type 8) → Echo Reply (type 0)
 *   - Destination Unreachable (type 3) for errors TCP/UDP
 */

#include "../include/types.h"
#include "ipv4.h"

/* =========================================================================
 * Costanti ICMP
 * ========================================================================= */
#define ICMP_TYPE_ECHO_REPLY    0u
#define ICMP_TYPE_UNREACHABLE   3u
#define ICMP_TYPE_ECHO_REQUEST  8u

/* Codici for Destination Unreachable (type 3) */
#define ICMP_CODE_NET_UNREACH   0u
#define ICMP_CODE_HOST_UNREACH  1u
#define ICMP_CODE_PORT_UNREACH  3u
#define ICMP_CODE_FRAG_NEEDED   4u

/* =========================================================================
 * Header ICMP on-wire
 * ========================================================================= */
typedef struct __attribute__((packed)) {
    uint8_t  type;
    uint8_t  queues;
    uint16_t checksum;    /* big-endian */
    uint16_t id;          /* big-endian — usato from echo */
    uint16_t seq;         /* big-endian — usato from echo */
} icmp_hdr_t;

#define ICMP_HDR_SIZE  sizeof(icmp_hdr_t)   /* 8 byte */

/* Header ICMP Unreachable: 4 byte unused + 8 byte IP+8 byte originali */
typedef struct __attribute__((packed)) {
    uint8_t  type;
    uint8_t  queues;
    uint16_t checksum;
    uint32_t unused;      /* 0 for all the codici tranne FRAG_NEEDED */
    /* Seguono: IP header originale + 8 byte of the datagramma originale */
} icmp_unreach_hdr_t;

/* =========================================================================
 * API pubblica
 * ========================================================================= */

/*
 * icmp_handle — processa to messaggio ICMP received.
 * @src_ip: IPv4 mittente (host byte order).
 * @data:   payload ICMP (after l'header IP).
 * @len:    length in byte.
 */
void icmp_handle(uint32_t src_ip, const void *data, uint16_t len);

/*
 * icmp_send_unreachable — send Destination Unreachable to the mittente.
 * @dst_ip:    IPv4 destination of the messaggio (= src of the pacchetto originale).
 * @queues:      ICMP_CODE_* (es. ICMP_CODE_PORT_UNREACH).
 * @orig_hdr:  pointer all'header IP originale (from includere nel payload).
 * @orig_len:  length: sizeof(ipv4_hdr_t) + 8 byte (standard RFC 792).
 */
void icmp_send_unreachable(uint32_t dst_ip, uint8_t queues,
                           const void *orig_hdr, uint16_t orig_len);

#endif /* MATTIAOS_ICMP_H */
