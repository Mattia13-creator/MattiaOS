#include "ethernet.h"
#include "arp.h"
#include "ipv4.h"
#include "../include/errno.h"
#include "../arch/x86_64/cpu.h"

/* =========================================================================
 * Stato internal
 * ========================================================================= */
static net_nic_t  s_nics[NET_MAX_NICS];
static int        s_nic_count = 0;
static spinlock_t s_nic_lock  __attribute__((unused)) = {0};

/* =========================================================================
 * Helper no-libc
 * ========================================================================= */
static inline void eth_memcpy(void *d, const void *s, size_t n) {
    uint8_t *dd = (uint8_t *)d;
    const uint8_t *ss = (const uint8_t *)s;
    for (size_t i = 0; i < n; i++) dd[i] = ss[i];
}
static inline void eth_memset(void *d, int v, size_t n) {
    uint8_t *dd = (uint8_t *)d;
    for (size_t i = 0; i < n; i++) dd[i] = (uint8_t)v;
}

/* =========================================================================
 * rx_callback installato up every NIC
 * ========================================================================= */
static void eth_rx_cb(device_t *dev, const void *data, uint16_t len) {
    ethernet_rx(dev, data, len);
}

/* =========================================================================
 * ethernet_init
 * ========================================================================= */
void ethernet_init(void) {
    eth_memset(s_nics, 0, sizeof(s_nics));
    s_nic_count = 0;

    device_t *d = g_device_root;
    while (d && s_nic_count < NET_MAX_NICS) {
        if (d->type  == DEV_TYPE_NET &&
            d->net_ops != NULL &&
            d->state  == DEV_STATE_ACTIVE) {

            net_nic_t *nic = &s_nics[s_nic_count++];
            nic->dev    = d;
            nic->active = true;

            /* Read MAC hardware */
            d->net_ops->get_mac(d, nic->mac);

            /* Installa rx callback — the driver the chiama from IRQ */
            d->net_ops->rx_callback = eth_rx_cb;

            serial_puts("[ETH] NIC: ");
            serial_puts(d->name);
            serial_puts("\n");
        }
        d = d->next;
    }

    serial_puts("[ETH] Initialiseto, NIC=");
    serial_putchar('0' + s_nic_count);
    serial_puts("\n");
}

/* =========================================================================
 * ethernet_send
 * ========================================================================= */
int ethernet_send(net_nic_t *nic, const uint8_t *dst_mac, uint16_t ethertype,
                  const void *payload, uint16_t payload_len) {
    if (!dst_mac || !payload)              return EINVAL;
    if (payload_len > ETH_MAX_PAYLOAD)    return EINVAL;

    /* Usa NIC primaria if nic == NULL */
    if (!nic) {
        if (s_nic_count == 0) return EIO;
        nic = &s_nics[0];
    }
    if (!nic->active || !nic->dev || !nic->dev->net_ops) return EIO;

    /* Build frame up stack (ETH_MAX_FRAME = 1514 byte — ok up 16KB stack) */
    uint8_t frame[ETH_MAX_FRAME];
    eth_hdr_t *hdr = (eth_hdr_t *)frame;

    eth_memcpy(hdr->dst, dst_mac,  ETH_ADDR_LEN);
    eth_memcpy(hdr->src, nic->mac, ETH_ADDR_LEN);
    hdr->ethertype = net_hton16(ethertype);

    eth_memcpy(frame + ETH_HDR_SIZE, payload, payload_len);

    int ret = nic->dev->net_ops->send_packet(nic->dev,
                                              frame,
                                              (uint16_t)(ETH_HDR_SIZE + payload_len));
    return ret;
}

/* =========================================================================
 * ethernet_rx — dispatch in arrivo
 * ========================================================================= */
void ethernet_rx(device_t *dev, const void *data, uint16_t len) {
    if (!data || len < ETH_HDR_SIZE) return;

    const eth_hdr_t *hdr    = (const eth_hdr_t *)data;
    const uint8_t   *payload = (const uint8_t *)data + ETH_HDR_SIZE;
    uint16_t         plen    = (uint16_t)(len - ETH_HDR_SIZE);
    uint16_t         et      = net_ntoh16(hdr->ethertype);

    /* Find NIC mittente (for passarla to the layer superiori) */
    net_nic_t *nic = NULL;
    for (int i = 0; i < s_nic_count; i++) {
        if (s_nics[i].dev == dev) { nic = &s_nics[i]; break; }
    }

    switch (et) {
    case ETH_TYPE_ARP:
        arp_handle(nic, payload, plen);
        break;
    case ETH_TYPE_IPV4:
        ipv4_handle(nic, payload, plen);
        break;
    default:
        /* Ethertype NOT gestito — scarta silenziosamente */
        break;
    }
}

/* =========================================================================
 * Accessori
 * ========================================================================= */
net_nic_t *ethernet_get_nic(int index) {
    if (index < 0 || index >= s_nic_count) return NULL;
    return &s_nics[index];
}

int ethernet_nic_count(void) { return s_nic_count; }
