#ifndef MATTIAOS_IPV4_H
#define MATTIAOS_IPV4_H

/*
 * ipv4.h — Internet Protocol v4 (RFC 791)
 *
 * Addresses IPv4 in host byte order ovunque nell'API.
 * La conversion big-endian avviene only to the momento of writere/readre
 * the header on-wire (uso esplicito of net_hton32/net_ntoh32).
 */

#include "../include/types.h"
#include "../include/errno.h"
#include "ethernet.h"

/* =========================================================================
 * Costanti IPv4
 * ========================================================================= */
#define IP_PROTO_ICMP  1u
#define IP_PROTO_TCP   6u
#define IP_PROTO_UDP   17u

#define IP_HDR_SIZE_MIN  20u      /* Senza opzioni */
#define IP_MAX_DATAGRAM  65535u
#define IP_DF_FLAG       0x4000u  /* Don't Fragment bit (nel field flags+frag_off) */
#define IP_MF_FLAG       0x2000u  /* More Fragments */
#define IP_FRAG_OFF_MASK 0x1FFFu  /* Offset frammento (8-byte units) */

/* Limiti riassemblaggio frammenti */
#define IP_MAX_FRAG_GROUPS   64   /* Gruppi of frammenti active */
#define IP_MAX_FRAG_BUF      4096u
#define IP_FRAG_TIMEOUT_MS   5000u  /* 5 secondi */

/* =========================================================================
 * Header IPv4 on-wire
 * ========================================================================= */
typedef struct __attribute__((packed)) {
    uint8_t  ver_ihl;     /* version (4) + IHL (header length in 32-bit words) */
    uint8_t  tos;
    uint16_t tot_len;     /* big-endian: total length including header */
    uint16_t id;          /* big-endian: identification */
    uint16_t frag_off;    /* big-endian: flags (3 bit) + fragment offset (13 bit) */
    uint8_t  ttl;
    uint8_t  protocol;
    uint16_t checksum;    /* big-endian: header checksum */
    uint32_t src;         /* big-endian */
    uint32_t dst;         /* big-endian */
} ipv4_hdr_t;

#define IP_VERSION(h)    (((h)->ver_ihl >> 4) & 0xF)
#define IP_IHL(h)        (((h)->ver_ihl) & 0xF)         /* words */
#define IP_IHL_BYTES(h)  ((uint32_t)IP_IHL(h) * 4u)

/* =========================================================================
 * Routing table minimale
 * ========================================================================= */
#define IP_ROUTE_MAX  8

typedef struct {
    uint32_t dest;     /* Network destination (host byte order) */
    uint32_t mask;     /* Subnet mask (host byte order) */
    uint32_t gateway;  /* 0 = link-local (on-link) */
    int      nic_idx;  /* Indice NIC of exit */
    bool     valid;
} ipv4_route_t;

/* =========================================================================
 * Checksum ones-complement
 * ========================================================================= */
static inline uint16_t net_checksum(const void *data, size_t len) {
    const uint16_t *p = (const uint16_t *)data;
    uint32_t sum = 0;
    while (len > 1) { sum += *p++; len -= 2; }
    if (len)  sum += *(const uint8_t *)p;
    while (sum >> 16) sum = (sum & 0xFFFFu) + (sum >> 16);
    return (uint16_t)~sum;
}

/* =========================================================================
 * API pubblica
 * ========================================================================= */

/*
 * ipv4_init — set address local, gateway, loopback, chiama arp_init.
 * @local_ip:  IPv4 dell'interface primaria (host byte order).
 * @netmask:   subnet mask (host byte order).
 * @gateway:   default gateway (host byte order, 0 = assente).
 */
void ipv4_init(uint32_t local_ip, uint32_t netmask, uint32_t gateway);

/*
 * ipv4_handle — processa to datagramma IPv4 received.
 * @nic:  NIC of arrivo.
 * @data: payload after header ETH.
 * @len:  length in byte.
 */
void ipv4_handle(net_nic_t *nic, const void *data, uint16_t len);

/*
 * ipv4_send — send to datagramma IPv4.
 * @dst_ip:   destination (host byte order).
 * @proto:    IP_PROTO_ICMP / IP_PROTO_TCP / IP_PROTO_UDP.
 * @payload:  data of the livello superiore.
 * @len:      size payload.
 * @return:   EOK, ENOMEM, EIO, EAGAIN (ARP miss — riprovare).
 */
int ipv4_send(uint32_t dst_ip, uint8_t proto,
              const void *payload, uint16_t len);

/* Returns l'address IPv4 local in host byte order. */
uint32_t ipv4_get_local_ip(void);

/* Aggiunge to rotta statica to the routing table. */
int ipv4_route_add(uint32_t dest, uint32_t mask, uint32_t gw, int nic_idx);

#endif /* MATTIAOS_IPV4_H */
