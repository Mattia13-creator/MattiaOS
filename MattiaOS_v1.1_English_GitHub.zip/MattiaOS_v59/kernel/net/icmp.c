#include "icmp.h"
#include "../arch/x86_64/cpu.h"

/* =========================================================================
 * Helper no-libc
 * ========================================================================= */
static inline void icmp_memcpy(void *d, const void *s, size_t n) {
    uint8_t *dd = (uint8_t *)d;
    const uint8_t *ss = (const uint8_t *)s;
    for (size_t i = 0; i < n; i++) dd[i] = ss[i];
}
static inline void icmp_memset(void *d, int v, size_t n) {
    uint8_t *dd = (uint8_t *)d;
    for (size_t i = 0; i < n; i++) dd[i] = (uint8_t)v;
}

/* =========================================================================
 * icmp_handle
 * ========================================================================= */
void icmp_handle(uint32_t src_ip, const void *data, uint16_t len) {
    if (len < (uint16_t)ICMP_HDR_SIZE) return;

    const icmp_hdr_t *hdr = (const icmp_hdr_t *)data;

    /* Verify checksum */
    if (net_checksum(data, len) != 0) return;

    switch (hdr->type) {
    case ICMP_TYPE_ECHO_REQUEST: {
        /*
         * Echo Request → Echo Reply
         * Il reply ha the stessa structure: scambia type to 0, ricalculate checksum.
         * Payload (data echo) copied invariato.
         */
        if (len > (uint16_t)(IP_HDR_SIZE_MIN + IP_MAX_DATAGRAM)) return;

        uint8_t reply[ETH_MAX_PAYLOAD];
        if (len > (uint16_t)sizeof(reply)) return;

        icmp_memcpy(reply, data, len);
        icmp_hdr_t *rhdr = (icmp_hdr_t *)reply;
        rhdr->type     = ICMP_TYPE_ECHO_REPLY;
        rhdr->checksum = 0;
        rhdr->checksum = net_checksum(reply, len);

        ipv4_send(src_ip, IP_PROTO_ICMP, reply, len);
        break;
    }
    case ICMP_TYPE_ECHO_REPLY:
        /* Rimove to to nostro ping — ignorata (no ping userspace active) */
        break;
    case ICMP_TYPE_UNREACHABLE:
        /* Notifica to the strati superiori — TODO in Fase 10 */
        break;
    default:
        break;
    }
}

/* =========================================================================
 * icmp_send_unreachable
 * ========================================================================= */
void icmp_send_unreachable(uint32_t dst_ip, uint8_t queues,
                           const void *orig_hdr, uint16_t orig_len) {
    if (!orig_hdr) return;
    if (orig_len > 28) orig_len = 28;   /* IP header (20) + 8 byte data = 28 */

    /*
     * Formato Destination Unreachable (RFC 792):
     *   type (1) + queues (1) + checksum (2) + unused (4) + orig_ip_hdr+8 (28)
     *   Total: 8 + 28 = 36 byte
     */
    uint8_t buf[36];
    icmp_memset(buf, 0, sizeof(buf));

    icmp_unreach_hdr_t *uhdr = (icmp_unreach_hdr_t *)buf;
    uhdr->type   = ICMP_TYPE_UNREACHABLE;
    uhdr->queues   = queues;
    uhdr->unused = 0;

    icmp_memcpy(buf + sizeof(icmp_unreach_hdr_t), orig_hdr, orig_len);

    uhdr->checksum = 0;
    uhdr->checksum = net_checksum(buf, (uint16_t)(sizeof(icmp_unreach_hdr_t) + orig_len));

    ipv4_send(dst_ip, IP_PROTO_ICMP, buf,
              (uint16_t)(sizeof(icmp_unreach_hdr_t) + orig_len));
}
