#ifndef MATTIAOS_UDP_H
#define MATTIAOS_UDP_H

/*
 * udp.h — User Datagram Protocol (RFC 768)
 *
 * Ogni socket UDP è to udp_socket_t with binding optional up port local.
 * I datagrammi ricevuti vengono inseriti in to ring buffer for socket;
 * the consumer reads with udp_recv().
 * Demultiplexing: port destination → socket corrispondente.
 */

#include "../include/types.h"
#include "../include/errno.h"
#include "ipv4.h"

/* =========================================================================
 * Costanti
 * ========================================================================= */
#define UDP_HDR_SIZE        8u
#define UDP_MAX_SOCKETS     16  /* Ridotto */
#define UDP_RECV_QUEUE_LEN  8       /* Ridotto for boot iniziale */
#define UDP_MAX_PAYLOAD     (ETH_MAX_PAYLOAD - IP_HDR_SIZE_MIN - UDP_HDR_SIZE)

/* =========================================================================
 * Header UDP on-wire
 * ========================================================================= */
typedef struct __attribute__((packed)) {
    uint16_t src_port;   /* big-endian */
    uint16_t dst_port;   /* big-endian */
    uint16_t length;     /* big-endian: header + data */
    uint16_t checksum;   /* big-endian: 0 = checksum disabled */
} udp_hdr_t;

/* Pseudo-header IPv4 for checksum UDP */
typedef struct __attribute__((packed)) {
    uint32_t src_ip;
    uint32_t dst_ip;
    uint8_t  zero;
    uint8_t  proto;      /* IP_PROTO_UDP = 17 */
    uint16_t udp_len;
} udp_pseudo_hdr_t;

/* =========================================================================
 * UDP socket
 * ========================================================================= */
typedef struct {
    uint8_t  data[UDP_MAX_PAYLOAD];
    uint16_t src_port;   /* host byte order */
    uint32_t src_ip;     /* host byte order */
    uint16_t len;
} udp_dgram_t;

typedef struct {
    bool     valid;
    uint16_t local_port;      /* host byte order; 0 = NOT bound */
    uint32_t local_ip;        /* host byte order; 0 = INADDR_ANY */
    uint32_t remote_ip;       /* host byte order; 0 = NOT connected */
    uint16_t remote_port;     /* host byte order */

    /* Ring buffer of datagrammi ricevuti */
    udp_dgram_t  queue[UDP_RECV_QUEUE_LEN];
    uint32_t     q_head;
    uint32_t     q_tail;
    uint32_t     q_count;

    spinlock_t lock;

    /* Thread bloccati waiting of data */
    struct thread *waiters[8];
    uint32_t       waiter_count;
} udp_socket_t;

/* =========================================================================
 * API pubblica
 * ========================================================================= */

/*
 * udp_handle — entry point for datagrammi IPv4/UDP ricevuti.
 * Chiamata from ipv4_handle() with the payload UDP (header incluso).
 */
void udp_handle(uint32_t src_ip, uint32_t dst_ip,
                const void *data, uint16_t len);

/*
 * udp_socket_alloc — allocate to nuovo socket UDP.
 * @return: pointer to the socket, NULL if esauriti.
 */
udp_socket_t *udp_socket_alloc(void);

/*
 * udp_socket_free — free to socket UDP.
 */
void udp_socket_free(udp_socket_t *sock);

/*
 * udp_bind — associa socket to port local.
 * @sock:  socket from legare.
 * @ip:    address local (0 = INADDR_ANY).
 * @port:  port local in host byte order (0 = assegna automaticamente).
 * @return: EOK, EADDRINUSE, EINVAL.
 */
int udp_bind(udp_socket_t *sock, uint32_t ip, uint16_t port);

/*
 * udp_send — send to datagramma UDP.
 * @sock:      socket mittente (può essere NOT bound).
 * @dst_ip:    destination (host byte order).
 * @dst_port:  port destination (host byte order).
 * @data:      payload applicativo.
 * @len:       length payload.
 * @return:    EOK, EINVAL, EIO, EAGAIN (ARP miss).
 */
int udp_send(udp_socket_t *sock, uint32_t dst_ip, uint16_t dst_port,
             const void *data, uint16_t len);

/*
 * udp_recv — reads the next datagramma from the queue of ricezione.
 * Blocca the thread if the queue è empty (via scheduler_block).
 * @sock:      socket.
 * @buf:       buffer of output.
 * @buf_size:  size buffer.
 * @src_ip_out: address mittente (host byte order), può essere NULL.
 * @src_port_out: port mittente (host byte order), può essere NULL.
 * @return:    byte ricevuti, EINVAL, EAGAIN (only with flag NOT-blocking).
 */
int udp_recv(udp_socket_t *sock, void *buf, uint16_t buf_size,
             uint32_t *src_ip_out, uint16_t *src_port_out);

/* Assegna to port effimera free (49152–65535). */
uint16_t udp_ephemeral_port(void);

#endif /* MATTIAOS_UDP_H */
