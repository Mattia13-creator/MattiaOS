#ifndef MATTIAOS_SOCKET_H
#define MATTIAOS_SOCKET_H

/*
 * socket.h — BSD socket API (POSIX subset)
 *
 * Ogni socket è to file descriptor nel fd_table of the process, backed
 * from to vnode devfs with vfs_ops_t.  read/write/close sul fd delegano
 * to sock_vfs_read/write/close qui definiti.
 *
 * Famiglie:   AF_INET (IPv4)
 * Tipi:       SOCK_STREAM (TCP), SOCK_DGRAM (UDP)
 * Protocolli: IPPROTO_TCP, IPPROTO_UDP (0 = default for type)
 */

#include "../include/types.h"
#include "../include/errno.h"
#include "tcp.h"
#include "udp.h"
#include "../fs/vfs.h"
#include "../proc/process.h"

/* =========================================================================
 * Costanti AF / type / protocollo
 * ========================================================================= */
#define AF_INET        2
#define SOCK_STREAM    1    /* TCP */
#define SOCK_DGRAM     2    /* UDP */

#define IPPROTO_TCP    6
#define IPPROTO_UDP    17
#define IPPROTO_IP     0    /* Default: TCP for STREAM, UDP for DGRAM */

/* =========================================================================
 * sockaddr_in — address IPv4 (POSIX)
 * ========================================================================= */
typedef struct __attribute__((packed)) {
    uint16_t sin_family;   /* AF_INET */
    uint16_t sin_port;     /* Port in network byte order (big-endian) */
    uint32_t sin_addr;     /* IPv4 in network byte order */
    uint8_t  sin_zero[8];
} sockaddr_in_t;

/* Alias POSIX generico */
typedef sockaddr_in_t sockaddr_t;

/* INADDR_ANY AND INADDR_BROADCAST */
#define INADDR_ANY        0x00000000u
#define INADDR_BROADCAST  0xFFFFFFFFu

/* =========================================================================
 * setsockopt — livello AND opzioni
 * ========================================================================= */
#define SOL_SOCKET       1
#define SO_REUSEADDR     2
#define SO_KEEPALIVE     9
#define SO_RCVBUF        8
#define SO_SNDBUF        7

#define IPPROTO_TCP_OPT  6
#define TCP_NODELAY      1    /* Disenable Nagle (NOT implementato, accettato) */

/* =========================================================================
 * socket_t — descriptor internal
 * ========================================================================= */
typedef enum {
    SOCK_PROTO_TCP,
    SOCK_PROTO_UDP,
} sock_proto_t;

typedef struct socket {
    bool        valid;
    int         domain;      /* AF_INET */
    int         type;        /* SOCK_STREAM / SOCK_DGRAM */
    sock_proto_t proto;

    /* Stato connection */
    bool        bound;
    bool        listening;
    bool        connected;
    bool        nonblock;

    /* Addresses locali AND remoti (host byte order) */
    uint32_t    local_ip;
    uint16_t    local_port;
    uint32_t    remote_ip;
    uint16_t    remote_port;

    /* Pointers to the sottosistema of trasporto */
    tcp_conn_t *tcp_conn;    /* Non NULL for SOCK_STREAM */
    udp_socket_t *udp_sock;  /* Non NULL for SOCK_DGRAM */

    /* vnode associato for l'integrazione VFS */
    vnode_t     vnode;
    vfs_ops_t   vops;        /* Vtable — initialiseta from socket_create */

    spinlock_t  lock;
} socket_t;

/* Numero massimo of socket aperti contemporaneamente */
#define SOCK_MAX  32  /* Ridotto for boot iniziale */

/* =========================================================================
 * API pubblica — syscall-level (operano up fd of the process current)
 * ========================================================================= */

/*
 * sys_socket — crea to nuovo socket.
 * @domain:   AF_INET.
 * @type:     SOCK_STREAM OR SOCK_DGRAM.
 * @protocol: IPPROTO_TCP, IPPROTO_UDP OR 0 (auto).
 * @return:   file descriptor >= 0, OR error negative.
 */
int sys_socket(int domain, int type, int protocol);

/*
 * sys_bind — associa the socket to to address local.
 * @sockfd: fd of the socket.
 * @addr:   pointer to sockaddr_in_t with sin_family=AF_INET,
 *          sin_port AND sin_addr in network byte order.
 * @addrlen: sizeof(sockaddr_in_t).
 * @return:  EOK, EBADF, EINVAL, EADDRINUSE.
 */
int sys_bind(int sockfd, const sockaddr_t *addr, uint32_t addrlen);

/*
 * sys_listen — pone the socket TCP in stato of ascolto.
 * @sockfd:  fd of the socket.
 * @backlog: size queue connections waiting (ignorato — sempre 8).
 * @return:  EOK, EBADF, EINVAL, EOPNOTSUPP (up UDP).
 */
int sys_listen(int sockfd, int backlog);

/*
 * sys_accept — estrae the before connection completata from the queue.
 * Blocca if none connection è available.
 * @sockfd:    fd of the socket LISTEN.
 * @addr_out:  if NOT NULL, riceve l'address of the client.
 * @addrlen:   pointer to the size of the buffer addr_out.
 * @return:    nuovo fd for the connection accettata, OR error.
 */
int sys_accept(int sockfd, sockaddr_t *addr_out, uint32_t *addrlen);

/*
 * sys_connect — start connection active TCP OR set destination UDP.
 * @sockfd: fd of the socket.
 * @addr:   address destination.
 * @addrlen: sizeof(sockaddr_in_t).
 * @return:  EOK (connection startta/stenable), OR error.
 *
 * Per TCP: block finché the connection NOT è ESTABLISHED OR fallisce.
 * Per UDP: register only l'address remoto (sendto semplificato).
 */
int sys_connect(int sockfd, const sockaddr_t *addr, uint32_t addrlen);

/*
 * sys_send — send data up socket connected.
 * @sockfd: fd.
 * @buf:    data from sendre.
 * @len:    size.
 * @flags:  ignorati (0).
 * @return: byte sendti, OR error.
 */
int sys_send(int sockfd, const void *buf, size_t len, int flags);

/*
 * sys_recv — riceve data from socket connected.
 * @sockfd: fd.
 * @buf:    buffer of output.
 * @len:    size massima.
 * @flags:  ignorati (0).
 * @return: byte ricevuti (0 = EOF/connection chiusa), OR error.
 */
int sys_recv(int sockfd, void *buf, size_t len, int flags);

/*
 * sys_sendto — send to datagramma UDP to address specificato.
 * @sockfd:  fd UDP.
 * @buf:     data.
 * @len:     size.
 * @flags:   ignorati.
 * @dst:     address destination.
 * @addrlen: sizeof(sockaddr_in_t).
 * @return:  byte sendti, OR error.
 */
int sys_sendto(int sockfd, const void *buf, size_t len, int flags,
               const sockaddr_t *dst, uint32_t addrlen);

/*
 * sys_recvfrom — riceve to datagramma UDP with address mittente.
 * @sockfd:     fd UDP.
 * @buf:        buffer of output.
 * @len:        size massima.
 * @flags:      ignorati.
 * @src_out:    riceve l'address mittente (può essere NULL).
 * @addrlen:    pointer to the size (in/out).
 * @return:     byte ricevuti, OR error.
 */
int sys_recvfrom(int sockfd, void *buf, size_t len, int flags,
                 sockaddr_t *src_out, uint32_t *addrlen);

/*
 * sys_setsockopt — set opzione sul socket.
 * @sockfd:   fd.
 * @level:    SOL_SOCKET OR IPPROTO_TCP_OPT.
 * @optname:  SO_REUSEADDR, SO_KEEPALIVE, TCP_NODELAY, ecc.
 * @optval:   pointer to the value (int).
 * @optlen:   sizeof(int).
 * @return:   EOK, EBADF, EINVAL (opzione NOT riconosciuta — tollerata).
 */
int sys_setsockopt(int sockfd, int level, int optname,
                   const void *optval, uint32_t optlen);

/*
 * sys_close_socket — closes the socket AND free the risorse.
 * Chiamata automaticamente from vfs_close when the fd is closed.
 */
int sys_close_socket(int sockfd);

/* =========================================================================
 * API interna — usata from the layer socket for collegare tcp_conn to socket_t
 * ========================================================================= */

/*
 * socket_from_tcp — returns the socket_t associato to to tcp_conn_t.
 * Usato from tcp.c for notificare eventi (ESTABLISHED, CLOSE_WAIT, ecc.)
 * via the field conn->sock.
 */
socket_t *socket_from_tcp(tcp_conn_t *conn);

#endif /* MATTIAOS_SOCKET_H */
