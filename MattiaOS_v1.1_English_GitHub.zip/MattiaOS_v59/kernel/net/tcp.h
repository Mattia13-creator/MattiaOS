#ifndef MATTIAOS_TCP_H
#define MATTIAOS_TCP_H

/*
 * tcp.h — Transmission Control Protocol (RFC 793 + Reno congestion RFC 2581)
 *
 * Implementa the state machine TCP complete, sliding window, congestion
 * control Reno AND retransmission timer with algorithm Jacobson/Karels.
 *
 * tcp_timer_tick() va chiamata every millisecondo dall'APIC timer IRQ
 * (connection pendente — annotata nella matrice dependencies of the blueprint).
 */

#include "../include/types.h"
#include "../include/errno.h"
#include "ipv4.h"

/* =========================================================================
 * Costanti TCP
 * ========================================================================= */
#define TCP_HDR_SIZE_MIN    20u
#define TCP_MAX_CONN        32   /* Ridotto for boot iniziale */

#define TCP_MSS             1460u   /* Max Segment Size: 1500 - 20 IP - 20 TCP */
#define TCP_SEND_BUF_SIZE   4096u   /* 4 KB send buffer */
#define TCP_RECV_BUF_SIZE   4096u   /* 4 KB receive buffer */

/* Congestion control */
#define TCP_INITIAL_CWND    (2u * TCP_MSS)
#define TCP_INITIAL_SSTHRESH 65535u

/* RTO (Jacobson/Karels) — ms */
#define TCP_RTO_INIT_MS     1000u
#define TCP_RTO_MIN_MS      200u
#define TCP_RTO_MAX_MS      60000u
#define TCP_MAX_RETRANSMIT  5u
#define TCP_TIMEWAIT_MS     60000u  /* 2×MSL */
#define TCP_KEEPALIVE_MS    75000u

/* Sequence number comparison (gestisce wraparound to 32 bit) */
#define TCP_SEQ_LT(a,b)  ((int32_t)((a)-(b)) < 0)
#define TCP_SEQ_LE(a,b)  ((int32_t)((a)-(b)) <= 0)
#define TCP_SEQ_GT(a,b)  ((int32_t)((a)-(b)) > 0)
#define TCP_SEQ_GE(a,b)  ((int32_t)((a)-(b)) >= 0)

/* =========================================================================
 * Flag TCP (field nel header)
 * ========================================================================= */
#define TCP_FLAG_FIN  0x01u
#define TCP_FLAG_SYN  0x02u
#define TCP_FLAG_RST  0x04u
#define TCP_FLAG_PSH  0x08u
#define TCP_FLAG_ACK  0x10u
#define TCP_FLAG_URG  0x20u

/* =========================================================================
 * Header TCP on-wire
 * ========================================================================= */
typedef struct __attribute__((packed)) {
    uint16_t src_port;   /* big-endian */
    uint16_t dst_port;   /* big-endian */
    uint32_t seq;        /* big-endian */
    uint32_t ack;        /* big-endian */
    uint8_t  data_off;   /* header length in 32-bit words (top 4 bit) */
    uint8_t  flags;      /* TCP_FLAG_* */
    uint16_t window;     /* big-endian: receive window */
    uint16_t checksum;   /* big-endian */
    uint16_t urgent;     /* big-endian */
} tcp_hdr_t;

#define TCP_HDR_OFFSET(h)    (((h)->data_off >> 4) * 4u)  /* in byte */

/* Pseudo-header IPv4 for checksum TCP */
typedef struct __attribute__((packed)) {
    uint32_t src_ip;
    uint32_t dst_ip;
    uint8_t  zero;
    uint8_t  proto;      /* IP_PROTO_TCP = 6 */
    uint16_t tcp_len;
} tcp_pseudo_hdr_t;

/* =========================================================================
 * State machine TCP
 * ========================================================================= */
typedef enum {
    TCP_CLOSED = 0,
    TCP_LISTEN,
    TCP_SYN_SENT,
    TCP_SYN_RECEIVED,
    TCP_ESTABLISHED,
    TCP_FIN_WAIT_1,
    TCP_FIN_WAIT_2,
    TCP_CLOSING,
    TCP_TIME_WAIT,
    TCP_CLOSE_WAIT,
    TCP_LAST_ACK,
} tcp_state_t;

/* =========================================================================
 * tcp_conn_t — connection TCP
 * ========================================================================= */
typedef struct {
    bool         valid;
    tcp_state_t  state;

    /* Addresses AND ports (host byte order) */
    uint32_t     local_ip;
    uint16_t     local_port;
    uint32_t     remote_ip;
    uint16_t     remote_port;

    /* Send sequence variables (RFC 793 §3.2) */
    uint32_t     snd_una;    /* Oldest unacknowledged */
    uint32_t     snd_nxt;    /* Next sequence to send */
    uint32_t     snd_wnd;    /* Send window (remote rwnd) */
    uint32_t     iss;        /* Initial send sequence number */

    /* Receive sequence variables */
    uint32_t     rcv_nxt;    /* Next expected from remote */
    uint32_t     rcv_wnd;    /* Our receive window */
    uint32_t     irs;        /* Initial receive sequence number */

    /* Send buffer (ring) */
    uint8_t      send_buf[TCP_SEND_BUF_SIZE];
    uint32_t     send_head;      /* Oldest byte (= snd_una offset) */
    uint32_t     send_tail;      /* Next write position */
    uint32_t     send_count;     /* Total bytes buffered (unacked + unsent) */
    uint32_t     send_unacked;   /* Bytes sent but NOT yet acked */

    /* Receive buffer (ring) */
    uint8_t      recv_buf[TCP_RECV_BUF_SIZE];
    uint32_t     recv_head;
    uint32_t     recv_tail;
    uint32_t     recv_count;

    /* Congestion control (Reno) */
    uint32_t     cwnd;           /* Congestion window (bytes) */
    uint32_t     ssthresh;       /* Slow start threshold */
    uint32_t     dup_ack_count;
    bool         fast_recovery;
    uint32_t     recover_seq;    /* Recovery point */

    /* RTT estimation (Jacobson/Karels, RFC 6298) — values in ms scalati */
    int32_t      srtt_ms8;       /* SRTT × 8 */
    int32_t      rttvar_ms4;     /* RTTVAR × 4 */
    uint32_t     rto_ms;
    bool         rtt_measuring;
    uint32_t     rtt_seq;        /* Sequence in corso of misura */
    uint64_t     rtt_send_tick;  /* Tick ms all'invio */

    /* Timer of ritrasmissione */
    uint64_t     retransmit_deadline;   /* 0 = disabled */
    uint32_t     retransmit_count;

    /* Timer TIME_WAIT */
    uint64_t     timewait_deadline;

    /* Socket associato (for notify) */
    struct socket *sock;

    /* Thread bloccati waiting (connect/accept/recv) */
    struct thread *waiters[4];
    uint32_t       waiter_count;

    spinlock_t   lock;
} tcp_conn_t;

/* =========================================================================
 * API pubblica
 * ========================================================================= */

/*
 * tcp_handle — entry point for segmenti IPv4/TCP ricevuti.
 * Chiamata from ipv4_handle() with the payload TCP (header incluso).
 */
void tcp_handle(uint32_t src_ip, uint32_t dst_ip,
                const void *data, uint16_t len);

/*
 * tcp_connect — start connection active (3-way handshake).
 * @dst_ip, @dst_port: destination (host byte order).
 * @conn_out: riceve the pointer to the connection allocateta.
 * @return: EOK (connection startta, NOT ancora stenable) OR error.
 */
int tcp_connect(uint32_t dst_ip, uint16_t dst_port, tcp_conn_t **conn_out);

/*
 * tcp_listen — pone to connection in stato LISTEN sulla port specificata.
 * @port:     port local (host byte order).
 * @conn_out: riceve the connection LISTEN.
 * @return:   EOK, EINVAL, EADDRINUSE.
 */
int tcp_listen(uint16_t port, tcp_conn_t **conn_out);

/*
 * tcp_accept — returns the prossima connection completata up to LISTEN socket.
 * Blocca the thread finché NOT arriva to connection (scheduler_block).
 * @listener: connection in stato LISTEN.
 * @return:   pointer to the nuova connection ESTABLISHED, NULL if error.
 */
tcp_conn_t *tcp_accept(tcp_conn_t *listener);

/*
 * tcp_send — inserisce data nel send buffer AND tenta l'invio.
 * @conn:   connection ESTABLISHED.
 * @data:   data from sendre.
 * @len:    size.
 * @return: byte acqueueti (>= 0) OR error negative.
 */
int tcp_send(tcp_conn_t *conn, const void *data, uint32_t len);

/*
 * tcp_recv — reads data from the receive buffer.
 * Blocca the thread if the buffer è empty.
 * @conn:   connection.
 * @buf:    buffer of output.
 * @len:    size massima from readre.
 * @return: byte letti (>= 0) OR error negative.
 */
int tcp_recv(tcp_conn_t *conn, void *buf, uint32_t len);

/*
 * tcp_close — closes the connection (send FIN, start sequence close).
 * @conn: connection from closere.
 */
void tcp_close(tcp_conn_t *conn);

/*
 * tcp_free — free the connection after that è arrivata to CLOSED.
 */
void tcp_free(tcp_conn_t *conn);

/*
 * tcp_timer_tick — from chiamare every millisecondo dall'APIC timer.
 * Gestisce retransmission timeout, TIME_WAIT expiry, keepalive.
 * NOTA: connection pendente — va aggiunta to the handler APIC timer IRQ 0x20.
 */
void tcp_timer_tick(void);

#endif /* MATTIAOS_TCP_H */
