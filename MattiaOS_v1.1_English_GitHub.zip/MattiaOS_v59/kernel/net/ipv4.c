#include "ipv4.h"
#include "arp.h"
#include "icmp.h"
#include "udp.h"
#include "tcp.h"
#include "../mm/slab.h"
#include "../arch/x86_64/cpu.h"

/* =========================================================================
 * Stato internal
 * ========================================================================= */
static uint32_t      s_local_ip  = 0;
static uint32_t      s_netmask   = 0;
static uint32_t      s_gateway   = 0;
static ipv4_route_t  s_routes[IP_ROUTE_MAX];
static int           s_nroutes   = 0;
static spinlock_t    s_route_lock = {0};

/* ID datagramma incrementle (big-endian all'exit) */
static uint16_t      s_ip_id    = 1;

/* Tick counter global usato from ARP AND TCP */
uint64_t g_net_ticks_ms = 0;

/* =========================================================================
 * Helper no-libc
 * ========================================================================= */
static inline void ip_memcpy(void *d, const void *s, size_t n) {
    uint8_t *dd = (uint8_t *)d;
    const uint8_t *ss = (const uint8_t *)s;
    for (size_t i = 0; i < n; i++) dd[i] = ss[i];
}
static inline void ip_memset(void *d, int v, size_t n) {
    uint8_t *dd = (uint8_t *)d;
    for (size_t i = 0; i < n; i++) dd[i] = (uint8_t)v;
}

/* =========================================================================
 * Riassemblaggio frammenti
 * ========================================================================= */
typedef struct {
    uint32_t src_ip;
    uint32_t dst_ip;
    uint16_t id;
    uint8_t  proto;
    bool     valid;

    uint8_t  buf[IP_MAX_FRAG_BUF];
    bool     received[512];       /* bit for every block from 8 byte (65536/128) */
    uint32_t total_len;           /* 0 finché NOT arriva l'last frammento */
    uint32_t bytes_received;
    uint64_t first_seen_ms;
} frag_group_t;

static frag_group_t s_frags[IP_MAX_FRAG_GROUPS];
static spinlock_t   s_frag_lock = {0};

static frag_group_t *frag_find_or_alloc(uint32_t src, uint32_t dst,
                                         uint16_t id, uint8_t proto) {
    /* Search group esistente */
    for (int i = 0; i < IP_MAX_FRAG_GROUPS; i++) {
        frag_group_t *g = &s_frags[i];
        if (g->valid && g->src_ip == src && g->dst_ip == dst &&
            g->id == id && g->proto == proto)
            return g;
    }
    /* Search slot free OR scade the più vecchio */
    int victim = 0;
    for (int i = 0; i < IP_MAX_FRAG_GROUPS; i++) {
        if (!s_frags[i].valid) { victim = i; goto found; }
        if (s_frags[i].first_seen_ms < s_frags[victim].first_seen_ms)
            victim = i;
    }
found:
    ip_memset(&s_frags[victim], 0, sizeof(frag_group_t));
    s_frags[victim].valid         = true;
    s_frags[victim].src_ip        = src;
    s_frags[victim].dst_ip        = dst;
    s_frags[victim].id            = id;
    s_frags[victim].proto         = proto;
    s_frags[victim].first_seen_ms = g_net_ticks_ms;
    return &s_frags[victim];
}

/* Returns pointer to the buffer complete if riassemblato, NULL altrimenti */
static const uint8_t *frag_reassemble(frag_group_t *g, uint32_t *out_len) {
    if (g->total_len == 0) return NULL;
    if (g->bytes_received < g->total_len) return NULL;
    *out_len = g->total_len;
    return g->buf;
}

/* =========================================================================
 * ipv4_init
 * ========================================================================= */
void ipv4_init(uint32_t local_ip, uint32_t netmask, uint32_t gateway) {
    s_local_ip = local_ip;
    s_netmask  = netmask;
    s_gateway  = gateway;
    s_nroutes  = 0;
    ip_memset(s_routes, 0, sizeof(s_routes));
    ip_memset(s_frags,  0, sizeof(s_frags));

    arp_init(local_ip);

    /* Rotta loopback */
    ipv4_route_add(0x7F000000u, 0xFF000000u, 0, -1);
    /* Rotta on-link for the subnet */
    if (netmask)
        ipv4_route_add(local_ip & netmask, netmask, 0, 0);
    /* Default gateway */
    if (gateway)
        ipv4_route_add(0, 0, gateway, 0);

    serial_puts("[IPv4] Initialiseto\n");
}

/* =========================================================================
 * ipv4_route_add
 * ========================================================================= */
int ipv4_route_add(uint32_t dest, uint32_t mask, uint32_t gw, int nic_idx) {
    uint64_t f = spinlock_irqsave(&s_route_lock);
    if (s_nroutes >= IP_ROUTE_MAX) {
        spinlock_irqrestore(&s_route_lock, f);
        return ENOMEM;
    }
    ipv4_route_t *r = &s_routes[s_nroutes++];
    r->dest    = dest;
    r->mask    = mask;
    r->gateway = gw;
    r->nic_idx = nic_idx;
    r->valid   = true;
    spinlock_irqrestore(&s_route_lock, f);
    return EOK;
}

/* =========================================================================
 * Lookup rotta più specifica (longest prefix match)
 * ========================================================================= */
static const ipv4_route_t *route_lookup(uint32_t dst_ip) {
    const ipv4_route_t *best = NULL;
    uint32_t best_mask = 0;
    for (int i = 0; i < s_nroutes; i++) {
        const ipv4_route_t *r = &s_routes[i];
        if (!r->valid) continue;
        if ((dst_ip & r->mask) == (r->dest & r->mask)) {
            if (!best || r->mask > best_mask) {
                best      = r;
                best_mask = r->mask;
            }
        }
    }
    return best;
}

/* =========================================================================
 * ipv4_get_local_ip
 * ========================================================================= */
uint32_t ipv4_get_local_ip(void) { return s_local_ip; }

/* =========================================================================
 * ipv4_send
 * ========================================================================= */
int ipv4_send(uint32_t dst_ip, uint8_t proto,
              const void *payload, uint16_t payload_len) {
    if (!payload || payload_len == 0) return EINVAL;
    if ((uint32_t)IP_HDR_SIZE_MIN + payload_len > IP_MAX_DATAGRAM) return EINVAL;

    /* Lookup rotta */
    const ipv4_route_t *route = route_lookup(dst_ip);
    if (!route) return EIO;

    /* Determina next-hop IP for ARP */
    uint32_t next_hop = (route->gateway) ? route->gateway : dst_ip;

    /* Risolvi MAC (loopback: MAC zero, skip ARP) */
    uint8_t dst_mac[ETH_ADDR_LEN];
    if ((dst_ip & 0xFF000000u) == 0x7F000000u) {
        ip_memset(dst_mac, 0, ETH_ADDR_LEN);
    } else {
        int r = arp_resolve(next_hop, dst_mac);
        if (r != EOK) return r;   /* EAGAIN if ARP miss */
    }

    /* Build header IP up stack */
    uint8_t pkt[IP_HDR_SIZE_MIN + ETH_MAX_PAYLOAD];
    if (payload_len > ETH_MAX_PAYLOAD) return EINVAL; /* Fragmentazione TODO */

    ipv4_hdr_t *hdr = (ipv4_hdr_t *)pkt;
    ip_memset(hdr, 0, IP_HDR_SIZE_MIN);
    hdr->ver_ihl  = (4u << 4) | 5u;   /* version=4, IHL=5 (20 byte) */
    hdr->tos      = 0;
    hdr->tot_len  = net_hton16((uint16_t)(IP_HDR_SIZE_MIN + payload_len));
    hdr->id       = net_hton16(s_ip_id++);
    hdr->frag_off = net_hton16(IP_DF_FLAG);
    hdr->ttl      = 64;
    hdr->protocol = proto;
    hdr->src      = net_hton32(s_local_ip);
    hdr->dst      = net_hton32(dst_ip);
    hdr->checksum = 0;
    hdr->checksum = net_checksum(hdr, IP_HDR_SIZE_MIN);

    ip_memcpy(pkt + IP_HDR_SIZE_MIN, payload, payload_len);

    net_nic_t *nic = ethernet_get_nic((route->nic_idx >= 0) ? route->nic_idx : 0);
    return ethernet_send(nic, dst_mac, ETH_TYPE_IPV4,
                         pkt, (uint16_t)(IP_HDR_SIZE_MIN + payload_len));
}

/* =========================================================================
 * ipv4_handle — ricezione AND dispatch
 * ========================================================================= */
void ipv4_handle(net_nic_t *nic, const void *data, uint16_t len) {
    if (len < IP_HDR_SIZE_MIN) return;

    const ipv4_hdr_t *hdr = (const ipv4_hdr_t *)data;

    if (IP_VERSION(hdr) != 4) return;

    uint32_t ihl = IP_IHL_BYTES(hdr);
    if (ihl < IP_HDR_SIZE_MIN || ihl > len) return;

    uint16_t tot = net_ntoh16(hdr->tot_len);
    if (tot > len || tot < ihl) return;

    /* Verify checksum header */
    if (net_checksum(hdr, ihl) != 0) return;

    uint32_t src_ip = net_ntoh32(hdr->src);
    uint32_t dst_ip = net_ntoh32(hdr->dst);

    /* Scarta pacchetti NOT diretti to noi (no promiscuous) */
    if (dst_ip != s_local_ip &&
        dst_ip != 0xFFFFFFFFu &&               /* broadcast limited */
        (dst_ip & 0xFF000000u) != 0x7F000000u  /* loopback */
        ) return;

    const uint8_t *payload = (const uint8_t *)data + ihl;
    uint16_t       plen    = (uint16_t)(tot - ihl);

    /* Gestione frammenti */
    uint16_t frag_field = net_ntoh16(hdr->frag_off);
    bool     mf         = (frag_field & IP_MF_FLAG) != 0;
    uint16_t frag_off   = (uint16_t)((frag_field & IP_FRAG_OFF_MASK) * 8u);

    if (mf || frag_off != 0) {
        /* Frammento: riassembla */
        uint64_t f = spinlock_irqsave(&s_frag_lock);
        frag_group_t *g = frag_find_or_alloc(src_ip, dst_ip,
                                              net_ntoh16(hdr->id),
                                              hdr->protocol);
        if (frag_off + plen <= IP_MAX_FRAG_BUF) {
            ip_memcpy(g->buf + frag_off, payload, plen);
            g->bytes_received += plen;
            for (uint16_t i = frag_off / 8; i < (frag_off + plen + 7) / 8; i++) {
                if (i < 512) g->received[i] = true;
            }
            if (!mf) g->total_len = frag_off + plen;
        }
        uint32_t reassembled_len = 0;
        const uint8_t *rbuf = frag_reassemble(g, &reassembled_len);
        if (rbuf) {
            uint8_t  proto = g->proto;
            uint8_t  tmp[IP_MAX_FRAG_BUF];
            ip_memcpy(tmp, rbuf, reassembled_len);
            g->valid = false;  /* Free the group */
            spinlock_irqrestore(&s_frag_lock, f);
            /* Dispatch with the buffer riassemblato */
            switch (proto) {
            case IP_PROTO_ICMP: icmp_handle(src_ip, tmp, (uint16_t)reassembled_len); break;
            case IP_PROTO_UDP:  udp_handle(src_ip, dst_ip, tmp, (uint16_t)reassembled_len); break;
            case IP_PROTO_TCP:  tcp_handle(src_ip, dst_ip, tmp, (uint16_t)reassembled_len); break;
            default: break;
            }
        } else {
            spinlock_irqrestore(&s_frag_lock, f);
        }
        return;
    }

    /* Datagramma complete — dispatch diretto */
    switch (hdr->protocol) {
    case IP_PROTO_ICMP: icmp_handle(src_ip, payload, plen);              break;
    case IP_PROTO_UDP:  udp_handle(src_ip, dst_ip, payload, plen);       break;
    case IP_PROTO_TCP:  tcp_handle(src_ip, dst_ip, payload, plen);       break;
    default: break;
    }

    (void)nic;
}
