#include "mlfq.h"
#include "../arch/x86_64/cpu.h"
#include "../include/errno.h"

/* Quantums for livello MLFQ (ms) — unica definizione in all the kernel */
const uint32_t MLFQ_QUANTUM_MS[NUM_QUEUES] = {5,10,20,40,80,160,320,640};

/* Global scheduler state */
run_queue_t g_mlfq[NUM_QUEUES];
thread_t   *g_idle_thread = NULL;

static spinlock_t  s_sched_lock        = {0};
static uint64_t    s_ms_since_boot     = 0;
static uint64_t    s_last_boost_ms     = 0;
static uint64_t    s_current_quantum   = 0; /* ms remaining for current thread */

/* ── scheduler_init ──────────────────────────────────────────────────────
 * Initialize all 8 run queues AND set their quantum values.
 * Must be called before any other scheduler function.
 */
void scheduler_init(void) {
    for (int i = 0; i < NUM_QUEUES; i++) {
        g_mlfq[i].head         = NULL;
        g_mlfq[i].tail         = NULL;
        g_mlfq[i].quantum_ms   = MLFQ_QUANTUM_MS[i];
        g_mlfq[i].thread_count = 0;
    }
    s_ms_since_boot   = 0;
    s_last_boost_ms   = 0;
    s_current_quantum = MLFQ_QUANTUM_MS[0];
}

/* ── scheduler_add ───────────────────────────────────────────────────────
 * Enqueue thread into its run queue (thread->sched_level).
 * Clamps sched_level to [0, NUM_QUEUES-1].
 */
void scheduler_add(thread_t *thread) {
    if (!thread) return;

    spinlock_acquire(&s_sched_lock);

    int level = thread->sched_level;
    if (level < 0) level = 0;
    if (level >= NUM_QUEUES) level = NUM_QUEUES - 1;
    thread->sched_level = level;

    run_queue_t *q = &g_mlfq[level];

    thread->next = NULL;
    thread->prev = q->tail;
    if (q->tail) q->tail->next = thread;
    else q->head = thread;
    q->tail = thread;
    q->thread_count++;

    thread->state = PROCESS_READY;

    spinlock_release(&s_sched_lock);
}

/* ── scheduler_remove ────────────────────────────────────────────────────
 * Dequeue thread from its current run queue.
 */
void scheduler_remove(thread_t *thread) {
    if (!thread) return;

    spinlock_acquire(&s_sched_lock);

    int level = thread->sched_level;
    if (level < 0 || level >= NUM_QUEUES) {
        spinlock_release(&s_sched_lock);
        return;
    }

    run_queue_t *q = &g_mlfq[level];

    if (thread->prev) thread->prev->next = thread->next;
    else q->head = thread->next;
    if (thread->next) thread->next->prev = thread->prev;
    else q->tail = thread->prev;

    thread->prev = NULL;
    thread->next = NULL;
    if (q->thread_count > 0) q->thread_count--;

    spinlock_release(&s_sched_lock);
}

/* ── scheduler_next ──────────────────────────────────────────────────────
 * Select the next thread to run using MLFQ policy:
 *   - Scan code from level 0 (highest) to 7 (lowest).
 *   - Return the head of the first NOT-empty queue.
 *   - If all queues are empty, return the idle thread.
 * scheduler_next() NEVER returns NULL.
 */
thread_t *scheduler_next(void) {
    spinlock_acquire(&s_sched_lock);

    for (int i = 0; i < NUM_QUEUES; i++) {
        run_queue_t *q = &g_mlfq[i];
        if (q->head && q->head->state == PROCESS_READY) {
            thread_t *t = q->head;

            /* Rotate: move to tail for round-robin within same level */
            q->head = t->next;
            if (q->head) q->head->prev = NULL;
            else q->tail = NULL;
            q->thread_count--;

            t->prev = NULL;
            t->next = NULL;

            spinlock_release(&s_sched_lock);

            s_current_quantum = (uint64_t)MLFQ_QUANTUM_MS[i];
            return t;
        }
    }

    spinlock_release(&s_sched_lock);

    /* No runnable thread — return idle */
    return g_idle_thread;
}

/* ── scheduler_tick ──────────────────────────────────────────────────────
 * Called every millisecond from the APIC timer interrupt handler.
 * Decrements the current quantum. On expiry, demotes the thread one
 * level AND triggers to context switch via scheduler_yield().
 * Triggers to priority boost every PRIORITY_BOOST_MS milliseconds.
 */
void scheduler_tick(void) {
    s_ms_since_boot++;

    /* Priority boost */
    if (s_ms_since_boot - s_last_boost_ms >= PRIORITY_BOOST_MS) {
        s_last_boost_ms = s_ms_since_boot;
        scheduler_priority_boost();
    }

    /* Quantum accounting */
    if (g_current_thread == g_idle_thread) return;

    if (g_current_thread) {
        g_current_thread->process->cpu_time_used++;
    }

    if (s_current_quantum > 0) s_current_quantum--;

    if (s_current_quantum == 0) {
        /* Thread exhausted its quantum: demote one level */
        if (g_current_thread) {
            int new_level = g_current_thread->sched_level + 1;
            if (new_level >= NUM_QUEUES) new_level = NUM_QUEUES - 1;
            g_current_thread->sched_level = new_level;
        }
        scheduler_yield();
    }
}

/* ── scheduler_yield ─────────────────────────────────────────────────────
 * Voluntarily give up the CPU. The current thread keeps its level
 * (voluntary yield does NOT cause demotion). Re-enqueues itself.
 * Actual context switch happens in the arch layer (context_switch.asm).
 */
void scheduler_yield(void) {
    if (!g_current_thread || g_current_thread == g_idle_thread) return;

    spinlock_acquire(&s_sched_lock);
    thread_t *current = g_current_thread;
    spinlock_release(&s_sched_lock);

    /* Re-enqueue current thread */
    scheduler_add(current);

    thread_t *next = scheduler_next();
    if (next == current) return; /* Nothing else to run */

    /* Arch-level context switch */
    g_current_thread  = next;
    g_current_process = next->process;

    /* context_switch(old, new, cr3) defined in context_switch.asm */
    extern void context_switch(cpu_context_t *old, cpu_context_t *new_ctx,
                                uint64_t cr3);
    uint64_t cr3 = vmm_get_cr3(next->process->pagemap);
    context_switch(&current->context, &next->context, cr3);
}

/* ── scheduler_block ─────────────────────────────────────────────────────
 * Move thread to BLOCKED state AND remove from run queue.
 * Thread will NOT be scheduled until scheduler_unblock() is called.
 */
void scheduler_block(thread_t *thread) {
    if (!thread) return;
    scheduler_remove(thread);
    thread->state = PROCESS_BLOCKED;
}

/* ── scheduler_unblock ───────────────────────────────────────────────────
 * Wake to blocked thread: bump it one priority level (I/O reward)
 * AND re-enqueue it.
 */
void scheduler_unblock(thread_t *thread) {
    if (!thread) return;
    if (thread->state != PROCESS_BLOCKED) return;

    /* I/O completion reward: move up one level */
    if (thread->sched_level > 0) thread->sched_level--;

    thread->state = PROCESS_READY;
    scheduler_add(thread);
}

/* ── scheduler_priority_boost ────────────────────────────────────────────
 * Anti-starvation: move ALL threads from every queue to level 0.
 * Called every PRIORITY_BOOST_MS milliseconds from scheduler_tick().
 */
void scheduler_priority_boost(void) {
    spinlock_acquire(&s_sched_lock);

    /* Collect all threads from levels 1-7 AND move them to level 0 */
    for (int i = 1; i < NUM_QUEUES; i++) {
        run_queue_t *src = &g_mlfq[i];
        run_queue_t *dst = &g_mlfq[0];

        if (!src->head) continue;

        /* Mark them all level 0 */
        thread_t *t = src->head;
        while (t) {
            t->sched_level = 0;
            t = t->next;
        }

        /* Concatenate src list onto dst */
        if (dst->tail) {
            dst->tail->next   = src->head;
            src->head->prev   = dst->tail;
        } else {
            dst->head = src->head;
        }
        dst->tail         = src->tail;
        dst->thread_count += src->thread_count;

        src->head         = NULL;
        src->tail         = NULL;
        src->thread_count = 0;
    }

    spinlock_release(&s_sched_lock);
}
