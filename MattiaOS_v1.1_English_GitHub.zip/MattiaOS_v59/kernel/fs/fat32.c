#include "fat32.h"
#include "../mm/slab.h"
#include "../include/errno.h"

/* FAT32 is READ-ONLY. Write operations return -EROFS (from errno.h). */

typedef struct {
    fat32_bpb_t  bpb;
    uint32_t     fat_start;      /* LBA of first FAT */
    uint32_t     data_start;     /* LBA of first data cluster */
    uint32_t     root_cluster;
    uint8_t     *fat_cache;      /* In-memory FAT */
    uint32_t     fat_sectors;
    /* Block device callbacks provided at mount time */
    int          (*read_sectors)(uint32_t lba, uint32_t count, void *buf);
} fat32_fs_t;

typedef struct {
    fat32_fs_t  *fs;
    uint32_t     first_cluster;
    uint32_t     cur_cluster;
    uint32_t     size;
} fat32_file_data_t;

static inline void *fm_memset(void *d, int c, size_t n) {
    uint8_t *p=(uint8_t*)d; while(n--)*p++=(uint8_t)c; return d;
}
static inline void *fm_memcpy(void *d, const void *s, size_t n) {
    uint8_t *dd=(uint8_t*)d; const uint8_t *ss=(const uint8_t*)s;
    while(n--) { *dd++=*ss++; } return d;
}
static inline size_t fm_strlen(const char *s){size_t n=0;while(s[n])n++;return n;}
static inline int fm_strncmp(const char *a, const char *b, size_t n) {
    while(n--&&*a&&*a==*b){a++;b++;} return (n+1)? (unsigned char)*a-(unsigned char)*b : 0;
}
static inline void fm_strncpy(char *d, const char *s, size_t n) {
    size_t i=0; while(i<n-1&&s[i]){d[i]=s[i];i++;} d[i]='\0';
}

static uint32_t fat32_next_cluster(fat32_fs_t *fs, uint32_t cluster) {
    if (!fs->fat_cache) return 0x0FFFFFFF;
    uint32_t offset = cluster * 4;
    uint32_t sector = offset / FAT32_SECTOR_SIZE;
    uint32_t off    = offset % FAT32_SECTOR_SIZE;
    if (sector >= fs->fat_sectors) return 0x0FFFFFFF;
    uint32_t val;
    fm_memcpy(&val, fs->fat_cache + sector * FAT32_SECTOR_SIZE + off, 4);
    return val & 0x0FFFFFFF;
}

static ssize_t fat32_read(vnode_t *node, void *buf, size_t count, off_t offset) {
    fat32_file_data_t *fd = (fat32_file_data_t*)node->fs_data;
    if (!fd) return EINVAL;
    if ((uint64_t)offset >= fd->size) return 0;

    fat32_fs_t *fs = fd->fs;
    size_t avail = (size_t)(fd->size - (uint32_t)offset);
    size_t to_read = count < avail ? count : avail;

    uint32_t bpc = (uint32_t)fs->bpb.sectors_per_cluster * FAT32_SECTOR_SIZE;
    uint32_t cluster_idx  = (uint32_t)offset / bpc;
    uint32_t cluster_off  = (uint32_t)offset % bpc;

    /* Walk cluster chain to cluster_idx */
    uint32_t cluster = fd->first_cluster;
    for (uint32_t i = 0; i < cluster_idx; i++) {
        cluster = fat32_next_cluster(fs, cluster);
        if (cluster >= FAT32_EOC) return 0;
    }

    uint8_t *dst = (uint8_t*)buf;
    size_t   done = 0;
    uint8_t *sector_buf = (uint8_t*)kmalloc(FAT32_SECTOR_SIZE);
    if (!sector_buf) return ENOMEM;

    while (done < to_read && cluster < FAT32_EOC) {
        uint32_t lba = fs->data_start + (cluster - 2) * fs->bpb.sectors_per_cluster;
        uint32_t sec_off = cluster_off / FAT32_SECTOR_SIZE;
        uint32_t byte_off = cluster_off % FAT32_SECTOR_SIZE;

        for (uint32_t s = sec_off;
             s < fs->bpb.sectors_per_cluster && done < to_read; s++) {
            if (fs->read_sectors(lba + s, 1, sector_buf) < 0) {
                kfree(sector_buf);
                return (ssize_t)done;
            }
            size_t copy = FAT32_SECTOR_SIZE - byte_off;
            if (copy > to_read - done) copy = to_read - done;
            fm_memcpy(dst + done, sector_buf + byte_off, copy);
            done     += copy;
            byte_off  = 0;
            cluster_off += (uint32_t)copy;
        }

        if (done < to_read) {
            cluster     = fat32_next_cluster(fs, cluster);
            cluster_off = 0;
        }
    }

    kfree(sector_buf);
    return (ssize_t)done;
}

static ssize_t fat32_write(vnode_t *n, const void *b, size_t c, off_t o) {
    (void)n;(void)b;(void)c;(void)o; return EROFS;
}
static int fat32_create(vnode_t *p, const char *n, mode_t m) {
    (void)p;(void)n;(void)m; return EROFS;
}
static int fat32_mkdir_op(vnode_t *p, const char *n, mode_t m) {
    (void)p;(void)n;(void)m; return EROFS;
}
static int fat32_unlink_op(vnode_t *p, const char *n) {
    (void)p;(void)n; return EROFS;
}

static vfs_ops_t s_fat32_ops = {
    .open=NULL,.close=NULL,
    .read=fat32_read, .write=fat32_write,
    .readdir=NULL,   /* populated for directory vnode */
    .stat=NULL,
    .create=fat32_create, .mkdir=fat32_mkdir_op, .unlink=fat32_unlink_op,
    .mmap=NULL,.ioctl=NULL
};

vnode_t *fat32_mount(const char *device) {
    /*
     * Real implementation reads sector 0 via block device.
     * For now, return to stub root vnode so the driver is registered.
     */
    (void)device;
    vnode_t *root = (vnode_t*)kzalloc(sizeof(vnode_t));
    if (!root) return NULL;
    root->inode   = 0xFA732;
    root->mode    = 0x41ED;
    root->ops     = &s_fat32_ops;
    root->name[0] = '/'; root->name[1] = '\0';
    return root;
}

void fat32_unmount(vnode_t *root) {
    if (!root) return;
    fat32_fs_t *fs = (fat32_fs_t*)root->fs_data;
    if (fs) {
        if (fs->fat_cache) kfree(fs->fat_cache);
        kfree(fs);
    }
    kfree(root);
}

static filesystem_t s_fat32 = {
    .name    = "fat32",
    .mount   = fat32_mount,
    .unmount = fat32_unmount,
    .next    = NULL,
};

filesystem_t *fat32_get_fs(void) { return &s_fat32; }
