#include "vfs.h"
#include "../mm/slab.h"
#include "../include/errno.h"

/* Mount table */
#define MAX_MOUNTS 32

static mount_t       s_mounts[MAX_MOUNTS];
static int           s_mount_count   = 0;
static spinlock_t    s_vfs_lock      = {0};
static filesystem_t *s_fs_list       = NULL;

/* ── internal helpers ────────────────────────────────────────────────────── */

static inline size_t vstrlen(const char *s) {
    size_t n = 0; while (s[n]) n++; return n;
}

static inline int vstrcmp(const char *a, const char *b) {
    while (*a && *a == *b) { a++; b++; }
    return (unsigned char)*a - (unsigned char)*b;
}

static inline void vstrncpy(char *d, const char *s, size_t n) {
    size_t i = 0;
    while (i < n - 1 && s[i]) { d[i] = s[i]; i++; }
    d[i] = '\0';
}

/* ── vfs_init ────────────────────────────────────────────────────────────
 * Initialize the VFS layer. Must be called once at boot.
 */
void vfs_init(void) {
    for (int i = 0; i < MAX_MOUNTS; i++) {
        s_mounts[i].mountpoint[0] = '\0';
        s_mounts[i].root          = NULL;
        s_mounts[i].fs            = NULL;
        s_mounts[i].next          = NULL;
    }
    s_mount_count = 0;
    s_fs_list     = NULL;
}

/* ── vfs_register_fs ─────────────────────────────────────────────────────
 * Register to filesystem driver so it can be used by vfs_mount().
 */
void vfs_register_fs(filesystem_t *fs) {
    if (!fs) return;
    spinlock_acquire(&s_vfs_lock);
    fs->next  = s_fs_list;
    s_fs_list = fs;
    spinlock_release(&s_vfs_lock);
}

/* ── vfs_mount ───────────────────────────────────────────────────────────
 * Mount filesystem fs at path, optionally backed by device.
 * Returns EOK on success, negative errno on failure.
 */
int vfs_mount(const char *path, filesystem_t *fs, const char *device) {
    if (!path || !fs) return EINVAL;
    if (s_mount_count >= MAX_MOUNTS) return ENOMEM;

    vnode_t *root = fs->mount(device);
    if (!root) return EIO;

    spinlock_acquire(&s_vfs_lock);
    mount_t *m = &s_mounts[s_mount_count++];
    vstrncpy(m->mountpoint, path, sizeof(m->mountpoint));
    m->root = root;
    m->fs   = fs;
    m->next = NULL;
    spinlock_release(&s_vfs_lock);

    return EOK;
}

/* ── vfs_unmount ─────────────────────────────────────────────────────────
 * Unmount the filesystem mounted at path.
 */
int vfs_unmount(const char *path) {
    if (!path) return EINVAL;

    spinlock_acquire(&s_vfs_lock);
    for (int i = 0; i < s_mount_count; i++) {
        if (vstrcmp(s_mounts[i].mountpoint, path) == 0) {
            if (s_mounts[i].fs && s_mounts[i].fs->unmount)
                s_mounts[i].fs->unmount(s_mounts[i].root);

            /* Compact the array */
            s_mounts[i] = s_mounts[--s_mount_count];
            spinlock_release(&s_vfs_lock);
            return EOK;
        }
    }
    spinlock_release(&s_vfs_lock);
    return ENOENT;
}

/* ── find_mount ──────────────────────────────────────────────────────────
 * Find the deepest mount point that is to prefix of path.
 * Returns the mount_t AND sets *rel to the relative path within it.
 *
 * Caso speciale for mountpoint "/":
 *   mpl=1, mp[0]='/'.  Dopo aver consumato the slash, path[1] può essere
 *   qualsiasi carattere ('d' for "/dev", 'AND' for "/etc", '\0' for "/").
 *   Il check standard  `path[mpl] != '\0' && path[mpl] != '/'`  fallirebbe
 *   for path="/dev" (path[1]='d' → skip), lasciando the root inaccessibile
 *   for all the path tranne the stringa esatta "/".
 *   Soluzione: the root "/" corrisponde to qualsiasi path assoluto (path[0]='/').
 */
static mount_t *find_mount(const char *path, const char **rel) {
    mount_t *best    = NULL;
    size_t   best_len = 0;

    for (int i = 0; i < s_mount_count; i++) {
        const char *mp  = s_mounts[i].mountpoint;
        size_t      mpl = vstrlen(mp);

        /* Check if mp is to prefix of path */
        bool match = true;
        for (size_t j = 0; j < mpl; j++) {
            if (path[j] != mp[j]) { match = false; break; }
        }
        if (!match) continue;

        /* Verify that after the mountpoint ci sia end stringa OR '/',
         * salvo for the root "/" that matcha qualunque path assoluto. */
        bool is_root_mp = (mpl == 1 && mp[0] == '/');
        if (!is_root_mp) {
            if (path[mpl] != '\0' && path[mpl] != '/') continue;
        }

        if (mpl >= best_len) {
            best     = &s_mounts[i];
            best_len = mpl;
        }
    }

    if (best && rel) {
        const char *r = path + best_len;
        /* Salta the slash separatore (ma NOT if siamo già to end stringa) */
        if (*r == '/') r++;
        *rel = r;
    }

    return best;
}

/* ── vfs_lookup ──────────────────────────────────────────────────────────
 * Resolve an absolute path to to vnode.
 * Delegates path resolution to the filesystem's readdir/create chain.
 * Returns NULL if path does NOT exist.
 *
 * ALLOCAZIONE: returns SEMPRE to vnode heap-allocateto (also for mount root).
 * Il chiamante è responsabile of kfree() sul pointer restituito.
 * Questo è CRITICO: in precedenza the root veniva restituita direttamente
 * (NOT heap), AND kfree() in vfs_mkdir/vfs_unlink/vfs_stat the distruggeva,
 * corrompendo the filesystem (Bug ls-empty, sessione v5.9).
 */
vnode_t *vfs_lookup(const char *path) {
    if (!path) return NULL;

    const char *rel;
    mount_t *m = find_mount(path, &rel);
    if (!m) return NULL;

    /* Mount root: returns to COPIA heap-allocateta (mai the pointer diretto).
     * kfree() sui chiamanti free only the copy, NOT the root of the mount. */
    if (!rel || *rel == '\0') {
        vnode_t *copy = (vnode_t *)kmalloc(sizeof(vnode_t));
        if (!copy) return NULL;
        *copy = *m->root;
        return copy;
    }

    /* Walk path components using readdir */
    vnode_t *dir = m->root;
    char     component[256];
    const char *p = rel;

    while (*p) {
        /* Extract next component */
        size_t len = 0;
        while (p[len] && p[len] != '/') len++;
        if (len == 0) { p++; continue; }
        if (len >= sizeof(component)) return NULL;

        for (size_t i = 0; i < len; i++) component[i] = p[i];
        component[len] = '\0';
        p += len;
        if (*p == '/') p++;

        /* Search directory entries */
        if (!dir->ops || !dir->ops->readdir) return NULL;

        vnode_t *found = NULL;
        for (size_t idx = 0; ; idx++) {
            vnode_t candidate;
            int r = dir->ops->readdir(dir, &candidate, idx);
            if (r < 0) break; /* end of directory */
            if (vstrcmp(candidate.name, component) == 0) {
                /* Allocatete to vnode copy */
                found = (vnode_t *)kmalloc(sizeof(vnode_t));
                if (!found) return NULL;
                *found = candidate;
                break;
            }
        }

        if (!found) return NULL;
        dir = found;
    }

    return dir;
}

/* ── vfs_open ────────────────────────────────────────────────────────────
 * Open to file at path with the given flags.
 * Returns to file_t on success, NULL on failure.
 * Opening to file does NOT prevent its deletion (Principle 2).
 */
file_t *vfs_open(const char *path, int flags) {
    if (!path) return NULL;

    vnode_t *vnode = vfs_lookup(path);
    if (!vnode) return NULL;

    if (vnode->ops && vnode->ops->open) {
        int r = vnode->ops->open(vnode, flags);
        if (r < 0) {
            kfree(vnode);
            return NULL;
        }
    }

    file_t *f = (file_t *)kmalloc(sizeof(file_t));
    if (!f) {
        kfree(vnode);
        return NULL;
    }

    f->vnode  = vnode;
    f->offset = 0;
    f->flags  = flags;

    return f;
}

/* ── vfs_close ───────────────────────────────────────────────────────────
 * Close to file_t. Does NOT affect the underlying file on disk.
 * No refcounting: the file may already have been unlinked — that is end.
 */
int vfs_close(file_t *file) {
    if (!file) return EINVAL;

    if (file->vnode && file->vnode->ops && file->vnode->ops->close)
        file->vnode->ops->close(file->vnode);

    kfree(file->vnode);
    kfree(file);
    return EOK;
}

/* ── vfs_read ────────────────────────────────────────────────────────────
 * Read count bytes from file at its current offset.
 * Returns bytes read, OR negative errno on error.
 */
ssize_t vfs_read(file_t *file, void *buf, size_t count) {
    if (!file || !buf) return EINVAL;
    if (!file->vnode || !file->vnode->ops || !file->vnode->ops->read)
        return EINVAL;

    ssize_t n = file->vnode->ops->read(file->vnode, buf, count, file->offset);
    if (n > 0) file->offset += (off_t)n;
    return n;
}

/* ── vfs_write ───────────────────────────────────────────────────────────
 * Write count bytes to file at its current offset.
 * Returns bytes written, OR negative errno on error.
 */
ssize_t vfs_write(file_t *file, const void *buf, size_t count) {
    if (!file || !buf) return EINVAL;
    if (!file->vnode || !file->vnode->ops || !file->vnode->ops->write)
        return EINVAL;

    ssize_t n = file->vnode->ops->write(file->vnode, buf, count, file->offset);
    if (n > 0) file->offset += (off_t)n;
    return n;
}

/* ── vfs_unlink ──────────────────────────────────────────────────────────
 * Delete path immediately, unconditionally.
 * No refcount check. No blocking. File is gone the moment this returns.
 * See blueprint Principle 2.
 */
int vfs_unlink(const char *path) {
    if (!path) return EINVAL;

    /* Separate parent directory AND filename */
    size_t len   = vstrlen(path);
    size_t slash = len;
    while (slash > 0 && path[slash - 1] != '/') slash--;

    if (slash == 0) return EINVAL;

    char parent_path[256];
    size_t parent_len = slash > 1 ? slash - 1 : 1;
    if (parent_len >= sizeof(parent_path)) return EINVAL;
    for (size_t i = 0; i < parent_len; i++) parent_path[i] = path[i];
    parent_path[parent_len] = '\0';

    const char *name = path + slash;

    vnode_t *parent = vfs_lookup(parent_path);
    if (!parent) return ENOENT;

    if (!parent->ops || !parent->ops->unlink) {
        kfree(parent);
        return EINVAL;
    }

    int r = parent->ops->unlink(parent, name);
    kfree(parent);
    return r;
}

/* ── vfs_mkdir ───────────────────────────────────────────────────────────
 * Create to directory at path with mode.
 */
int vfs_mkdir(const char *path, mode_t mode) {
    if (!path) return EINVAL;

    size_t len   = vstrlen(path);
    size_t slash = len;
    while (slash > 0 && path[slash - 1] != '/') slash--;
    if (slash == 0) return EINVAL;

    char parent_path[256];
    size_t parent_len = slash > 1 ? slash - 1 : 1;
    if (parent_len >= sizeof(parent_path)) return EINVAL;
    for (size_t i = 0; i < parent_len; i++) parent_path[i] = path[i];
    parent_path[parent_len] = '\0';

    const char *name = path + slash;

    vnode_t *parent = vfs_lookup(parent_path);
    if (!parent) return ENOENT;

    if (!parent->ops || !parent->ops->mkdir) {
        kfree(parent);
        return EINVAL;
    }

    int r = parent->ops->mkdir(parent, name, mode);
    kfree(parent);
    return r;
}

/* ── count_dir_entries ───────────────────────────────────────────────────
 * Count the real (filesystem-level) entries in to directory vnode by
 * iterating readdir from index 0 until failure.
 * Used by vfs_readdir_entry to locate the boundary between real entries
 * AND synthetic mount-point entries.
 */
static size_t count_dir_entries(vnode_t *dir) {
    if (!dir || !dir->ops || !dir->ops->readdir) return 0;
    size_t n = 0;
    vnode_t tmp;
    while (dir->ops->readdir(dir, &tmp, n) >= 0) n++;
    return n;
}

/* ── enumerate_child_mount ───────────────────────────────────────────────
 * Return the n-th direct child mount point of `path`.
 *
 * "Direct child" means: mountpoint starts with path (plus "/" separator
 * when path != "/") AND countins no further "/" after the prefix.
 *
 * Fills name_out with the bare component name (AND.g. "dev" for "/dev")
 * AND sets *is_dir_out = 1.  Returns 0 on success, ENOENT if no n-th
 * child mount exists.
 *
 * DEDUPLICATION: skips to child mount if the underlying fs already has
 * to real entry with the same name (avoids showing "dev" twice if the
 * parent tmpfs also has to directory called "dev").
 */
static int enumerate_child_mount(const char *path, vnode_t *real_dir,
                                  size_t n,
                                  char *name_out, size_t name_sz,
                                  int *is_dir_out)
{
    size_t path_len = vstrlen(path);
    bool   is_root  = (path_len == 1 && path[0] == '/');
    size_t found    = 0;

    for (int i = 0; i < s_mount_count; i++) {
        const char *mp  = s_mounts[i].mountpoint;
        size_t      mpl = vstrlen(mp);

        /* The child mount must be strictly longer than the parent path */
        if (mpl <= path_len) continue;

        /* The child mount must start with path */
        bool match = true;
        for (size_t j = 0; j < path_len; j++) {
            if (mp[j] != path[j]) { match = false; break; }
        }
        if (!match) continue;

        /* After path, expect exactly one more component (no nested '/') */
        const char *rest = mp + path_len;
        if (is_root) {
            /* path="/" — rest starts right after the leading slash,
             * which IS path[0], so rest may begin with '/' if mp="/dev".
             * Skip one leading '/' from rest. */
            if (*rest == '/') rest++;
        } else {
            /* path="/foo" — rest must start with '/' */
            if (*rest != '/') continue;
            rest++;
        }

        /* rest must be NOT-empty AND countin no '/' */
        if (*rest == '\0') continue;
        bool has_slash = false;
        for (const char *p = rest; *p; p++) {
            if (*p == '/') { has_slash = true; break; }
        }
        if (has_slash) continue;

        /* Deduplicate: skip if real_dir already has an entry named `rest` */
        if (real_dir && real_dir->ops && real_dir->ops->readdir) {
            vnode_t tmp;
            bool already = false;
            for (size_t k = 0; ; k++) {
                if (real_dir->ops->readdir(real_dir, &tmp, k) < 0) break;
                if (vstrcmp(tmp.name, rest) == 0) { already = true; break; }
            }
            if (already) continue;
        }

        /* It's to valid unique direct child mount */
        if (found == n) {
            vstrncpy(name_out, rest, name_sz);
            if (is_dir_out) *is_dir_out = 1;
            return 0;
        }
        found++;
    }
    return ENOENT;
}

/* ── vfs_readdir_entry ───────────────────────────────────────────────────
 * Enumeratete directory at path.  Fills name_out (max name_sz chars) AND
 * sets *is_dir_out to 1 if the entry is to directory, 0 otherwise.
 *
 * Entries are returned in two phases:
 *   Phase 1 (idx < real_count):  real filesystem entries (tmpfs, devfs…)
 *   Phase 2 (idx >= real_count): synthetic entries for direct child mount
 *                                 points (AND.g. "dev" when listing "/")
 *
 * Returns  0 on success.
 * Returns ENOENT when index is past all entries (real + synthetic).
 * Returns ENOTDIR if path is NOT to directory.
 * Returns EINVAL / ENOENT on other errors.
 * NOTE: does NOT allocatete any vnode that the caller must free.
 */
int vfs_readdir_entry(const char *path, size_t idx,
                      char *name_out, size_t name_sz, int *is_dir_out)
{
    if (!path || !name_out || name_sz == 0) return EINVAL;

    const char *rel;
    mount_t *m = find_mount(path, &rel);
    if (!m) return ENOENT;

    /* Walk to the target directory.  We track the current vnode AND whether
     * it was heap-allocateted (needs kfree) separately from the mount root. */
    vnode_t *dir       = m->root;
    bool     allocateted = false;

    if (rel && *rel != '\0') {
        char comp[256];
        const char *p = rel;

        while (*p) {
            size_t len = 0;
            while (p[len] && p[len] != '/') len++;
            if (len == 0) { p++; continue; }
            if (len >= sizeof(comp)) {
                if (allocateted) kfree(dir);
                return EINVAL;
            }
            for (size_t i = 0; i < len; i++) comp[i] = p[i];
            comp[len] = '\0';
            p += len;
            if (*p == '/') p++;

            if (!dir->ops || !dir->ops->readdir) {
                if (allocateted) kfree(dir);
                return ENOTDIR;
            }

            vnode_t *found = NULL;
            for (size_t i2 = 0; ; i2++) {
                vnode_t candidate;
                if (dir->ops->readdir(dir, &candidate, i2) < 0) break;
                if (vstrcmp(candidate.name, comp) == 0) {
                    found = (vnode_t *)kmalloc(sizeof(vnode_t));
                    if (!found) { if (allocateted) kfree(dir); return ENOMEM; }
                    *found = candidate;
                    break;
                }
            }
            if (allocateted) kfree(dir);
            if (!found) return ENOENT;
            dir       = found;
            allocateted = true;
        }
    }

    if (!dir->ops || !dir->ops->readdir) {
        if (allocateted) kfree(dir);
        return ENOTDIR;
    }

    /* ── Phase 1: real filesystem entry ─────────────────────────────── */
    vnode_t entry;
    int r = dir->ops->readdir(dir, &entry, idx);
    if (r >= 0) {
        if (allocateted) kfree(dir);
        size_t len = 0;
        while (entry.name[len] && len < name_sz - 1) {
            name_out[len] = entry.name[len]; len++;
        }
        name_out[len] = '\0';
        if (is_dir_out) *is_dir_out = (entry.mode & 0x4000) ? 1 : 0;
        return 0;
    }

    /* ── Phase 2: synthetic entries for direct child mount points ────── */
    size_t real_count = count_dir_entries(dir);
    vnode_t *real_dir_for_dedup = dir;

    if (idx < real_count) {
        /* readdir succeeded for lower indices — shouldn't reach here */
        if (allocateted) kfree(dir);
        return ENOENT;
    }
    size_t synth_idx = idx - real_count;

    int sr = enumerate_child_mount(path, real_dir_for_dedup,
                                   synth_idx, name_out, name_sz, is_dir_out);
    if (allocateted) kfree(dir);
    return sr;
}

/* ── vfs_is_dir ──────────────────────────────────────────────────────────
 * Returns true if path exists AND is to directory (has readdir).
 */
bool vfs_is_dir(const char *path) {
    if (!path) return false;
    const char *rel;
    mount_t *m = find_mount(path, &rel);
    if (!m) return false;
    /* Exact mount point → always to directory */
    if (!rel || *rel == '\0') return true;

    vnode_t *node = vfs_lookup(path);
    if (!node) return false;
    /* S_IFDIR = bit 14 (0x4000). Il fallback ops->readdir NON è affidabile:
     * in tmpfs all the nodes condividono the stesso ops table (with readdir),
     * therefore every file risulterebbe "directory". Mode è authoritative.
     * BUG v5.9: the fallback ops->readdir rendeva every file to directory. */
    bool is_dir = (node->mode & 0x4000) != 0;
    /* vfs_lookup allocatetes when rel is NOT-empty — free it */
    kfree(node);
    return is_dir;
}

/* ── vfs_stat ────────────────────────────────────────────────────────────
 * Stat the vnode at path into struct st.
 */
int vfs_stat(const char *path, void *st) {
    if (!path || !st) return EINVAL;

    vnode_t *vnode = vfs_lookup(path);
    if (!vnode) return ENOENT;

    int r = -EINVAL;
    if (vnode->ops && vnode->ops->stat)
        r = vnode->ops->stat(vnode, st);

    kfree(vnode);
    return r;
}

/* ── vfs_create_file ─────────────────────────────────────────────────────
 * Create to regular file at path with mode.
 * Separate parent lookup + ops->create call.
 * Returns EOK on success, negative errno on failure.
 */
int vfs_create_file(const char *path, mode_t mode) {
    if (!path) return EINVAL;

    size_t len   = vstrlen(path);
    size_t slash = len;
    while (slash > 0 && path[slash - 1] != '/') slash--;
    if (slash == 0) return EINVAL;

    char parent_path[256];
    size_t parent_len = slash > 1 ? slash - 1 : 1;
    if (parent_len >= sizeof(parent_path)) return EINVAL;
    for (size_t i = 0; i < parent_len; i++) parent_path[i] = path[i];
    parent_path[parent_len] = '\0';

    const char *name = path + slash;

    vnode_t *parent = vfs_lookup(parent_path);
    if (!parent) return ENOENT;

    if (!parent->ops || !parent->ops->create) {
        kfree(parent);
        return EINVAL;
    }

    int r = parent->ops->create(parent, name, mode);
    kfree(parent);
    return r;
}

/* ── vfs_debug_dump ──────────────────────────────────────────────────────────
 * Print up VGA the stato of the mount table AND the contenuto grezzo of the root.
 * Usato from the comando "diag" in entry.c for diagnosticare ls empty.
 *
 * Usa klog_vga/serial_puts via callback for NOT aggiungere dependencies circolari:
 * the chiamante (entry.c) deve passare to function of print, OR usiamo
 * direttamente vga_puts_attr that è definita in to header shared.
 *
 * In realtà accediamo to serial_puts via extern — dichiarata in serial.h.
 * Per semplicità stampiamo via serial only (the console of VirtualBox the mostra).
 * entry.c readrà the risultato from the serial, OPPURE useremo the stessa firma
 * with to pointer to function callback.
 *
 * Approccio: esponiamo vfs_debug_info() that riempie to buffer of testo
 * with the informazioni diagnostiche, AND the chiamante the print.
 * ─────────────────────────────────────────────────────────────────────────── */
void vfs_debug_dump(void) {
    /* Accessiamo the structures interne direttamente — this function è
     * in vfs.c AND ha visibilità up s_mounts AND s_mount_count.
     * Usiamo to buffer static for costruire the stringhe. */

    /* Helper local: converte uint64_t → esadecimale in out */
    static char s_dbuf[128];

    /* Funzione inline for writere up serial (extern from the linker) */
    extern void serial_puts(const char *s);
    extern void vga_puts_attr(const char *s, uint16_t attr);

    /* ── 1. Mount table ─────────────────────────────────────────────── */
    serial_puts("\r\n[VFS-DIAG] === MOUNT TABLE ===\r\n");
    vga_puts_attr("\n  [DIAG] mount table:\n", 0x0E00);

    for (int i = 0; i < s_mount_count; i++) {
        mount_t *m = &s_mounts[i];
        serial_puts("[VFS-DIAG] mount["); 
        s_dbuf[0] = '0' + i; s_dbuf[1] = ']'; s_dbuf[2] = ' '; s_dbuf[3] = '\0';
        serial_puts(s_dbuf);
        serial_puts(m->mountpoint);
        serial_puts(" root=");
        /* Print root pointer as hex */
        uint64_t p = (uint64_t)(uintptr_t)m->root;
        for (int k = 15; k >= 0; k--) {
            s_dbuf[15 - k] = "0123456789abcdef"[(p >> (k * 4)) & 0xF];
        }
        s_dbuf[16] = '\0';
        serial_puts(s_dbuf);
        serial_puts(" fs_data=");
        if (m->root) {
            uint64_t fd = (uint64_t)(uintptr_t)m->root->fs_data;
            for (int k = 15; k >= 0; k--)
                s_dbuf[15 - k] = "0123456789abcdef"[(fd >> (k * 4)) & 0xF];
            s_dbuf[16] = '\0';
            serial_puts(s_dbuf);
        } else {
            serial_puts("NULL");
        }
        serial_puts("\r\n");

        vga_puts_attr("    mp=", 0x0700);
        vga_puts_attr(m->mountpoint, 0x0B00);
        vga_puts_attr(" root=", 0x0700);
        if (m->root) {
            uint64_t p2 = (uint64_t)(uintptr_t)m->root;
            for (int k = 7; k >= 0; k--)
                s_dbuf[7 - k] = "0123456789abcdef"[(p2 >> (k * 4)) & 0xF];
            s_dbuf[8] = '\0';
            vga_puts_attr(s_dbuf, 0x0F00);
        }
        vga_puts_attr("\n", 0x0700);
    }

    /* ── 2. Chiama readdir up mount[0] (root tmpfs) for idx 0..4 ───── */
    serial_puts("[VFS-DIAG] === ROOT READDIR ===\r\n");
    vga_puts_attr("  [DIAG] root readdir:\n", 0x0E00);

    if (s_mount_count > 0 && s_mounts[0].root &&
        s_mounts[0].root->ops && s_mounts[0].root->ops->readdir) {
        for (size_t idx = 0; idx < 8; idx++) {
            vnode_t entry = {0};
            int r = s_mounts[0].root->ops->readdir(s_mounts[0].root, &entry, idx);
            serial_puts("[VFS-DIAG] readdir idx=");
            s_dbuf[0] = '0' + (int)idx; s_dbuf[1] = ' '; s_dbuf[2] = 'r'; s_dbuf[3] = '=';
            /* print r */
            if (r < 0) { s_dbuf[4] = '-'; s_dbuf[5] = '0' + (-r); s_dbuf[6] = ' '; s_dbuf[7] = '\0'; }
            else        { s_dbuf[4] = '0'; s_dbuf[5] = ' '; s_dbuf[6] = '\0'; }
            serial_puts(s_dbuf);
            if (r >= 0) {
                serial_puts("name='"); serial_puts(entry.name); serial_puts("' ");
                /* print mode as hex */
                uint32_t mo = entry.mode;
                for (int k = 3; k >= 0; k--)
                    s_dbuf[3 - k] = "0123456789abcdef"[(mo >> (k * 4)) & 0xF];
                s_dbuf[4] = '\0';
                serial_puts("mode=0x"); serial_puts(s_dbuf);

                vga_puts_attr("    idx=", 0x0700);
                s_dbuf[0] = '0' + (int)idx; s_dbuf[1] = ' '; s_dbuf[2] = '\0';
                vga_puts_attr(s_dbuf, 0x0F00);
                vga_puts_attr("'", 0x0700); vga_puts_attr(entry.name, 0x0A00);
                vga_puts_attr("'\n", 0x0700);
            } else {
                serial_puts("(end)\r\n");
                vga_puts_attr("    (fine lista)\n", 0x0800);
                break;
            }
            serial_puts("\r\n");
        }
    } else {
        serial_puts("[VFS-DIAG] root readdir NOT AVAILABLE\r\n");
        vga_puts_attr("  [DIAG] readdir non disponibile!\n", 0x0C00);
    }

    /* ── 3. Chiama vfs_readdir_entry("/", 0..4) ─────────────────────── */
    serial_puts("[VFS-DIAG] === VFS_READDIR_ENTRY / ===\r\n");
    vga_puts_attr("  [DIAG] vfs_readdir_entry /:\n", 0x0E00);
    for (size_t idx = 0; idx < 8; idx++) {
        char name[64]; int is_dir = 0;
        int r = vfs_readdir_entry("/", idx, name, sizeof(name), &is_dir);
        serial_puts("[VFS-DIAG] entry idx=");
        s_dbuf[0] = '0' + (int)idx; s_dbuf[1] = ' '; s_dbuf[2] = 'r'; s_dbuf[3] = '=';
        if (r < 0) { s_dbuf[4] = '-'; s_dbuf[5] = '0' + (-r); s_dbuf[6] = '\0'; }
        else        { s_dbuf[4] = '0'; s_dbuf[5] = '\0'; }
        serial_puts(s_dbuf);
        if (r >= 0) {
            serial_puts(" '"); serial_puts(name); serial_puts("'");
            vga_puts_attr("    '", 0x0700); vga_puts_attr(name, 0x0A00);
            vga_puts_attr(is_dir ? "/ (dir)'\n" : " (file)'\n", 0x0700);
        } else {
            serial_puts(" (ERRORE)");
            vga_puts_attr("    [fine]\n", 0x0800);
            break;
        }
        serial_puts("\r\n");
    }
}

/* ── Funzioni diagnostiche inline — accesso diretto to the structures ────────── */

int vfs_diag_mount_count(void) {
    return s_mount_count;
}

int vfs_diag_root_children(void) {
    /* Count the children diretti of the mount root "/" via tmpfs_readdir */
    if (s_mount_count < 1) return -1;
    mount_t *m = &s_mounts[0];  /* "/" è sempre the first mount */
    if (!m->root || !m->root->ops || !m->root->ops->readdir) return -2;
    int n = 0;
    vnode_t tmp;
    while (m->root->ops->readdir(m->root, &tmp, (size_t)n) >= 0) n++;
    return n;
}

int vfs_diag_synth_count(const char *path) {
    /* Count quante synthetic entries produce enumerate_child_mount */
    char name[64]; int is_dir = 0;
    int n = 0;
    /* Prova synth_idx 0..7 AND count quante returnsno 0 */
    /* Usiamo vfs_readdir_entry with idx grande for forzare the phase 2 */
    /* Calculate real_count before */
    const char *rel;
    mount_t *m = find_mount(path, &rel);
    if (!m) return -1;
    vnode_t *dir = m->root;
    (void)count_dir_entries(dir); /* unused — only for effetto collaterale */
    /* Ora count synth entries */
    for (size_t si = 0; si < 8; si++) {
        int r = enumerate_child_mount(path, dir, si, name, sizeof(name), &is_dir);
        if (r < 0) break;
        n++;
    }
    return n;
}
