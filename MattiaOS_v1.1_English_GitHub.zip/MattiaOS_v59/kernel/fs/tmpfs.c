#include "tmpfs.h"
#include "../mm/slab.h"
#include "../include/errno.h"

/* Maximum file data held in to single tmpfs node */
#define TMPFS_MAX_FILE_SIZE (64 * 1024 * 1024ULL)  /* 64 MB */

/* Internal node type */
typedef enum { TMPFS_FILE, TMPFS_DIR } tmpfs_type_t;

typedef struct tmpfs_node {
    vnode_t         vnode;
    tmpfs_type_t    type;
    uint8_t        *data;       /* file data buffer */
    uint64_t        capacity;   /* allocateted capacity */
    struct tmpfs_node *children; /* linked list for dirs */
    struct tmpfs_node *next;     /* sibling link */
    struct tmpfs_node *parent;
} tmpfs_node_t;

/* ── helper ── */
static inline void *tm_memset(void *d, int c, size_t n) {
    uint8_t *p = (uint8_t*)d; while(n--) *p++ = (uint8_t)c; return d;
}
static inline void *tm_memcpy(void *d, const void *s, size_t n) {
    uint8_t *dd=(uint8_t*)d; const uint8_t *ss=(const uint8_t*)s;
    while(n--) { *dd++ = *ss++; } return d;
}
static inline size_t tm_strlen(const char *s) { size_t n=0; while(s[n]) n++; return n; }
static inline int tm_strcmp(const char *a, const char *b) {
    while(*a && *a==*b){a++;b++;} return (unsigned char)*a-(unsigned char)*b;
}
static inline void tm_strncpy(char *d, const char *s, size_t n) {
    size_t i=0; while(i<n-1&&s[i]){d[i]=s[i];i++;} d[i]='\0';
}

/* Forward declaration — l'istanza è definita after all the op */
static vfs_ops_t s_tmpfs_ops;

/* ── ops ── */

static ssize_t tmpfs_read(vnode_t *node, void *buf, size_t count, off_t offset) {
    tmpfs_node_t *n = (tmpfs_node_t*)node->fs_data;
    if (!n || n->type != TMPFS_FILE) return EINVAL;
    /* CRITICO: usa n->vnode.size (the size canonica nel node reale),
     * NON node->size that è to copy heap-allocateta from vfs_lookup AND può
     * essere stale (=0) if the file è stato scritto in to sessione previous.
     * BUG: tmpfs_write aggiornava only the copy → rilettura restituiva 0. */
    uint64_t real_size = n->vnode.size;
    if ((uint64_t)offset >= real_size) return 0;
    size_t avail = (size_t)(real_size - (uint64_t)offset);
    size_t to_read = count < avail ? count : avail;
    tm_memcpy(buf, n->data + offset, to_read);
    return (ssize_t)to_read;
}

static ssize_t tmpfs_write(vnode_t *node, const void *buf, size_t count, off_t offset) {
    tmpfs_node_t *n = (tmpfs_node_t*)node->fs_data;
    if (!n || n->type != TMPFS_FILE) return EINVAL;

    uint64_t end = (uint64_t)offset + count;
    if (end > TMPFS_MAX_FILE_SIZE) return EFBIG;

    if (end > n->capacity) {
        uint64_t new_cap = end + 4096;
        uint8_t *new_data = (uint8_t*)kmalloc((size_t)new_cap);
        if (!new_data) return ENOMEM;
        if (n->data) {
            tm_memcpy(new_data, n->data, (size_t)n->capacity);
            kfree(n->data);
        }
        n->data     = new_data;
        n->capacity = new_cap;
    }

    tm_memcpy(n->data + offset, buf, count);
    /* CRITICO: aggiorna ENTRAMBI:
     * 1. n->vnode.size  — the size canonica nel node reale (persiste tra open/close)
     * 2. node->size     — the copy heap-allocateta current (coerenza sessione)
     * BUG ORIGINALE: only node->size veniva aggiornato → n->vnode.size restava 0
     * → to the prossima open, tmpfs_readdir copyva size=0 → file apparentemente empty. */
    if (end > n->vnode.size) {
        n->vnode.size = end;   /* CANONICO — unica fonte of verità */
        node->size    = end;   /* copy current — coerenza for this sessione */
    }
    return (ssize_t)count;
}

static int tmpfs_readdir(vnode_t *node, void *entry_out, size_t index) {
    tmpfs_node_t *dir = (tmpfs_node_t*)node->fs_data;
    if (!dir || dir->type != TMPFS_DIR) return ENOTDIR;

    tmpfs_node_t *child = dir->children;
    size_t i = 0;
    while (child) {
        if (i == index) {
            vnode_t *out = (vnode_t*)entry_out;
            *out = child->vnode;
            return EOK;
        }
        i++;
        child = child->next;
    }
    return ENOENT;
}

static int tmpfs_create(vnode_t *parent, const char *name, mode_t mode) {
    tmpfs_node_t *dir = (tmpfs_node_t*)parent->fs_data;
    if (!dir || dir->type != TMPFS_DIR) return ENOTDIR;

    tmpfs_node_t *node = (tmpfs_node_t*)kzalloc(sizeof(tmpfs_node_t));
    if (!node) return ENOMEM;

    node->type = TMPFS_FILE;
    node->vnode.inode = (uint64_t)(uintptr_t)node;
    node->vnode.size  = 0;
    node->vnode.mode  = mode;
    node->vnode.ops   = &s_tmpfs_ops;   /* FIX v5.9: ops era NULL → crash up vfs_open/stat */
    node->vnode.fs_data = node;
    tm_strncpy(node->vnode.name, name, sizeof(node->vnode.name));
    node->parent = dir;
    node->next   = dir->children;
    dir->children = node;

    return EOK;
}

static int tmpfs_mkdir_op(vnode_t *parent, const char *name, mode_t mode) {
    tmpfs_node_t *dir = (tmpfs_node_t*)parent->fs_data;
    if (!dir || dir->type != TMPFS_DIR) return ENOTDIR;

    tmpfs_node_t *node = (tmpfs_node_t*)kzalloc(sizeof(tmpfs_node_t));
    if (!node) return ENOMEM;

    node->type = TMPFS_DIR;
    node->vnode.inode = (uint64_t)(uintptr_t)node;
    node->vnode.mode  = mode | 0x4000; /* S_IFDIR */
    node->vnode.ops   = &s_tmpfs_ops;   /* FIX v5.9: ops era NULL → ls up subdir falliva */
    node->vnode.fs_data = node;
    tm_strncpy(node->vnode.name, name, sizeof(node->vnode.name));
    node->parent   = dir;
    node->next     = dir->children;
    dir->children  = node;

    return EOK;
}

static int tmpfs_unlink_op(vnode_t *parent, const char *name) {
    tmpfs_node_t *dir = (tmpfs_node_t*)parent->fs_data;
    if (!dir || dir->type != TMPFS_DIR) return ENOTDIR;

    tmpfs_node_t **prev = &dir->children;
    tmpfs_node_t  *cur  = dir->children;
    while (cur) {
        if (tm_strcmp(cur->vnode.name, name) == 0) {
            *prev = cur->next;
            if (cur->data) kfree(cur->data);
            kfree(cur);
            return EOK;
        }
        prev = &cur->next;
        cur  = cur->next;
    }
    return ENOENT;
}

static int tmpfs_stat_op(vnode_t *node, void *st_out) {
    if (!node || !st_out) return EINVAL;
    tmpfs_node_t *n = (tmpfs_node_t*)node->fs_data;
    if (!n) return EINVAL;
    uint64_t *s = (uint64_t *)st_out;
    for (int i = 0; i < 16; i++) s[i] = 0;
    s[1] = node->inode;
    ((uint32_t *)st_out)[4] = node->mode;
    /* CRITICO: usa n->vnode.size (canonica) NOT node->size (copy stale) */
    ((int64_t  *)st_out)[6] = (int64_t)n->vnode.size;
    ((int64_t  *)st_out)[7] = 4096;
    ((int64_t  *)st_out)[8] = (int64_t)((n->vnode.size + 511) / 512);
    return EOK;
}

static vfs_ops_t s_tmpfs_ops = {
    .open    = NULL,
    .close   = NULL,
    .read    = tmpfs_read,
    .write   = tmpfs_write,
    .readdir = tmpfs_readdir,
    .stat    = tmpfs_stat_op,
    .create  = tmpfs_create,
    .mkdir   = tmpfs_mkdir_op,
    .unlink  = tmpfs_unlink_op,
    .mmap    = NULL,
    .ioctl   = NULL,
};

/* ── mount / unmount ── */

static tmpfs_node_t *s_root_node = NULL;

vnode_t *tmpfs_mount(const char *device) {
    (void)device;
    tmpfs_node_t *root = (tmpfs_node_t*)kzalloc(sizeof(tmpfs_node_t));
    if (!root) return NULL;

    root->type = TMPFS_DIR;
    root->vnode.inode   = (uint64_t)(uintptr_t)root;
    root->vnode.mode    = 0x41ED; /* S_IFDIR | 0755 */
    root->vnode.fs_data = root;
    root->vnode.ops     = &s_tmpfs_ops;

    s_root_node = root;
    return &root->vnode;
}

void tmpfs_unmount(vnode_t *root) {
    /* Recursively free all nodes — simplified: just free root for now */
    if (!root) return;
    tmpfs_node_t *n = (tmpfs_node_t*)root->fs_data;
    if (n && n->data) kfree(n->data);
    kfree(n);
}

static filesystem_t s_tmpfs = {
    .name     = "tmpfs",
    .mount    = tmpfs_mount,
    .unmount  = tmpfs_unmount,
    .next     = NULL,
};

filesystem_t *tmpfs_get_fs(void) { return &s_tmpfs; }
