#ifndef MATTIAOS_TMPFS_H
#define MATTIAOS_TMPFS_H

#include "../include/types.h"
#include "vfs.h"

/* tmpfs: RAM-backed filesystem for /tmp, AND early /dev, /proc */

filesystem_t *tmpfs_get_fs(void);
vnode_t      *tmpfs_mount(const char *device);
void          tmpfs_unmount(vnode_t *root);

#endif
