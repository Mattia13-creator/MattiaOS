#ifndef MATTIAOS_SYSCALL_NUMBERS_H
#define MATTIAOS_SYSCALL_NUMBERS_H

#define SYS_READ        0
#define SYS_WRITE       1
#define SYS_OPEN        2
#define SYS_CLOSE       3
#define SYS_STAT        4
#define SYS_FSTAT       5
#define SYS_LSTAT       6
#define SYS_POLL        7
#define SYS_LSEEK       8
#define SYS_MMAP        9
#define SYS_MPROTECT   10
#define SYS_MUNMAP     11
#define SYS_BRK        12
#define SYS_IOCTL      16
#define SYS_READV      19
#define SYS_WRITEV     20
#define SYS_PIPE       22
#define SYS_SELECT     23
#define SYS_DUP        32
#define SYS_DUP2       33
#define SYS_GETPID     39
#define SYS_SOCKET     41
#define SYS_CONNECT    42
#define SYS_ACCEPT     43
#define SYS_SENDTO     44
#define SYS_RECVFROM   45
#define SYS_SENDMSG    46
#define SYS_RECVMSG    47
#define SYS_BIND       49
#define SYS_LISTEN     50
#define SYS_GETSOCKNAME 51
#define SYS_FORK       57
#define SYS_EXECVE     59
#define SYS_EXIT       60
#define SYS_WAIT4      61
#define SYS_KILL       62
#define SYS_UNAME      63
#define SYS_FCNTL      72
#define SYS_MKDIR      83
#define SYS_RMDIR      84
#define SYS_UNLINK     87
#define SYS_RENAME     82
#define SYS_CHMOD      90
#define SYS_CHOWN      92
#define SYS_GETDENTS   78
#define SYS_GETCWD     79
#define SYS_CHDIR      80
#define SYS_MOUNT     165
#define SYS_UMOUNT    166
#define SYS_GETUID    102
#define SYS_GETGID    104
#define SYS_CLOCK_GETTIME 228
#define SYS_THREAD_CREATE 300
#define SYS_THREAD_EXIT   301

#endif

/* Syscall aggiuntive — necessarie for userspace v2.9 */
#define SYS_RT_SIGACTION       13
#define SYS_RT_SIGPROCMASK     14
#define SYS_NANOSLEEP          35
#define SYS_ALARM              37
#define SYS_FSYNC              74
#define SYS_TRUNCATE           76
#define SYS_FTRUNCATE          77
#define SYS_LINK               86
#define SYS_SYMLINK            88
#define SYS_READLINK           89
#define SYS_SYSINFO            99
#define SYS_SETUID            105
#define SYS_SETGID            106
#define SYS_SETPGID           109
#define SYS_GETPPID           110
#define SYS_SETSID            112
#define SYS_GETPGID           121
#define SYS_GETSID            124
#define SYS_STATFS            137
#define SYS_FSTATFS           138
#define SYS_CHROOT            161
#define SYS_GETDENTS64        217
#define SYS_UTIMENSAT         280

#endif /* MATTIAOS_SYSCALL_NUMBERS_H */
