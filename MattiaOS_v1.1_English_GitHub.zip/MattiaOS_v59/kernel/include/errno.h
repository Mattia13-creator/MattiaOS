#ifndef MATTIAOS_ERRNO_H
#define MATTIAOS_ERRNO_H

#define EOK      0
#define ENOMEM  -1
#define EINVAL  -2
#define ENOENT  -3
#define EACCES  -4
#define EBUSY   -5
#define EFAULT  -6
#define EEXIST  -7
#define ENOTDIR -8
#define EISDIR  -9
#define EMFILE  -10
#define ENFILE  -11
#define EBADF   -12
#define EPERM   -13
#define ESRCH   -14
#define EINTR   -15
#define EIO     -16
#define ENOSPC  -17
#define EROFS   -18
#define ENOSYS  -19
#define ERANGE  -20
#define EAGAIN  -21
#define EPIPE   -22
#define ENOTTY  -23
#define EFBIG   -24



/* Codici of error network (aggiunti in v2.7 for kernel/net/) */
#define EADDRINUSE      -25
#define EAFNOSUPPORT    -26
#define ECONNREFUSED    -27
#define EDESTADDRREQ    -28
#define EISCONN         -29
#define ENOTCONN        -30
#define ENOPROTOOPT     -31
#define EOPNOTSUPP      -32
#define EPROTONOSUPPORT -33

#endif
