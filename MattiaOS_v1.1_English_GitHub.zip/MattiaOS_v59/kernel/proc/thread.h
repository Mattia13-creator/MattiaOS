#ifndef MATTIAOS_THREAD_H
#define MATTIAOS_THREAD_H

/*
 * kernel/proc/thread.h — stub of inclusione for simmetria .h/.c
 *
 * thread.c implementa thread_create() AND thread_destroy(),
 * that are dichiarate in process.h insieme to thread_t.
 * Includere process.h for l'intera API proc/thread.
 */

#include "process.h"

#endif /* MATTIAOS_THREAD_H */
