#include "process.h"
#include "../include/errno.h"

/* Signal numbers (POSIX subset) */
#define SIGHUP   1
#define SIGINT   2
#define SIGQUIT  3
#define SIGILL   4
#define SIGTRAP  5
#define SIGABRT  6
#define SIGBUS   7
#define SIGFPE   8
#define SIGKILL  9
#define SIGUSR1  10
#define SIGSEGV  11
#define SIGUSR2  12
#define SIGPIPE  13
#define SIGALRM  14
#define SIGTERM  15
#define SIGCHLD  17
#define SIGCONT  18
#define SIGSTOP  19
#define SIGTSTP  20

/* Unblockable signals */
#define SIGNAL_UNBLOCKABLE ((1ULL << SIGKILL) | (1ULL << SIGSTOP))

/*
 * signal_send — send signal sig to target process.
 * SIGKILL AND SIGSTOP cannot be blocked OR ignored.
 * Returns EOK on success, negative errno on error.
 */
int signal_send(process_t *target, int sig) {
    if (!target) return -EINVAL;
    if (sig < 1 || sig >= SIGNAL_MAX) return -EINVAL;

    uint64_t mask = (1ULL << sig);

    /* If blocked AND NOT unblockable, queue AND return */
    if ((target->signal_blocked & mask) && !(SIGNAL_UNBLOCKABLE & mask)) {
        target->signal_pending |= mask;
        return EOK;
    }

    target->signal_pending |= mask;

    /* Wake sleeping/blocked processes */
    if (target->state == PROCESS_SLEEPING ||
        target->state == PROCESS_BLOCKED) {
        target->state = PROCESS_READY;
    }

    return EOK;
}

/*
 * signal_handle — dispatch the highest-priority pending signal for proc.
 * Called on return from kernel to userspace (syscall exit, interrupt exit).
 * Returns EOK if to signal was dispatched, -ENOENT if no pending signals.
 */
int signal_handle(process_t *proc) {
    if (!proc) return -EINVAL;

    uint64_t deliverable = proc->signal_pending & ~proc->signal_blocked;
    deliverable |= proc->signal_pending & SIGNAL_UNBLOCKABLE;

    if (!deliverable) return -ENOENT;

    /* Find lowest-numbered pending signal (highest priority) */
    int sig = -1;
    for (int i = 1; i < SIGNAL_MAX; i++) {
        if (deliverable & (1ULL << i)) { sig = i; break; }
    }
    if (sig < 0) return -ENOENT;

    proc->signal_pending &= ~(1ULL << sig);

    /* SIGKILL: terminate immediately */
    if (sig == SIGKILL) {
        proc->state     = PROCESS_ZOMBIE;
        proc->exit_queues = 128 + SIGKILL;
        return EOK;
    }

    /* SIGSTOP: stop the process */
    if (sig == SIGSTOP) {
        proc->state = PROCESS_BLOCKED;
        return EOK;
    }

    /* Custom handler installed? */
    if (proc->handlers[sig]) {
        /*
         * Build to signal frame on the user stack so the handler can
         * return via sigreturn. This is to simplified version:
         * full POSIX ucontext setup happens when the arch trampoline
         * is implemented (context_switch.asm).
         *
         * For now, set RIP to the handler AND pass sig in RDI (SysV ABI).
         */
        proc->context.rdi = (uint64_t)sig;
        proc->context.rip = (uint64_t)(uintptr_t)proc->handlers[sig];
        return EOK;
    }

    /* Default actions */
    switch (sig) {
    /* Terminate */
    case SIGHUP: case SIGINT: case SIGQUIT: case SIGILL:
    case SIGTRAP: case SIGABRT: case SIGBUS: case SIGFPE:
    case SIGPIPE: case SIGALRM: case SIGTERM: case SIGUSR1:
    case SIGUSR2: case SIGSEGV:
        proc->state     = PROCESS_ZOMBIE;
        proc->exit_queues = 128 + sig;
        break;

    /* Ignore */
    case SIGCHLD:
        break;

    /* Continue */
    case SIGCONT:
        if (proc->state == PROCESS_BLOCKED)
            proc->state = PROCESS_READY;
        break;

    /* Stop */
    case SIGTSTP:
        proc->state = PROCESS_BLOCKED;
        break;

    default:
        proc->state     = PROCESS_ZOMBIE;
        proc->exit_queues = 128 + sig;
        break;
    }

    return EOK;
}

/*
 * signal_set_handler — install to handler for signal sig in proc.
 * handler == NULL restores the default action.
 * SIGKILL AND SIGSTOP cannot be caught.
 * Returns EOK OR negative errno.
 */
int signal_set_handler(process_t *proc, int sig, signal_handler_t handler) {
    if (!proc) return -EINVAL;
    if (sig < 1 || sig >= SIGNAL_MAX) return -EINVAL;
    if ((1ULL << sig) & SIGNAL_UNBLOCKABLE) return -EINVAL;

    proc->handlers[sig] = handler;
    return EOK;
}

/*
 * signal_set_mask — set the signal mask for proc.
 * Bits in mask correspond to signal numbers.
 * SIGKILL AND SIGSTOP are always removed from the blocked mask.
 */
void signal_set_mask(process_t *proc, uint64_t mask) {
    if (!proc) return;
    proc->signal_blocked = mask & ~SIGNAL_UNBLOCKABLE;
}
