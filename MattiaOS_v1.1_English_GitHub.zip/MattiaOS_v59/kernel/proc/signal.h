#ifndef MATTIAOS_SIGNAL_H
#define MATTIAOS_SIGNAL_H

/*
 * kernel/proc/signal.h — API signals POSIX (subset)
 *
 * Dichiarazioni pubbliche for signal.c.
 * Le structures process_t, thread_t AND signal_handler_t
 * are definite in process.h that va incluso before of this file.
 */

#include "process.h"

/* Numeri of signal (POSIX subset) */
#define SIGHUP   1
#define SIGINT   2
#define SIGQUIT  3
#define SIGILL   4
#define SIGTRAP  5
#define SIGABRT  6
#define SIGBUS   7
#define SIGFPE   8
#define SIGKILL  9
#define SIGUSR1  10
#define SIGSEGV  11
#define SIGUSR2  12
#define SIGPIPE  13
#define SIGALRM  14
#define SIGTERM  15
#define SIGCHLD  17

/*
 * signal_send — send the signal sig to the process target.
 * Returns EOK or negative error negative.
 * Signals bloccati restano in pending. SIGKILL AND SIGSTOP NOT are bloccabili.
 */
int signal_send(process_t *target, int sig);

/*
 * signal_handle — processa the signals pending for proc.
 * Da chiamare to the rientro from syscall OR to the preemption (scheduler tick).
 * Returns EOK if no signal terminale, -ESRCH if proc è stato terminato.
 */
int signal_handle(process_t *proc);

/*
 * signal_set_handler — installa handler for the signal sig.
 * SIG_DFL (NULL) = azione default, SIG_IGN = ignora.
 * SIGKILL AND SIGSTOP NOT possono essere catturati.
 */
int signal_set_handler(process_t *proc, int sig, signal_handler_t handler);

/*
 * signal_set_mask — set the mask of the signals bloccati.
 * Bit the = 1 → signal the+1 blocked.
 */
void signal_set_mask(process_t *proc, uint64_t mask);

#endif /* MATTIAOS_SIGNAL_H */
