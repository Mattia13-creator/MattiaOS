#include "msgq.h"
#include "../mm/slab.h"
#include "../include/errno.h"
#include "../sched/mlfq.h"
#include "../arch/x86_64/cpu.h"   /* serial_puts — debug logging */

/* =========================================================================
 * Table global of the code of messaggi
 * ========================================================================= */
static msgq_t     s_queues[MQ_MAX_QUEUES];
static spinlock_t s_table_lock = {0};

/* =========================================================================
 * Helper no-libc
 * ========================================================================= */
static inline void mq_memset(void *dst, int val, size_t n) {
    uint8_t *p = (uint8_t *)dst;
    for (size_t i = 0; i < n; i++) p[i] = (uint8_t)val;
}

static inline void mq_memcpy(void *dst, const void *src, size_t n) {
    uint8_t       *d = (uint8_t *)dst;
    const uint8_t *s = (const uint8_t *)src;
    for (size_t i = 0; i < n; i++) d[i] = s[i];
}

static inline size_t mq_strlen(const char *s) {
    size_t n = 0;
    while (s[n]) n++;
    return n;
}

static inline int mq_strcmp(const char *a, const char *b) {
    while (*a && *a == *b) { a++; b++; }
    return (unsigned char)*a - (unsigned char)*b;
}

static inline void mq_strncpy(char *dst, const char *src, size_t n) {
    size_t i = 0;
    while (i < n - 1 && src[i]) { dst[i] = src[i]; i++; }
    dst[i] = '\0';
}

/* =========================================================================
 * Search the queue for name (without lock external — the chiamante deve tenere
 * s_table_lock).
 * ========================================================================= */
static int find_by_name(const char *name) {
    for (int i = 0; i < MQ_MAX_QUEUES; i++) {
        if (s_queues[i].valid && !s_queues[i].unlinked &&
            mq_strcmp(s_queues[i].name, name) == 0) {
            return i;
        }
    }
    return ENOENT;
}

/* =========================================================================
 * Distrugge to queue: free the ring buffer AND zero the record.
 * Chiamata below lock of the queue (r->lock già acquisito from the chiamante
 * OR below s_table_lock with none that usa the queue).
 * ========================================================================= */
static void destroy_queue(int mqd) {
    msgq_t *q = &s_queues[mqd];
    if (q->ring) {
        kfree(q->ring);
        q->ring = NULL;
    }
    mq_memset(q, 0, sizeof(*q));
}

/* =========================================================================
 * Inserisce to messaggio nel ring buffer mantenendo l'ordine for priorità.
 * La queue è già blocked from the chiamante.
 * Strategia: inserimento in queue AND bubble-up for rispettare prio max-first.
 * ========================================================================= */
static void ring_insert(msgq_t *q, const mq_msg_t *msg) {
    q->ring[q->tail] = *msg;
    q->tail = (q->tail + 1) % q->capacity;
    q->count++;

    /*
     * Risort the messaggio appena inserito verso the testa finché the sua
     * priorità è maggiore of the previous (ordine decrescente of prio).
     * Opera sugli indici logici [0..count-1] mapti sul ring circolare.
     */
    uint32_t pos = q->count - 1;
    while (pos > 0) {
        uint32_t cur  = (q->head + pos)     % q->capacity;
        uint32_t prev = (q->head + pos - 1) % q->capacity;
        if (q->ring[cur].prio > q->ring[prev].prio) {
            /* Scambia */
            mq_msg_t tmp   = q->ring[cur];
            q->ring[cur]   = q->ring[prev];
            q->ring[prev]  = tmp;
            pos--;
        } else {
            break;
        }
    }
}

/* =========================================================================
 * Estrae the messaggio to testa (priorità massima).
 * La queue è già blocked from the chiamante.
 * ========================================================================= */
static void ring_pop(msgq_t *q, mq_msg_t *out) {
    *out   = q->ring[q->head];
    q->head = (q->head + 1) % q->capacity;
    q->count--;
}

/* =========================================================================
 * Sveglia to waiter from the lista indicata (send OR recv).
 * Deve essere chiamato with the lock of the queue già acquisito.
 * ========================================================================= */
static void wake_one_sender(msgq_t *q) {
    if (q->waiters_send_count == 0) return;
    thread_t *t = q->waiters_send[0];
    uint32_t last = q->waiters_send_count - 1;
    q->waiters_send[0] = q->waiters_send[last];
    q->waiters_send[last] = NULL;
    q->waiters_send_count--;
    scheduler_unblock(t);
}

static void wake_one_receiver(msgq_t *q) {
    if (q->waiters_recv_count == 0) return;
    thread_t *t = q->waiters_recv[0];
    uint32_t last = q->waiters_recv_count - 1;
    q->waiters_recv[0] = q->waiters_recv[last];
    q->waiters_recv[last] = NULL;
    q->waiters_recv_count--;
    scheduler_unblock(t);
}

/* =========================================================================
 * API — mq_open
 * ========================================================================= */
int mq_open(const char *name, uint32_t flags, uint32_t depth) {
    if (!name || name[0] != '/' || mq_strlen(name) >= MQ_NAME_MAX)
        return EINVAL;

    uint64_t f = spinlock_irqsave(&s_table_lock);

    int existing = find_by_name(name);
    if (existing >= 0) {
        /* Queue già esiste */
        if ((flags & MQ_OFLAG_CREAT) && (flags & MQ_OFLAG_EXCL)) {
            spinlock_irqrestore(&s_table_lock, f);
            return EEXIST;
        }
        s_queues[existing].open_count++;
        spinlock_irqrestore(&s_table_lock, f);
        return existing;
    }

    /* Non esiste: richiede CREAT */
    if (!(flags & MQ_OFLAG_CREAT)) {
        spinlock_irqrestore(&s_table_lock, f);
        return ENOENT;
    }

    /* Search slot free */
    int slot = -1;
    for (int i = 0; i < MQ_MAX_QUEUES; i++) {
        if (!s_queues[i].valid) { slot = i; break; }
    }
    if (slot < 0) {
        spinlock_irqrestore(&s_table_lock, f);
        return ENOMEM;
    }

    uint32_t cap = (depth == 0) ? MQ_DEFAULT_DEPTH : depth;
    if (cap > MQ_MAX_DEPTH) cap = MQ_MAX_DEPTH;

    /* Allocate ring buffer */
    mq_msg_t *ring = (mq_msg_t *)kmalloc(cap * sizeof(mq_msg_t));
    if (!ring) {
        spinlock_irqrestore(&s_table_lock, f);
        return ENOMEM;
    }
    mq_memset(ring, 0, cap * sizeof(mq_msg_t));

    msgq_t *q = &s_queues[slot];
    mq_memset(q, 0, sizeof(*q));
    mq_strncpy(q->name, name, MQ_NAME_MAX);
    q->valid      = true;
    q->unlinked   = false;
    q->ring       = ring;
    q->capacity   = cap;
    q->open_count = 1;

    spinlock_irqrestore(&s_table_lock, f);

    serial_puts("[MSGQ] Queue creata: ");
    serial_puts(name);
    serial_puts("\n");
    return slot;
}

/* =========================================================================
 * API — mq_close
 * ========================================================================= */
int mq_close(int mqd) {
    if (mqd < 0 || mqd >= MQ_MAX_QUEUES) return EBADF;

    msgq_t *q = &s_queues[mqd];
    uint64_t f = spinlock_irqsave(&q->lock);

    if (!q->valid) {
        spinlock_irqrestore(&q->lock, f);
        return EBADF;
    }

    q->open_count--;
    bool should_destroy = (q->open_count <= 0 && q->unlinked);
    spinlock_irqrestore(&q->lock, f);

    if (should_destroy) {
        uint64_t tf = spinlock_irqsave(&s_table_lock);
        destroy_queue(mqd);
        spinlock_irqrestore(&s_table_lock, tf);
    }
    return EOK;
}

/* =========================================================================
 * API — mq_send
 * ========================================================================= */
int mq_send(int mqd, const void *data, size_t size, uint32_t prio) {
    if (mqd < 0 || mqd >= MQ_MAX_QUEUES) return EBADF;
    if (!data || size == 0 || size > MQ_MSG_DATA_MAX) return EINVAL;

    msgq_t *q = &s_queues[mqd];

    while (1) {
        uint64_t f = spinlock_irqsave(&q->lock);

        if (!q->valid) {
            spinlock_irqrestore(&q->lock, f);
            return EBADF;
        }

        if (q->count < q->capacity) {
            /* Spazio available: inserisci the messaggio */
            mq_msg_t msg;
            msg.prio = prio;
            msg.size = size;
            mq_memcpy(msg.data, data, size);

            ring_insert(q, &msg);

            /* Sveglia to eventuale receiver waiting */
            wake_one_receiver(q);
            spinlock_irqrestore(&q->lock, f);
            return EOK;
        }

        /* Queue piena */
        if (q->waiters_send_count >= MQ_MAX_WAITERS) {
            spinlock_irqrestore(&q->lock, f);
            return EAGAIN;
        }

        /* Register the thread current as waiter */
        q->waiters_send[q->waiters_send_count++] = g_current_thread;

        /*
         * Blocca the thread current.  scheduler_block() NOT rilascia the
         * lock — dobbiamo farlo before.  Il thread verrà sblocked from
         * wake_one_sender() chiamata in mq_receive().
         */
        spinlock_irqrestore(&q->lock, f);
        scheduler_block(g_current_thread);
        scheduler_yield();
        /* Riprendiamo qui after the sblock: ritenta */
    }
}

/* =========================================================================
 * API — mq_receive
 * ========================================================================= */
int mq_receive(int mqd, void *buf, size_t buf_size, uint32_t *prio_out) {
    if (mqd < 0 || mqd >= MQ_MAX_QUEUES) return EBADF;
    if (!buf || buf_size == 0)            return EINVAL;

    msgq_t *q = &s_queues[mqd];

    while (1) {
        uint64_t f = spinlock_irqsave(&q->lock);

        if (!q->valid) {
            spinlock_irqrestore(&q->lock, f);
            return EBADF;
        }

        if (q->count > 0) {
            mq_msg_t msg;
            ring_pop(q, &msg);

            size_t to_copy = msg.size < buf_size ? msg.size : buf_size;
            mq_memcpy(buf, msg.data, to_copy);
            if (prio_out) *prio_out = msg.prio;

            /* Sveglia to eventuale sender waiting */
            wake_one_sender(q);
            spinlock_irqrestore(&q->lock, f);
            return (int)to_copy;
        }

        /* Queue empty */
        if (q->waiters_recv_count >= MQ_MAX_WAITERS) {
            spinlock_irqrestore(&q->lock, f);
            return EAGAIN;
        }

        q->waiters_recv[q->waiters_recv_count++] = g_current_thread;

        spinlock_irqrestore(&q->lock, f);
        scheduler_block(g_current_thread);
        scheduler_yield();
        /* Riprendiamo qui after the sblock: ritenta */
    }
}

/* =========================================================================
 * API — mq_unlink
 * ========================================================================= */
int mq_unlink(const char *name) {
    if (!name || name[0] != '/') return EINVAL;

    uint64_t tf = spinlock_irqsave(&s_table_lock);
    int idx = find_by_name(name);
    if (idx < 0) {
        spinlock_irqrestore(&s_table_lock, tf);
        return ENOENT;
    }

    msgq_t *q = &s_queues[idx];
    uint64_t qf = spinlock_irqsave(&q->lock);

    q->unlinked = true;
    bool should_destroy = (q->open_count <= 0);

    spinlock_irqrestore(&q->lock, qf);
    spinlock_irqrestore(&s_table_lock, tf);

    if (should_destroy) {
        uint64_t f2 = spinlock_irqsave(&s_table_lock);
        destroy_queue(idx);
        spinlock_irqrestore(&s_table_lock, f2);
    }
    return EOK;
}
