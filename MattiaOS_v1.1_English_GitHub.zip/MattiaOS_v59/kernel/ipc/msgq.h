#ifndef MATTIAOS_MSGQ_H
#define MATTIAOS_MSGQ_H

#include "../include/types.h"
#include "../proc/process.h"

/* =========================================================================
 * msgq.h — Message Queues IPC
 *
 * Queues of messaggi kernel-side with semantica POSIX-like.  Ogni queue è
 * identificata from to name stringa (path virtual, es. "/myqueue").
 * I messaggi hanno size variable (max MQ_MSG_DATA_MAX) AND priorità
 * numerica: values più alti → consegnati before (ordine max-first).
 *
 * Block AND sblock avvengono via scheduler_block/scheduler_unblock of the
 * modulo mlfq.  Quando the queue è piena, mq_send() block the thread
 * mittente finché NOT c'è spazio.  Quando è empty, mq_receive() block the
 * thread ricevente finché NOT arriva to messaggio.
 *
 * Uso of the prefixed mq_ for all the functions pubbliche.
 * ========================================================================= */

/* Limiti of system */
#define MQ_MAX_QUEUES     32      /* Queues attive contemporaneamente */
#define MQ_NAME_MAX       128     /* Length massima of the name (with '\0') */
#define MQ_MSG_DATA_MAX   4096    /* Payload massimo for messaggio in byte */
#define MQ_DEFAULT_DEPTH  64      /* Profondità default if depth=0 to mq_open */
#define MQ_MAX_DEPTH      256     /* Profondità massima assoluta */
#define MQ_MAX_WAITERS    32      /* Thread waiting (send OR receive) for queue */

/* Flags for mq_open */
#define MQ_OFLAG_CREAT    0x01    /* Crea the queue if NOT esiste */
#define MQ_OFLAG_EXCL     0x02    /* Error if the queue esiste già (with CREAT) */
#define MQ_OFLAG_RDONLY   0x04    /* Apri only for receive */
#define MQ_OFLAG_WRONLY   0x08    /* Apri only for send */
#define MQ_OFLAG_RDWR     0x0C    /* Apri for send AND receive */
#define MQ_OFLAG_NONBLOCK 0x10    /* Operazioni NOT bloccanti */

/* Priorità of default for messaggi sendti without priorità esplicita */
#define MQ_PRIO_DEFAULT   0

/* -------------------------------------------------------------------------
 * mq_msg_t — to singolo messaggio nella queue
 * ------------------------------------------------------------------------- */
typedef struct {
    uint32_t prio;                  /* Priorità: value maggiore → before */
    size_t   size;                  /* Size effettiva of the payload */
    uint8_t  data[MQ_MSG_DATA_MAX]; /* Payload */
} mq_msg_t;

/* -------------------------------------------------------------------------
 * msgq_t — descriptor internal of to queue of messaggi
 * ------------------------------------------------------------------------- */
typedef struct {
    char     name[MQ_NAME_MAX]; /* Nome of the queue (es. "/myqueue") */
    bool     valid;             /* true if the record è in uso */
    bool     unlinked;          /* true after mq_unlink: chiusa all'last close */

    /* Ring buffer of messaggi (allocateto dinamicamente with kmalloc) */
    mq_msg_t *ring;             /* Array of `capacity` elementi */
    uint32_t  capacity;         /* Capacità massima (depth) */
    uint32_t  head;             /* Indice prossima read */
    uint32_t  tail;             /* Indice prossima write */
    uint32_t  count;            /* Messaggi presenti */

    /* Numero of fd/descriptors aperti that referenziano this queue */
    int32_t  open_count;

    spinlock_t lock;            /* Protegge head/tail/count/ring */

    /* Thread bloccati waiting of spazio (mq_send up queue piena) */
    thread_t *waiters_send[MQ_MAX_WAITERS];
    uint32_t  waiters_send_count;

    /* Thread bloccati waiting of to messaggio (mq_receive up queue empty) */
    thread_t *waiters_recv[MQ_MAX_WAITERS];
    uint32_t  waiters_recv_count;
} msgq_t;

/* =========================================================================
 * API pubblica
 * ========================================================================= */

/*
 * mq_open — opens (OR crea) to queue of messaggi.
 *
 * @name:   name of the queue, deve iniziare with '/'.
 * @flags:  combinazione of MQ_OFLAG_*. MQ_OFLAG_CREAT required for creare.
 * @depth:  profondità of the queue (0 = MQ_DEFAULT_DEPTH). Ignorato if the
 *          queue già esiste without MQ_OFLAG_EXCL.
 * @return: mqd (message queue descriptor) >= 0; EINVAL, ENOMEM, EEXIST,
 *          ENOENT (if CREAT NOT specificato AND queue NOT esiste).
 */
int mq_open(const char *name, uint32_t flags, uint32_t depth);

/*
 * mq_close — closes to descriptor of queue.
 *
 * @mqd: descriptor restituito from mq_open.
 * @return: EOK, EBADF if mqd NOT valid.
 *
 * Se open_count scende to 0 AND the queue è stata mq_unlink'd, the queue
 * is distrutta AND the ring buffer freeto.
 */
int mq_close(int mqd);

/*
 * mq_send — send to messaggio nella queue.
 *
 * @mqd:   descriptor of the queue.
 * @data:  pointer to the payload.
 * @size:  size of the payload (max MQ_MSG_DATA_MAX).
 * @prio:  priorità of the messaggio (maggiore = consegnato before).
 * @return: EOK, EBADF, EINVAL (size troppo grande), EAGAIN (queue piena
 *          with MQ_OFLAG_NONBLOCK).
 *
 * Se the queue è piena AND the flag NONBLOCK NOT è set, the thread
 * current is blocked via scheduler_block() finché to receiver
 * NOT consuma almeno to messaggio.
 */
int mq_send(int mqd, const void *data, size_t size, uint32_t prio);

/*
 * mq_receive — riceve the messaggio to priorità più alta from the queue.
 *
 * @mqd:      descriptor of the queue.
 * @buf:      buffer of output for the payload.
 * @buf_size: size of the buffer (deve essere >= MQ_MSG_DATA_MAX
 *            for NOT troncare; is comunque scritto min(msg.size, buf_size)).
 * @prio_out: if NOT NULL, riceve the priorità of the messaggio letto.
 * @return:   number of byte copyti in buf (>= 0); EBADF, EAGAIN (queue
 *            empty with NONBLOCK), EINVAL.
 *
 * Se the queue è empty AND the flag NONBLOCK NOT è set, the thread
 * is blocked via scheduler_block() finché to sender NOT inserisce
 * to messaggio.
 */
int mq_receive(int mqd, void *buf, size_t buf_size, uint32_t *prio_out);

/*
 * mq_unlink — segna the queue for removezione to the next close.
 *
 * @name: name of the queue from removere.
 * @return: EOK, ENOENT if NOT found.
 *
 * Dopo mq_unlink the queue NOT è più apribile from nuovi chiamanti ma rimane
 * funzionante for the descriptors già aperti.  Distrutta all'last mq_close().
 */
int mq_unlink(const char *name);

#endif /* MATTIAOS_MSGQ_H */
