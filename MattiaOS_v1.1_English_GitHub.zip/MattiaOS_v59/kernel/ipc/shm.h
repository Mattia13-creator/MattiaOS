#ifndef MATTIAOS_SHM_H
#define MATTIAOS_SHM_H

#include "../include/types.h"
#include "../proc/process.h"

/* =========================================================================
 * shm.h — Shared Memory IPC
 *
 * Regioni of memory condivisa identificate from chiave numerica (shm_key_t).
 * Implementazione: the pages fisiche of every regione vengono mapte with
 * vmm_map() in every spazio of addresses of the processes that eseguono attach.
 * Uso principale: compositor GUI → sharing buffer of rendering with
 * the applications (Fase 13+).
 *
 * Nota sul refcount: shm_region_t mantiene to counter of attach active
 * (attach_count) for sapere when freere the pages fisiche.  Questo NOT
 * viola the Principio 2 of the blueprint, that riguarda the file up disk.  La
 * memory condivisa è to dominio separato: the pages fisiche devono
 * esistere finché almeno to process the usa.
 * ========================================================================= */

/* Chiave identificativa of to regione condivisa — scelta from the chiamante */
typedef uint64_t shm_key_t;

/* Limiti of system */
#define SHM_MAX_REGIONS        64    /* Numero massimo of regioni attive */
#define SHM_MAX_PAGES_PER_REGION 256 /* Max pages for regione = 1 MB */
#define SHM_MAX_ATTACHMENTS    32    /* Max attacchi simultanei for regione */

/* Flags for shm_create */
#define SHM_FLAG_NONE          0x00
#define SHM_FLAG_EXCL          0x01  /* Error if the chiave esiste già */

/* Flags of protezione for shm_attach (combinabili) */
#define SHM_PROT_READ          0x01
#define SHM_PROT_WRITE         0x02
#define SHM_PROT_RW            (SHM_PROT_READ | SHM_PROT_WRITE)

/* -------------------------------------------------------------------------
 * shm_region_t — descriptor internal of to regione condivisa.
 * Non esposto direttamente all'utente: si accede via shmid (indice).
 * ------------------------------------------------------------------------- */
typedef struct {
    shm_key_t  key;               /* Chiave univoca assegnata from the chiamante */
    bool       valid;             /* true if the record è in uso */

    size_t     size;              /* Size in byte (arrotondata to PAGE_SIZE) */
    uint32_t   n_pages;           /* Numero of pages fisiche allocatete */
    uint64_t   phys_pages[SHM_MAX_PAGES_PER_REGION]; /* Addresses fisici */

    /* Processes attualmente attaccati + address virtual nel loro spazio */
    process_t *attach_procs[SHM_MAX_ATTACHMENTS];
    uint64_t   attach_vaddrs[SHM_MAX_ATTACHMENTS];
    uint32_t   attach_count;      /* Numero of attacchi active */

    spinlock_t lock;              /* Protegge the fields above */
} shm_region_t;

/* =========================================================================
 * API pubblica
 * ========================================================================= */

/*
 * shm_create — crea to nuova regione of memory condivisa.
 *
 * @key:   chiave numerica univoca scelta from the chiamante.
 * @size:  size richiesta in byte (arrotondata internamente to PAGE_SIZE).
 * @flags: SHM_FLAG_NONE OR SHM_FLAG_EXCL.
 * @return: shmid >= 0 in caso of successo; EINVAL, ENOMEM, EEXIST if error.
 *
 * Se the chiave esiste già AND flags NOT include SHM_FLAG_EXCL, returns
 * the shmid of the regione esistente (semantica get-OR-create).
 */
int shm_create(shm_key_t key, size_t size, uint32_t flags);

/*
 * shm_attach — map the regione nel pagemap of the process chiamante.
 *
 * @shmid:     identifier restituito from shm_create.
 * @proc:      process that richiede l'attach.
 * @prot:      SHM_PROT_READ | SHM_PROT_WRITE (combinazione).
 * @vaddr_out: riceve l'address virtual nel pagemap of the process.
 * @return:    EOK, EINVAL (shmid NOT valid), ENOMEM, EBUSY (troppi attach).
 *
 * Le pages vengono mapte to partire from the before VMA free above 0x10000
 * nello spazio utente of the process.  The kernel NON tiene traccia of the vaddr
 * after detach — è responsabilità of the process NOT usarlo più.
 */
int shm_attach(int shmid, process_t *proc, uint32_t prot, uint64_t *vaddr_out);

/*
 * shm_detach — rimuove the mapping from the pagemap of the process.
 *
 * @shmid: identifier of the regione.
 * @proc:  process that esegue the detach.
 * @return: EOK, EINVAL if shmid NOT valid OR process NOT attaccato.
 *
 * Se attach_count scende to 0 AND the regione NOT è più referenced from none,
 * the pages fisiche vengono freete immediatamente.
 */
int shm_detach(int shmid, process_t *proc);

/*
 * shm_destroy — marca the regione for removezione.
 *
 * @shmid: identifier of the regione.
 * @return: EOK, EINVAL if shmid NOT valid.
 *
 * Se no process è attaccato, the pages fisiche are freete subito.
 * Se ci are attach active, the regione is marcata as pending-destroy:
 * the pages saranno freete all'last shm_detach().
 */
int shm_destroy(int shmid);

/*
 * shm_find — search to regione for chiave.
 *
 * @key:    chiave from searchre.
 * @return: shmid >= 0 if found, ENOENT if NOT esiste.
 */
int shm_find(shm_key_t key);

#endif /* MATTIAOS_SHM_H */
