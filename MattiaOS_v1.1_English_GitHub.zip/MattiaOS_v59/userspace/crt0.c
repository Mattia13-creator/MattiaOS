/*
 * crt0.c — entry point userspace MattiaOS
 *
 * The kernel salta to _start with the stack aligned AND argc/argv già presenti:
 *   [rsp+0]  = argc (int64)
 *   [rsp+8]  = argv[0] (char*)
 *   ...
 *   [rsp+8*(argc+1)] = NULL  (end argv)
 *   [rsp+8*(argc+2)] = envp[0] ...
 *
 * _start prepara the registers rdi=argc, rsi=argv, rdx=envp,
 * allinea rsp to 16 byte AND chiama main(). Al return chiama exit().
 */

#include "../include/userspace.h"

extern int main(int argc, char **argv, char **envp);

__attribute__((naked, noreturn))
void _start(void) {
    __asm__ __volatile__(
        /* Zero the frame pointer — ABI x86-64 the richiede */
        "xorq  %%rbp, %%rbp\n\t"

        /* argc è in [rsp], argv parte from [rsp+8] */
        "movq  (%%rsp),  %%rdi\n\t"          /* rdi = argc              */
        "leaq  8(%%rsp), %%rsi\n\t"          /* rsi = argv              */
        "leaq  8(%%rsi,%%rdi,8), %%rdx\n\t"  /* rdx = envp = argv+argc+1 */

        /* Allinea rsp to 16 byte (mandatory before of call) */
        "andq  $-16, %%rsp\n\t"

        /* Chiama main() */
        "call  main\n\t"

        /* Passa the queues of return to exit() */
        "movq  %%rax, %%rdi\n\t"
        "call  exit\n\t"

        /* Non si dovrebbe mai arrivare qui */
        "hlt"
        ::: "memory"
    );
}
