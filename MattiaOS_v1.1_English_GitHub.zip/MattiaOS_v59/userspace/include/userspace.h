#ifndef _USERSPACE_H
#define _USERSPACE_H

/*
 * userspace.h — header comune for all the programs userspace of MattiaOS.
 * Include tutta the libc interna AND aggiunge structures of system, numbers
 * syscall supplementari AND wrapper inline.
 */

#include "../../libc/include/stddef.h"
#include "../../libc/include/stdint.h"
#include "../../libc/include/stdbool.h"
#include "../../libc/include/stdarg.h"
#include "../../libc/include/errno.h"
#include "../../libc/include/syscall.h"
#include "../../libc/include/string.h"
#include "../../libc/include/stdlib.h"
#include "../../libc/include/stdio.h"
#include "../../libc/include/unistd.h"
#include "../../libc/include/fcntl.h"

/* =========================================================================
 * Numeri syscall supplementari (in aggiunta to kernel/include/syscall_numbers.h)
 * ========================================================================= */
#define SYS_RT_SIGACTION   13
#define SYS_RT_SIGPROCMASK 14
#define SYS_NANOSLEEP      35
#define SYS_ALARM          37
#define SYS_SETPGID       109
#define SYS_GETPPID       110
#define SYS_SETSID        112
#define SYS_GETPGID       121
#define SYS_GETSID        124
#define SYS_SYSINFO        99
#define SYS_LINK           86
#define SYS_SYMLINK        88
#define SYS_READLINK       89
#define SYS_STATFS        137
#define SYS_FSTATFS       138
#define SYS_UTIMENSAT     280
#define SYS_GETDENTS64    217
#define SYS_WAITPID        61   /* alias for wait4 */
#define SYS_CHROOT        161
#define SYS_SETUID        105
#define SYS_SETGID        106
#define SYS_UMOUNT2       166
#define SYS_TRUNCATE       76
#define SYS_FTRUNCATE      77
#define SYS_FSYNC          74
#define SYS_TCGETS        0x5401 /* IOCTL */
#define TIOCGWINSZ        0x5413
#define TIOCSWINSZ        0x5414
#define TIOCGPGRP         0x540F
#define TIOCSPGRP         0x5410

/* =========================================================================
 * Signals
 * ========================================================================= */
#define SIGHUP    1
#define SIGINT    2
#define SIGQUIT   3
#define SIGILL    4
#define SIGTRAP   5
#define SIGABRT   6
#define SIGBUS    7
#define SIGFPE    8
#define SIGKILL   9
#define SIGUSR1  10
#define SIGSEGV  11
#define SIGUSR2  12
#define SIGPIPE  13
#define SIGALRM  14
#define SIGTERM  15
#define SIGCHLD  17
#define SIGCONT  18
#define SIGSTOP  19
#define SIGTSTP  20
#define SIGTTIN  21
#define SIGTTOU  22
#define SIGWINCH 28
#define SIG_DFL  ((void (*)(int))0)
#define SIG_IGN  ((void (*)(int))1)

/* =========================================================================
 * struct stat — layout x86-64 Linux (MattiaOS segue the stessa ABI)
 * ========================================================================= */
struct stat {
    uint64_t st_dev;
    uint64_t st_ino;
    uint64_t st_nlink;
    uint32_t st_mode;
    uint32_t st_uid;
    uint32_t st_gid;
    uint32_t __pad0;
    uint64_t st_rdev;
    int64_t  st_size;
    int64_t  st_blksize;
    int64_t  st_blocks;
    int64_t  st_atime;
    uint64_t st_atime_nsec;
    int64_t  st_mtime;
    uint64_t st_mtime_nsec;
    int64_t  st_ctime;
    uint64_t st_ctime_nsec;
    int64_t  __reserved[3];
};

/* =========================================================================
 * struct dirent64 — usato with SYS_GETDENTS64
 * ========================================================================= */
struct dirent {
    uint64_t d_ino;
    int64_t  d_off;
    uint16_t d_reclen;
    uint8_t  d_type;
    char     d_name[256];
} __attribute__((packed));

#define DT_UNKNOWN 0
#define DT_FIFO    1
#define DT_CHR     2
#define DT_DIR     4
#define DT_BLK     6
#define DT_REG     8
#define DT_LNK    10
#define DT_SOCK   12

/* =========================================================================
 * Modalità file
 * ========================================================================= */
#ifndef S_IFMT
#define S_IFMT   0170000
#endif
#ifndef S_IFSOCK
#define S_IFSOCK 0140000
#endif
#ifndef S_IFLNK
#define S_IFLNK  0120000
#endif
#ifndef S_IFREG
#define S_IFREG  0100000
#endif
#ifndef S_IFBLK
#define S_IFBLK  0060000
#endif
#ifndef S_IFDIR
#define S_IFDIR  0040000
#endif
#ifndef S_IFCHR
#define S_IFCHR  0020000
#endif
#ifndef S_IFIFO
#define S_IFIFO  0010000
#endif

#ifndef S_ISREG
#define S_ISREG(m)  (((m) & S_IFMT) == S_IFREG)
#endif
#ifndef S_ISDIR
#define S_ISDIR(m)  (((m) & S_IFMT) == S_IFDIR)
#endif
#ifndef S_ISLNK
#define S_ISLNK(m)  (((m) & S_IFMT) == S_IFLNK)
#endif
#ifndef S_ISBLK
#define S_ISBLK(m)  (((m) & S_IFMT) == S_IFBLK)
#endif
#ifndef S_ISCHR
#define S_ISCHR(m)  (((m) & S_IFMT) == S_IFCHR)
#endif
#ifndef S_ISFIFO
#define S_ISFIFO(m) (((m) & S_IFMT) == S_IFIFO)
#endif
#ifndef S_ISSOCK
#define S_ISSOCK(m) (((m) & S_IFMT) == S_IFSOCK)
#endif

#ifndef S_ISUID
#define S_ISUID  04000
#endif
#ifndef S_ISGID
#define S_ISGID  02000
#endif
#ifndef S_ISVTX
#define S_ISVTX  01000
#endif
#ifndef S_IRWXU
#define S_IRWXU  00700
#endif
#ifndef S_IRUSR
#define S_IRUSR  00400
#endif
#ifndef S_IWUSR
#define S_IWUSR  00200
#endif
#ifndef S_IXUSR
#define S_IXUSR  00100
#endif
#ifndef S_IRWXG
#define S_IRWXG  00070
#endif
#ifndef S_IRGRP
#define S_IRGRP  00040
#endif
#ifndef S_IWGRP
#define S_IWGRP  00020
#endif
#ifndef S_IXGRP
#define S_IXGRP  00010
#endif
#ifndef S_IRWXO
#define S_IRWXO  00007
#endif
#ifndef S_IROTH
#define S_IROTH  00004
#endif
#ifndef S_IWOTH
#define S_IWOTH  00002
#endif
#ifndef S_IXOTH
#define S_IXOTH  00001
#endif

/* =========================================================================
 * struct utsname — usato with SYS_UNAME (63)
 * ========================================================================= */
struct utsname {
    char sysname  [65];
    char nodename [65];
    char release  [65];
    char version  [65];
    char machine  [65];
    char domainname[65];
};

/* =========================================================================
 * struct sysinfo — usato with SYS_SYSINFO (99)
 * ========================================================================= */
struct sysinfo {
    int64_t  uptime;
    uint64_t loads[3];
    uint64_t totalram;
    uint64_t freeram;
    uint64_t sharedram;
    uint64_t bufferram;
    uint64_t totalswap;
    uint64_t freeswap;
    uint16_t procs;
    uint16_t pad;
    uint32_t pad2;
    uint64_t totalhigh;
    uint64_t freehigh;
    uint32_t mem_unit;
    char     _f[8];
};

/* =========================================================================
 * struct statfs — usato with SYS_STATFS (137)
 * ========================================================================= */
struct statfs {
    int64_t  f_type;
    int64_t  f_bsize;
    int64_t  f_blocks;
    int64_t  f_bfree;
    int64_t  f_bavail;
    int64_t  f_files;
    int64_t  f_ffree;
    uint64_t f_fsid;
    int64_t  f_namelen;
    int64_t  f_frsize;
    int64_t  f_flags;
    int64_t  f_spare[4];
};

/* =========================================================================
 * struct timespec — for SYS_NANOSLEEP, SYS_CLOCK_GETTIME, SYS_UTIMENSAT
 * ========================================================================= */
struct timespec {
    int64_t tv_sec;
    int64_t tv_nsec;
};

#define CLOCK_REALTIME  0
#define CLOCK_MONOTONIC 1

/* =========================================================================
 * struct winsize — for TIOCGWINSZ / TIOCSWINSZ
 * ========================================================================= */
struct winsize {
    uint16_t ws_row;
    uint16_t ws_col;
    uint16_t ws_xpixel;
    uint16_t ws_ypixel;
};

/* =========================================================================
 * struct sigaction — for SYS_RT_SIGACTION (13)
 * ========================================================================= */
struct sigaction {
    void     (*sa_handler)(int);
    uint64_t   sa_flags;
    void     (*sa_restorer)(void);
    uint64_t   sa_mask;
};

#define SA_RESTART   0x10000000
#define SA_NOCLDSTOP 0x00000001
#define SA_NOCLDWAIT 0x00000002
#define SA_SIGINFO   0x00000004

/* =========================================================================
 * Structures of network
 * ========================================================================= */
struct in_addr { uint32_t s_addr; };

struct sockaddr {
    uint16_t sa_family;
    char     sa_data[14];
};

struct ifreq {
    char ifr_name[16];
    union {
        struct sockaddr ifr_addr;
        struct sockaddr ifr_dstaddr;
        struct sockaddr ifr_netmask;
        struct sockaddr ifr_hwaddr;
        short           ifr_flags;
        int             ifr_ifindex;
        int             ifr_metric;
        int             ifr_mtu;
    };
};

struct ifconf {
    int   ifc_len;
    char *ifc_buf;
};

/* Net ioctl */
#define SIOCGIFCONF   0x8912
#define SIOCGIFFLAGS  0x8913
#define SIOCGIFADDR   0x8915
#define SIOCGIFNETMASK 0x891b
#define SIOCGIFHWADDR 0x8927
#define IFF_UP        0x0001
#define IFF_LOOPBACK  0x0008
#define IFF_RUNNING   0x0040
#define AF_INET       2
#define AF_PACKET     17
#define SOCK_RAW      3
#define IPPROTO_ICMP  1
#define IPPROTO_RAW   255

/* =========================================================================
 * Wrapper syscall aggiuntivi
 * ========================================================================= */
static inline int sys_stat(const char *path, struct stat *buf) {
    return (int)__sc_errno(__syscall2(4, (long)path, (long)buf));
}
static inline int sys_lstat(const char *path, struct stat *buf) {
    return (int)__sc_errno(__syscall2(6, (long)path, (long)buf));
}
static inline int sys_fstat(int fd, struct stat *buf) {
    return (int)__sc_errno(__syscall2(5, (long)fd, (long)buf));
}
static inline int sys_getdents(int fd, void *buf, size_t count) {
    return (int)__sc_errno(__syscall3(SYS_GETDENTS64, (long)fd, (long)buf, (long)count));
}
static inline int sys_rename(const char *old, const char *newp) {
    return (int)__sc_errno(__syscall2(82, (long)old, (long)newp));
}
static inline int sys_link(const char *old, const char *newp) {
    return (int)__sc_errno(__syscall2(SYS_LINK, (long)old, (long)newp));
}
static inline int sys_symlink(const char *target, const char *linkpath) {
    return (int)__sc_errno(__syscall2(SYS_SYMLINK, (long)target, (long)linkpath));
}
static inline int sys_readlink(const char *path, char *buf, size_t sz) {
    return (int)__sc_errno(__syscall3(SYS_READLINK, (long)path, (long)buf, (long)sz));
}
static inline int sys_chmod(const char *path, unsigned int mode) {
    return (int)__sc_errno(__syscall2(90, (long)path, (long)mode));
}
static inline int sys_chown(const char *path, unsigned int uid, unsigned int gid) {
    return (int)__sc_errno(__syscall3(92, (long)path, (long)uid, (long)gid));
}
static inline int sys_kill(int pid, int sig) {
    return (int)__sc_errno(__syscall2(62, (long)pid, (long)sig));
}
static inline int sys_wait4(int pid, int *status, int opts) {
    return (int)__sc_errno(__syscall4(61, (long)pid, (long)status, (long)opts, 0L));
}
static inline int sys_pipe(int fds[2]) {
    return (int)__sc_errno(__syscall1(22, (long)fds));
}
static inline int sys_dup(int fd) {
    return (int)__sc_errno(__syscall1(32, (long)fd));
}
static inline int sys_dup2(int old, int newfd) {
    return (int)__sc_errno(__syscall2(33, (long)old, (long)newfd));
}
static inline int sys_setsid(void) {
    return (int)__sc_errno(__syscall0(SYS_SETSID));
}
static inline int sys_setpgid(int pid, int pgid) {
    return (int)__sc_errno(__syscall2(SYS_SETPGID, (long)pid, (long)pgid));
}
static inline int sys_getpgid(int pid) {
    return (int)__sc_errno(__syscall1(SYS_GETPGID, (long)pid));
}
static inline int sys_getppid(void) {
    return (int)__sc_errno(__syscall0(SYS_GETPPID));
}
static inline int sys_ioctl(int fd, unsigned long req, void *arg) {
    return (int)__sc_errno(__syscall3(16, (long)fd, (long)req, (long)arg));
}
static inline int sys_mount(const char *src, const char *tgt,
                             const char *fs, unsigned long flags, void *data) {
    return (int)__sc_errno(__syscall5(165, (long)src, (long)tgt,
                                       (long)fs, (long)flags, (long)data));
}
static inline int sys_umount(const char *tgt) {
    return (int)__sc_errno(__syscall2(SYS_UMOUNT2, (long)tgt, 0L));
}
static inline int sys_uname(struct utsname *buf) {
    return (int)__sc_errno(__syscall1(63, (long)buf));
}
static inline int sys_sysinfo(struct sysinfo *info) {
    return (int)__sc_errno(__syscall1(SYS_SYSINFO, (long)info));
}
static inline int sys_statfs(const char *path, struct statfs *buf) {
    return (int)__sc_errno(__syscall2(SYS_STATFS, (long)path, (long)buf));
}
static inline int sys_nanosleep(const struct timespec *req, struct timespec *rem) {
    return (int)__sc_errno(__syscall2(SYS_NANOSLEEP, (long)req, (long)rem));
}
static inline int sys_clock_gettime(int clk, struct timespec *tp) {
    return (int)__sc_errno(__syscall2(228, (long)clk, (long)tp));
}
static inline int sys_truncate(const char *path, int64_t len) {
    return (int)__sc_errno(__syscall2(SYS_TRUNCATE, (long)path, (long)len));
}
static inline int sys_sigaction(int sig, const struct sigaction *act,
                                 struct sigaction *old) {
    return (int)__sc_errno(__syscall4(SYS_RT_SIGACTION, (long)sig,
                                       (long)act, (long)old, 8L));
}
static inline int sys_socket(int dom, int type, int proto) {
    return (int)__sc_errno(__syscall3(41, (long)dom, (long)type, (long)proto));
}
static inline int sys_sendto(int fd, const void *buf, size_t len, int flags,
                              const struct sockaddr *addr, uint32_t addrlen) {
    return (int)__sc_errno(__syscall6(44, (long)fd, (long)buf, (long)len,
                                       (long)flags, (long)addr, (long)addrlen));
}
static inline int sys_recvfrom(int fd, void *buf, size_t len, int flags,
                                struct sockaddr *addr, uint32_t *addrlen) {
    return (int)__sc_errno(__syscall6(45, (long)fd, (long)buf, (long)len,
                                       (long)flags, (long)addr, (long)addrlen));
}

/* =========================================================================
 * sleep() — in secondi
 * ========================================================================= */
static inline unsigned int sleep(unsigned int secs) {
    struct timespec req = { .tv_sec = secs, .tv_nsec = 0 };
    sys_nanosleep(&req, (void*)0);
    return 0;
}

static inline int usleep(unsigned long usec) {
    struct timespec req = { .tv_sec = (int64_t)(usec / 1000000),
                            .tv_nsec = (int64_t)(usec % 1000000) * 1000 };
    return sys_nanosleep(&req, (void*)0);
}

/* =========================================================================
 * signal() — wrapper semplice attorno to rt_sigaction
 * ========================================================================= */
static inline void (*signal(int signum, void (*handler)(int)))(int) {
    struct sigaction act = {0}, old = {0};
    act.sa_handler = handler;
    act.sa_flags   = SA_RESTART;
    sys_sigaction(signum, &act, &old);
    return old.sa_handler;
}

/* =========================================================================
 * WNOHANG for wait4
 * ========================================================================= */
#define WNOHANG   1
#define WUNTRACED 2

#define WIFEXITED(s)   (((s) & 0x7f) == 0)
#define WEXITSTATUS(s) (((s) >> 8) & 0xff)
#define WIFSIGNALED(s) (((s) & 0x7f) != 0 && ((s) & 0x7f) != 0x7f)
#define WTERMSIG(s)    ((s) & 0x7f)
#define WIFSTOPPED(s)  (((s) & 0xff) == 0x7f)
#define WSTOPSIG(s)    (((s) >> 8) & 0xff)

/* =========================================================================
 * Helper: format permessi stile "drwxr-xr-x"
 * ========================================================================= */
static inline void format_mode(uint32_t mode, char out[11]) {
    out[0] = S_ISDIR(mode)  ? 'd' :
             S_ISLNK(mode)  ? 'l' :
             S_ISBLK(mode)  ? 'b' :
             S_ISCHR(mode)  ? 'c' :
             S_ISFIFO(mode) ? 'p' :
             S_ISSOCK(mode) ? 's' : '-';
    out[1] = (mode & S_IRUSR) ? 'r' : '-';
    out[2] = (mode & S_IWUSR) ? 'w' : '-';
    out[3] = (mode & S_IXUSR) ? ((mode & S_ISUID) ? 's' : 'x') :
             (mode & S_ISUID) ? 'S' : '-';
    out[4] = (mode & S_IRGRP) ? 'r' : '-';
    out[5] = (mode & S_IWGRP) ? 'w' : '-';
    out[6] = (mode & S_IXGRP) ? ((mode & S_ISGID) ? 's' : 'x') :
             (mode & S_ISGID) ? 'S' : '-';
    out[7] = (mode & S_IROTH) ? 'r' : '-';
    out[8] = (mode & S_IWOTH) ? 'w' : '-';
    out[9] = (mode & S_IXOTH) ? ((mode & S_ISVTX) ? 't' : 'x') :
             (mode & S_ISVTX) ? 'T' : '-';
    out[10] = '\0';
}

/* =========================================================================
 * Helper: formato human-readable size (1.2K, 3.4M, ecc.)
 * ========================================================================= */
static inline void format_size_human(int64_t sz, char *out, size_t outsz) {
    const char *units[] = {"B","K","M","G","T","P"};
    int u = 0;
    double v = (double)sz;
    while (v >= 1024.0 && u < 5) { v /= 1024.0; u++; }
    if (u == 0) snprintf(out, outsz, "%lld", (long long)sz);
    else        snprintf(out, outsz, "%.1f%s", v, units[u]);
}

/* =========================================================================
 * Helper: reads to riga from fd (without FILE*) — for /proc parsing
 * ========================================================================= */
static inline int read_line(int fd, char *buf, int max) {
    int n = 0;
    while (n < max - 1) {
        char c;
        long r = __syscall3(0, (long)fd, (long)&c, 1L);
        if (r <= 0) break;
        buf[n++] = c;
        if (c == '\n') break;
    }
    buf[n] = '\0';
    return n;
}

/* =========================================================================
 * Costanti ANSI for colori (usati from ls, top, edit)
 * ========================================================================= */
#define ANSI_RESET   "\033[0m"
#define ANSI_BOLD    "\033[1m"
#define ANSI_RED     "\033[31m"
#define ANSI_GREEN   "\033[32m"
#define ANSI_YELLOW  "\033[33m"
#define ANSI_BLUE    "\033[34m"
#define ANSI_MAGENTA "\033[35m"
#define ANSI_CYAN    "\033[36m"
#define ANSI_WHITE   "\033[37m"
#define ANSI_CLEAR   "\033[2J\033[H"
#define ANSI_UP(n)   "\033[" #n "A"
#define ANSI_HOME    "\033[H"
#define ANSI_HIDE_CURSOR "\033[?25l"
#define ANSI_SHOW_CURSOR "\033[?25h"
#define ANSI_ALT_SCREEN  "\033[?1049h"
#define ANSI_NORM_SCREEN "\033[?1049l"

/* =========================================================================
 * Macro helper: print up stderr AND torna queues of error
 * ========================================================================= */
#define die(fmt, ...) do { \
    fprintf(stderr, fmt "\n", ##__VA_ARGS__); exit(1); \
} while(0)

#define warn(fmt, ...) do { \
    fprintf(stderr, fmt "\n", ##__VA_ARGS__); \
} while(0)

/* =========================================================================
 * strdup sicuro (muore up OOM)
 * ========================================================================= */
static inline char *xstrdup(const char *s) {
    char *p = strdup(s);
    if (!p) die("out of memory");
    return p;
}
static inline void *xmalloc(size_t n) {
    void *p = malloc(n);
    if (!p) die("out of memory");
    return p;
}
static inline void *xcalloc(size_t n, size_t s) {
    void *p = calloc(n, s);
    if (!p) die("out of memory");
    return p;
}

#endif /* _USERSPACE_H */
