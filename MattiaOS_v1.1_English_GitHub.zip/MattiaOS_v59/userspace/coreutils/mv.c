/*
 * mv.c — move/rinomina file
 * Flags: -f forza, -v verbose, -n NOT sovrawritere
 */
#include "../include/userspace.h"
#define BUF_SZ (64*1024)

static int opt_force = 0, opt_verbose = 0, opt_no_clobber = 0;
static int s_errors = 0;

/* Copy ricorsiva with rimozione source (fallback cross-device) */
static int copy_and_remove_file(const char *src, const char *dst) {
    int in  = open(src, O_RDONLY, 0);
    if (in < 0) { fprintf(stderr, "mv: %s: %s\n", src, strerror(errno)); return 1; }
    struct stat st; sys_fstat(in, &st);
    int out = open(dst, O_WRONLY|O_CREAT|O_TRUNC, st.st_mode & 0777);
    if (out < 0) {
        fprintf(stderr, "mv: %s: %s\n", dst, strerror(errno));
        close(in); return 1;
    }
    static char buf[BUF_SZ];
    ssize_t n;
    while ((n = read(in, buf, BUF_SZ)) > 0) {
        ssize_t w = 0;
        while (w < n) { ssize_t r = write(out, buf+w, n-w); if(r<=0) break; w+=r; }
    }
    close(in); close(out);
    unlink(src);
    return 0;
}

static int copy_and_remove_dir(const char *src, const char *dst);

static int copy_and_remove_dir(const char *src, const char *dst) {
    struct stat st;
    sys_lstat(src, &st);
    struct stat dst_st;
    if (sys_stat(dst, &dst_st) < 0)
        mkdir(dst, st.st_mode & 0777);

    int fd = open(src, O_RDONLY, 0);
    if (fd < 0) return 1;
    char dbuf[4096]; int bytes;
    while ((bytes = sys_getdents(fd, dbuf, sizeof(dbuf))) > 0) {
        int off = 0;
        while (off < bytes) {
            struct dirent *d = (struct dirent *)(dbuf + off);
            if (d->d_reclen == 0) break;
            if (strcmp(d->d_name, ".") && strcmp(d->d_name, "..")) {
                char ss[4096], dd[4096];
                snprintf(ss, sizeof(ss), "%s/%s", src, d->d_name);
                snprintf(dd, sizeof(dd), "%s/%s", dst, d->d_name);
                struct stat sub; sys_lstat(ss, &sub);
                if (S_ISDIR(sub.st_mode)) copy_and_remove_dir(ss, dd);
                else copy_and_remove_file(ss, dd);
            }
            off += d->d_reclen;
        }
    }
    close(fd);
    rmdir(src);
    return 0;
}

static void do_move(const char *src, const char *dst) {
    /* Controlla opt_no_clobber */
    if (opt_no_clobber) {
        struct stat st;
        if (sys_lstat(dst, &st) == 0) return;
    }

    /* Prova before rename() — funziona if stesso filesystem */
    if (sys_rename(src, dst) == 0) {
        if (opt_verbose) printf("'%s' -> '%s'\n", src, dst);
        return;
    }

    /* Fallback cross-device */
    if (errno == 18 /* EXDEV */) {
        struct stat st;
        sys_lstat(src, &st);
        int r;
        if (S_ISDIR(st.st_mode)) r = copy_and_remove_dir(src, dst);
        else r = copy_and_remove_file(src, dst);
        if (r == 0 && opt_verbose) printf("'%s' -> '%s'\n", src, dst);
        if (r) s_errors++;
    } else {
        fprintf(stderr, "mv: '%s' -> '%s': %s\n", src, dst, strerror(errno));
        s_errors++;
    }
}

int main(int argc, char **argv) {
    int first_arg = 1;
    for (int i = 1; i < argc; i++) {
        if (argv[i][0] == '-' && argv[i][1]) {
            for (int j = 1; argv[i][j]; j++) {
                switch (argv[i][j]) {
                case 'f': opt_force = 1; break;
                case 'v': opt_verbose = 1; break;
                case 'n': opt_no_clobber = 1; break;
                }
            }
            first_arg = i + 1;
        }
    }

    int nfiles = argc - first_arg;
    if (nfiles < 2) { fprintf(stderr, "Uso: mv [-fvn] sorgente... dest\n"); return 1; }

    char *dst = argv[argc - 1];
    struct stat dst_st;
    int dst_is_dir = (sys_stat(dst, &dst_st) == 0 && S_ISDIR(dst_st.st_mode));

    if (nfiles > 2 && !dst_is_dir) {
        fprintf(stderr, "mv: '%s' non è una directory\n", dst); return 1;
    }

    for (int i = first_arg; i < argc - 1; i++) {
        if (dst_is_dir) {
            const char *base = strrchr(argv[i], '/');
            base = base ? base + 1 : argv[i];
            char full[4096];
            snprintf(full, sizeof(full), "%s/%s", dst, base);
            do_move(argv[i], full);
        } else {
            do_move(argv[i], dst);
        }
    }
    return s_errors ? 1 : 0;
}
