/*
 * chmod.c — cambia the permessi of file/directory
 * Support: modalità ottale (755) AND simbolica (u+x, go-w, to=r, ...)
 * Flags: -R recursive, -v verbose
 */
#include "../include/userspace.h"

static int opt_recursive = 0, opt_verbose = 0;
static int s_errors = 0;

/* Calculate nuovi permessi from stringa simbolica "u+x", "to=rw", ecc. */
static unsigned int parse_symbolic(const char *mode_str, unsigned int current) {
    unsigned int result = current & 07777;
    const char *p = mode_str;

    while (*p) {
        /* Chi */
        unsigned int who = 0;
        while (*p == 'u' || *p == 'g' || *p == 'o' || *p == 'a') {
            if (*p == 'u') who |= 0100;
            if (*p == 'g') who |= 0010;
            if (*p == 'o') who |= 0001;
            if (*p == 'a') who |= 0111;
            p++;
        }
        if (!who) who = 0111; /* default: all */

        /* Op */
        char op = *p++;

        /* Permessi */
        unsigned int bits = 0;
        while (*p == 'r' || *p == 'w' || *p == 'x' ||
               *p == 's' || *p == 't' || *p == 'X') {
            if (*p == 'r') bits |= 04;
            if (*p == 'w') bits |= 02;
            if (*p == 'x' || *p == 'X') bits |= 01;
            if (*p == 's') bits |= 010;
            if (*p == 't') bits |= 0100;
            p++;
        }

        /* Applica */
        for (int shift = 0; shift < 3; shift++) {
            if (who & (1 << shift)) {
                unsigned int mask = bits << (shift * 3);
                if (op == '+') result |= mask;
                else if (op == '-') result &= ~mask;
                else if (op == '=') {
                    unsigned int clear = 07 << (shift * 3);
                    result = (result & ~clear) | mask;
                }
            }
        }

        if (*p == ',') p++;
    }
    return result;
}

static unsigned int parse_mode(const char *mode_str, unsigned int current) {
    /* Ottale diretto */
    if (mode_str[0] >= '0' && mode_str[0] <= '7') {
        return (unsigned int)strtol(mode_str, (char **)0, 8);
    }
    return parse_symbolic(mode_str, current);
}

static void chmod_path(const char *path, const char *mode_str) {
    struct stat st;
    if (sys_lstat(path, &st) < 0) {
        fprintf(stderr, "chmod: %s: %s\n", path, strerror(errno));
        s_errors++; return;
    }

    unsigned int new_mode = parse_mode(mode_str, st.st_mode & 07777);

    if (sys_chmod(path, new_mode) < 0) {
        fprintf(stderr, "chmod: %s: %s\n", path, strerror(errno));
        s_errors++; return;
    }
    if (opt_verbose) {
        char old_p[11], new_p[11];
        format_mode(st.st_mode, old_p);
        struct stat new_st; sys_lstat(path, &new_st);
        format_mode(new_st.st_mode, new_p);
        printf("modo di '%s' cambiato da %s (%04o) a %s (%04o)\n",
               path, old_p, st.st_mode & 07777, new_p, new_mode);
    }

    if (opt_recursive && S_ISDIR(st.st_mode)) {
        int fd = open(path, O_RDONLY, 0);
        if (fd < 0) return;
        char dbuf[4096]; int bytes;
        while ((bytes = sys_getdents(fd, dbuf, sizeof(dbuf))) > 0) {
            int off = 0;
            while (off < bytes) {
                struct dirent *d = (struct dirent *)(dbuf + off);
                if (d->d_reclen == 0) break;
                if (strcmp(d->d_name, ".") && strcmp(d->d_name, "..")) {
                    char sub[4096];
                    snprintf(sub, sizeof(sub), "%s/%s", path, d->d_name);
                    chmod_path(sub, mode_str);
                }
                off += d->d_reclen;
            }
        }
        close(fd);
    }
}

int main(int argc, char **argv) {
    int first = 1;
    for (int i = 1; i < argc; i++) {
        if (argv[i][0] == '-' && argv[i][1]) {
            for (int j = 1; argv[i][j]; j++) {
                if (argv[i][j] == 'R') opt_recursive = 1;
                if (argv[i][j] == 'v') opt_verbose   = 1;
            }
            first = i + 1;
        }
    }
    if (argc - first < 2) {
        fprintf(stderr, "Uso: chmod [-Rv] MODO file...\n"); return 1;
    }
    const char *mode_str = argv[first++];
    for (int i = first; i < argc; i++) chmod_path(argv[i], mode_str);
    return s_errors ? 1 : 0;
}
