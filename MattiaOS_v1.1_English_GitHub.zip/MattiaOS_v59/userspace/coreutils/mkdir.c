/*
 * mkdir.c — crea directory
 * Flags: -p crea parents, -v verbose, -m modalità
 */
#include "../include/userspace.h"

static int opt_parents = 0, opt_verbose = 0;
static int s_mode = 0755;

static int mkdir_p(const char *path, int mode) {
    struct stat st;
    if (sys_stat(path, &st) == 0) {
        if (S_ISDIR(st.st_mode)) return 0;
        fprintf(stderr, "mkdir: %s: esiste ed è un file\n", path);
        return 1;
    }

    /* Crea the path parent */
    char parent[4096];
    strncpy(parent, path, sizeof(parent) - 1);
    char *last_slash = strrchr(parent, '/');
    if (last_slash && last_slash != parent) {
        *last_slash = '\0';
        if (mkdir_p(parent, mode) != 0) return 1;
    }

    if (mkdir(path, mode) < 0 && errno != 17 /* EEXIST */) {
        fprintf(stderr, "mkdir: %s: %s\n", path, strerror(errno));
        return 1;
    }
    if (opt_verbose) printf("mkdir: creata directory '%s'\n", path);
    return 0;
}

int main(int argc, char **argv) {
    int first = 1;
    for (int i = 1; i < argc; i++) {
        if (strcmp(argv[i], "-p") == 0) { opt_parents = 1; first = i+1; }
        else if (strcmp(argv[i], "-v") == 0) { opt_verbose = 1; first = i+1; }
        else if (strcmp(argv[i], "-m") == 0 && argv[i+1]) {
            s_mode = (int)strtol(argv[++i], (char **)0, 8); first = i+1;
        } else if (argv[i][0] == '-') {
            for (int j = 1; argv[i][j]; j++) {
                if (argv[i][j] == 'p') opt_parents = 1;
                if (argv[i][j] == 'v') opt_verbose = 1;
            }
            first = i+1;
        }
    }
    if (first >= argc) { fprintf(stderr, "Uso: mkdir [-pv] [-m mode] dir...\n"); return 1; }

    int errors = 0;
    for (int i = first; i < argc; i++) {
        if (opt_parents) errors += mkdir_p(argv[i], s_mode);
        else {
            if (mkdir(argv[i], s_mode) < 0) {
                fprintf(stderr, "mkdir: %s: %s\n", argv[i], strerror(errno));
                errors++;
            } else if (opt_verbose) {
                printf("mkdir: creata directory '%s'\n", argv[i]);
            }
        }
    }
    return errors ? 1 : 0;
}
