/*
 * top.c — monitor processes interactive
 * Comandi: q quit, k kill, r renice, s sleep interval, 1 toggle CPU for core
 *          h help, SPAZIO refresh
 */
#include "../include/userspace.h"

/* termios semplificato */
struct termios {
    uint32_t c_iflag, c_oflag, c_cflag, c_lflag;
    uint8_t  c_line; uint8_t c_cc[19];
    uint32_t c_ispeed, c_ospeed;
};
#define TCGETS 0x5401
#define TCSETS 0x5402
#define ICANON 0000002
#define ECHO   0000010
#define ISIG   0000001

#define MAX_PROCS 512

typedef struct {
    int  pid, ppid;
    unsigned int uid;
    char name[64];
    char state;
    long long vsz, rss;
} pinfo_t;

static pinfo_t  s_procs[MAX_PROCS];
static int      s_nprocs;
static int      s_interval = 2;
static struct termios s_saved;

static void raw_mode(void) {
    struct termios t;
    sys_ioctl(0, TCGETS, &s_saved);
    t = s_saved;
    t.c_lflag &= ~(ICANON | ECHO | ISIG);
    t.c_cc[6] = 1; t.c_cc[5] = 0;
    sys_ioctl(0, TCSETS, &t);
}
static void restore(void) { sys_ioctl(0, TCSETS, &s_saved); }

static int read_proc(int pid, pinfo_t *p) {
    char path[64];
    snprintf(path, sizeof(path), "/proc/%d/status", pid);
    int fd = open(path, O_RDONLY, 0);
    if (fd < 0) return -1;
    char buf[2048]; int n = (int)read(fd, buf, sizeof(buf)-1); close(fd);
    if (n <= 0) return -1;
    buf[n] = '\0';
    p->pid = pid; p->ppid = 0; p->uid = 0; p->state = '?';
    p->vsz = 0; p->rss = 0; strncpy(p->name, "?", 63);
    char *line = buf;
    while (line && *line) {
        char *nl = strchr(line, '\n');
        if (nl) *nl = '\0';
        if (!strncmp(line, "Name:", 5)) { char *v = line+5; while(*v==' '||*v=='\t')v++; strncpy(p->name,v,63); }
        else if (!strncmp(line, "State:", 6)) { char *v=line+6; while(*v==' ')v++; p->state=*v; }
        else if (!strncmp(line, "PPid:", 5)) p->ppid=atoi(line+5);
        else if (!strncmp(line, "Uid:", 4)) p->uid=(unsigned)atoi(line+4);
        else if (!strncmp(line, "VmSize:", 7)) p->vsz=atoll(line+7);
        else if (!strncmp(line, "VmRSS:", 6)) p->rss=atoll(line+6);
        if (!nl) { break; } line = nl+1;
    }
    return 0;
}

static void scan(void) {
    s_nprocs = 0;
    int fd = open("/proc", O_RDONLY, 0);
    if (fd < 0) return;
    char dbuf[4096]; int bytes;
    while ((bytes = sys_getdents(fd, dbuf, sizeof(dbuf))) > 0 && s_nprocs < MAX_PROCS) {
        int off = 0;
        while (off < bytes && s_nprocs < MAX_PROCS) {
            struct dirent *d = (struct dirent *)(dbuf + off);
            if (d->d_reclen == 0) break;
            int is_pid = d->d_name[0] >= '1' && d->d_name[0] <= '9';
            for (int i = 1; is_pid && d->d_name[i]; i++)
                if (d->d_name[i] < '0' || d->d_name[i] > '9') is_pid = 0;
            if (is_pid && read_proc(atoi(d->d_name), &s_procs[s_nprocs]) == 0)
                s_nprocs++;
            off += d->d_reclen;
        }
    }
    close(fd);
}

static int cmp_rss(const void *a, const void *b) {
    return (int)(((pinfo_t*)b)->rss - ((pinfo_t*)a)->rss);
}

static void draw(void) {
    struct winsize ws = {0};
    sys_ioctl(1, TIOCGWINSZ, &ws);
    int rows = ws.ws_row > 0 ? ws.ws_row : 24;
    int cols = ws.ws_col > 0 ? ws.ws_col : 80;

    /* Leggi sysinfo */
    struct sysinfo si = {0};
    sys_sysinfo(&si);
    long long total_mb = (long long)si.totalram * si.mem_unit / 1048576;
    long long free_mb  = (long long)si.freeram  * si.mem_unit / 1048576;
    long long used_mb  = total_mb - free_mb;

    printf(ANSI_HOME ANSI_CLEAR);
    printf(ANSI_BOLD "top" ANSI_RESET " - MattiaOS | uptime %lldd %02lldh%02lldm | procs: %d\n",
           (long long)si.uptime/86400, (si.uptime%86400)/3600, (si.uptime%3600)/60, s_nprocs);
    printf("Mem:  total %lld MB  usata %lld MB  free %lld MB\n",
           total_mb, used_mb, free_mb);
    printf("Swap: total %lld MB  free %lld MB\n",
           (long long)si.totalswap * si.mem_unit / 1048576,
           (long long)si.freeswap  * si.mem_unit / 1048576);
    printf("\n");

    /* Header colonne */
    printf(ANSI_BOLD "%-6s %-4s %-8s %-6s %-6s %-8s %s\n" ANSI_RESET,
           "PID", "S", "USER", "VSZ(kB)", "RSS(kB)", "%%MEM", "COMMAND");

    int max_rows = rows - 7;
    for (int i = 0; i < s_nprocs && i < max_rows; i++) {
        pinfo_t *p = &s_procs[i];
        double pct = total_mb > 0 ? (p->rss * 100.0 / (total_mb * 1024.0)) : 0.0;
        printf("%-6d %-4c %-8u %-6lld %-6lld %-8.1f %.*s\n",
               p->pid, p->state, p->uid,
               p->vsz, p->rss, pct,
               cols - 47, p->name);
    }
    printf("\n" ANSI_BOLD "q" ANSI_RESET "=esci  "
           ANSI_BOLD "k" ANSI_RESET "=kill  "
           ANSI_BOLD "s" ANSI_RESET "=intervallo  "
           ANSI_BOLD "SPAZIO" ANSI_RESET "=refresh\n");
    fflush(stdout);
}

static int try_read_char(char *c) {
    /* VTIME usa timeout: aspetta s_interval secondi */
    struct termios t;
    sys_ioctl(0, TCGETS, &t);
    t.c_cc[5] = (uint8_t)(s_interval * 10);  /* VTIME in decimi of second */
    t.c_cc[6] = 0;                             /* VMIN */
    sys_ioctl(0, TCSETS, &t);
    int r = (int)read(0, c, 1);
    /* Ripristina VMIN=1 VTIME=0 */
    t.c_cc[5] = 0; t.c_cc[6] = 1;
    sys_ioctl(0, TCSETS, &t);
    return r;
}

int main(int argc, char **argv) {
    (void)argc; (void)argv;

    printf(ANSI_ALT_SCREEN ANSI_HIDE_CURSOR);
    raw_mode();

    for (;;) {
        scan();
        qsort(s_procs, s_nprocs, sizeof(pinfo_t), cmp_rss);
        draw();

        char c; int r = try_read_char(&c);
        if (r <= 0) continue;  /* timeout: refresh */

        if (c == 'q' || c == 'Q') break;
        if (c == ' ') continue;

        if (c == 'k') {
            printf("\nKill PID: "); fflush(stdout);
            char buf[16]; int bi = 0;
            struct termios save2 = s_saved;
            sys_ioctl(0, TCSETS, &save2);
            while (bi < 15) {
                if (read(0, &buf[bi], 1) <= 0) break;
                if (buf[bi] == '\n' || buf[bi] == '\r') break;
                write(1, &buf[bi], 1); bi++;
            }
            buf[bi] = '\0'; raw_mode();
            int pid = atoi(buf);
            if (pid > 0) sys_kill(pid, SIGTERM);
        } else if (c == 's') {
            printf("\nIntervallo (s): "); fflush(stdout);
            char buf[8]; int bi = 0;
            struct termios save2 = s_saved;
            sys_ioctl(0, TCSETS, &save2);
            while (bi < 7) {
                if (read(0, &buf[bi], 1) <= 0) break;
                if (buf[bi] == '\n') break;
                write(1, &buf[bi], 1); bi++;
            }
            buf[bi] = '\0'; raw_mode();
            int n = atoi(buf);
            if (n > 0 && n < 3600) s_interval = n;
        }
    }

    restore();
    printf(ANSI_NORM_SCREEN ANSI_SHOW_CURSOR);
    return 0;
}
