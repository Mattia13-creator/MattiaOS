/*
 * rm.c — rimozione file AND directory
 * -r / -R recursive, -f forza (NOT error if NOT esiste), -v verbose
 * Nota: for blueprint MattiaOS, the kernel remove immediatamente also
 * the file aperti from altri processes (no refcount nel vnode).
 */
#include "../include/userspace.h"

static int opt_recursive = 0, opt_force = 0, opt_verbose = 0;
static int s_errors = 0;

static void rm_entry(const char *path);

static void rm_dir_recursive(const char *path) {
    int fd = open(path, O_RDONLY, 0);
    if (fd < 0) {
        if (!opt_force) fprintf(stderr, "rm: %s: %s\n", path, strerror(errno));
        s_errors++;
        return;
    }
    char dbuf[4096];
    int bytes;
    while ((bytes = sys_getdents(fd, dbuf, sizeof(dbuf))) > 0) {
        int off = 0;
        while (off < bytes) {
            struct dirent *d = (struct dirent *)(dbuf + off);
            if (d->d_reclen == 0) break;
            if (strcmp(d->d_name, ".") != 0 && strcmp(d->d_name, "..") != 0) {
                char sub[4096];
                snprintf(sub, sizeof(sub), "%s/%s", path, d->d_name);
                rm_entry(sub);
            }
            off += d->d_reclen;
        }
    }
    close(fd);

    if (rmdir(path) < 0) {
        if (!opt_force) fprintf(stderr, "rm: %s: %s\n", path, strerror(errno));
        s_errors++;
    } else if (opt_verbose) {
        printf("removed directory '%s'\n", path);
    }
}

static void rm_entry(const char *path) {
    struct stat st;
    if (sys_lstat(path, &st) < 0) {
        if (!opt_force) fprintf(stderr, "rm: %s: %s\n", path, strerror(errno));
        else return;
        s_errors++;
        return;
    }

    if (S_ISDIR(st.st_mode)) {
        if (!opt_recursive) {
            fprintf(stderr, "rm: %s: è una directory (usa -r)\n", path);
            s_errors++;
            return;
        }
        rm_dir_recursive(path);
    } else {
        if (unlink(path) < 0) {
            if (!opt_force) fprintf(stderr, "rm: %s: %s\n", path, strerror(errno));
            s_errors++;
        } else if (opt_verbose) {
            printf("removed '%s'\n", path);
        }
    }
}

int main(int argc, char **argv) {
    int first_file = 1;
    for (int i = 1; i < argc; i++) {
        if (argv[i][0] == '-' && argv[i][1] != '\0' && !strchr(argv[i]+1, '/')) {
            for (int j = 1; argv[i][j]; j++) {
                switch(argv[i][j]) {
                case 'r': case 'R': opt_recursive = 1; break;
                case 'f': opt_force = 1; break;
                case 'v': opt_verbose = 1; break;
                default:
                    fprintf(stderr, "rm: opzione sconosciuta: -%c\n", argv[i][j]);
                    return 1;
                }
            }
        } else {
            first_file = 0;
            rm_entry(argv[i]);
        }
    }
    if (first_file && !opt_force) {
        fprintf(stderr, "Uso: rm [-rfv] file...\n");
        return 1;
    }
    return s_errors ? 1 : 0;
}
