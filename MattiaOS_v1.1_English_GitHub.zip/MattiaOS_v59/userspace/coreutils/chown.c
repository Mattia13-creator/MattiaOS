/*
 * chown.c — cambia proprietario/group of file
 * Uso: chown [-Rv] OWNER[:GROUP] file...
 * OWNER può essere UID numerico OR name utente (searchto in /etc/passwd)
 */
#include "../include/userspace.h"

static int opt_recursive = 0, opt_verbose = 0;
static int s_errors = 0;

/* Risolve name utente → UID readndo /etc/passwd */
static int resolve_uid(const char *name, unsigned int *uid_out) {
    /* Prima prova numerico */
    char *end;
    long v = strtol(name, &end, 10);
    if (*end == '\0') { *uid_out = (unsigned int)v; return 0; }

    /* Search in /etc/passwd: root:x:0:0:root:/root:/bin/sh */
    FILE *f = fopen("/etc/passwd", "r");
    if (!f) { *uid_out = 0; return -1; }
    char line[256];
    while (fgets(line, sizeof(line), f)) {
        char *fields[7]; int n = 0;
        char *save, *tok = strtok_r(line, ":", &save);
        while (tok && n < 7) { fields[n++] = tok; tok = strtok_r((char*)0, ":", &save); }
        if (n >= 3 && strcmp(fields[0], name) == 0) {
            *uid_out = (unsigned int)atoi(fields[2]);
            fclose(f); return 0;
        }
    }
    fclose(f);
    fprintf(stderr, "chown: utente sconosciuto: %s\n", name);
    return -1;
}

static int resolve_gid(const char *name, unsigned int *gid_out) {
    char *end;
    long v = strtol(name, &end, 10);
    if (*end == '\0') { *gid_out = (unsigned int)v; return 0; }

    FILE *f = fopen("/etc/group", "r");
    if (!f) { *gid_out = 0; return -1; }
    char line[256];
    while (fgets(line, sizeof(line), f)) {
        char *save, *tok = strtok_r(line, ":", &save);
        char *gname = tok;
        tok = strtok_r((char*)0, ":", &save); /* password */
        char *gid_s = strtok_r((char*)0, ":", &save);
        if (gname && gid_s && strcmp(gname, name) == 0) {
            *gid_out = (unsigned int)atoi(gid_s);
            fclose(f); return 0;
        }
    }
    fclose(f);
    fprintf(stderr, "chown: gruppo sconosciuto: %s\n", name);
    return -1;
}

static void do_chown(const char *path, unsigned int uid, unsigned int gid,
                     int change_uid, int change_gid) {
    struct stat st;
    if (sys_lstat(path, &st) < 0) {
        fprintf(stderr, "chown: %s: %s\n", path, strerror(errno));
        s_errors++; return;
    }

    unsigned int new_uid = change_uid ? uid : st.st_uid;
    unsigned int new_gid = change_gid ? gid : st.st_gid;

    if (sys_chown(path, new_uid, new_gid) < 0) {
        fprintf(stderr, "chown: %s: %s\n", path, strerror(errno));
        s_errors++; return;
    }
    if (opt_verbose)
        printf("proprietario di '%s' cambiato in %u:%u\n", path, new_uid, new_gid);

    if (opt_recursive && S_ISDIR(st.st_mode)) {
        int fd = open(path, O_RDONLY, 0);
        if (fd < 0) return;
        char dbuf[4096]; int bytes;
        while ((bytes = sys_getdents(fd, dbuf, sizeof(dbuf))) > 0) {
            int off = 0;
            while (off < bytes) {
                struct dirent *d = (struct dirent *)(dbuf + off);
                if (d->d_reclen == 0) break;
                if (strcmp(d->d_name, ".") && strcmp(d->d_name, "..")) {
                    char sub[4096];
                    snprintf(sub, sizeof(sub), "%s/%s", path, d->d_name);
                    do_chown(sub, uid, gid, change_uid, change_gid);
                }
                off += d->d_reclen;
            }
        }
        close(fd);
    }
}

int main(int argc, char **argv) {
    int first = 1;
    for (int i = 1; i < argc; i++) {
        if (argv[i][0] == '-' && argv[i][1]) {
            for (int j = 1; argv[i][j]; j++) {
                if (argv[i][j] == 'R') opt_recursive = 1;
                if (argv[i][j] == 'v') opt_verbose   = 1;
            }
            first = i + 1;
        }
    }
    if (argc - first < 2) {
        fprintf(stderr, "Uso: chown [-Rv] OWNER[:GROUP] file...\n"); return 1;
    }

    /* Parsa OWNER[:GROUP] */
    char spec[256]; strncpy(spec, argv[first++], 255);
    char *colon = strchr(spec, ':');
    unsigned int uid = 0, gid = 0;
    int change_uid = 0, change_gid = 0;

    if (colon) {
        *colon = '\0';
        if (*spec)       { change_uid = (resolve_uid(spec,    &uid) == 0); }
        if (*(colon+1))  { change_gid = (resolve_gid(colon+1, &gid) == 0); }
    } else {
        change_uid = (resolve_uid(spec, &uid) == 0);
    }

    for (int i = first; i < argc; i++)
        do_chown(argv[i], uid, gid, change_uid, change_gid);
    return s_errors ? 1 : 0;
}
