/*
 * dmesg.c — print the ring buffer of the kernel
 * Read /proc/kmsg OR /dev/kmsg. Flags: -c pulisce, -n level, -w segui
 */
#include "../include/userspace.h"

/* SYS_SYSLOG = 103 up Linux x86-64 — MattiaOS usa the stesso number */
#define SYS_SYSLOG 103
#define SYSLOG_ACTION_READ_ALL   3
#define SYSLOG_ACTION_CLEAR      5
#define SYSLOG_ACTION_SIZE_BUFFER 10

static long syslog_call(int type, char *buf, int len) {
    return __syscall3(SYS_SYSLOG, (long)type, (long)buf, (long)len);
}

int main(int argc, char **argv) {
    int opt_clear = 0, opt_follow = 0, opt_level = -1;
    for (int i = 1; i < argc; i++) {
        if (!strcmp(argv[i], "-c"))      opt_clear  = 1;
        else if (!strcmp(argv[i], "-w")) opt_follow = 1;
        else if (!strcmp(argv[i], "-n") && argv[i+1])
            opt_level = atoi(argv[++i]);
        else if (argv[i][0] == '-')
            for (int j = 1; argv[i][j]; j++) {
                if (argv[i][j] == 'c') opt_clear  = 1;
                if (argv[i][j] == 'w') opt_follow = 1;
            }
    }
    (void)opt_level;

    /* Prima prova syslog syscall */
    long sz = syslog_call(SYSLOG_ACTION_SIZE_BUFFER, (char*)0, 0);
    if (sz > 0) {
        char *buf = xmalloc((size_t)sz + 1);
        long n = syslog_call(SYSLOG_ACTION_READ_ALL, buf, (int)sz);
        if (n > 0) {
            buf[n] = '\0';
            write(1, buf, (size_t)n);
            if (buf[n-1] != '\n') write(1, "\n", 1);
        }
        free(buf);
        if (opt_clear) syslog_call(SYSLOG_ACTION_CLEAR, (char*)0, 0);
        return 0;
    }

    /* Fallback: leggi /proc/kmsg OR /var/log/dmesg */
    const char *sources[] = { "/proc/kmsg", "/var/log/dmesg", "/dev/kmsg", (char*)0 };
    int fd = -1;
    for (int i = 0; sources[i]; i++) {
        fd = open(sources[i], O_RDONLY, 0);
        if (fd >= 0) break;
    }
    if (fd < 0) {
        fprintf(stderr, "dmesg: impossibile readre ring buffer kernel\n");
        return 1;
    }

    char buf[4096];
    ssize_t n;
    while ((n = read(fd, buf, sizeof(buf))) > 0) {
        write(1, buf, (size_t)n);
        if (!opt_follow) {
            /* Verify if ci are altri data */
            struct stat st;
            if (sys_fstat(fd, &st) == 0 && !S_ISCHR(st.st_mode) &&
                !S_ISFIFO(st.st_mode))
                break;
        }
    }
    close(fd);
    return 0;
}
