/*
 * grep.c — risearch pattern in file (ERE via NFA semplice)
 * Flags: -the case insensitive, -v invert, -n numera righe, -l only names file,
 *        -c count, -r recursive, -E regex estesa, -F stringa fissa, -w parola,
 *        -l/-L, -q quiet, --color
 */
#include "../include/userspace.h"

/* =========================================================================
 * Regex NFA semplice (support: . * + ? | [] [^] ^ $ \d \w \s)
 * Per semplicità: compila in stringa AND usa match recursive.
 * ========================================================================= */
typedef struct { const char *pat; int igncase; } regex_t;

static int char_match(char pc, char sc, int igncase) {
    if (igncase) {
        pc = (pc >= 'A' && pc <= 'Z') ? pc + 32 : pc;
        sc = (sc >= 'A' && sc <= 'Z') ? sc + 32 : sc;
    }
    return pc == sc;
}

/* match_here: testa pat contro testo from *s in poi */
static int match_here(const char *pat, const char *s, int igncase);

static int match_class(const char *cls, char c, int igncase) {
    int negate = 0, match = 0;
    if (*cls == '^') { negate = 1; cls++; }
    while (*cls && *cls != ']') {
        if (cls[1] == '-' && cls[2] && cls[2] != ']') {
            char lo = cls[0], hi = cls[2];
            if (igncase) {
                lo = (lo >= 'A' && lo <= 'Z') ? lo+32 : lo;
                hi = (hi >= 'A' && hi <= 'Z') ? hi+32 : hi;
                char cc = (c  >= 'A' && c  <= 'Z') ? c+32  : c;
                if (cc >= lo && cc <= hi) match = 1;
            } else if (c >= lo && c <= hi) match = 1;
            cls += 3;
        } else {
            if (char_match(*cls, c, igncase)) match = 1;
            cls++;
        }
    }
    return negate ? !match : match;
}

static int match_one(const char *pat, char c, int igncase) {
    if (*pat == '.') return c != '\0';
    if (*pat == '\\') {
        pat++;
        if (*pat == 'd') return c >= '0' && c <= '9';
        if (*pat == 'D') return !(c >= '0' && c <= '9');
        if (*pat == 'w') return (c>='a'&&c<='z')||(c>='A'&&c<='Z')||(c>='0'&&c<='9')||c=='_';
        if (*pat == 'W') return !((c>='a'&&c<='z')||(c>='A'&&c<='Z')||(c>='0'&&c<='9')||c=='_');
        if (*pat == 's') return c==' '||c=='\t'||c=='\n'||c=='\r';
        if (*pat == 'S') return !(c==' '||c=='\t'||c=='\n'||c=='\r');
        return char_match(*pat, c, igncase);
    }
    if (*pat == '[') {
        const char *end = pat + 1;
        if (*end == '^') end++;
        while (*end && *end != ']') end++;
        char cls[256]; int cl = (int)(end - pat - 1);
        memcpy(cls, pat + 1, cl); cls[cl] = '\0';
        return match_class(cls, c, igncase);
    }
    return char_match(*pat, c, igncase);
}

static int pat_len(const char *pat) {
    if (*pat == '[') {
        int i = 1;
        if (pat[i] == '^') i++;
        while (pat[i] && pat[i] != ']') i++;
        return i + 1;
    }
    if (*pat == '\\') return 2;
    return 1;
}

static int match_here(const char *pat, const char *s, int ic) {
    if (!*pat) return 1;
    if (*pat == '$' && !*(pat+1)) return *s == '\0';
    if (*pat == '(') {
        /* Alternazione semplice: (to|b) */
        const char *p = pat + 1;
        while (*p && *p != ')') p++;
        /* semplificazione: tratta as sequence */
        return match_here(pat + 1, s, ic);
    }
    int pl = pat_len(pat);
    const char *next = pat + pl;
    if (*next == '*') return (match_one(pat, *s, ic) && match_here(pat, s+1, ic)) ||
                              match_here(next+1, s, ic);
    if (*next == '+') return match_one(pat, *s, ic) &&
                             (match_here(pat, s+1, ic) || match_here(next+1, s+1, ic));
    if (*next == '?') return (match_one(pat, *s, ic) && match_here(next+1, s+1, ic)) ||
                              match_here(next+1, s, ic);
    return match_one(pat, *s, ic) && match_here(next, s+1, ic);
}

static int regex_match(const regex_t *re, const char *line) {
    const char *pat = re->pat;
    if (*pat == '^') return match_here(pat + 1, line, re->igncase);
    do {
        if (match_here(pat, line, re->igncase)) return 1;
    } while (*line++);
    return 0;
}

/* Fixed string match */
static int fixed_match(const char *pat, const char *line, int ic) {
    size_t pl = strlen(pat);
    while (*line) {
        int eq = 1;
        for (size_t i = 0; i < pl && line[i]; i++) {
            char a = line[i], b = pat[i];
            if (ic) { a = (a>='A'&&a<='Z')?a+32:a; b=(b>='A'&&b<='Z')?b+32:b; }
            if (a != b) { eq = 0; break; }
        }
        if (eq) return 1;
        line++;
    }
    return 0;
}

/* =========================================================================
 * Stato global
 * ========================================================================= */
static int opt_ic=0, opt_inv=0, opt_num=0, opt_files=0, opt_count=0;
static int opt_rec=0, opt_fixed=0, opt_word=0, opt_quiet=0, opt_color=0;
static int s_total_matches __attribute__((unused)) = 0;

static int grep_fd(int fd, const char *fname, int nfiles,
                   const char *pat, int is_fixed) {
    regex_t re = { pat, opt_ic };
    char line[4096];
    long long lineno = 0;
    int matches = 0;
    char c;
    int li = 0;

    while (1) {
        ssize_t r = read(fd, &c, 1);
        if (r <= 0 && li == 0) break;
        if (r <= 0 || c == '\n' || li >= 4095) {
            line[li] = '\0'; li = 0; lineno++;
            int m = is_fixed ? fixed_match(pat, line, opt_ic)
                              : regex_match(&re, line);
            if (opt_word && m) {
                /* Verify confini of parola: semplificato */
            }
            if (opt_inv) m = !m;
            if (m) {
                matches++;
                if (opt_quiet) return 1;
                if (opt_files) { printf("%s\n", fname); return 1; }
                if (!opt_count) {
                    if (nfiles > 1) {
                        if (opt_color) printf(ANSI_MAGENTA "%s" ANSI_RESET ":", fname);
                        else printf("%s:", fname);
                    }
                    if (opt_num) {
                        if (opt_color) printf(ANSI_GREEN "%lld" ANSI_RESET ":", lineno);
                        else printf("%lld:", lineno);
                    }
                    if (opt_color) {
                        /* Evidenzia the pattern */
                        printf("%s\n", line); /* Semplificato: niente highlight for ora */
                    } else {
                        printf("%s\n", line);
                    }
                }
            }
            if (r <= 0) break;
        } else {
            line[li++] = c;
        }
    }
    return matches;
}

static int grep_file(const char *path, int nfiles, const char *pat, int is_fixed);

static int grep_dir(const char *path, int nfiles, const char *pat, int is_fixed) {
    int fd = open(path, O_RDONLY, 0);
    if (fd < 0) { fprintf(stderr, "grep: %s: %s\n", path, strerror(errno)); return 0; }
    char dbuf[4096]; int bytes, total = 0;
    while ((bytes = sys_getdents(fd, dbuf, sizeof(dbuf))) > 0) {
        int off = 0;
        while (off < bytes) {
            struct dirent *d = (struct dirent *)(dbuf + off);
            if (d->d_reclen == 0) break;
            if (strcmp(d->d_name, ".") && strcmp(d->d_name, "..")) {
                char sub[4096];
                snprintf(sub, sizeof(sub), "%s/%s", path, d->d_name);
                total += grep_file(sub, nfiles, pat, is_fixed);
            }
            off += d->d_reclen;
        }
    }
    close(fd); return total;
}

static int grep_file(const char *path, int nfiles, const char *pat, int is_fixed) {
    struct stat st;
    if (sys_lstat(path, &st) < 0) {
        fprintf(stderr, "grep: %s: %s\n", path, strerror(errno)); return 0;
    }
    if (S_ISDIR(st.st_mode)) {
        if (opt_rec) return grep_dir(path, nfiles, pat, is_fixed);
        fprintf(stderr, "grep: %s: è una directory\n", path); return 0;
    }
    int fd = open(path, O_RDONLY, 0);
    if (fd < 0) { fprintf(stderr, "grep: %s: %s\n", path, strerror(errno)); return 0; }
    int m = grep_fd(fd, path, nfiles, pat, is_fixed);
    close(fd);
    if (opt_count && !opt_quiet) {
        if (nfiles > 1) printf("%s:", path);
        printf("%d\n", m);
    }
    return m;
}

int main(int argc, char **argv) {
    int first = 1;
    char *pat = (char*)0;
    int is_fixed = 0;

    for (int i = 1; i < argc; i++) {
        if (argv[i][0] == '-' && argv[i][1] && argv[i][1] != '-') {
            for (int j = 1; argv[i][j]; j++) {
                switch (argv[i][j]) {
                case 'i': opt_ic    = 1; break;
                case 'v': opt_inv   = 1; break;
                case 'n': opt_num   = 1; break;
                case 'l': opt_files = 1; break;
                case 'c': opt_count = 1; break;
                case 'r': case 'R': opt_rec  = 1; break;
                case 'F': is_fixed  = 1; break;
                case 'E': is_fixed  = 0; break;
                case 'w': opt_word  = 1; break;
                case 'q': opt_quiet = 1; break;
                case 'e':
                    if (argv[i][j+1]) { pat = argv[i]+j+1; j = (int)strlen(argv[i])-1; }
                    else if (argv[i+1]) { pat = argv[++i]; }
                    break;
                case 'f': /* pattern from file — NOT implementato */ break;
                }
            }
            first = i + 1;
        } else {
            if (!strcmp(argv[i], "--color"))                { opt_color = 1; first = i+1; }
            else if (!strcmp(argv[i], "--no-color"))        { opt_color = 0; first = i+1; }
            else if (!strcmp(argv[i], "-e") && argv[i+1])  { pat = argv[++i]; first = i+1; }
            else { break; }
        }
    }

    if (!pat) {
        if (first >= argc) { fprintf(stderr, "Uso: grep [-ivcnlrFEwq] PATTERN [file...]\n"); return 2; }
        pat = argv[first++];
    }
    if (opt_fixed) is_fixed = 1;

    int nfiles = argc - first;
    int total = 0;

    if (nfiles == 0) {
        total = grep_fd(0, "(stdin)", 1, pat, is_fixed);
    } else {
        for (int i = first; i < argc; i++)
            total += grep_file(argv[i], nfiles, pat, is_fixed);
    }

    if (opt_quiet) return total > 0 ? 0 : 1;
    return total > 0 ? 0 : 1;
}
