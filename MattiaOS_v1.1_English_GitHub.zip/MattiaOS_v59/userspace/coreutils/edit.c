/*
 * edit.c — editor TUI stile nano for MattiaOS
 *
 * Comandi:
 *   Ctrl+S  salva          Ctrl+Q  esci (chiede conferma if NOT salvato)
 *   Ctrl+X  esci           Ctrl+G  vai to the riga
 *   Ctrl+K  taglia riga    Ctrl+U  incolla
 *   Ctrl+F  search          Ctrl+H  sostituisci
 *   Frecce  muovi cursore  Home/End start/end riga
 *   PgUp/PgDn pages       Ctrl+A  start riga  Ctrl+E end riga
 *   Ctrl+D  delete char
 */
#include "../include/userspace.h"

/* =========================================================================
 * Structures
 * ========================================================================= */
#define MAX_ROWS    65536
#define MAX_COL     4096
#define TAB_STOP    4

typedef struct {
    char *data;
    int   len;
    int   cap;
} row_t;

static row_t  s_rows[MAX_ROWS];
static int    s_nrows    = 0;
static int    s_cx = 0, s_cy = 0;   /* cursore (colonna, riga) */
static int    s_rowoff   = 0;        /* riga of scroll */
static int    s_coloff   = 0;        /* colonna of scroll */
static int    s_dirty    = 0;        /* modified */
static char   s_filename[512];
static int    s_term_rows = 24, s_term_cols = 80;
static char  *s_clipboard = (char*)0;  /* Ctrl+K clipboard */
static char   s_status_msg[256];
static int    s_quit_confirm = 0;

/* termios */
struct termios {
    uint32_t c_iflag, c_oflag, c_cflag, c_lflag;
    uint8_t  c_line; uint8_t c_cc[19];
    uint32_t c_ispeed, c_ospeed;
};
#define TCGETS 0x5401
#define TCSETS 0x5402
#define ICANON 0000002
#define ECHO   0000010
#define ISIG   0000001
#define OPOST  0000001
#define ICRNL  0000400
#define IXON   0002000
static struct termios s_orig_term;

static void raw_on(void) {
    struct termios t;
    sys_ioctl(0, TCGETS, &s_orig_term);
    t = s_orig_term;
    t.c_iflag &= ~(ICRNL | IXON);
    t.c_oflag &= ~OPOST;
    t.c_lflag &= ~(ICANON | ECHO | ISIG);
    t.c_cc[6] = 1; t.c_cc[5] = 0;
    sys_ioctl(0, TCSETS, &t);
}
static void raw_off(void) { sys_ioctl(0, TCSETS, &s_orig_term); }

static void get_term_size(void) {
    struct winsize ws = {0};
    if (sys_ioctl(1, TIOCGWINSZ, &ws) == 0 && ws.ws_row > 0) {
        s_term_rows = ws.ws_row;
        s_term_cols = ws.ws_col;
    }
}

/* =========================================================================
 * Gestione righe
 * ========================================================================= */
static void row_init(row_t *r, const char *s, int len) {
    r->cap  = len + 16;
    r->data = xmalloc(r->cap);
    memcpy(r->data, s, len);
    r->len  = len;
}

static void row_insert_char(row_t *r, int at, char c) {
    if (r->len + 2 >= r->cap) {
        r->cap = r->cap * 2 + 16;
        r->data = realloc(r->data, r->cap);
    }
    memmove(r->data + at + 1, r->data + at, r->len - at);
    r->data[at] = c;
    r->len++;
    r->data[r->len] = '\0';
}

static void row_delete_char(row_t *r, int at) {
    if (at < 0 || at >= r->len) return;
    memmove(r->data + at, r->data + at + 1, r->len - at);
    r->len--;
}

static void insert_row(int at, const char *s, int len) {
    if (s_nrows >= MAX_ROWS) return;
    memmove(&s_rows[at + 1], &s_rows[at], (s_nrows - at) * sizeof(row_t));
    row_init(&s_rows[at], s, len);
    s_nrows++;
}

static void delete_row(int at) {
    if (at < 0 || at >= s_nrows) return;
    free(s_rows[at].data);
    memmove(&s_rows[at], &s_rows[at + 1], (s_nrows - at - 1) * sizeof(row_t));
    s_nrows--;
}

/* =========================================================================
 * I/O File
 * ========================================================================= */
static void load_file(const char *path) {
    int fd = open(path, O_RDONLY, 0);
    if (fd < 0) {
        /* Nuovo file */
        insert_row(0, "", 0);
        snprintf(s_status_msg, sizeof(s_status_msg),
                 "Nuovo file: %s", path);
        return;
    }
    char buf[MAX_COL]; int bi = 0; char c;
    while (read(fd, &c, 1) == 1) {
        if (c == '\r') continue;
        if (c == '\n') {
            insert_row(s_nrows, buf, bi);
            bi = 0;
        } else if (bi < MAX_COL - 1) buf[bi++] = c;
    }
    if (bi > 0 || s_nrows == 0) insert_row(s_nrows, buf, bi);
    close(fd);
    snprintf(s_status_msg, sizeof(s_status_msg), "Loadto: %s (%d righe)", path, s_nrows);
}

static int save_file(void) {
    if (!s_filename[0]) {
        snprintf(s_status_msg, sizeof(s_status_msg), "No nome file");
        return -1;
    }
    int fd = open(s_filename, O_WRONLY | O_CREAT | O_TRUNC, 0644);
    if (fd < 0) {
        snprintf(s_status_msg, sizeof(s_status_msg), "Error salvataggio: %s", strerror(errno));
        return -1;
    }
    for (int i = 0; i < s_nrows; i++) {
        write(fd, s_rows[i].data, s_rows[i].len);
        write(fd, "\n", 1);
    }
    close(fd);
    s_dirty = 0;
    snprintf(s_status_msg, sizeof(s_status_msg),
             "Salvato: %s (%d righe)", s_filename, s_nrows);
    return 0;
}

/* =========================================================================
 * Rendering
 * ========================================================================= */
/* Buffer output for ridurre write() */
static char s_obuf[65536]; static int s_opos = 0;
static void ob_append(const char *s, int n) {
    if (s_opos + n >= (int)sizeof(s_obuf) - 1) {
        write(1, s_obuf, s_opos); s_opos = 0;
    }
    memcpy(s_obuf + s_opos, s, n); s_opos += n;
}
static void ob_flush(void) { if(s_opos>0){write(1,s_obuf,s_opos);s_opos=0;} }

static void draw_rows(void) {
    int edit_rows = s_term_rows - 2; /* -2: status + help bar */
    for (int y = 0; y < edit_rows; y++) {
        int filerow = y + s_rowoff;
        ob_append("\033[K", 3); /* clear line */
        if (filerow < s_nrows) {
            row_t *r = &s_rows[filerow];
            int len = r->len - s_coloff;
            if (len < 0) len = 0;
            if (len > s_term_cols) len = s_term_cols;
            if (len > 0) ob_append(r->data + s_coloff, len);
        } else {
            ob_append("~", 1);
        }
        ob_append("\r\n", 2);
    }
}

static void draw_status_bar(void) {
    ob_append("\033[7m", 4); /* reverse video */
    char buf[512];
    const char *mod = s_dirty ? "[+] " : "";
    const char *fn  = s_filename[0] ? s_filename : "[Nuovo]";
    int n = snprintf(buf, sizeof(buf), " %s%s  %d/%d riga, %d col ",
                     mod, fn, s_cy + 1, s_nrows, s_cx + 1);
    if (n > s_term_cols) n = s_term_cols;
    ob_append(buf, n);
    for (int i = n; i < s_term_cols; i++) ob_append(" ", 1);
    ob_append("\033[m\r\n", 6);
}

static void draw_help_bar(void) __attribute__((unused));
static void draw_help_bar(void) {
    ob_append("\033[K", 3);
    const char *help = " ^S Salva  ^Q Esci  ^K Taglia  ^U Incolla  ^F Search  ^G Vai a riga";
    int l = (int)strlen(help);
    if (l > s_term_cols) l = s_term_cols;
    ob_append(help, l);
}

static void draw_message(void) {
    ob_append("\033[K", 3);
    if (s_status_msg[0]) {
        int l = (int)strlen(s_status_msg);
        if (l > s_term_cols) l = s_term_cols;
        ob_append(s_status_msg, l);
    }
}

static void refresh_screen(void) {
    /* Scroll */
    if (s_cy < s_rowoff) s_rowoff = s_cy;
    if (s_cy >= s_rowoff + s_term_rows - 2) s_rowoff = s_cy - s_term_rows + 3;
    if (s_cx < s_coloff) s_coloff = s_cx;
    if (s_cx >= s_coloff + s_term_cols) s_coloff = s_cx - s_term_cols + 1;

    ob_append("\033[?25l", 6); /* nascondi cursore */
    ob_append("\033[H", 3);    /* home */
    draw_rows();
    draw_status_bar();
    draw_message();

    /* Posiziona cursore */
    char cur[32];
    int n = snprintf(cur, sizeof(cur), "\033[%d;%dH",
                     (s_cy - s_rowoff) + 1,
                     (s_cx - s_coloff) + 1);
    ob_append(cur, n);
    ob_append("\033[?25h", 6); /* mostra cursore */
    ob_flush();
}

/* =========================================================================
 * Input
 * ========================================================================= */
#define KEY_UP    1000
#define KEY_DOWN  1001
#define KEY_LEFT  1002
#define KEY_RIGHT 1003
#define KEY_HOME  1004
#define KEY_END   1005
#define KEY_PGUP  1006
#define KEY_PGDN  1007
#define KEY_DEL   1008

static int read_key(void) {
    char c;
    while (read(0, &c, 1) != 1);
    if (c != 27) return (unsigned char)c;
    char seq[4]; seq[0] = 0;
    if (read(0, &seq[0], 1) != 1) return 27;
    if (seq[0] != '[') return 27;
    if (read(0, &seq[1], 1) != 1) return 27;
    if (seq[1] >= '0' && seq[1] <= '9') {
        if (read(0, &seq[2], 1) != 1) return 27;
        if (seq[2] == '~') {
            if (seq[1] == '1' || seq[1] == '7') return KEY_HOME;
            if (seq[1] == '4' || seq[1] == '8') return KEY_END;
            if (seq[1] == '5') return KEY_PGUP;
            if (seq[1] == '6') return KEY_PGDN;
            if (seq[1] == '3') return KEY_DEL;
        }
    } else {
        if (seq[1] == 'A') return KEY_UP;
        if (seq[1] == 'B') return KEY_DOWN;
        if (seq[1] == 'C') return KEY_RIGHT;
        if (seq[1] == 'D') return KEY_LEFT;
        if (seq[1] == 'H') return KEY_HOME;
        if (seq[1] == 'F') return KEY_END;
    }
    return 27;
}

/* =========================================================================
 * Inserimento testo
 * ========================================================================= */
static void editor_insert_char(char c) {
    if (s_cy == s_nrows) insert_row(s_nrows, "", 0);
    row_insert_char(&s_rows[s_cy], s_cx, c);
    s_cx++; s_dirty = 1;
}

static void editor_insert_newline(void) {
    if (s_cy >= s_nrows) {
        insert_row(s_nrows, "", 0);
    } else {
        row_t *r = &s_rows[s_cy];
        int tail_len = r->len - s_cx;
        insert_row(s_cy + 1, r->data + s_cx, tail_len);
        r->len = s_cx; r->data[r->len] = '\0';
    }
    s_cy++; s_cx = 0; s_dirty = 1;
}

static void editor_delete_char(void) {
    if (s_cy >= s_nrows) return;
    row_t *r = &s_rows[s_cy];
    if (s_cx > 0) {
        row_delete_char(r, s_cx - 1);
        s_cx--; s_dirty = 1;
    } else if (s_cy > 0) {
        /* Unisci with riga previous */
        row_t *prev = &s_rows[s_cy - 1];
        int pcol = prev->len;
        int newcap = prev->len + r->len + 2;
        prev->data = realloc(prev->data, newcap);
        prev->cap  = newcap;
        memcpy(prev->data + prev->len, r->data, r->len);
        prev->len += r->len;
        prev->data[prev->len] = '\0';
        delete_row(s_cy);
        s_cy--; s_cx = pcol; s_dirty = 1;
    }
}

/* =========================================================================
 * Operazioni up riga (Ctrl+K / Ctrl+U)
 * ========================================================================= */
static void cut_row(void) {
    if (s_cy >= s_nrows) return;
    free(s_clipboard);
    s_clipboard = xstrdup(s_rows[s_cy].data);
    delete_row(s_cy);
    if (s_cy >= s_nrows && s_cy > 0) s_cy--;
    s_cx = 0; s_dirty = 1;
    snprintf(s_status_msg, sizeof(s_status_msg), "Riga tagliata");
}

static void paste_row(void) {
    if (!s_clipboard) return;
    insert_row(s_cy, s_clipboard, (int)strlen(s_clipboard));
    s_cy++; s_dirty = 1;
    snprintf(s_status_msg, sizeof(s_status_msg), "Riga incollata");
}

/* =========================================================================
 * Risearch (Ctrl+F)
 * ========================================================================= */
static void prompt_search(void) {
    char query[256] = {0};
    int qi = 0;
    snprintf(s_status_msg, sizeof(s_status_msg), "Search: ");
    refresh_screen();

    while (1) {
        char c;
        if (read(0, &c, 1) != 1) break;
        if (c == 27 || c == 7) break;  /* ESC OR Ctrl+G: annulla */
        if (c == 13 || c == '\n') {
            /* Search from the riga current */
            for (int i = s_cy; i < s_nrows; i++) {
                if (strstr(s_rows[i].data, query)) {
                    s_cy = i;
                    s_cx = (int)(strstr(s_rows[i].data, query) - s_rows[i].data);
                    snprintf(s_status_msg, sizeof(s_status_msg), "Findto a riga %d", i+1);
                    break;
                }
            }
            break;
        }
        if ((c == 127 || c == 8) && qi > 0) {
            query[--qi] = '\0';
        } else if (c >= 32 && qi < 255) {
            query[qi++] = c; query[qi] = '\0';
        }
        snprintf(s_status_msg, sizeof(s_status_msg), "Search: %s", query);
        refresh_screen();
    }
}

/* =========================================================================
 * Vai to riga (Ctrl+G)
 * ========================================================================= */
static void goto_line(void) {
    char buf[16] = {0}; int bi = 0;
    snprintf(s_status_msg, sizeof(s_status_msg), "Vai a riga: ");
    refresh_screen();
    while (1) {
        char c; if(read(0,&c,1)!=1) break;
        if(c==13||c=='\n') break;
        if((c==127||c==8)&&bi>0){buf[--bi]='\0';}
        else if(c>='0'&&c<='9'&&bi<15){buf[bi++]=c;buf[bi]='\0';}
        snprintf(s_status_msg,sizeof(s_status_msg),"Vai a riga: %s",buf);
        refresh_screen();
    }
    int n = atoi(buf) - 1;
    if (n >= 0 && n < s_nrows) { s_cy = n; s_cx = 0; }
}

/* =========================================================================
 * Movimento cursore
 * ========================================================================= */
static void move_cursor(int key) {
    row_t *row = (s_cy < s_nrows) ? &s_rows[s_cy] : (row_t*)0;
    switch (key) {
    case KEY_LEFT:
        if (s_cx > 0) s_cx--;
        else if (s_cy > 0) { s_cy--; s_cx = s_rows[s_cy].len; }
        break;
    case KEY_RIGHT:
        if (row && s_cx < row->len) s_cx++;
        else if (row && s_cx == row->len && s_cy < s_nrows-1) { s_cy++; s_cx=0; }
        break;
    case KEY_UP:   if (s_cy > 0) s_cy--; break;
    case KEY_DOWN: if (s_cy < s_nrows - 1) s_cy++; break;
    case KEY_HOME: s_cx = 0; break;
    case KEY_END:  s_cx = row ? row->len : 0; break;
    case KEY_PGUP: s_cy -= s_term_rows - 2; if (s_cy < 0) s_cy = 0; break;
    case KEY_PGDN: s_cy += s_term_rows - 2; if (s_cy >= s_nrows) s_cy = s_nrows - 1; break;
    }
    /* Clamp cx to the length of the riga current */
    row = (s_cy < s_nrows) ? &s_rows[s_cy] : (row_t*)0;
    int rlen = row ? row->len : 0;
    if (s_cx > rlen) s_cx = rlen;
}

/* =========================================================================
 * Loop principale
 * ========================================================================= */
static void process_key(void) {
    int k = read_key();
    s_status_msg[0] = '\0';

    switch (k) {
    /* Ctrl+S: salva */
    case 19: save_file(); s_quit_confirm = 0; break;

    /* Ctrl+Q OR Ctrl+X: esci */
    case 17: case 24:
        if (s_dirty && !s_quit_confirm) {
            snprintf(s_status_msg, sizeof(s_status_msg),
                     "File non salvato! Premi ^Q di nuovo per uscire.");
            s_quit_confirm = 1;
        } else {
            raw_off();
            printf(ANSI_NORM_SCREEN ANSI_SHOW_CURSOR);
            exit(0);
        }
        break;

    /* Ctrl+K: taglia riga */
    case 11: cut_row(); s_quit_confirm = 0; break;
    /* Ctrl+U: incolla */
    case 21: paste_row(); s_quit_confirm = 0; break;
    /* Ctrl+F: search */
    case 6: prompt_search(); s_quit_confirm = 0; break;
    /* Ctrl+G: vai to riga */
    case 7: goto_line(); s_quit_confirm = 0; break;

    /* Ctrl+A: start riga */
    case 1: s_cx = 0; s_quit_confirm = 0; break;
    /* Ctrl+E: end riga */
    case 5: if(s_cy<s_nrows) s_cx=s_rows[s_cy].len; s_quit_confirm=0; break;

    /* Frecce, PgUp/Dn, Home, End */
    case KEY_UP: case KEY_DOWN: case KEY_LEFT: case KEY_RIGHT:
    case KEY_HOME: case KEY_END: case KEY_PGUP: case KEY_PGDN:
        move_cursor(k); s_quit_confirm = 0; break;

    /* Backspace */
    case 127: case 8: editor_delete_char(); s_quit_confirm=0; break;

    /* Delete */
    case KEY_DEL:
        if (s_cy < s_nrows) {
            move_cursor(KEY_RIGHT);
            editor_delete_char();
        }
        s_quit_confirm = 0; break;

    /* Enter */
    case 13: case '\n': editor_insert_newline(); s_quit_confirm=0; break;

    /* Tab */
    case '\t':
        for (int i=0;i<TAB_STOP;i++) editor_insert_char(' ');
        s_quit_confirm=0; break;

    /* Ctrl+L: ridisegna */
    case 12: get_term_size(); s_quit_confirm=0; break;

    default:
        if (k >= 32 && k < 127) { editor_insert_char((char)k); s_quit_confirm=0; }
        break;
    }
}

/* =========================================================================
 * main
 * ========================================================================= */
int main(int argc, char **argv) {
    if (argc >= 2) {
        strncpy(s_filename, argv[1], 511);
        load_file(s_filename);
    } else {
        insert_row(0, "", 0);
        snprintf(s_status_msg, sizeof(s_status_msg),
                 "edit — no file. ^S per salvare, ^Q per uscire.");
    }

    raw_on();
    get_term_size();
    printf(ANSI_ALT_SCREEN ANSI_HIDE_CURSOR);

    while (1) {
        refresh_screen();
        process_key();
    }
    /* Non raggiunto */
    return 0;
}
