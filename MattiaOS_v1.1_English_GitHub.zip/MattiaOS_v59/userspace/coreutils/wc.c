/*
 * wc.c — count parole, righe, byte
 * Flags: -l righe, -w parole, -c byte, -m caratteri
 */
#include "../include/userspace.h"

static void count_fd(int fd, long long *lines, long long *words, long long *bytes) {
    char buf[4096]; ssize_t n;
    int in_word = 0;
    while ((n = read(fd, buf, sizeof(buf))) > 0) {
        *bytes += n;
        for (ssize_t i = 0; i < n; i++) {
            if (buf[i] == '\n') (*lines)++;
            if (buf[i] == ' ' || buf[i] == '\t' || buf[i] == '\n' ||
                buf[i] == '\r') {
                in_word = 0;
            } else if (!in_word) {
                in_word = 1; (*words)++;
            }
        }
    }
}

int main(int argc, char **argv) {
    int opt_l = 0, opt_w = 0, opt_c = 0, opt_m = 0;
    int first = 1, explicit = 0;

    for (int i = 1; i < argc; i++) {
        if (argv[i][0] == '-' && argv[i][1]) {
            for (int j = 1; argv[i][j]; j++) {
                switch (argv[i][j]) {
                case 'l': opt_l = 1; explicit = 1; break;
                case 'w': opt_w = 1; explicit = 1; break;
                case 'c': opt_c = 1; explicit = 1; break;
                case 'm': opt_m = 1; explicit = 1; break;
                }
            }
            first = i + 1;
        }
    }
    if (!explicit) { opt_l = opt_w = opt_c = 1; }

    long long total_l = 0, total_w = 0, total_b = 0;
    int nfiles = argc - first;

    if (nfiles == 0) {
        long long l = 0, w = 0, b = 0;
        count_fd(0, &l, &w, &b);
        if (opt_l) printf(" %7lld", l);
        if (opt_w) printf(" %7lld", w);
        if (opt_c || opt_m) printf(" %7lld", b);
        printf("\n");
        return 0;
    }

    for (int i = first; i < argc; i++) {
        int fd = open(argv[i], O_RDONLY, 0);
        if (fd < 0) { fprintf(stderr, "wc: %s: %s\n", argv[i], strerror(errno)); continue; }
        long long l = 0, w = 0, b = 0;
        count_fd(fd, &l, &w, &b);
        close(fd);
        total_l += l; total_w += w; total_b += b;
        if (opt_l) printf(" %7lld", l);
        if (opt_w) printf(" %7lld", w);
        if (opt_c || opt_m) printf(" %7lld", b);
        printf(" %s\n", argv[i]);
    }
    if (nfiles > 1) {
        if (opt_l) printf(" %7lld", total_l);
        if (opt_w) printf(" %7lld", total_w);
        if (opt_c || opt_m) printf(" %7lld", total_b);
        printf(" total\n");
    }
    return 0;
}
