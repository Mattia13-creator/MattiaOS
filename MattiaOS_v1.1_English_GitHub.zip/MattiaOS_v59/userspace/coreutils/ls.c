/*
 * ls.c — lista contenuto directory
 * Flags: -l (long), -to (all), -h (human), -r (reverse), -t (time sort),
 *        -S (size sort), -R (recursive), -1 (to for riga), --color
 */
#include "../include/userspace.h"

#define MAX_ENTRIES 8192

typedef struct {
    char         name[256];
    char         link_target[256];
    struct stat  st;
} entry_t;

static entry_t  s_entries[MAX_ENTRIES];
static int      s_nentries;

/* Opzioni */
static int opt_long = 0, opt_all = 0, opt_human = 0;
static int opt_reverse = 0, opt_time_sort = 0, opt_size_sort = 0;
static int opt_recursive = 0, opt_one = 0, opt_color = 1;

static int cmp_name(const void *a, const void *b) {
    const entry_t *ea = (const entry_t *)a, *eb = (const entry_t *)b;
    int r = strcmp(ea->name, eb->name);
    return opt_reverse ? -r : r;
}
static int cmp_time(const void *a, const void *b) {
    const entry_t *ea = (const entry_t *)a, *eb = (const entry_t *)b;
    long long d = eb->st.st_mtime - ea->st.st_mtime;
    if (d < 0) d = opt_reverse ? -1 : 1;
    else if (d > 0) d = opt_reverse ? 1 : -1;
    return (int)d;
}
static int cmp_size(const void *a, const void *b) {
    const entry_t *ea = (const entry_t *)a, *eb = (const entry_t *)b;
    long long d = eb->st.st_size - ea->st.st_size;
    return opt_reverse ? (d < 0 ? -1 : d > 0 ? 1 : 0) : (d < 0 ? 1 : d > 0 ? -1 : 0);
}

static const char *entry_color(const entry_t *e) {
    if (!opt_color) return "";
    if (S_ISDIR(e->st.st_mode))  return ANSI_BOLD ANSI_BLUE;
    if (S_ISLNK(e->st.st_mode))  return ANSI_BOLD ANSI_CYAN;
    if (S_ISBLK(e->st.st_mode) ||
        S_ISCHR(e->st.st_mode))  return ANSI_BOLD ANSI_YELLOW;
    if (S_ISFIFO(e->st.st_mode)) return ANSI_YELLOW;
    if (S_ISSOCK(e->st.st_mode)) return ANSI_BOLD ANSI_MAGENTA;
    if (e->st.st_mode & (S_IXUSR|S_IXGRP|S_IXOTH)) return ANSI_BOLD ANSI_GREEN;
    return "";
}

static void format_time_str(int64_t t, char *out, int outsz) {
    /* Usa the values direttamente as UNIX timestamp semplificato */
    long long s = (long long)t;
    long long sec  = s % 60;  s /= 60;
    long long min  = s % 60;  s /= 60;
    long long hour = s % 24;  s /= 24;
    long long day  = (s % 30) + 1;
    long long month= (s / 30 % 12) + 1;
    long long year = 1970 + s / 365;
    const char *months[] = {"Jan","Feb","Mar","Apr","May","Jun",
                             "Jul","Aug","Sep","Oct","Nov","Dec"};
    snprintf(out, outsz, "%s %2lld %02lld:%02lld",
             months[(int)(month-1)], day, hour, min);
    (void)sec; (void)year;
}

static void list_dir(const char *path);

static void print_entry_long(const entry_t *e, const char *dirpath) {
    char perm[11]; format_mode(e->st.st_mode, perm);
    char size_s[32];
    if (opt_human) format_size_human(e->st.st_size, size_s, sizeof(size_s));
    else           snprintf(size_s, sizeof(size_s), "%lld", (long long)e->st.st_size);
    char tstr[32]; format_time_str(e->st.st_mtime, tstr, sizeof(tstr));
    const char *col = entry_color(e);
    const char *rst = opt_color ? ANSI_RESET : "";

    printf("%s %3llu %4u %4u %8s %s %s%s%s",
           perm,
           (unsigned long long)e->st.st_nlink,
           e->st.st_uid,
           e->st.st_gid,
           size_s,
           tstr,
           col, e->name, rst);

    if (S_ISLNK(e->st.st_mode) && e->link_target[0])
        printf(" -> %s", e->link_target);
    printf("\n");

    if (opt_recursive && S_ISDIR(e->st.st_mode) &&
        strcmp(e->name, ".") != 0 && strcmp(e->name, "..") != 0) {
        char sub[4096];
        snprintf(sub, sizeof(sub), "%s/%s", dirpath, e->name);
        printf("\n%s:\n", sub);
        list_dir(sub);
    }
}

static void list_dir(const char *path) {
    int fd = open(path, O_RDONLY, 0);
    if (fd < 0) { fprintf(stderr, "ls: %s: %s\n", path, strerror(errno)); return; }

    s_nentries = 0;
    char dbuf[8192];
    int bytes;
    while ((bytes = sys_getdents(fd, dbuf, sizeof(dbuf))) > 0) {
        int off = 0;
        while (off < bytes && s_nentries < MAX_ENTRIES) {
            struct dirent *d = (struct dirent *)(dbuf + off);
            if (d->d_reclen == 0) break;
            if (!opt_all && d->d_name[0] == '.') { off += d->d_reclen; continue; }
            if (strcmp(d->d_name, ".") == 0 || strcmp(d->d_name, "..") == 0) {
                if (!opt_all) { off += d->d_reclen; continue; }
            }
            entry_t *e = &s_entries[s_nentries];
            strncpy(e->name, d->d_name, 255);
            e->link_target[0] = '\0';
            char full[4096];
            snprintf(full, sizeof(full), "%s/%s", path, d->d_name);
            if (sys_lstat(full, &e->st) < 0)
                memset(&e->st, 0, sizeof(e->st));
            if (S_ISLNK(e->st.st_mode)) {
                int n = sys_readlink(full, e->link_target, 255);
                if (n >= 0) e->link_target[n] = '\0';
            }
            s_nentries++;
            off += d->d_reclen;
        }
    }
    close(fd);

    /* Sort */
    if (opt_time_sort) qsort(s_entries, s_nentries, sizeof(entry_t), cmp_time);
    else if (opt_size_sort) qsort(s_entries, s_nentries, sizeof(entry_t), cmp_size);
    else qsort(s_entries, s_nentries, sizeof(entry_t), cmp_name);

    if (opt_long) {
        /* Calculate total blocks */
        long long total = 0;
        for (int i = 0; i < s_nentries; i++) total += s_entries[i].st.st_blocks;
        printf("total %lld\n", total / 2);
        for (int i = 0; i < s_nentries; i++)
            print_entry_long(&s_entries[i], path);
    } else if (opt_one) {
        for (int i = 0; i < s_nentries; i++) {
            const char *col = entry_color(&s_entries[i]);
            const char *rst = opt_color ? ANSI_RESET : "";
            printf("%s%s%s\n", col, s_entries[i].name, rst);
        }
    } else {
        /* Formato colonne */
        int max_len = 0;
        for (int i = 0; i < s_nentries; i++) {
            int l = (int)strlen(s_entries[i].name);
            if (l > max_len) max_len = l;
        }
        max_len += 2;

        /* Width terminale */
        struct winsize ws = {0};
        sys_ioctl(1, TIOCGWINSZ, &ws);
        int term_w = (ws.ws_col > 0) ? ws.ws_col : 80;
        int cols = term_w / max_len;
        if (cols < 1) cols = 1;

        for (int i = 0; i < s_nentries; i++) {
            const char *col = entry_color(&s_entries[i]);
            const char *rst = opt_color ? ANSI_RESET : "";
            int nlen = (int)strlen(s_entries[i].name);
            printf("%s%-*s%s", col, nlen, s_entries[i].name, rst);
            if ((i + 1) % cols == 0 || i == s_nentries - 1) printf("\n");
            else { for (int j = nlen; j < max_len; j++) printf(" "); }
        }
    }

    if (opt_recursive) {
        for (int i = 0; i < s_nentries; i++) {
            if (!S_ISDIR(s_entries[i].st.st_mode)) continue;
            if (strcmp(s_entries[i].name, ".") == 0 ||
                strcmp(s_entries[i].name, "..") == 0) continue;
            char sub[4096];
            snprintf(sub, sizeof(sub), "%s/%s", path, s_entries[i].name);
            printf("\n%s:\n", sub);
            list_dir(sub);
        }
    }
}

int main(int argc, char **argv) {
    char *targets[256]; int ntargets = 0;

    for (int i = 1; i < argc; i++) {
        if (argv[i][0] == '-' && argv[i][1] != '\0' && argv[i][1] != '-') {
            for (int j = 1; argv[i][j]; j++) {
                switch (argv[i][j]) {
                case 'l': opt_long = 1; break;
                case 'a': opt_all  = 1; break;
                case 'h': opt_human = 1; break;
                case 'r': opt_reverse = 1; break;
                case 't': opt_time_sort = 1; break;
                case 'S': opt_size_sort = 1; break;
                case 'R': opt_recursive = 1; break;
                case '1': opt_one = 1; break;
                case 'A': opt_all = 1; break;
                }
            }
        } else if (strcmp(argv[i], "--color") == 0)    opt_color = 1;
        else if (strcmp(argv[i], "--no-color") == 0)   opt_color = 0;
        else targets[ntargets++] = argv[i];
    }

    if (ntargets == 0) { targets[0] = "."; ntargets = 1; }

    /* Controlla if the terminale support colori */
    if (opt_color) {
        struct stat st;
        if (sys_fstat(1, &st) == 0 && !S_ISCHR(st.st_mode)) opt_color = 0;
    }

    for (int i = 0; i < ntargets; i++) {
        struct stat st;
        if (sys_lstat(targets[i], &st) < 0) {
            fprintf(stderr, "ls: %s: %s\n", targets[i], strerror(errno));
            continue;
        }
        if (S_ISDIR(st.st_mode)) {
            if (ntargets > 1) printf("%s:\n", targets[i]);
            list_dir(targets[i]);
        } else {
            /* File singolo */
            entry_t e;
            strncpy(e.name, targets[i], 255);
            e.link_target[0] = '\0'; e.st = st;
            if (S_ISLNK(st.st_mode)) {
                int n = sys_readlink(targets[i], e.link_target, 255);
                if (n >= 0) e.link_target[n] = '\0';
            }
            if (opt_long) print_entry_long(&e, ".");
            else {
                const char *col = entry_color(&e);
                const char *rst = opt_color ? ANSI_RESET : "";
                printf("%s%s%s\n", col, e.name, rst);
            }
        }
    }
    return 0;
}
