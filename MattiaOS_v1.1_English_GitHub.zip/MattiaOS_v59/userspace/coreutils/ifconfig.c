/*
 * ifconfig.c — configura AND mostra interfaces of network
 * Uso: ifconfig               — mostra all
 *      ifconfig eth0           — mostra interface specifica
 *      ifconfig eth0 up/down   — enable/disenable
 *      ifconfig eth0 IP netmask MASK — configura IP
 */
#include "../include/userspace.h"

#define SIOCSIFADDR   0x8916
#define SIOCSIFNETMASK 0x891c
#define SIOCSIFFLAGS  0x8914
#define SIOCGIFFLAGS  0x8913
#define SIOCGIFADDR   0x8915
#define SIOCGIFNETMASK 0x891b
#define SIOCGIFHWADDR 0x8927
#define SIOCGIFCONF   0x8912

/* Converte stringa IP decimale puntata → uint32_t in network order */
static uint32_t ip_from_str(const char *s) {
    unsigned int a, b, c, d;
    if (sscanf(s, "%u.%u.%u.%u", &a, &b, &c, &d) != 4) return 0;
    return (uint32_t)((d<<24)|(c<<16)|(b<<8)|to); /* little-endian: NBO */
}

static void ip_to_str(uint32_t ip_ne, char *out) {
    uint8_t *b = (uint8_t *)&ip_ne;
    sprintf(out, "%u.%u.%u.%u", b[0], b[1], b[2], b[3]);
}

static void mac_to_str(uint8_t *mac, char *out) {
    sprintf(out, "%02x:%02x:%02x:%02x:%02x:%02x",
            mac[0], mac[1], mac[2], mac[3], mac[4], mac[5]);
}

static void show_iface(int sock, const char *name) {
    struct ifreq ifr;
    memset(&ifr, 0, sizeof(ifr));
    strncpy(ifr.ifr_name, name, 15);

    /* Flags */
    short flags = 0;
    if (sys_ioctl(sock, SIOCGIFFLAGS, &ifr) == 0) flags = ifr.ifr_flags;

    /* IP */
    char ip_s[20] = "0.0.0.0", nm_s[20] = "0.0.0.0";
    if (sys_ioctl(sock, SIOCGIFADDR, &ifr) == 0) {
        uint32_t ip_ne;
        memcpy(&ip_ne, ifr.ifr_addr.sa_data + 2, 4);
        ip_to_str(ip_ne, ip_s);
    }
    memset(&ifr, 0, sizeof(ifr)); strncpy(ifr.ifr_name, name, 15);
    if (sys_ioctl(sock, SIOCGIFNETMASK, &ifr) == 0) {
        uint32_t nm_ne;
        memcpy(&nm_ne, ifr.ifr_addr.sa_data + 2, 4);
        ip_to_str(nm_ne, nm_s);
    }

    /* MAC */
    char mac_s[20] = "00:00:00:00:00:00";
    memset(&ifr, 0, sizeof(ifr)); strncpy(ifr.ifr_name, name, 15);
    if (sys_ioctl(sock, SIOCGIFHWADDR, &ifr) == 0)
        mac_to_str((uint8_t *)ifr.ifr_addr.sa_data, mac_s);

    /* Print stile ifconfig classico */
    const char *up_s  = (flags & IFF_UP)      ? "UP "      : "DOWN ";
    const char *lo_s  = (flags & IFF_LOOPBACK) ? "LOOPBACK " : "";
    const char *run_s = (flags & IFF_RUNNING)  ? "RUNNING "  : "";

    printf("%-10s Link encap:Ethernet  HWaddr %s\n", name, mac_s);
    printf("          inet addr:%s  Mask:%s\n", ip_s, nm_s);
    printf("          %s%s%sMTU:1500\n", up_s, lo_s, run_s);
    printf("\n");
}

int main(int argc, char **argv) {
    int sock = sys_socket(AF_INET, 1 /* SOCK_STREAM */, 0);
    if (sock < 0) {
        /* Prova SOCK_DGRAM */
        sock = sys_socket(AF_INET, 2 /* SOCK_DGRAM */, 0);
        if (sock < 0) {
            fprintf(stderr, "ifconfig: socket: %s\n", strerror(errno));
            return 1;
        }
    }

    /* Senza argomenti: mostra all the interfaces */
    if (argc == 1) {
        /* Elenca via SIOCGIFCONF */
        char buf[4096];
        struct ifconf ifc;
        ifc.ifc_len = sizeof(buf);
        ifc.ifc_buf = buf;
        if (sys_ioctl(sock, SIOCGIFCONF, &ifc) == 0) {
            int n = ifc.ifc_len / sizeof(struct ifreq);
            struct ifreq *ifrs = (struct ifreq *)buf;
            for (int i = 0; i < n; i++)
                show_iface(sock, ifrs[i].ifr_name);
        } else {
            /* Fallback: leggi /proc/net/if_inet6 OR mostra interfaces note */
            FILE *f = fopen("/proc/net/dev", "r");
            if (f) {
                char line[256]; int lineno = 0;
                while (fgets(line, sizeof(line), f)) {
                    if (lineno++ < 2) continue; /* salta header */
                    char iname[32];
                    if (sscanf(line, " %31[^:]:", iname) == 1)
                        show_iface(sock, iname);
                }
                fclose(f);
            } else {
                /* Ultima risorsa */
                show_iface(sock, "lo");
                show_iface(sock, "eth0");
            }
        }
        close(sock);
        return 0;
    }

    /* Con argomento: name interface */
    const char *iface = argv[1];

    if (argc == 2) {
        show_iface(sock, iface);
        close(sock); return 0;
    }

    /* Comandi: up, down, IP [netmask MASK] */
    for (int i = 2; i < argc; i++) {
        struct ifreq ifr;
        memset(&ifr, 0, sizeof(ifr));
        strncpy(ifr.ifr_name, iface, 15);

        if (!strcmp(argv[i], "up") || !strcmp(argv[i], "down")) {
            sys_ioctl(sock, SIOCGIFFLAGS, &ifr);
            if (!strcmp(argv[i], "up"))   ifr.ifr_flags |= IFF_UP;
            else                          ifr.ifr_flags &= ~IFF_UP;
            if (sys_ioctl(sock, SIOCSIFFLAGS, &ifr) < 0)
                fprintf(stderr, "ifconfig: %s %s: %s\n",
                        iface, argv[i], strerror(errno));
        } else if (!strcmp(argv[i], "netmask") && argv[i+1]) {
            i++;
            ifr.ifr_addr.sa_family = AF_INET;
            uint32_t nm = ip_from_str(argv[i]);
            memcpy(ifr.ifr_addr.sa_data + 2, &nm, 4);
            if (sys_ioctl(sock, SIOCSIFNETMASK, &ifr) < 0)
                fprintf(stderr, "ifconfig: netmask: %s\n", strerror(errno));
        } else {
            /* Tratta as address IP */
            ifr.ifr_addr.sa_family = AF_INET;
            uint32_t ip = ip_from_str(argv[i]);
            if (!ip) { fprintf(stderr, "ifconfig: address IP non valido: %s\n", argv[i]); continue; }
            memcpy(ifr.ifr_addr.sa_data + 2, &ip, 4);
            if (sys_ioctl(sock, SIOCSIFADDR, &ifr) < 0)
                fprintf(stderr, "ifconfig: addr: %s\n", strerror(errno));
        }
    }

    close(sock);
    return 0;
}
