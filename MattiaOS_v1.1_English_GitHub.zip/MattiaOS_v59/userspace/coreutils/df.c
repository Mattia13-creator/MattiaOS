/*
 * df.c — spazio available sui filesystem mounted
 * Flags: -h human-readable, -the inode info, -T mostra type fs
 */
#include "../include/userspace.h"

static int opt_human = 0, opt_inodes = 0, opt_type = 0;

static void print_fs(const char *path, const char *dev, const char *fstype) {
    struct statfs sf = {0};
    if (sys_statfs(path, &sf) < 0) return;

    long long bsize  = sf.f_bsize > 0 ? sf.f_bsize : 4096;
    long long total  = sf.f_blocks * bsize;
    long long avail  = sf.f_bavail * bsize;
    long long used   = (sf.f_blocks - sf.f_bfree) * bsize;
    long long pct    = total > 0 ? (used * 100 / total) : 0;

    if (opt_inodes) {
        printf("%-20s %12lld %12lld %12lld %3lld%% %s\n",
               dev,
               (long long)sf.f_files,
               (long long)(sf.f_files - sf.f_ffree),
               (long long)sf.f_ffree,
               sf.f_files > 0 ? (sf.f_files - sf.f_ffree) * 100 / sf.f_files : 0LL,
               path);
        return;
    }

    if (opt_human) {
        char t[16], u[16], a[16];
        format_size_human(total, t, sizeof(t));
        format_size_human(used,  u, sizeof(u));
        format_size_human(avail, a, sizeof(a));
        if (opt_type)
            printf("%-20s %-8s %8s %8s %8s %4lld%% %s\n",
                   dev, fstype, t, u, a, pct, path);
        else
            printf("%-20s %8s %8s %8s %4lld%% %s\n",
                   dev, t, u, a, pct, path);
    } else {
        if (opt_type)
            printf("%-20s %-8s %12lld %12lld %12lld %4lld%% %s\n",
                   dev, fstype, total/1024, used/1024, avail/1024, pct, path);
        else
            printf("%-20s %12lld %12lld %12lld %4lld%% %s\n",
                   dev, total/1024, used/1024, avail/1024, pct, path);
    }
}

int main(int argc, char **argv) {
    int first = 1;
    for (int i = 1; i < argc; i++) {
        if (!strcmp(argv[i], "-h"))      { opt_human  = 1; first = i+1; }
        else if (!strcmp(argv[i], "-i")) { opt_inodes = 1; first = i+1; }
        else if (!strcmp(argv[i], "-T")) { opt_type   = 1; first = i+1; }
        else if (argv[i][0] == '-') {
            for (int j = 1; argv[i][j]; j++) {
                if (argv[i][j] == 'h') opt_human  = 1;
                if (argv[i][j] == 'i') opt_inodes = 1;
                if (argv[i][j] == 'T') opt_type   = 1;
            }
            first = i+1;
        }
    }

    /* Intestazione */
    if (opt_inodes) {
        printf("%-20s %12s %12s %12s %4s %s\n",
               "Filesystem", "Inodes", "IUsed", "IFree", "IUse%", "Mountto su");
    } else if (opt_human) {
        if (opt_type)
            printf("%-20s %-8s %8s %8s %8s %5s %s\n",
                   "Filesystem", "Tipo", "Dim", "Usato", "Disp", "Uso%", "Mountto su");
        else
            printf("%-20s %8s %8s %8s %5s %s\n",
                   "Filesystem", "Dim", "Usato", "Disp", "Uso%", "Mountto su");
    } else {
        if (opt_type)
            printf("%-20s %-8s %12s %12s %12s %5s %s\n",
                   "Filesystem", "Tipo", "1K-blocks", "Usati", "Disp", "Uso%", "Mountto su");
        else
            printf("%-20s %12s %12s %12s %5s %s\n",
                   "Filesystem", "1K-blocks", "Usati", "Disp", "Uso%", "Mountto su");
    }

    /* Se specificati paths, print only quelli */
    if (first < argc) {
        for (int i = first; i < argc; i++)
            print_fs(argv[i], argv[i], "?");
        return 0;
    }

    /* Leggi /proc/mounts */
    FILE *f = fopen("/proc/mounts", "r");
    if (!f) {
        /* Fallback: print only root */
        print_fs("/", "/dev/root", "mattiafs");
        return 0;
    }
    char line[512];
    while (fgets(line, sizeof(line), f)) {
        char dev[128], mp[256], fstype[64], opts[256];
        int dump = 0, pass = 0;
        if (sscanf(line, "%127s %255s %63s %255s %d %d",
                   dev, mp, fstype, opts, &dump, &pass) >= 3) {
            /* Salta pseudo-fs */
            if (!strcmp(fstype, "proc") && !strcmp(dev, "proc")) continue;
            print_fs(mp, dev, fstype);
        }
    }
    fclose(f);
    return 0;
}
