/*
 * free.c — mostra utilizzo memory
 * Flags: -h human-readable, -m MiB, -g GiB, -b byte, -k kB (default)
 */
#include "../include/userspace.h"

int main(int argc, char **argv) {
    int opt_human = 0, unit_shift = 10; /* default: kB = >>10 */
    const char *unit_label = "kB";

    for (int i = 1; i < argc; i++) {
        if (!strcmp(argv[i], "-h"))      { opt_human = 1; }
        else if (!strcmp(argv[i], "-b")) { unit_shift = 0;  unit_label = "B";   }
        else if (!strcmp(argv[i], "-k")) { unit_shift = 10; unit_label = "kB";  }
        else if (!strcmp(argv[i], "-m")) { unit_shift = 20; unit_label = "MiB"; }
        else if (!strcmp(argv[i], "-g")) { unit_shift = 30; unit_label = "GiB"; }
    }

    struct sysinfo si = {0};
    long long total = 0, free_m = 0, used = 0, buffers = 0, cached = 0;
    long long swap_total = 0, swap_free = 0;

    if (sys_sysinfo(&si) == 0) {
        uint64_t mu = si.mem_unit ? si.mem_unit : 1;
        total      = (long long)(si.totalram  * mu);
        free_m     = (long long)(si.freeram   * mu);
        buffers    = (long long)(si.bufferram * mu);
        swap_total = (long long)(si.totalswap * mu);
        swap_free  = (long long)(si.freeswap  * mu);
        used       = total - free_m;
        cached     = 0;
    } else {
        /* Fallback: /proc/meminfo */
        FILE *f = fopen("/proc/meminfo", "r");
        if (f) {
            char line[256];
            while (fgets(line, sizeof(line), f)) {
                long long v = atoll(strchr(line, ':') ? strchr(line, ':') + 1 : "0") * 1024;
                if (!strncmp(line, "MemTotal:",    9))  total      = v;
                if (!strncmp(line, "MemFree:",     8))  free_m     = v;
                if (!strncmp(line, "Buffers:",     8))  buffers    = v;
                if (!strncmp(line, "Cached:",      7))  cached     = v;
                if (!strncmp(line, "SwapTotal:",  10))  swap_total = v;
                if (!strncmp(line, "SwapFree:",    9))  swap_free  = v;
            }
            fclose(f);
            used = total - free_m - buffers - cached;
        }
    }

    /* Print */
    if (opt_human) {
        char t[16], u[16], f[16], b[16], c[16], st[16], sf[16];
        format_size_human(total,      t,  sizeof(t));
        format_size_human(used,       u,  sizeof(u));
        format_size_human(free_m,     f,  sizeof(f));
        format_size_human(buffers,    b,  sizeof(b));
        format_size_human(cached,     c,  sizeof(c));
        format_size_human(swap_total, st, sizeof(st));
        format_size_human(swap_free,  sf, sizeof(sf));
        printf("%-10s %8s %8s %8s %8s %8s\n",
               "", "total", "usata", "free", "buffer", "cache");
        printf("%-10s %8s %8s %8s %8s %8s\n",
               "Mem:", t, u, f, b, c);
        printf("%-10s %8s %8s\n",
               "Swap:", st, sf);
    } else {
        long long div = 1LL << unit_shift;
        printf("%-10s %10s %10s %10s %10s %10s\n",
               "", unit_label, "usata", "free", "buffer", "cache");
        printf("%-10s %10lld %10lld %10lld %10lld %10lld\n",
               "Mem:", total/div, used/div, free_m/div, buffers/div, cached/div);
        printf("%-10s %10lld %10lld\n",
               "Swap:", swap_total/div, swap_free/div);
    }
    return 0;
}
