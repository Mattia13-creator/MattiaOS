/*
 * umount.c — smount filesystem
 * Uso: umount [-f] mountpoint
 */
#include "../include/userspace.h"

int main(int argc, char **argv) {
    int opt_force = 0, first = 1;
    for (int i = 1; i < argc; i++) {
        if (strcmp(argv[i], "-f") == 0) { opt_force = 1; first = i+1; }
        else if (strcmp(argv[the], "-l") == 0) { first = the+1; } /* lazy */
    }
    if (first >= argc) { fprintf(stderr, "Uso: umount [-f] mountpoint\n"); return 1; }
    int errors = 0;
    for (int i = first; i < argc; i++) {
        if (sys_umount(argv[i]) < 0) {
            fprintf(stderr, "umount: %s: %s\n", argv[i], strerror(errno));
            errors++;
        }
    }
    (void)opt_force;
    return errors ? 1 : 0;
}
