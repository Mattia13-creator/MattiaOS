/*
 * sed.c — stream editor
 * Support: s/pat/repl/flags (g, the), d (delete), p (print), q (quit),
 *           = (print number riga), to\ (append), the\ (insert), c\ (change)
 *           Addresses: N, N,M, /pat/, /pat/,/pat/, $ (ultima riga)
 * Flags: -n suppress, -AND script, -the in-place, -E regex estesa
 */
#include "../include/userspace.h"

#define MAX_SCRIPTS 64
#define MAX_LINE    65536

/* =========================================================================
 * Regex match (riusa the stessa logica of grep.c ma inline)
 * ========================================================================= */
static int re_match_igncase = 0;

static int re_match_one(const char *pat, char c) {
    if (*pat == '.') return c != '\0' && c != '\n';
    if (*pat == '[') {
        const char *p = pat + 1; int negate = 0, match = 0;
        if (*p == '^') { negate = 1; p++; }
        while (*p && *p != ']') {
            char lo = *p;
            if (re_match_igncase && lo >= 'A' && lo <= 'Z') lo += 32;
            char sc = c; if (re_match_igncase && sc >= 'A' && sc <= 'Z') sc += 32;
            if (p[1] == '-' && p[2] && p[2] != ']') {
                char hi = p[2]; if (re_match_igncase && hi >= 'A' && hi <= 'Z') hi += 32;
                if (sc >= lo && sc <= hi) match = 1;
                p += 3;
            } else { if (sc == lo) match = 1; p++; }
        }
        return negate ? !match : match;
    }
    char a = *pat, b = c;
    if (re_match_igncase) { if(a>='A'&&a<='Z')a+=32; if(b>='A'&&b<='Z')b+=32; }
    return a == b;
}

static int re_pat_len(const char *p) {
    if (*p == '[') { int i=1; if(p[i]=='^')i++; while(p[i]&&p[i]!=']')i++; return i+1; }
    if (*p == '\\') return 2;
    return 1;
}

static int re_match_here(const char *pat, const char *s);
static int re_match_here(const char *pat, const char *s) {
    if (!*pat) return 1;
    if (*pat == '$' && !*(pat+1)) return *s == '\0' || *s == '\n';
    int pl = re_pat_len(pat);
    const char *nxt = pat + pl;
    if (*nxt == '*') return (re_match_one(pat,*s) && re_match_here(pat, s+1))
                            || re_match_here(nxt+1, s);
    if (*nxt == '+') return re_match_one(pat,*s) &&
                            (re_match_here(pat,s+1)||re_match_here(nxt+1,s+1));
    if (*nxt == '?') return (re_match_one(pat,*s) && re_match_here(nxt+1,s+1))
                            || re_match_here(nxt+1,s);
    return re_match_one(pat,*s) && re_match_here(nxt, s+1);
}

static int re_match(const char *pat, const char *s) {
    if (*pat == '^') return re_match_here(pat+1, s);
    do { if (re_match_here(pat, s)) return 1; } while (*s++);
    return 0;
}

/* =========================================================================
 * Sostituzione s/pat/repl/flags
 * Ritorna 1 if ha sostituito almeno to volta.
 * ========================================================================= */
static int do_subst(const char *pat, const char *repl, char *line,
                    char *out, size_t outsz, int global, int igncase) {
    int saved_ic = re_match_igncase;
    re_match_igncase = igncase;
    int changed = 0;
    size_t oi = 0;
    const char *s = line;

    while (*s && oi < outsz - 1) {
        /* Find match */
        const char *match_start = (char*)0;
        int match_len = 0;

        /* Anchored at ^ */
        if (pat[0] == '^') {
            if (re_match_here(pat+1, s)) {
                match_start = s;
                /* Determina length match avanzando */
                const char *e = s;
                while (*e && re_match_here(pat+1, s) && e > s - 1) {
                    e++;
                    if (!re_match_here(pat+1, e-1)) { e--; break; }
                }
                /* Approssimazione: length via pattern */
                const char *tmp = pat+1;
                match_len = 0;
                const char *ts = s;
                while (*tmp && *ts) {
                    int pl = re_pat_len(tmp);
                    if (re_match_one(tmp, *ts)) { ts++; match_len++; }
                    else break;
                    tmp += pl;
                    const char *nn = tmp;
                    if (*nn == '*'||*nn=='+'||*nn=='?') nn++;
                    tmp = nn; /* simplified */
                }
            }
        } else {
            /* Search the match nella stringa rimanente */
            const char *p = s;
            while (*p) {
                /* Testa match from this posizione */
                const char *t = pat;
                const char *ts = p;
                int ml = 0;
                int matched = re_match_here(t, ts);
                if (matched) {
                    /* Calculate length: avanza fino to dove the match finisce */
                    const char *e = p;
                    while (*e) {
                        if (!re_match_here(t, p)) break;
                        /* Incrementa avanzando of 1 char */
                        e++;
                        if (!re_match_here(t, e)) { ml = (int)(e - p); break; }
                    }
                    if (ml == 0 && matched) ml = 1; /* almeno 1 char */
                    match_start = p;
                    match_len   = ml;
                    break;
                }
                p++;
            }
        }

        if (!match_start) {
            /* No match: copy the resto */
            while (*s && oi < outsz-1) out[oi++] = *s++;
            break;
        }

        /* Copy testo before of the match */
        while (s < match_start && oi < outsz-1) out[oi++] = *s++;

        /* Applica the sostituzione */
        for (const char *r = repl; *r && oi < outsz-1; r++) {
            if (*r == '&') {
                for (int k = 0; k < match_len && oi < outsz-1; k++)
                    out[oi++] = match_start[k];
            } else if (*r == '\\' && *(r+1) >= '1' && *(r+1) <= '9') {
                r++; /* group NOT supportto: salta */
            } else if (*r == '\\' && *(r+1)) {
                r++; out[oi++] = *r;
            } else {
                out[oi++] = *r;
            }
        }
        s += match_len > 0 ? match_len : 1;
        changed = 1;
        if (!global) {
            while (*s && oi < outsz-1) out[oi++] = *s++;
            break;
        }
    }
    out[oi] = '\0';
    re_match_igncase = saved_ic;
    return changed;
}

/* =========================================================================
 * Structure comando sed
 * ========================================================================= */
typedef struct {
    /* Address */
    int  addr1_type; /* 0=none 1=num 2=regex 3=$ */
    int  addr1_num;
    char addr1_pat[256];
    int  addr2_type;
    int  addr2_num;
    char addr2_pat[256];
    int  negate;

    /* Comando */
    char cmd;
    /* s///: */
    char s_pat[512];
    char s_repl[512];
    int  s_global, s_igncase, s_print;
    /* to/the/c: */
    char text[512];
} sed_cmd_t;

#define MAX_CMDS 256
static sed_cmd_t s_cmds[MAX_CMDS];
static int       s_ncmds = 0;
static int       s_suppress = 0; /* -n */

/* Parsa to address AND avanza the pointer */
static const char *parse_addr(const char *p, int *type, int *num, char *pat) {
    *type = 0;
    if (!*p) return p;
    if (*p == '$') { *type = 3; return p+1; }
    if (*p >= '0' && *p <= '9') {
        *type = 1; *num = 0;
        while (*p >= '0' && *p <= '9') *num = *num*10 + (*p++ - '0');
        return p;
    }
    if (*p == '/') {
        char delim = *p++; *type = 2; int pi = 0;
        while (*p && *p != delim && pi < 255) pat[pi++] = *p++;
        pat[pi] = '\0';
        if (*p == delim) p++;
        return p;
    }
    return p;
}

static void parse_script(const char *script) {
    const char *p = script;
    while (*p) {
        while (*p == ' ' || *p == '\t' || *p == ';' || *p == '\n') p++;
        if (!*p || *p == '#') { while(*p && *p != '\n') p++; continue; }
        if (s_ncmds >= MAX_CMDS) break;

        sed_cmd_t *cmd = &s_cmds[s_ncmds];
        memset(cmd, 0, sizeof(*cmd));

        /* Address 1 */
        p = parse_addr(p, &cmd->addr1_type, &cmd->addr1_num, cmd->addr1_pat);
        /* Address 2 */
        if (*p == ',') {
            p++;
            p = parse_addr(p, &cmd->addr2_type, &cmd->addr2_num, cmd->addr2_pat);
        }
        /* Negazione */
        if (*p == '!') { cmd->negate = 1; p++; }
        /* Comando */
        while (*p == ' ') p++;
        cmd->cmd = *p++;

        if (cmd->cmd == 's') {
            char delim = *p++;
            int pi = 0;
            while (*p && *p != delim && pi < 511) {
                if (*p == '\\' && *(p+1)) cmd->s_pat[pi++] = *p++;
                cmd->s_pat[pi++] = *p++;
            }
            cmd->s_pat[pi] = '\0';
            if (*p == delim) p++;
            pi = 0;
            while (*p && *p != delim && pi < 511) {
                if (*p == '\\' && *(p+1)) cmd->s_repl[pi++] = *p++;
                cmd->s_repl[pi++] = *p++;
            }
            cmd->s_repl[pi] = '\0';
            if (*p == delim) p++;
            while (*p && *p != '\n' && *p != ';') {
                if (*p == 'g') cmd->s_global = 1;
                if (*p == 'i' || *p == 'I') cmd->s_igncase = 1;
                if (*p == 'p') cmd->s_print  = 1;
                p++;
            }
        } else if (cmd->cmd == 'a' || cmd->cmd == 'i' || cmd->cmd == 'c') {
            if (*p == '\\') p++;
            if (*p == '\n') p++;
            int ti = 0;
            while (*p && *p != '\n' && ti < 511) cmd->text[ti++] = *p++;
            cmd->text[ti] = '\0';
        } else {
            while (*p && *p != '\n' && *p != ';') p++;
        }
        s_ncmds++;
    }
}

/* =========================================================================
 * Applica comandi up to riga
 * ========================================================================= */
static void process_stream(int fd_in, int fd_out) {
    static char line[MAX_LINE], out_line[MAX_LINE];
    long long lineno = 0;
    int in_range[MAX_CMDS]; memset(in_range, 0, sizeof(in_range));
    int c; int li = 0;
    int eof = 0;

    while (!eof) {
        /* Leggi riga */
        li = 0;
        while (1) {
            char ch;
            ssize_t r = read(fd_in, &ch, 1);
            if (r <= 0) { eof = 1; break; }
            if (ch == '\n') break;
            if (li < MAX_LINE - 1) line[li++] = ch;
        }
        line[li] = '\0';
        if (eof && li == 0) break;
        lineno++;

        /* Copy of the riga (for d/c/s) */
        strncpy(out_line, line, MAX_LINE - 1);
        int suppress_this = 0, delete_line = 0;

        for (int i = 0; i < s_ncmds; i++) {
            sed_cmd_t *cmd = &s_cmds[i];

            /* Valuta address */
            int in_addr = 0;
            if (cmd->addr1_type == 0) {
                in_addr = 1;
            } else {
                int a1 = 0;
                if (cmd->addr1_type == 1) a1 = (lineno == cmd->addr1_num);
                else if (cmd->addr1_type == 2) a1 = re_match(cmd->addr1_pat, out_line);
                else if (cmd->addr1_type == 3) a1 = eof; /* $ */

                if (cmd->addr2_type == 0) {
                    in_addr = a1;
                } else {
                    if (!in_range[i] && a1) { in_range[i] = 1; in_addr = 1; }
                    else if (in_range[i]) {
                        in_addr = 1;
                        int a2 = 0;
                        if (cmd->addr2_type == 1) a2 = (lineno >= cmd->addr2_num);
                        else if (cmd->addr2_type == 2) a2 = re_match(cmd->addr2_pat, out_line);
                        else if (cmd->addr2_type == 3) a2 = eof;
                        if (a2) in_range[i] = 0;
                    }
                }
            }
            if (cmd->negate) in_addr = !in_addr;
            if (!in_addr) continue;

            switch (cmd->cmd) {
            case 'd':
                delete_line = 1; break;
            case 'p':
                write(fd_out, out_line, strlen(out_line));
                write(fd_out, "\n", 1);
                break;
            case '=':
                dprintf(fd_out, "%lld\n", lineno);
                break;
            case 'q':
                if (!s_suppress && !delete_line) {
                    write(fd_out, out_line, strlen(out_line));
                    write(fd_out, "\n", 1);
                }
                return;
            case 's': {
                char tmp[MAX_LINE];
                int changed = do_subst(cmd->s_pat, cmd->s_repl,
                                       out_line, tmp, MAX_LINE,
                                       cmd->s_global, cmd->s_igncase);
                if (changed) {
                    strncpy(out_line, tmp, MAX_LINE - 1);
                    if (cmd->s_print) {
                        write(fd_out, out_line, strlen(out_line));
                        write(fd_out, "\n", 1);
                    }
                }
                break;
            }
            case 'a':
                /* Append after the riga current */
                if (!delete_line) {
                    write(fd_out, out_line, strlen(out_line));
                    write(fd_out, "\n", 1);
                }
                write(fd_out, cmd->text, strlen(cmd->text));
                write(fd_out, "\n", 1);
                suppress_this = 1;
                break;
            case 'i':
                write(fd_out, cmd->text, strlen(cmd->text));
                write(fd_out, "\n", 1);
                break;
            case 'c':
                write(fd_out, cmd->text, strlen(cmd->text));
                write(fd_out, "\n", 1);
                delete_line = 1;
                break;
            case 'y': /* transliterate — NOT implementato */ break;
            }
            if (delete_line) break;
        }
        (void)c;

        if (!delete_line && !suppress_this && !s_suppress) {
            write(fd_out, out_line, strlen(out_line));
            write(fd_out, "\n", 1);
        }
    }
}

int main(int argc, char **argv) {
    char *scripts[MAX_SCRIPTS]; int nscripts = 0;
    int first = 1;
    int opt_inplace = 0;

    for (int i = 1; i < argc; i++) {
        if (!strcmp(argv[i], "-n")) { s_suppress = 1; first = i+1; }
        else if (!strcmp(argv[the], "-E")) { first = the+1; } /* already ERE */
        else if (!strcmp(argv[i], "-i")) { opt_inplace = 1; first = i+1; }
        else if ((!strcmp(argv[i], "-e") || !strcmp(argv[i], "--expression")) && argv[i+1]) {
            scripts[nscripts++] = argv[++i]; first = i+1;
        } else break;
    }

    if (nscripts == 0) {
        if (first >= argc) { fprintf(stderr, "Uso: sed [-nEi] [-e script] script [file...]\n"); return 1; }
        scripts[nscripts++] = argv[first++];
    }

    for (int i = 0; i < nscripts; i++) parse_script(scripts[i]);

    (void)opt_inplace; /* TODO: in-place with file temporary */

    if (first >= argc) {
        process_stream(0, 1);
    } else {
        for (int i = first; i < argc; i++) {
            int fd = open(argv[i], O_RDONLY, 0);
            if (fd < 0) { fprintf(stderr, "sed: %s: %s\n", argv[i], strerror(errno)); continue; }
            process_stream(fd, 1);
            close(fd);
        }
    }
    return 0;
}
