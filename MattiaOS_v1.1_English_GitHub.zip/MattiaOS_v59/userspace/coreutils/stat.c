/*
 * stat.c — mostra informazioni dettagliate up file
 * Flags: -L segui symlink, -f filesystem info
 */
#include "../include/userspace.h"

static int opt_follow = 0, opt_fs = 0;
static int opt_terse = 0;

static void print_file_stat(const char *path) {
    struct stat st;
    int r = opt_follow ? sys_stat(path, &st) : sys_lstat(path, &st);
    if (r < 0) { fprintf(stderr, "stat: %s: %s\n", path, strerror(errno)); return; }

    char perm[11]; format_mode(st.st_mode, perm);
    char sz_h[32]; format_size_human(st.st_size, sz_h, sizeof(sz_h));

    printf("  File: %s", path);
    if (S_ISLNK(st.st_mode)) {
        char target[4096];
        int n = sys_readlink(path, target, sizeof(target)-1);
        if (n >= 0) { target[n] = '\0'; printf(" -> %s", target); }
    }
    printf("\n");
    printf("  Size: %-15lld\tBlocks: %-10lld IO Block: %lld  ",
           (long long)st.st_size,
           (long long)st.st_blocks,
           (long long)st.st_blksize);
    if (S_ISREG(st.st_mode))       printf("regular file\n");
    else if (S_ISDIR(st.st_mode))  printf("directory\n");
    else if (S_ISLNK(st.st_mode))  printf("symbolic link\n");
    else if (S_ISBLK(st.st_mode))  printf("block special file\n");
    else if (S_ISCHR(st.st_mode))  printf("character special file\n");
    else if (S_ISFIFO(st.st_mode)) printf("fifo\n");
    else if (S_ISSOCK(st.st_mode)) printf("socket\n");
    else printf("unknown\n");

    printf("Device: %llxh/%lldd\tInode: %-15llu  Links: %llu\n",
           (unsigned long long)st.st_dev,
           (unsigned long long)st.st_dev,
           (unsigned long long)st.st_ino,
           (unsigned long long)st.st_nlink);
    printf("Access: (%04o/%s)  Uid: (%5u)   Gid: (%5u)\n",
           st.st_mode & 0777, perm, st.st_uid, st.st_gid);
    printf("Access: %lld\n", (long long)st.st_atime);
    printf("Modify: %lld\n", (long long)st.st_mtime);
    printf("Change: %lld\n", (long long)st.st_ctime);
}

static void print_fs_stat(const char *path) {
    struct statfs sf;
    if (sys_statfs(path, &sf) < 0) {
        fprintf(stderr, "stat: %s: %s\n", path, strerror(errno)); return;
    }
    printf("  File: \"%s\"\n", path);
    printf("    ID: %llx Namelen: %lld  Type: %lld\n",
           (unsigned long long)sf.f_fsid,
           (long long)sf.f_namelen,
           (long long)sf.f_type);
    printf("Block size: %lld  Total: %lld  Free: %lld  Avail: %lld\n",
           (long long)sf.f_bsize,
           (long long)sf.f_blocks,
           (long long)sf.f_bfree,
           (long long)sf.f_bavail);
    printf("Inodes:  Total: %lld  Free: %lld\n",
           (long long)sf.f_files,
           (long long)sf.f_ffree);
}

int main(int argc, char **argv) {
    int first = 1;
    for (int i = 1; i < argc; i++) {
        if (strcmp(argv[i], "-L") == 0) { opt_follow = 1; first = i+1; }
        else if (strcmp(argv[i], "-f") == 0) { opt_fs = 1; first = i+1; }
        else if (strcmp(argv[i], "--terse") == 0 || strcmp(argv[i], "-t") == 0)
            { opt_terse = 1; first = i+1; }
    }
    if (first >= argc) { fprintf(stderr, "Uso: stat [-Lf] file...\n"); return 1; }
    for (int i = first; i < argc; i++) {
        if (opt_fs) print_fs_stat(argv[i]);
        else print_file_stat(argv[i]);
    }
    return 0;
}
