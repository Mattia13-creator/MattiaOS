/*
 * uname.c — informazioni sul system
 * Flags: -to all, -s sysname, -n nodename, -r release, -v version, -m machine
 */
#include "../include/userspace.h"

int main(int argc, char **argv) {
    struct utsname u;
    if (sys_uname(&u) < 0) { perror("uname"); return 1; }

    int opt_all = 0, opt_s = 0, opt_n = 0, opt_r = 0, opt_v = 0, opt_m = 0;

    if (argc == 1) { opt_s = 1; }
    for (int i = 1; i < argc; i++) {
        if (argv[i][0] == '-') {
            for (int j = 1; argv[i][j]; j++) {
                switch(argv[i][j]) {
                case 'a': opt_all = 1; break;
                case 's': opt_s   = 1; break;
                case 'n': opt_n   = 1; break;
                case 'r': opt_r   = 1; break;
                case 'v': opt_v   = 1; break;
                case 'm': opt_m   = 1; break;
                }
            }
        }
    }

    int printed = 0;
#define PRINT_FIELD(flag, val) \
    if (opt_all || flag) { if (printed++) printf(" "); printf("%s", val); }

    PRINT_FIELD(opt_s, u.sysname);
    PRINT_FIELD(opt_n, u.nodename);
    PRINT_FIELD(opt_r, u.release);
    PRINT_FIELD(opt_v, u.version);
    PRINT_FIELD(opt_m, u.machine);
    printf("\n");
    return 0;
}
