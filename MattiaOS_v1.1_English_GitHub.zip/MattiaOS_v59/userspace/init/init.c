/*
 * init.c — PID 1 of MattiaOS
 *
 * Responsabilità:
 *  1. Mountre devfs /dev, tmpfs /tmp, procfs /proc
 *  2. Creare the device node fondamentali (/dev/null, /dev/tty, ...)
 *  3. Setre the variabili d'ambiente of system
 *  4. Lanciare /bin/sh up /dev/tty0 (TTY principale)
 *  5. Adottare the processes orfani
 *  6. Raccogliere the processes zombie via SIGCHLD / waitpid loop
 */

#include "../include/userspace.h"

/* =========================================================================
 * Costanti
 * ========================================================================= */
#define SHELL_PATH  "/bin/sh"
#define CONSOLE_DEV "/dev/tty0"
#define DEVFS_TYPE  "devfs"
#define TMPFS_TYPE  "tmpfs"
#define PROCFS_TYPE "procfs"
#define INIT_TTY    CONSOLE_DEV

/* =========================================================================
 * Variabili d'ambiente of default
 * ========================================================================= */
static char *s_default_env[] = {
    "PATH=/bin:/usr/bin:/sbin:/usr/sbin",
    "HOME=/root",
    "SHELL=" SHELL_PATH,
    "TERM=vt100",
    "LOGNAME=root",
    "USER=root",
    "HOSTNAME=mattiaos",
    "LANG=C",
    (char *)0
};

/* =========================================================================
 * shell_argv for execve
 * ========================================================================= */
static char *s_shell_argv[] = {
    SHELL_PATH,
    (char *)0
};

/* =========================================================================
 * SIGCHLD handler — raccoglie zombie without bloccare
 * ========================================================================= */
static volatile int s_sigchld_received = 0;

static void sigchld_handler(int sig) {
    (void)sig;
    s_sigchld_received = 1;
}

static void reap_zombies(void) {
    int status;
    int pid;
    while ((pid = sys_wait4(-1, &status, WNOHANG)) > 0) {
        if (WIFEXITED(status)) {
            printf("[init] PID %d esited with queues %d\n",
                   pid, WEXITSTATUS(status));
        } else if (WIFSIGNALED(status)) {
            printf("[init] PID %d killed by signal %d\n",
                   pid, WTERMSIG(status));
        }
    }
}

/* =========================================================================
 * mount_fs — mount to filesystem, print error if fallisce
 * ========================================================================= */
static int mount_fs(const char *src, const char *target,
                    const char *type, unsigned long flags) {
    if (sys_mount(src, target, type, flags, (void *)0) < 0) {
        fprintf(stderr, "[init] mount %s su %s fallito: %s\n",
                type, target, strerror(errno));
        return -1;
    }
    printf("[init] mountto %s su %s\n", type, target);
    return 0;
}

/* =========================================================================
 * make_dir — crea directory if NOT esiste
 * ========================================================================= */
static void make_dir(const char *path) {
    struct stat st;
    if (sys_stat(path, &st) < 0) {
        if (mkdir(path, 0755) < 0)
            fprintf(stderr, "[init] mkdir %s: %s\n", path, strerror(errno));
    }
}

/* =========================================================================
 * open_console — opens /dev/tty0 as stdin/stdout/stderr (fd 0,1,2)
 * ========================================================================= */
static void open_console(void) {
    /* Chiudi eventuali fd aperti from the kernel */
    close(0); close(1); close(2);

    int fd = open(CONSOLE_DEV, O_RDWR, 0);
    if (fd < 0) {
        /* Fallback up /dev/tty */
        fd = open("/dev/tty", O_RDWR, 0);
        if (fd < 0) {
            /* Ultimo tentativo: crea to fd up /dev/null */
            fd = open("/dev/null", O_RDWR, 0);
        }
    }
    if (fd < 0) return; /* Non c'è nulla from fare */

    if (fd != 0) { sys_dup2(fd, 0); close(fd); }
    sys_dup2(0, 1);
    sys_dup2(0, 2);
}

/* =========================================================================
 * setup_environment — writes the variabili d'ambiente nel file /etc/environment
 * ========================================================================= */
static void setup_environment(void) {
    make_dir("/etc");
    FILE *f = fopen("/etc/environment", "w");
    if (!f) return;
    for (int i = 0; s_default_env[i]; i++)
        fprintf(f, "%s\n", s_default_env[i]);
    fclose(f);
}

/* =========================================================================
 * write_file — writes contenuto in to file (crea if NOT esiste)
 * ========================================================================= */
static void write_file(const char *path, const char *content) {
    int fd = open(path, O_WRONLY | O_CREAT | O_TRUNC, 0644);
    if (fd < 0) return;
    write(fd, content, strlen(content));
    close(fd);
}

/* =========================================================================
 * setup_rootfs — crea the gerarchia /etc, /var, /tmp, ...
 * ========================================================================= */
static void setup_rootfs(void) {
    /* Directory of base */
    make_dir("/bin");
    make_dir("/sbin");
    make_dir("/usr");
    make_dir("/usr/bin");
    make_dir("/usr/sbin");
    make_dir("/etc");
    make_dir("/var");
    make_dir("/var/log");
    make_dir("/var/run");
    make_dir("/root");
    make_dir("/home");
    make_dir("/proc");
    make_dir("/dev");
    make_dir("/tmp");
    make_dir("/mnt");
    make_dir("/lib");
    make_dir("/sys");

    /* File of configuration minimi */
    write_file("/etc/hostname", "mattiaos\n");
    write_file("/etc/os-release",
               "NAME=\"MattiaOS\"\n"
               "VERSION=\"2.8\"\n"
               "ID=mattiaos\n"
               "PRETTY_NAME=\"MattiaOS 2.8\"\n");
    write_file("/etc/fstab",
               "# <device>  <mountpoint>  <type>    <options>  <dump>  <pass>\n"
               "devfs       /dev          devfs     defaults   0       0\n"
               "tmpfs       /tmp          tmpfs     defaults   0       0\n"
               "procfs      /proc         procfs    defaults   0       0\n");

    setup_environment();
}

/* =========================================================================
 * spawn_shell — fork + execve /bin/sh
 * ========================================================================= */
static int spawn_shell(void) {
    int pid = fork();
    if (pid < 0) {
        fprintf(stderr, "[init] fork fallito: %s\n", strerror(errno));
        return -1;
    }
    if (pid == 0) {
        /* Figlio: diventa session leader */
        sys_setsid();
        sys_setpgid(0, 0);

        /* Riapri the console */
        open_console();

        /* Enable the controllo of the terminale */
        sys_ioctl(0, TIOCSPGRP, &(int){getpid()});

        printf("\n"
               " __  __       _   _   _       ___  ____  \n"
               "|  \\/  | __ _| |_| |_(_) __ _/ _ \\/ ___| \n"
               "| |\\/| |/ _` | __| __| |/ _` | | | \\___ \\ \n"
               "| |  | | (_| | |_| |_| | (_| | |_| |___) |\n"
               "|_|  |_|\\__,_|\\__|\\__|_|\\__,_|\\___/|____/ \n"
               "\n"
               "MattiaOS v2.8 — Operating system custom\n"
               "Digita 'help' per la lista dei comandi.\n\n");

        execve(SHELL_PATH, s_shell_argv, s_default_env);
        /* execve NOT è tornato */
        fprintf(stderr, "[init] execve %s: %s\n", SHELL_PATH, strerror(errno));
        exit(1);
    }
    printf("[init] startta shell PID %d\n", pid);
    return pid;
}

/* =========================================================================
 * main — PID 1
 * ========================================================================= */
int main(int argc, char **argv, char **envp) {
    (void)argc; (void)argv; (void)envp;

    printf("[init] MattiaOS init startto (PID %d)\n", getpid());

    /* Mount the filesystem of system */
    mount_fs("devfs",  "/dev",  DEVFS_TYPE,  0);
    mount_fs("tmpfs",  "/tmp",  TMPFS_TYPE,  0);
    mount_fs("procfs", "/proc", PROCFS_TYPE, 0);

    /* Build the gerarchia of the directory */
    setup_rootfs();

    /* Apri the console */
    open_console();

    /* Installa handler SIGCHLD for raccogliere zombie */
    signal(SIGCHLD, sigchld_handler);
    signal(SIGINT,  SIG_IGN);
    signal(SIGQUIT, SIG_IGN);
    signal(SIGHUP,  SIG_IGN);
    signal(SIGTERM, SIG_IGN);  /* init NOT is terminato */

    /* Start the shell */
    int shell_pid = spawn_shell();

    /* Loop principale: raccoglie zombie AND ristart the shell if termina */
    for (;;) {
        /* Aspetta qualsiasi evento child */
        int status;
        int dead_pid = sys_wait4(-1, &status, 0);

        if (dead_pid < 0) {
            /* No child — dormi AND riprova */
            sleep(1);
            continue;
        }

        if (WIFEXITED(status) || WIFSIGNALED(status)) {
            if (dead_pid == shell_pid) {
                /* La shell principale è morta: ristart after 1 second */
                printf("[init] shell (PID %d) terminata. Reboot...\n", dead_pid);
                sleep(1);
                shell_pid = spawn_shell();
            }
        }

        /* Raccoglie altri eventuali zombie rimasti */
        reap_zombies();
    }

    /* Non si arriva mai qui */
    return 0;
}
