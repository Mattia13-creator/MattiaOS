BITS 16
ORG 0x7C00

    jmp short _start
    nop
    times 8 - ($ - $$) db 0
bi_PVD:      dd 0
bi_boot_LBA: dd 0
bi_boot_len: dd 0
bi_checksum: dd 0
             times 40 db 0
    times 90 - ($ - $$) db 0

_start:
    cli
    cld
    xor ax, ax
    mov ds, ax
    mov es, ax
    mov ss, ax
    mov sp, 0x7BFE
    sti
    mov [drv], dl

    ; INT 13h extensions check
    mov ah, 0x41
    mov bx, 0x55AA
    int 0x13
    jnc .ok
.halt: hlt
    jmp .halt
.ok:
    ; A20 line enable (fast gate)
    in  al, 0x92
    or  al, 2
    and al, 0xFE        ; do not trigger reset
    out 0x92, al

    ; E820: save count at 0x5FFC, buffer from 0x6000
    xor ebx, ebx
    mov di, 0x6000
    mov dword [0x5FFC], 0
.e820:
    mov eax, 0xE820
    mov edx, 0x534D4150
    mov ecx, 20
    int 0x15
    jc .e820done
    cmp eax, 0x534D4150
    jne .e820done
    add di, 20
    inc dword [0x5FFC]
    cmp dword [0x5FFC], 32
    je .e820done
    test ebx, ebx
    jnz .e820
.e820done:

    ; Load stage2 (28 CD sectors) from (bi_boot_LBA+1) to 0x8000
    mov eax, dword [bi_boot_LBA]
    inc eax
    mov dword [dap+8], eax
    mov word  [dap+2], 28
    mov word  [dap+4], 0x8000
    mov word  [dap+6], 0x0000
    lea si, [dap]
    mov ah, 0x42
    mov dl, [drv]
    int 0x13
    jc .halt

    ; Load kernel ELF (600 sectors = 1.2MB) from (bi_boot_LBA+29) upward
    ; We use INT 15h AX=0x87 (Extended Memory Copy) to load above 1MB
    ; Alternative: load in chunks < 1MB and copy up

    ; Plan: load to 0x20000 (128KB low mem) in 128KB blocks,
    ; then copy high via INT15/AX=0x87
    ; This is complex. Simpler alternative:
    ; pass to stage2 in real mode, stage2 handles loading

    mov dl, [drv]
    ; Pass kernel LBA to stage2 via 0x7DF0
    mov eax, dword [bi_boot_LBA]
    add eax, 29
    mov dword [0x7DF0], eax     ; kernel_start_LBA for stage2

    jmp 0x0000:0x8000           ; jump to stage2 (still in real mode)

drv: db 0
dap: db 16, 0
     dw 1, 0, 0
     dd 0, 0

; Boot signature at offset 510 — required by SeaBIOS for El Torito no-emulation
times 510 - ($ - $$) db 0
dw 0xAA55
; Padding to 2048 bytes (1 CD sector)
times 2048 - ($ - $$) db 0
